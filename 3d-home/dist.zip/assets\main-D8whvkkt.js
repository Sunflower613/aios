import{siteConfig as $n}from"./site-config-CqbHk6xq.js";import{_ as Zc}from"./preload-helper-BZTpFI01.js";/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const ia="160",Kc=0,va=1,Jc=2,sa=1,ic=2,dn=3,An=0,Fe=1,he=2,bn=0,vi=1,Ns=2,_a=3,Ma=4,Qc=5,On=100,tl=101,el=102,Sa=103,ba=104,nl=200,il=201,sl=202,ol=203,Vo=204,Wo=205,al=206,rl=207,cl=208,ll=209,hl=210,dl=211,ul=212,fl=213,pl=214,ml=0,gl=1,yl=2,Bs=3,wl=4,xl=5,vl=6,_l=7,oa=0,Ml=1,Sl=2,En=0,sc=1,bl=2,El=3,Tl=4,Al=5,Cl=6,oc=300,Mi=301,Si=302,Xo=303,qo=304,qs=306,Yo=1e3,Je=1001,$o=1002,Ue=1003,Ea=1004,so=1005,Xe=1006,Rl=1007,Vi=1008,Tn=1009,Pl=1010,Ll=1011,aa=1012,ac=1013,_n=1014,Mn=1015,Wi=1016,rc=1017,cc=1018,kn=1020,Il=1021,Qe=1023,Dl=1024,Ul=1025,Gn=1026,bi=1027,Nl=1028,lc=1029,Bl=1030,hc=1031,dc=1033,oo=33776,ao=33777,ro=33778,co=33779,Ta=35840,Aa=35841,Ca=35842,Ra=35843,uc=36196,Pa=37492,La=37496,Ia=37808,Da=37809,Ua=37810,Na=37811,Ba=37812,Fa=37813,Oa=37814,za=37815,ka=37816,Ga=37817,Ha=37818,Va=37819,Wa=37820,Xa=37821,lo=36492,qa=36494,Ya=36495,Fl=36283,$a=36284,ja=36285,Za=36286,fc=3e3,Hn=3001,Ol=3200,zl=3201,pc=0,kl=1,Ye="",Te="srgb",mn="srgb-linear",ra="display-p3",Ys="display-p3-linear",Fs="linear",le="srgb",Os="rec709",zs="p3",jn=7680,Ka=519,Gl=512,Hl=513,Vl=514,mc=515,Wl=516,Xl=517,ql=518,Yl=519,jo=35044,Ja="300 es",Zo=1035,fn=2e3,ks=2001;class Ti{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;const n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;const i=this._listeners[t];if(i!==void 0){const s=i.indexOf(e);s!==-1&&i.splice(s,1)}}dispatchEvent(t){if(this._listeners===void 0)return;const n=this._listeners[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let s=0,a=i.length;s<a;s++)i[s].call(this,t);t.target=null}}}const Re=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],ho=Math.PI/180,Gs=180/Math.PI;function pn(){const o=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Re[o&255]+Re[o>>8&255]+Re[o>>16&255]+Re[o>>24&255]+"-"+Re[t&255]+Re[t>>8&255]+"-"+Re[t>>16&15|64]+Re[t>>24&255]+"-"+Re[e&63|128]+Re[e>>8&255]+"-"+Re[e>>16&255]+Re[e>>24&255]+Re[n&255]+Re[n>>8&255]+Re[n>>16&255]+Re[n>>24&255]).toLowerCase()}function Le(o,t,e){return Math.max(t,Math.min(e,o))}function $l(o,t){return(o%t+t)%t}function uo(o,t,e){return(1-e)*o+e*t}function Qa(o){return(o&o-1)===0&&o!==0}function Ko(o){return Math.pow(2,Math.floor(Math.log(o)/Math.LN2))}function un(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function ae(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}class ut{constructor(t=0,e=0){ut.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Le(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),s=this.x-t.x,a=this.y-t.y;return this.x=s*n-a*i+t.x,this.y=s*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Zt{constructor(t,e,n,i,s,a,r,c,l){Zt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,r,c,l)}set(t,e,n,i,s,a,r,c,l){const h=this.elements;return h[0]=t,h[1]=i,h[2]=r,h[3]=e,h[4]=s,h[5]=c,h[6]=n,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],r=n[3],c=n[6],l=n[1],h=n[4],d=n[7],u=n[2],f=n[5],g=n[8],y=i[0],m=i[3],p=i[6],_=i[1],w=i[4],v=i[7],R=i[2],T=i[5],E=i[8];return s[0]=a*y+r*_+c*R,s[3]=a*m+r*w+c*T,s[6]=a*p+r*v+c*E,s[1]=l*y+h*_+d*R,s[4]=l*m+h*w+d*T,s[7]=l*p+h*v+d*E,s[2]=u*y+f*_+g*R,s[5]=u*m+f*w+g*T,s[8]=u*p+f*v+g*E,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8];return e*a*h-e*r*l-n*s*h+n*r*c+i*s*l-i*a*c}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8],d=h*a-r*l,u=r*c-h*s,f=l*s-a*c,g=e*d+n*u+i*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const y=1/g;return t[0]=d*y,t[1]=(i*l-h*n)*y,t[2]=(r*n-i*a)*y,t[3]=u*y,t[4]=(h*e-i*c)*y,t[5]=(i*s-r*e)*y,t[6]=f*y,t[7]=(n*c-l*e)*y,t[8]=(a*e-n*s)*y,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,s,a,r){const c=Math.cos(s),l=Math.sin(s);return this.set(n*c,n*l,-n*(c*a+l*r)+a+t,-i*l,i*c,-i*(-l*a+c*r)+r+e,0,0,1),this}scale(t,e){return this.premultiply(fo.makeScale(t,e)),this}rotate(t){return this.premultiply(fo.makeRotation(-t)),this}translate(t,e){return this.premultiply(fo.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const fo=new Zt;function gc(o){for(let t=o.length-1;t>=0;--t)if(o[t]>=65535)return!0;return!1}function Hs(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function jl(){const o=Hs("canvas");return o.style.display="block",o}const tr={};function Oi(o){o in tr||(tr[o]=!0,console.warn(o))}const er=new Zt().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),nr=new Zt().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),is={[mn]:{transfer:Fs,primaries:Os,toReference:o=>o,fromReference:o=>o},[Te]:{transfer:le,primaries:Os,toReference:o=>o.convertSRGBToLinear(),fromReference:o=>o.convertLinearToSRGB()},[Ys]:{transfer:Fs,primaries:zs,toReference:o=>o.applyMatrix3(nr),fromReference:o=>o.applyMatrix3(er)},[ra]:{transfer:le,primaries:zs,toReference:o=>o.convertSRGBToLinear().applyMatrix3(nr),fromReference:o=>o.applyMatrix3(er).convertLinearToSRGB()}},Zl=new Set([mn,Ys]),oe={enabled:!0,_workingColorSpace:mn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(o){if(!Zl.has(o))throw new Error(`Unsupported working color space, "${o}".`);this._workingColorSpace=o},convert:function(o,t,e){if(this.enabled===!1||t===e||!t||!e)return o;const n=is[t].toReference,i=is[e].fromReference;return i(n(o))},fromWorkingColorSpace:function(o,t){return this.convert(o,this._workingColorSpace,t)},toWorkingColorSpace:function(o,t){return this.convert(o,t,this._workingColorSpace)},getPrimaries:function(o){return is[o].primaries},getTransfer:function(o){return o===Ye?Fs:is[o].transfer}};function _i(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function po(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Zn;class yc{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Zn===void 0&&(Zn=Hs("canvas")),Zn.width=t.width,Zn.height=t.height;const n=Zn.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Zn}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Hs("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),s=i.data;for(let a=0;a<s.length;a++)s[a]=_i(s[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(_i(e[n]/255)*255):e[n]=_i(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Kl=0;class wc{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Kl++}),this.uuid=pn(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let a=0,r=i.length;a<r;a++)i[a].isDataTexture?s.push(mo(i[a].image)):s.push(mo(i[a]))}else s=mo(i);n.url=s}return e||(t.images[this.uuid]=n),n}}function mo(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?yc.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Jl=0;class Oe extends Ti{constructor(t=Oe.DEFAULT_IMAGE,e=Oe.DEFAULT_MAPPING,n=Je,i=Je,s=Xe,a=Vi,r=Qe,c=Tn,l=Oe.DEFAULT_ANISOTROPY,h=Ye){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Jl++}),this.uuid=pn(),this.name="",this.source=new wc(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=a,this.anisotropy=l,this.format=r,this.internalFormat=null,this.type=c,this.offset=new ut(0,0),this.repeat=new ut(1,1),this.center=new ut(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Zt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(Oi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===Hn?Te:Ye),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==oc)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Yo:t.x=t.x-Math.floor(t.x);break;case Je:t.x=t.x<0?0:1;break;case $o:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Yo:t.y=t.y-Math.floor(t.y);break;case Je:t.y=t.y<0?0:1;break;case $o:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Oi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Te?Hn:fc}set encoding(t){Oi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===Hn?Te:Ye}}Oe.DEFAULT_IMAGE=null;Oe.DEFAULT_MAPPING=oc;Oe.DEFAULT_ANISOTROPY=1;class ue{constructor(t=0,e=0,n=0,i=1){ue.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*s,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*s,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*s,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*s,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,s;const c=t.elements,l=c[0],h=c[4],d=c[8],u=c[1],f=c[5],g=c[9],y=c[2],m=c[6],p=c[10];if(Math.abs(h-u)<.01&&Math.abs(d-y)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+y)<.1&&Math.abs(g+m)<.1&&Math.abs(l+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const w=(l+1)/2,v=(f+1)/2,R=(p+1)/2,T=(h+u)/4,E=(d+y)/4,U=(g+m)/4;return w>v&&w>R?w<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(w),i=T/n,s=E/n):v>R?v<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(v),n=T/i,s=U/i):R<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(R),n=E/s,i=U/s),this.set(n,i,s,e),this}let _=Math.sqrt((m-g)*(m-g)+(d-y)*(d-y)+(u-h)*(u-h));return Math.abs(_)<.001&&(_=1),this.x=(m-g)/_,this.y=(d-y)/_,this.z=(u-h)/_,this.w=Math.acos((l+f+p-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Ql extends Ti{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new ue(0,0,t,e),this.scissorTest=!1,this.viewport=new ue(0,0,t,e);const i={width:t,height:e,depth:1};n.encoding!==void 0&&(Oi("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===Hn?Te:Ye),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Xe,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new Oe(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;const e=Object.assign({},t.texture.image);return this.texture.source=new wc(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Vn extends Ql{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class xc extends Oe{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ue,this.minFilter=Ue,this.wrapR=Je,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class th extends Oe{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ue,this.minFilter=Ue,this.wrapR=Je,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Zi{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,s,a,r){let c=n[i+0],l=n[i+1],h=n[i+2],d=n[i+3];const u=s[a+0],f=s[a+1],g=s[a+2],y=s[a+3];if(r===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d;return}if(r===1){t[e+0]=u,t[e+1]=f,t[e+2]=g,t[e+3]=y;return}if(d!==y||c!==u||l!==f||h!==g){let m=1-r;const p=c*u+l*f+h*g+d*y,_=p>=0?1:-1,w=1-p*p;if(w>Number.EPSILON){const R=Math.sqrt(w),T=Math.atan2(R,p*_);m=Math.sin(m*T)/R,r=Math.sin(r*T)/R}const v=r*_;if(c=c*m+u*v,l=l*m+f*v,h=h*m+g*v,d=d*m+y*v,m===1-r){const R=1/Math.sqrt(c*c+l*l+h*h+d*d);c*=R,l*=R,h*=R,d*=R}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d}static multiplyQuaternionsFlat(t,e,n,i,s,a){const r=n[i],c=n[i+1],l=n[i+2],h=n[i+3],d=s[a],u=s[a+1],f=s[a+2],g=s[a+3];return t[e]=r*g+h*d+c*f-l*u,t[e+1]=c*g+h*u+l*d-r*f,t[e+2]=l*g+h*f+r*u-c*d,t[e+3]=h*g-r*d-c*u-l*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,s=t._z,a=t._order,r=Math.cos,c=Math.sin,l=r(n/2),h=r(i/2),d=r(s/2),u=c(n/2),f=c(i/2),g=c(s/2);switch(a){case"XYZ":this._x=u*h*d+l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d-u*f*g;break;case"YXZ":this._x=u*h*d+l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d+u*f*g;break;case"ZXY":this._x=u*h*d-l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d-u*f*g;break;case"ZYX":this._x=u*h*d-l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d+u*f*g;break;case"YZX":this._x=u*h*d+l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d-u*f*g;break;case"XZY":this._x=u*h*d-l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d+u*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],s=e[8],a=e[1],r=e[5],c=e[9],l=e[2],h=e[6],d=e[10],u=n+r+d;if(u>0){const f=.5/Math.sqrt(u+1);this._w=.25/f,this._x=(h-c)*f,this._y=(s-l)*f,this._z=(a-i)*f}else if(n>r&&n>d){const f=2*Math.sqrt(1+n-r-d);this._w=(h-c)/f,this._x=.25*f,this._y=(i+a)/f,this._z=(s+l)/f}else if(r>d){const f=2*Math.sqrt(1+r-n-d);this._w=(s-l)/f,this._x=(i+a)/f,this._y=.25*f,this._z=(c+h)/f}else{const f=2*Math.sqrt(1+d-n-r);this._w=(a-i)/f,this._x=(s+l)/f,this._y=(c+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Le(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,s=t._z,a=t._w,r=e._x,c=e._y,l=e._z,h=e._w;return this._x=n*h+a*r+i*l-s*c,this._y=i*h+a*c+s*r-n*l,this._z=s*h+a*l+n*c-i*r,this._w=a*h-n*r-i*c-s*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,i=this._y,s=this._z,a=this._w;let r=a*t._w+n*t._x+i*t._y+s*t._z;if(r<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,r=-r):this.copy(t),r>=1)return this._w=a,this._x=n,this._y=i,this._z=s,this;const c=1-r*r;if(c<=Number.EPSILON){const f=1-e;return this._w=f*a+e*this._w,this._x=f*n+e*this._x,this._y=f*i+e*this._y,this._z=f*s+e*this._z,this.normalize(),this}const l=Math.sqrt(c),h=Math.atan2(l,r),d=Math.sin((1-e)*h)/l,u=Math.sin(e*h)/l;return this._w=a*d+this._w*u,this._x=n*d+this._x*u,this._y=i*d+this._y*u,this._z=s*d+this._z*u,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),i=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(e*Math.cos(i),n*Math.sin(s),n*Math.cos(s),e*Math.sin(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class P{constructor(t=0,e=0,n=0){P.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(ir.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(ir.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6]*i,this.y=s[1]*e+s[4]*n+s[7]*i,this.z=s[2]*e+s[5]*n+s[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=t.elements,a=1/(s[3]*e+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*e+s[4]*n+s[8]*i+s[12])*a,this.y=(s[1]*e+s[5]*n+s[9]*i+s[13])*a,this.z=(s[2]*e+s[6]*n+s[10]*i+s[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,s=t.x,a=t.y,r=t.z,c=t.w,l=2*(a*i-r*n),h=2*(r*e-s*i),d=2*(s*n-a*e);return this.x=e+c*l+a*d-r*h,this.y=n+c*h+r*l-s*d,this.z=i+c*d+s*h-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[4]*n+s[8]*i,this.y=s[1]*e+s[5]*n+s[9]*i,this.z=s[2]*e+s[6]*n+s[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,s=t.z,a=e.x,r=e.y,c=e.z;return this.x=i*c-s*r,this.y=s*a-n*c,this.z=n*r-i*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return go.copy(this).projectOnVector(t),this.sub(go)}reflect(t){return this.sub(go.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Le(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const go=new P,ir=new Zi;class Ki{constructor(t=new P(1/0,1/0,1/0),e=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(je.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(je.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=je.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const s=n.getAttribute("position");if(e===!0&&s!==void 0&&t.isInstancedMesh!==!0)for(let a=0,r=s.count;a<r;a++)t.isMesh===!0?t.getVertexPosition(a,je):je.fromBufferAttribute(s,a),je.applyMatrix4(t.matrixWorld),this.expandByPoint(je);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),ss.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ss.copy(n.boundingBox)),ss.applyMatrix4(t.matrixWorld),this.union(ss)}const i=t.children;for(let s=0,a=i.length;s<a;s++)this.expandByObject(i[s],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,je),je.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Pi),os.subVectors(this.max,Pi),Kn.subVectors(t.a,Pi),Jn.subVectors(t.b,Pi),Qn.subVectors(t.c,Pi),gn.subVectors(Jn,Kn),yn.subVectors(Qn,Jn),In.subVectors(Kn,Qn);let e=[0,-gn.z,gn.y,0,-yn.z,yn.y,0,-In.z,In.y,gn.z,0,-gn.x,yn.z,0,-yn.x,In.z,0,-In.x,-gn.y,gn.x,0,-yn.y,yn.x,0,-In.y,In.x,0];return!yo(e,Kn,Jn,Qn,os)||(e=[1,0,0,0,1,0,0,0,1],!yo(e,Kn,Jn,Qn,os))?!1:(as.crossVectors(gn,yn),e=[as.x,as.y,as.z],yo(e,Kn,Jn,Qn,os))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,je).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(je).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(an[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),an[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),an[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),an[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),an[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),an[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),an[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),an[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(an),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}}const an=[new P,new P,new P,new P,new P,new P,new P,new P],je=new P,ss=new Ki,Kn=new P,Jn=new P,Qn=new P,gn=new P,yn=new P,In=new P,Pi=new P,os=new P,as=new P,Dn=new P;function yo(o,t,e,n,i){for(let s=0,a=o.length-3;s<=a;s+=3){Dn.fromArray(o,s);const r=i.x*Math.abs(Dn.x)+i.y*Math.abs(Dn.y)+i.z*Math.abs(Dn.z),c=t.dot(Dn),l=e.dot(Dn),h=n.dot(Dn);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>r)return!1}return!0}const eh=new Ki,Li=new P,wo=new P;class Ji{constructor(t=new P,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):eh.setFromPoints(t).getCenter(n);let i=0;for(let s=0,a=t.length;s<a;s++)i=Math.max(i,n.distanceToSquared(t[s]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Li.subVectors(t,this.center);const e=Li.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(Li,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(wo.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Li.copy(t.center).add(wo)),this.expandByPoint(Li.copy(t.center).sub(wo))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}}const rn=new P,xo=new P,rs=new P,wn=new P,vo=new P,cs=new P,_o=new P;class $s{constructor(t=new P,e=new P(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,rn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=rn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(rn.copy(this.origin).addScaledVector(this.direction,e),rn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){xo.copy(t).add(e).multiplyScalar(.5),rs.copy(e).sub(t).normalize(),wn.copy(this.origin).sub(xo);const s=t.distanceTo(e)*.5,a=-this.direction.dot(rs),r=wn.dot(this.direction),c=-wn.dot(rs),l=wn.lengthSq(),h=Math.abs(1-a*a);let d,u,f,g;if(h>0)if(d=a*c-r,u=a*r-c,g=s*h,d>=0)if(u>=-g)if(u<=g){const y=1/h;d*=y,u*=y,f=d*(d+a*u+2*r)+u*(a*d+u+2*c)+l}else u=s,d=Math.max(0,-(a*u+r)),f=-d*d+u*(u+2*c)+l;else u=-s,d=Math.max(0,-(a*u+r)),f=-d*d+u*(u+2*c)+l;else u<=-g?(d=Math.max(0,-(-a*s+r)),u=d>0?-s:Math.min(Math.max(-s,-c),s),f=-d*d+u*(u+2*c)+l):u<=g?(d=0,u=Math.min(Math.max(-s,-c),s),f=u*(u+2*c)+l):(d=Math.max(0,-(a*s+r)),u=d>0?s:Math.min(Math.max(-s,-c),s),f=-d*d+u*(u+2*c)+l);else u=a>0?-s:s,d=Math.max(0,-(a*u+r)),f=-d*d+u*(u+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,d),i&&i.copy(xo).addScaledVector(rs,u),f}intersectSphere(t,e){rn.subVectors(t.center,this.origin);const n=rn.dot(this.direction),i=rn.dot(rn)-n*n,s=t.radius*t.radius;if(i>s)return null;const a=Math.sqrt(s-i),r=n-a,c=n+a;return c<0?null:r<0?this.at(c,e):this.at(r,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,s,a,r,c;const l=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return l>=0?(n=(t.min.x-u.x)*l,i=(t.max.x-u.x)*l):(n=(t.max.x-u.x)*l,i=(t.min.x-u.x)*l),h>=0?(s=(t.min.y-u.y)*h,a=(t.max.y-u.y)*h):(s=(t.max.y-u.y)*h,a=(t.min.y-u.y)*h),n>a||s>i||((s>n||isNaN(n))&&(n=s),(a<i||isNaN(i))&&(i=a),d>=0?(r=(t.min.z-u.z)*d,c=(t.max.z-u.z)*d):(r=(t.max.z-u.z)*d,c=(t.min.z-u.z)*d),n>c||r>i)||((r>n||n!==n)&&(n=r),(c<i||i!==i)&&(i=c),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,rn)!==null}intersectTriangle(t,e,n,i,s){vo.subVectors(e,t),cs.subVectors(n,t),_o.crossVectors(vo,cs);let a=this.direction.dot(_o),r;if(a>0){if(i)return null;r=1}else if(a<0)r=-1,a=-a;else return null;wn.subVectors(this.origin,t);const c=r*this.direction.dot(cs.crossVectors(wn,cs));if(c<0)return null;const l=r*this.direction.dot(vo.cross(wn));if(l<0||c+l>a)return null;const h=-r*wn.dot(_o);return h<0?null:this.at(h/a,s)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class fe{constructor(t,e,n,i,s,a,r,c,l,h,d,u,f,g,y,m){fe.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,r,c,l,h,d,u,f,g,y,m)}set(t,e,n,i,s,a,r,c,l,h,d,u,f,g,y,m){const p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=i,p[1]=s,p[5]=a,p[9]=r,p[13]=c,p[2]=l,p[6]=h,p[10]=d,p[14]=u,p[3]=f,p[7]=g,p[11]=y,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new fe().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,i=1/ti.setFromMatrixColumn(t,0).length(),s=1/ti.setFromMatrixColumn(t,1).length(),a=1/ti.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*s,e[5]=n[5]*s,e[6]=n[6]*s,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,s=t.z,a=Math.cos(n),r=Math.sin(n),c=Math.cos(i),l=Math.sin(i),h=Math.cos(s),d=Math.sin(s);if(t.order==="XYZ"){const u=a*h,f=a*d,g=r*h,y=r*d;e[0]=c*h,e[4]=-c*d,e[8]=l,e[1]=f+g*l,e[5]=u-y*l,e[9]=-r*c,e[2]=y-u*l,e[6]=g+f*l,e[10]=a*c}else if(t.order==="YXZ"){const u=c*h,f=c*d,g=l*h,y=l*d;e[0]=u+y*r,e[4]=g*r-f,e[8]=a*l,e[1]=a*d,e[5]=a*h,e[9]=-r,e[2]=f*r-g,e[6]=y+u*r,e[10]=a*c}else if(t.order==="ZXY"){const u=c*h,f=c*d,g=l*h,y=l*d;e[0]=u-y*r,e[4]=-a*d,e[8]=g+f*r,e[1]=f+g*r,e[5]=a*h,e[9]=y-u*r,e[2]=-a*l,e[6]=r,e[10]=a*c}else if(t.order==="ZYX"){const u=a*h,f=a*d,g=r*h,y=r*d;e[0]=c*h,e[4]=g*l-f,e[8]=u*l+y,e[1]=c*d,e[5]=y*l+u,e[9]=f*l-g,e[2]=-l,e[6]=r*c,e[10]=a*c}else if(t.order==="YZX"){const u=a*c,f=a*l,g=r*c,y=r*l;e[0]=c*h,e[4]=y-u*d,e[8]=g*d+f,e[1]=d,e[5]=a*h,e[9]=-r*h,e[2]=-l*h,e[6]=f*d+g,e[10]=u-y*d}else if(t.order==="XZY"){const u=a*c,f=a*l,g=r*c,y=r*l;e[0]=c*h,e[4]=-d,e[8]=l*h,e[1]=u*d+y,e[5]=a*h,e[9]=f*d-g,e[2]=g*d-f,e[6]=r*h,e[10]=y*d+u}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(nh,t,ih)}lookAt(t,e,n){const i=this.elements;return Ge.subVectors(t,e),Ge.lengthSq()===0&&(Ge.z=1),Ge.normalize(),xn.crossVectors(n,Ge),xn.lengthSq()===0&&(Math.abs(n.z)===1?Ge.x+=1e-4:Ge.z+=1e-4,Ge.normalize(),xn.crossVectors(n,Ge)),xn.normalize(),ls.crossVectors(Ge,xn),i[0]=xn.x,i[4]=ls.x,i[8]=Ge.x,i[1]=xn.y,i[5]=ls.y,i[9]=Ge.y,i[2]=xn.z,i[6]=ls.z,i[10]=Ge.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],r=n[4],c=n[8],l=n[12],h=n[1],d=n[5],u=n[9],f=n[13],g=n[2],y=n[6],m=n[10],p=n[14],_=n[3],w=n[7],v=n[11],R=n[15],T=i[0],E=i[4],U=i[8],M=i[12],S=i[1],L=i[5],F=i[9],Z=i[13],I=i[2],B=i[6],k=i[10],Y=i[14],$=i[3],q=i[7],Q=i[11],it=i[15];return s[0]=a*T+r*S+c*I+l*$,s[4]=a*E+r*L+c*B+l*q,s[8]=a*U+r*F+c*k+l*Q,s[12]=a*M+r*Z+c*Y+l*it,s[1]=h*T+d*S+u*I+f*$,s[5]=h*E+d*L+u*B+f*q,s[9]=h*U+d*F+u*k+f*Q,s[13]=h*M+d*Z+u*Y+f*it,s[2]=g*T+y*S+m*I+p*$,s[6]=g*E+y*L+m*B+p*q,s[10]=g*U+y*F+m*k+p*Q,s[14]=g*M+y*Z+m*Y+p*it,s[3]=_*T+w*S+v*I+R*$,s[7]=_*E+w*L+v*B+R*q,s[11]=_*U+w*F+v*k+R*Q,s[15]=_*M+w*Z+v*Y+R*it,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],s=t[12],a=t[1],r=t[5],c=t[9],l=t[13],h=t[2],d=t[6],u=t[10],f=t[14],g=t[3],y=t[7],m=t[11],p=t[15];return g*(+s*c*d-i*l*d-s*r*u+n*l*u+i*r*f-n*c*f)+y*(+e*c*f-e*l*u+s*a*u-i*a*f+i*l*h-s*c*h)+m*(+e*l*d-e*r*f-s*a*d+n*a*f+s*r*h-n*l*h)+p*(-i*r*h-e*c*d+e*r*u+i*a*d-n*a*u+n*c*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8],d=t[9],u=t[10],f=t[11],g=t[12],y=t[13],m=t[14],p=t[15],_=d*m*l-y*u*l+y*c*f-r*m*f-d*c*p+r*u*p,w=g*u*l-h*m*l-g*c*f+a*m*f+h*c*p-a*u*p,v=h*y*l-g*d*l+g*r*f-a*y*f-h*r*p+a*d*p,R=g*d*c-h*y*c-g*r*u+a*y*u+h*r*m-a*d*m,T=e*_+n*w+i*v+s*R;if(T===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const E=1/T;return t[0]=_*E,t[1]=(y*u*s-d*m*s-y*i*f+n*m*f+d*i*p-n*u*p)*E,t[2]=(r*m*s-y*c*s+y*i*l-n*m*l-r*i*p+n*c*p)*E,t[3]=(d*c*s-r*u*s-d*i*l+n*u*l+r*i*f-n*c*f)*E,t[4]=w*E,t[5]=(h*m*s-g*u*s+g*i*f-e*m*f-h*i*p+e*u*p)*E,t[6]=(g*c*s-a*m*s-g*i*l+e*m*l+a*i*p-e*c*p)*E,t[7]=(a*u*s-h*c*s+h*i*l-e*u*l-a*i*f+e*c*f)*E,t[8]=v*E,t[9]=(g*d*s-h*y*s-g*n*f+e*y*f+h*n*p-e*d*p)*E,t[10]=(a*y*s-g*r*s+g*n*l-e*y*l-a*n*p+e*r*p)*E,t[11]=(h*r*s-a*d*s-h*n*l+e*d*l+a*n*f-e*r*f)*E,t[12]=R*E,t[13]=(h*y*i-g*d*i+g*n*u-e*y*u-h*n*m+e*d*m)*E,t[14]=(g*r*i-a*y*i-g*n*c+e*y*c+a*n*m-e*r*m)*E,t[15]=(a*d*i-h*r*i+h*n*c-e*d*c-a*n*u+e*r*u)*E,this}scale(t){const e=this.elements,n=t.x,i=t.y,s=t.z;return e[0]*=n,e[4]*=i,e[8]*=s,e[1]*=n,e[5]*=i,e[9]*=s,e[2]*=n,e[6]*=i,e[10]*=s,e[3]*=n,e[7]*=i,e[11]*=s,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),s=1-n,a=t.x,r=t.y,c=t.z,l=s*a,h=s*r;return this.set(l*a+n,l*r-i*c,l*c+i*r,0,l*r+i*c,h*r+n,h*c-i*a,0,l*c-i*r,h*c+i*a,s*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,s,a){return this.set(1,n,s,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,s=e._x,a=e._y,r=e._z,c=e._w,l=s+s,h=a+a,d=r+r,u=s*l,f=s*h,g=s*d,y=a*h,m=a*d,p=r*d,_=c*l,w=c*h,v=c*d,R=n.x,T=n.y,E=n.z;return i[0]=(1-(y+p))*R,i[1]=(f+v)*R,i[2]=(g-w)*R,i[3]=0,i[4]=(f-v)*T,i[5]=(1-(u+p))*T,i[6]=(m+_)*T,i[7]=0,i[8]=(g+w)*E,i[9]=(m-_)*E,i[10]=(1-(u+y))*E,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;let s=ti.set(i[0],i[1],i[2]).length();const a=ti.set(i[4],i[5],i[6]).length(),r=ti.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),t.x=i[12],t.y=i[13],t.z=i[14],Ze.copy(this);const l=1/s,h=1/a,d=1/r;return Ze.elements[0]*=l,Ze.elements[1]*=l,Ze.elements[2]*=l,Ze.elements[4]*=h,Ze.elements[5]*=h,Ze.elements[6]*=h,Ze.elements[8]*=d,Ze.elements[9]*=d,Ze.elements[10]*=d,e.setFromRotationMatrix(Ze),n.x=s,n.y=a,n.z=r,this}makePerspective(t,e,n,i,s,a,r=fn){const c=this.elements,l=2*s/(e-t),h=2*s/(n-i),d=(e+t)/(e-t),u=(n+i)/(n-i);let f,g;if(r===fn)f=-(a+s)/(a-s),g=-2*a*s/(a-s);else if(r===ks)f=-a/(a-s),g=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+r);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=h,c[9]=u,c[13]=0,c[2]=0,c[6]=0,c[10]=f,c[14]=g,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,i,s,a,r=fn){const c=this.elements,l=1/(e-t),h=1/(n-i),d=1/(a-s),u=(e+t)*l,f=(n+i)*h;let g,y;if(r===fn)g=(a+s)*d,y=-2*d;else if(r===ks)g=s*d,y=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+r);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-u,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-f,c[2]=0,c[6]=0,c[10]=y,c[14]=-g,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const ti=new P,Ze=new fe,nh=new P(0,0,0),ih=new P(1,1,1),xn=new P,ls=new P,Ge=new P,sr=new fe,or=new Zi;class js{constructor(t=0,e=0,n=0,i=js.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,s=i[0],a=i[4],r=i[8],c=i[1],l=i[5],h=i[9],d=i[2],u=i[6],f=i[10];switch(e){case"XYZ":this._y=Math.asin(Le(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Le(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(r,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,s),this._z=0);break;case"ZXY":this._x=Math.asin(Le(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,f),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-Le(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,f),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Le(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-d,s)):(this._x=0,this._y=Math.atan2(r,f));break;case"XZY":this._z=Math.asin(-Le(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(r,s)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return sr.makeRotationFromQuaternion(t),this.setFromRotationMatrix(sr,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return or.setFromEuler(this),this.setFromQuaternion(or,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}js.DEFAULT_ORDER="XYZ";class ca{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let sh=0;const ar=new P,ei=new Zi,cn=new fe,hs=new P,Ii=new P,oh=new P,ah=new Zi,rr=new P(1,0,0),cr=new P(0,1,0),lr=new P(0,0,1),rh={type:"added"},ch={type:"removed"};class ye extends Ti{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:sh++}),this.uuid=pn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=ye.DEFAULT_UP.clone();const t=new P,e=new js,n=new Zi,i=new P(1,1,1);function s(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new fe},normalMatrix:{value:new Zt}}),this.matrix=new fe,this.matrixWorld=new fe,this.matrixAutoUpdate=ye.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=ye.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ca,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return ei.setFromAxisAngle(t,e),this.quaternion.multiply(ei),this}rotateOnWorldAxis(t,e){return ei.setFromAxisAngle(t,e),this.quaternion.premultiply(ei),this}rotateX(t){return this.rotateOnAxis(rr,t)}rotateY(t){return this.rotateOnAxis(cr,t)}rotateZ(t){return this.rotateOnAxis(lr,t)}translateOnAxis(t,e){return ar.copy(t).applyQuaternion(this.quaternion),this.position.add(ar.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(rr,t)}translateY(t){return this.translateOnAxis(cr,t)}translateZ(t){return this.translateOnAxis(lr,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(cn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?hs.copy(t):hs.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),Ii.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?cn.lookAt(Ii,hs,this.up):cn.lookAt(hs,Ii,this.up),this.quaternion.setFromRotationMatrix(cn),i&&(cn.extractRotation(i.matrixWorld),ei.setFromRotationMatrix(cn),this.quaternion.premultiply(ei.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(rh)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(ch)),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),cn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),cn.multiply(t.parent.matrixWorld)),t.applyMatrix4(cn),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let s=0,a=i.length;s<a;s++)i[s].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ii,t,oh),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ii,ah,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++){const s=e[n];(s.matrixWorldAutoUpdate===!0||t===!0)&&s.updateMatrixWorld(t)}}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){const i=this.children;for(let s=0,a=i.length;s<a;s++){const r=i[s];r.matrixWorldAutoUpdate===!0&&r.updateWorldMatrix(!1,!0)}}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(r=>({boxInitialized:r.boxInitialized,boxMin:r.box.min.toArray(),boxMax:r.box.max.toArray(),sphereInitialized:r.sphereInitialized,sphereRadius:r.sphere.radius,sphereCenter:r.sphere.center.toArray()})),i.maxGeometryCount=this._maxGeometryCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function s(r,c){return r[c.uuid]===void 0&&(r[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(t.geometries,this.geometry);const r=this.geometry.parameters;if(r!==void 0&&r.shapes!==void 0){const c=r.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const d=c[l];s(t.shapes,d)}else s(t.shapes,c)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const r=[];for(let c=0,l=this.material.length;c<l;c++)r.push(s(t.materials,this.material[c]));i.material=r}else i.material=s(t.materials,this.material);if(this.children.length>0){i.children=[];for(let r=0;r<this.children.length;r++)i.children.push(this.children[r].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let r=0;r<this.animations.length;r++){const c=this.animations[r];i.animations.push(s(t.animations,c))}}if(e){const r=a(t.geometries),c=a(t.materials),l=a(t.textures),h=a(t.images),d=a(t.shapes),u=a(t.skeletons),f=a(t.animations),g=a(t.nodes);r.length>0&&(n.geometries=r),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),d.length>0&&(n.shapes=d),u.length>0&&(n.skeletons=u),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=i,n;function a(r){const c=[];for(const l in r){const h=r[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}}ye.DEFAULT_UP=new P(0,1,0);ye.DEFAULT_MATRIX_AUTO_UPDATE=!0;ye.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Ke=new P,ln=new P,Mo=new P,hn=new P,ni=new P,ii=new P,hr=new P,So=new P,bo=new P,Eo=new P;let ds=!1;class qe{constructor(t=new P,e=new P,n=new P){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),Ke.subVectors(t,e),i.cross(Ke);const s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(t,e,n,i,s){Ke.subVectors(i,e),ln.subVectors(n,e),Mo.subVectors(t,e);const a=Ke.dot(Ke),r=Ke.dot(ln),c=Ke.dot(Mo),l=ln.dot(ln),h=ln.dot(Mo),d=a*l-r*r;if(d===0)return s.set(0,0,0),null;const u=1/d,f=(l*c-r*h)*u,g=(a*h-r*c)*u;return s.set(1-f-g,g,f)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,hn)===null?!1:hn.x>=0&&hn.y>=0&&hn.x+hn.y<=1}static getUV(t,e,n,i,s,a,r,c){return ds===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),ds=!0),this.getInterpolation(t,e,n,i,s,a,r,c)}static getInterpolation(t,e,n,i,s,a,r,c){return this.getBarycoord(t,e,n,i,hn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,hn.x),c.addScaledVector(a,hn.y),c.addScaledVector(r,hn.z),c)}static isFrontFacing(t,e,n,i){return Ke.subVectors(n,e),ln.subVectors(t,e),Ke.cross(ln).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Ke.subVectors(this.c,this.b),ln.subVectors(this.a,this.b),Ke.cross(ln).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return qe.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return qe.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,i,s){return ds===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),ds=!0),qe.getInterpolation(t,this.a,this.b,this.c,e,n,i,s)}getInterpolation(t,e,n,i,s){return qe.getInterpolation(t,this.a,this.b,this.c,e,n,i,s)}containsPoint(t){return qe.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return qe.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,s=this.c;let a,r;ni.subVectors(i,n),ii.subVectors(s,n),So.subVectors(t,n);const c=ni.dot(So),l=ii.dot(So);if(c<=0&&l<=0)return e.copy(n);bo.subVectors(t,i);const h=ni.dot(bo),d=ii.dot(bo);if(h>=0&&d<=h)return e.copy(i);const u=c*d-h*l;if(u<=0&&c>=0&&h<=0)return a=c/(c-h),e.copy(n).addScaledVector(ni,a);Eo.subVectors(t,s);const f=ni.dot(Eo),g=ii.dot(Eo);if(g>=0&&f<=g)return e.copy(s);const y=f*l-c*g;if(y<=0&&l>=0&&g<=0)return r=l/(l-g),e.copy(n).addScaledVector(ii,r);const m=h*g-f*d;if(m<=0&&d-h>=0&&f-g>=0)return hr.subVectors(s,i),r=(d-h)/(d-h+(f-g)),e.copy(i).addScaledVector(hr,r);const p=1/(m+y+u);return a=y*p,r=u*p,e.copy(n).addScaledVector(ni,a).addScaledVector(ii,r)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const vc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},vn={h:0,s:0,l:0},us={h:0,s:0,l:0};function To(o,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?o+(t-o)*6*e:e<1/2?t:e<2/3?o+(t-o)*6*(2/3-e):o}class Xt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Te){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,oe.toWorkingColorSpace(this,e),this}setRGB(t,e,n,i=oe.workingColorSpace){return this.r=t,this.g=e,this.b=n,oe.toWorkingColorSpace(this,i),this}setHSL(t,e,n,i=oe.workingColorSpace){if(t=$l(t,1),e=Le(e,0,1),n=Le(n,0,1),e===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+e):n+e-n*e,a=2*n-s;this.r=To(a,s,t+1/3),this.g=To(a,s,t),this.b=To(a,s,t-1/3)}return oe.toWorkingColorSpace(this,i),this}setStyle(t,e=Te){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let s;const a=i[1],r=i[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,e);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,e);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const s=i[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(s,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Te){const n=vc[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=_i(t.r),this.g=_i(t.g),this.b=_i(t.b),this}copyLinearToSRGB(t){return this.r=po(t.r),this.g=po(t.g),this.b=po(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Te){return oe.fromWorkingColorSpace(Pe.copy(this),t),Math.round(Le(Pe.r*255,0,255))*65536+Math.round(Le(Pe.g*255,0,255))*256+Math.round(Le(Pe.b*255,0,255))}getHexString(t=Te){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=oe.workingColorSpace){oe.fromWorkingColorSpace(Pe.copy(this),e);const n=Pe.r,i=Pe.g,s=Pe.b,a=Math.max(n,i,s),r=Math.min(n,i,s);let c,l;const h=(r+a)/2;if(r===a)c=0,l=0;else{const d=a-r;switch(l=h<=.5?d/(a+r):d/(2-a-r),a){case n:c=(i-s)/d+(i<s?6:0);break;case i:c=(s-n)/d+2;break;case s:c=(n-i)/d+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=oe.workingColorSpace){return oe.fromWorkingColorSpace(Pe.copy(this),e),t.r=Pe.r,t.g=Pe.g,t.b=Pe.b,t}getStyle(t=Te){oe.fromWorkingColorSpace(Pe.copy(this),t);const e=Pe.r,n=Pe.g,i=Pe.b;return t!==Te?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(vn),this.setHSL(vn.h+t,vn.s+e,vn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(vn),t.getHSL(us);const n=uo(vn.h,us.h,e),i=uo(vn.s,us.s,e),s=uo(vn.l,us.l,e);return this.setHSL(n,i,s),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,s=t.elements;return this.r=s[0]*e+s[3]*n+s[6]*i,this.g=s[1]*e+s[4]*n+s[7]*i,this.b=s[2]*e+s[5]*n+s[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Pe=new Xt;Xt.NAMES=vc;let lh=0;class Cn extends Ti{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:lh++}),this.uuid=pn(),this.name="",this.type="Material",this.blending=vi,this.side=An,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Vo,this.blendDst=Wo,this.blendEquation=On,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Xt(0,0,0),this.blendAlpha=0,this.depthFunc=Bs,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Ka,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=jn,this.stencilZFail=jn,this.stencilZPass=jn,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==vi&&(n.blending=this.blending),this.side!==An&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Vo&&(n.blendSrc=this.blendSrc),this.blendDst!==Wo&&(n.blendDst=this.blendDst),this.blendEquation!==On&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Bs&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Ka&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==jn&&(n.stencilFail=this.stencilFail),this.stencilZFail!==jn&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==jn&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(s){const a=[];for(const r in s){const c=s[r];delete c.metadata,a.push(c)}return a}if(e){const s=i(t.textures),a=i(t.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=e[s].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class Mt extends Cn{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Xt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=oa,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const ve=new P,fs=new ut;class $e{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=jo,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Mn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)fs.fromBufferAttribute(this,e),fs.applyMatrix3(t),this.setXY(e,fs.x,fs.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.applyMatrix3(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.applyMatrix4(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.applyNormalMatrix(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)ve.fromBufferAttribute(this,e),ve.transformDirection(t),this.setXYZ(e,ve.x,ve.y,ve.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=un(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ae(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=un(e,this.array)),e}setX(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=un(e,this.array)),e}setY(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=un(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=un(e,this.array)),e}setW(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,s){return t*=this.itemSize,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array),s=ae(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=s,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==jo&&(t.usage=this.usage),t}}class _c extends $e{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class Mc extends $e{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class Jt extends $e{constructor(t,e,n){super(new Float32Array(t),e,n)}}let hh=0;const We=new fe,Ao=new ye,si=new P,He=new Ki,Di=new Ki,Ee=new P;class _e extends Ti{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:hh++}),this.uuid=pn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(gc(t)?Mc:_c)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new Zt().getNormalMatrix(t);n.applyNormalMatrix(s),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return We.makeRotationFromQuaternion(t),this.applyMatrix4(We),this}rotateX(t){return We.makeRotationX(t),this.applyMatrix4(We),this}rotateY(t){return We.makeRotationY(t),this.applyMatrix4(We),this}rotateZ(t){return We.makeRotationZ(t),this.applyMatrix4(We),this}translate(t,e,n){return We.makeTranslation(t,e,n),this.applyMatrix4(We),this}scale(t,e,n){return We.makeScale(t,e,n),this.applyMatrix4(We),this}lookAt(t){return Ao.lookAt(t),Ao.updateMatrix(),this.applyMatrix4(Ao.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(si).negate(),this.translate(si.x,si.y,si.z),this}setFromPoints(t){const e=[];for(let n=0,i=t.length;n<i;n++){const s=t[n];e.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Jt(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ki);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const s=e[n];He.setFromBufferAttribute(s),this.morphTargetsRelative?(Ee.addVectors(this.boundingBox.min,He.min),this.boundingBox.expandByPoint(Ee),Ee.addVectors(this.boundingBox.max,He.max),this.boundingBox.expandByPoint(Ee)):(this.boundingBox.expandByPoint(He.min),this.boundingBox.expandByPoint(He.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ji);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new P,1/0);return}if(t){const n=this.boundingSphere.center;if(He.setFromBufferAttribute(t),e)for(let s=0,a=e.length;s<a;s++){const r=e[s];Di.setFromBufferAttribute(r),this.morphTargetsRelative?(Ee.addVectors(He.min,Di.min),He.expandByPoint(Ee),Ee.addVectors(He.max,Di.max),He.expandByPoint(Ee)):(He.expandByPoint(Di.min),He.expandByPoint(Di.max))}He.getCenter(n);let i=0;for(let s=0,a=t.count;s<a;s++)Ee.fromBufferAttribute(t,s),i=Math.max(i,n.distanceToSquared(Ee));if(e)for(let s=0,a=e.length;s<a;s++){const r=e[s],c=this.morphTargetsRelative;for(let l=0,h=r.count;l<h;l++)Ee.fromBufferAttribute(r,l),c&&(si.fromBufferAttribute(t,l),Ee.add(si)),i=Math.max(i,n.distanceToSquared(Ee))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.array,i=e.position.array,s=e.normal.array,a=e.uv.array,r=i.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new $e(new Float32Array(4*r),4));const c=this.getAttribute("tangent").array,l=[],h=[];for(let S=0;S<r;S++)l[S]=new P,h[S]=new P;const d=new P,u=new P,f=new P,g=new ut,y=new ut,m=new ut,p=new P,_=new P;function w(S,L,F){d.fromArray(i,S*3),u.fromArray(i,L*3),f.fromArray(i,F*3),g.fromArray(a,S*2),y.fromArray(a,L*2),m.fromArray(a,F*2),u.sub(d),f.sub(d),y.sub(g),m.sub(g);const Z=1/(y.x*m.y-m.x*y.y);isFinite(Z)&&(p.copy(u).multiplyScalar(m.y).addScaledVector(f,-y.y).multiplyScalar(Z),_.copy(f).multiplyScalar(y.x).addScaledVector(u,-m.x).multiplyScalar(Z),l[S].add(p),l[L].add(p),l[F].add(p),h[S].add(_),h[L].add(_),h[F].add(_))}let v=this.groups;v.length===0&&(v=[{start:0,count:n.length}]);for(let S=0,L=v.length;S<L;++S){const F=v[S],Z=F.start,I=F.count;for(let B=Z,k=Z+I;B<k;B+=3)w(n[B+0],n[B+1],n[B+2])}const R=new P,T=new P,E=new P,U=new P;function M(S){E.fromArray(s,S*3),U.copy(E);const L=l[S];R.copy(L),R.sub(E.multiplyScalar(E.dot(L))).normalize(),T.crossVectors(U,L);const Z=T.dot(h[S])<0?-1:1;c[S*4]=R.x,c[S*4+1]=R.y,c[S*4+2]=R.z,c[S*4+3]=Z}for(let S=0,L=v.length;S<L;++S){const F=v[S],Z=F.start,I=F.count;for(let B=Z,k=Z+I;B<k;B+=3)M(n[B+0]),M(n[B+1]),M(n[B+2])}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new $e(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let u=0,f=n.count;u<f;u++)n.setXYZ(u,0,0,0);const i=new P,s=new P,a=new P,r=new P,c=new P,l=new P,h=new P,d=new P;if(t)for(let u=0,f=t.count;u<f;u+=3){const g=t.getX(u+0),y=t.getX(u+1),m=t.getX(u+2);i.fromBufferAttribute(e,g),s.fromBufferAttribute(e,y),a.fromBufferAttribute(e,m),h.subVectors(a,s),d.subVectors(i,s),h.cross(d),r.fromBufferAttribute(n,g),c.fromBufferAttribute(n,y),l.fromBufferAttribute(n,m),r.add(h),c.add(h),l.add(h),n.setXYZ(g,r.x,r.y,r.z),n.setXYZ(y,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let u=0,f=e.count;u<f;u+=3)i.fromBufferAttribute(e,u+0),s.fromBufferAttribute(e,u+1),a.fromBufferAttribute(e,u+2),h.subVectors(a,s),d.subVectors(i,s),h.cross(d),n.setXYZ(u+0,h.x,h.y,h.z),n.setXYZ(u+1,h.x,h.y,h.z),n.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ee.fromBufferAttribute(t,e),Ee.normalize(),t.setXYZ(e,Ee.x,Ee.y,Ee.z)}toNonIndexed(){function t(r,c){const l=r.array,h=r.itemSize,d=r.normalized,u=new l.constructor(c.length*h);let f=0,g=0;for(let y=0,m=c.length;y<m;y++){r.isInterleavedBufferAttribute?f=c[y]*r.data.stride+r.offset:f=c[y]*h;for(let p=0;p<h;p++)u[g++]=l[f++]}return new $e(u,h,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new _e,n=this.index.array,i=this.attributes;for(const r in i){const c=i[r],l=t(c,n);e.setAttribute(r,l)}const s=this.morphAttributes;for(const r in s){const c=[],l=s[r];for(let h=0,d=l.length;h<d;h++){const u=l[h],f=t(u,n);c.push(f)}e.morphAttributes[r]=c}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let r=0,c=a.length;r<c;r++){const l=a[r];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const i={};let s=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let d=0,u=l.length;d<u;d++){const f=l[d];h.push(f.toJSON(t.data))}h.length>0&&(i[c]=h,s=!0)}s&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const r=this.boundingSphere;return r!==null&&(t.data.boundingSphere={center:r.center.toArray(),radius:r.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone(e));const i=t.attributes;for(const l in i){const h=i[l];this.setAttribute(l,h.clone(e))}const s=t.morphAttributes;for(const l in s){const h=[],d=s[l];for(let u=0,f=d.length;u<f;u++)h.push(d[u].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let l=0,h=a.length;l<h;l++){const d=a[l];this.addGroup(d.start,d.count,d.materialIndex)}const r=t.boundingBox;r!==null&&(this.boundingBox=r.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const dr=new fe,Un=new $s,ps=new Ji,ur=new P,oi=new P,ai=new P,ri=new P,Co=new P,ms=new P,gs=new ut,ys=new ut,ws=new ut,fr=new P,pr=new P,mr=new P,xs=new P,vs=new P;class x extends ye{constructor(t=new _e,e=new Mt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const r=this.morphTargetInfluences;if(s&&r){ms.set(0,0,0);for(let c=0,l=s.length;c<l;c++){const h=r[c],d=s[c];h!==0&&(Co.fromBufferAttribute(d,t),a?ms.addScaledVector(Co,h):ms.addScaledVector(Co.sub(e),h))}e.add(ms)}return e}raycast(t,e){const n=this.geometry,i=this.material,s=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ps.copy(n.boundingSphere),ps.applyMatrix4(s),Un.copy(t.ray).recast(t.near),!(ps.containsPoint(Un.origin)===!1&&(Un.intersectSphere(ps,ur)===null||Un.origin.distanceToSquared(ur)>(t.far-t.near)**2))&&(dr.copy(s).invert(),Un.copy(t.ray).applyMatrix4(dr),!(n.boundingBox!==null&&Un.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Un)))}_computeIntersections(t,e,n){let i;const s=this.geometry,a=this.material,r=s.index,c=s.attributes.position,l=s.attributes.uv,h=s.attributes.uv1,d=s.attributes.normal,u=s.groups,f=s.drawRange;if(r!==null)if(Array.isArray(a))for(let g=0,y=u.length;g<y;g++){const m=u[g],p=a[m.materialIndex],_=Math.max(m.start,f.start),w=Math.min(r.count,Math.min(m.start+m.count,f.start+f.count));for(let v=_,R=w;v<R;v+=3){const T=r.getX(v),E=r.getX(v+1),U=r.getX(v+2);i=_s(this,p,t,n,l,h,d,T,E,U),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,f.start),y=Math.min(r.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){const _=r.getX(m),w=r.getX(m+1),v=r.getX(m+2);i=_s(this,a,t,n,l,h,d,_,w,v),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(c!==void 0)if(Array.isArray(a))for(let g=0,y=u.length;g<y;g++){const m=u[g],p=a[m.materialIndex],_=Math.max(m.start,f.start),w=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let v=_,R=w;v<R;v+=3){const T=v,E=v+1,U=v+2;i=_s(this,p,t,n,l,h,d,T,E,U),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,f.start),y=Math.min(c.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){const _=m,w=m+1,v=m+2;i=_s(this,a,t,n,l,h,d,_,w,v),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}}function dh(o,t,e,n,i,s,a,r){let c;if(t.side===Fe?c=n.intersectTriangle(a,s,i,!0,r):c=n.intersectTriangle(i,s,a,t.side===An,r),c===null)return null;vs.copy(r),vs.applyMatrix4(o.matrixWorld);const l=e.ray.origin.distanceTo(vs);return l<e.near||l>e.far?null:{distance:l,point:vs.clone(),object:o}}function _s(o,t,e,n,i,s,a,r,c,l){o.getVertexPosition(r,oi),o.getVertexPosition(c,ai),o.getVertexPosition(l,ri);const h=dh(o,t,e,n,oi,ai,ri,xs);if(h){i&&(gs.fromBufferAttribute(i,r),ys.fromBufferAttribute(i,c),ws.fromBufferAttribute(i,l),h.uv=qe.getInterpolation(xs,oi,ai,ri,gs,ys,ws,new ut)),s&&(gs.fromBufferAttribute(s,r),ys.fromBufferAttribute(s,c),ws.fromBufferAttribute(s,l),h.uv1=qe.getInterpolation(xs,oi,ai,ri,gs,ys,ws,new ut),h.uv2=h.uv1),a&&(fr.fromBufferAttribute(a,r),pr.fromBufferAttribute(a,c),mr.fromBufferAttribute(a,l),h.normal=qe.getInterpolation(xs,oi,ai,ri,fr,pr,mr,new P),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a:r,b:c,c:l,normal:new P,materialIndex:0};qe.getNormal(oi,ai,ri,d.normal),h.face=d}return h}class O extends _e{constructor(t=1,e=1,n=1,i=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:s,depthSegments:a};const r=this;i=Math.floor(i),s=Math.floor(s),a=Math.floor(a);const c=[],l=[],h=[],d=[];let u=0,f=0;g("z","y","x",-1,-1,n,e,t,a,s,0),g("z","y","x",1,-1,n,e,-t,a,s,1),g("x","z","y",1,1,t,n,e,i,a,2),g("x","z","y",1,-1,t,n,-e,i,a,3),g("x","y","z",1,-1,t,e,n,i,s,4),g("x","y","z",-1,-1,t,e,-n,i,s,5),this.setIndex(c),this.setAttribute("position",new Jt(l,3)),this.setAttribute("normal",new Jt(h,3)),this.setAttribute("uv",new Jt(d,2));function g(y,m,p,_,w,v,R,T,E,U,M){const S=v/E,L=R/U,F=v/2,Z=R/2,I=T/2,B=E+1,k=U+1;let Y=0,$=0;const q=new P;for(let Q=0;Q<k;Q++){const it=Q*L-Z;for(let rt=0;rt<B;rt++){const V=rt*S-F;q[y]=V*_,q[m]=it*w,q[p]=I,l.push(q.x,q.y,q.z),q[y]=0,q[m]=0,q[p]=T>0?1:-1,h.push(q.x,q.y,q.z),d.push(rt/E),d.push(1-Q/U),Y+=1}}for(let Q=0;Q<U;Q++)for(let it=0;it<E;it++){const rt=u+it+B*Q,V=u+it+B*(Q+1),et=u+(it+1)+B*(Q+1),ft=u+(it+1)+B*Q;c.push(rt,V,ft),c.push(V,et,ft),$+=6}r.addGroup(f,$,M),f+=$,u+=Y}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new O(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function Ei(o){const t={};for(const e in o){t[e]={};for(const n in o[e]){const i=o[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function De(o){const t={};for(let e=0;e<o.length;e++){const n=Ei(o[e]);for(const i in n)t[i]=n[i]}return t}function uh(o){const t=[];for(let e=0;e<o.length;e++)t.push(o[e].clone());return t}function Sc(o){return o.getRenderTarget()===null?o.outputColorSpace:oe.workingColorSpace}const fh={clone:Ei,merge:De};var ph=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,mh=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Wn extends Cn{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=ph,this.fragmentShader=mh,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Ei(t.uniforms),this.uniformsGroups=uh(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class bc extends ye{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new fe,this.projectionMatrix=new fe,this.projectionMatrixInverse=new fe,this.coordinateSystem=fn}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class Be extends bc{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Gs*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(ho*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Gs*2*Math.atan(Math.tan(ho*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,i,s,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(ho*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,s=-.5*i;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;s+=a.offsetX*i/c,e-=a.offsetY*n/l,i*=a.width/c,n*=a.height/l}const r=this.filmOffset;r!==0&&(s+=t*r/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const ci=-90,li=1;class gh extends ye{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new Be(ci,li,t,e);i.layers=this.layers,this.add(i);const s=new Be(ci,li,t,e);s.layers=this.layers,this.add(s);const a=new Be(ci,li,t,e);a.layers=this.layers,this.add(a);const r=new Be(ci,li,t,e);r.layers=this.layers,this.add(r);const c=new Be(ci,li,t,e);c.layers=this.layers,this.add(c);const l=new Be(ci,li,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,s,a,r,c]=e;for(const l of e)this.remove(l);if(t===fn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),r.up.set(0,1,0),r.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===ks)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),r.up.set(0,-1,0),r.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[s,a,r,c,l,h]=this.children,d=t.getRenderTarget(),u=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const y=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,s),t.setRenderTarget(n,1,i),t.render(e,a),t.setRenderTarget(n,2,i),t.render(e,r),t.setRenderTarget(n,3,i),t.render(e,c),t.setRenderTarget(n,4,i),t.render(e,l),n.texture.generateMipmaps=y,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(d,u,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class Ec extends Oe{constructor(t,e,n,i,s,a,r,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:Mi,super(t,e,n,i,s,a,r,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class yh extends Vn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];e.encoding!==void 0&&(Oi("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===Hn?Te:Ye),this.texture=new Ec(i,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Xe}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new O(5,5,5),s=new Wn({name:"CubemapFromEquirect",uniforms:Ei(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Fe,blending:bn});s.uniforms.tEquirect.value=e;const a=new x(i,s),r=e.minFilter;return e.minFilter===Vi&&(e.minFilter=Xe),new gh(1,10,this).update(t,a),e.minFilter=r,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,i){const s=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(s)}}const Ro=new P,wh=new P,xh=new Zt;class Bn{constructor(t=new P(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=Ro.subVectors(n,e).cross(wh.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Ro),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const s=-(t.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:e.copy(t.start).addScaledVector(n,s)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||xh.getNormalMatrix(t),i=this.coplanarPoint(Ro).applyMatrix4(t),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Nn=new Ji,Ms=new P;class la{constructor(t=new Bn,e=new Bn,n=new Bn,i=new Bn,s=new Bn,a=new Bn){this.planes=[t,e,n,i,s,a]}set(t,e,n,i,s,a){const r=this.planes;return r[0].copy(t),r[1].copy(e),r[2].copy(n),r[3].copy(i),r[4].copy(s),r[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=fn){const n=this.planes,i=t.elements,s=i[0],a=i[1],r=i[2],c=i[3],l=i[4],h=i[5],d=i[6],u=i[7],f=i[8],g=i[9],y=i[10],m=i[11],p=i[12],_=i[13],w=i[14],v=i[15];if(n[0].setComponents(c-s,u-l,m-f,v-p).normalize(),n[1].setComponents(c+s,u+l,m+f,v+p).normalize(),n[2].setComponents(c+a,u+h,m+g,v+_).normalize(),n[3].setComponents(c-a,u-h,m-g,v-_).normalize(),n[4].setComponents(c-r,u-d,m-y,v-w).normalize(),e===fn)n[5].setComponents(c+r,u+d,m+y,v+w).normalize();else if(e===ks)n[5].setComponents(r,d,y,w).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Nn.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Nn.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Nn)}intersectsSprite(t){return Nn.center.set(0,0,0),Nn.radius=.7071067811865476,Nn.applyMatrix4(t.matrixWorld),this.intersectsSphere(Nn)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let s=0;s<6;s++)if(e[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(Ms.x=i.normal.x>0?t.max.x:t.min.x,Ms.y=i.normal.y>0?t.max.y:t.min.y,Ms.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(Ms)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Tc(){let o=null,t=!1,e=null,n=null;function i(s,a){e(s,a),n=o.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=o.requestAnimationFrame(i),t=!0)},stop:function(){o.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(s){e=s},setContext:function(s){o=s}}}function vh(o,t){const e=t.isWebGL2,n=new WeakMap;function i(l,h){const d=l.array,u=l.usage,f=d.byteLength,g=o.createBuffer();o.bindBuffer(h,g),o.bufferData(h,d,u),l.onUploadCallback();let y;if(d instanceof Float32Array)y=o.FLOAT;else if(d instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(e)y=o.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else y=o.UNSIGNED_SHORT;else if(d instanceof Int16Array)y=o.SHORT;else if(d instanceof Uint32Array)y=o.UNSIGNED_INT;else if(d instanceof Int32Array)y=o.INT;else if(d instanceof Int8Array)y=o.BYTE;else if(d instanceof Uint8Array)y=o.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)y=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:g,type:y,bytesPerElement:d.BYTES_PER_ELEMENT,version:l.version,size:f}}function s(l,h,d){const u=h.array,f=h._updateRange,g=h.updateRanges;if(o.bindBuffer(d,l),f.count===-1&&g.length===0&&o.bufferSubData(d,0,u),g.length!==0){for(let y=0,m=g.length;y<m;y++){const p=g[y];e?o.bufferSubData(d,p.start*u.BYTES_PER_ELEMENT,u,p.start,p.count):o.bufferSubData(d,p.start*u.BYTES_PER_ELEMENT,u.subarray(p.start,p.start+p.count))}h.clearUpdateRanges()}f.count!==-1&&(e?o.bufferSubData(d,f.offset*u.BYTES_PER_ELEMENT,u,f.offset,f.count):o.bufferSubData(d,f.offset*u.BYTES_PER_ELEMENT,u.subarray(f.offset,f.offset+f.count)),f.count=-1),h.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),n.get(l)}function r(l){l.isInterleavedBufferAttribute&&(l=l.data);const h=n.get(l);h&&(o.deleteBuffer(h.buffer),n.delete(l))}function c(l,h){if(l.isGLBufferAttribute){const u=n.get(l);(!u||u.version<l.version)&&n.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);const d=n.get(l);if(d===void 0)n.set(l,i(l,h));else if(d.version<l.version){if(d.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(d.buffer,l,h),d.version=l.version}}return{get:a,remove:r,update:c}}class nn extends _e{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const s=t/2,a=e/2,r=Math.floor(n),c=Math.floor(i),l=r+1,h=c+1,d=t/r,u=e/c,f=[],g=[],y=[],m=[];for(let p=0;p<h;p++){const _=p*u-a;for(let w=0;w<l;w++){const v=w*d-s;g.push(v,-_,0),y.push(0,0,1),m.push(w/r),m.push(1-p/c)}}for(let p=0;p<c;p++)for(let _=0;_<r;_++){const w=_+l*p,v=_+l*(p+1),R=_+1+l*(p+1),T=_+1+l*p;f.push(w,v,T),f.push(v,R,T)}this.setIndex(f),this.setAttribute("position",new Jt(g,3)),this.setAttribute("normal",new Jt(y,3)),this.setAttribute("uv",new Jt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new nn(t.width,t.height,t.widthSegments,t.heightSegments)}}var _h=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Mh=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Sh=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,bh=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Eh=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Th=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ah=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Ch=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Rh=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Ph=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,Lh=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Ih=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Dh=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Uh=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Nh=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Bh=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Fh=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Oh=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,zh=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,kh=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Gh=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Hh=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Vh=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Wh=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Xh=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,qh=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Yh=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,$h=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,jh=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Zh=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Kh="gl_FragColor = linearToOutputTexel( gl_FragColor );",Jh=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Qh=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,td=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,ed=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,nd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,id=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,sd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,od=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,ad=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,rd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,cd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,ld=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,hd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,dd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,ud=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,fd=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,pd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,md=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,gd=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,yd=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,wd=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,xd=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,vd=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,_d=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Md=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Sd=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,bd=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Ed=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Td=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,Ad=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,Cd=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Rd=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Pd=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Ld=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Id=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Dd=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ud=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Nd=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Bd=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Fd=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Od=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,zd=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,kd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Gd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Hd=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Vd=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Wd=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Xd=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,qd=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Yd=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,$d=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,jd=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Zd=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Kd=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Jd=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Qd=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,tu=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,eu=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,nu=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,iu=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,su=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,ou=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,au=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,ru=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,cu=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,lu=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,hu=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,du=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,uu=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,fu=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,pu=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,mu=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,gu=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,yu=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,wu=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,xu=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const vu=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,_u=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Mu=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Su=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,bu=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Eu=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Tu=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Au=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,Cu=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Ru=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Pu=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Lu=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Iu=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Du=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Uu=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Nu=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Bu=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Fu=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ou=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,zu=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ku=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Gu=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Hu=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Vu=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Wu=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Xu=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,qu=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Yu=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$u=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,ju=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Zu=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ku=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ju=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Qu=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,jt={alphahash_fragment:_h,alphahash_pars_fragment:Mh,alphamap_fragment:Sh,alphamap_pars_fragment:bh,alphatest_fragment:Eh,alphatest_pars_fragment:Th,aomap_fragment:Ah,aomap_pars_fragment:Ch,batching_pars_vertex:Rh,batching_vertex:Ph,begin_vertex:Lh,beginnormal_vertex:Ih,bsdfs:Dh,iridescence_fragment:Uh,bumpmap_pars_fragment:Nh,clipping_planes_fragment:Bh,clipping_planes_pars_fragment:Fh,clipping_planes_pars_vertex:Oh,clipping_planes_vertex:zh,color_fragment:kh,color_pars_fragment:Gh,color_pars_vertex:Hh,color_vertex:Vh,common:Wh,cube_uv_reflection_fragment:Xh,defaultnormal_vertex:qh,displacementmap_pars_vertex:Yh,displacementmap_vertex:$h,emissivemap_fragment:jh,emissivemap_pars_fragment:Zh,colorspace_fragment:Kh,colorspace_pars_fragment:Jh,envmap_fragment:Qh,envmap_common_pars_fragment:td,envmap_pars_fragment:ed,envmap_pars_vertex:nd,envmap_physical_pars_fragment:pd,envmap_vertex:id,fog_vertex:sd,fog_pars_vertex:od,fog_fragment:ad,fog_pars_fragment:rd,gradientmap_pars_fragment:cd,lightmap_fragment:ld,lightmap_pars_fragment:hd,lights_lambert_fragment:dd,lights_lambert_pars_fragment:ud,lights_pars_begin:fd,lights_toon_fragment:md,lights_toon_pars_fragment:gd,lights_phong_fragment:yd,lights_phong_pars_fragment:wd,lights_physical_fragment:xd,lights_physical_pars_fragment:vd,lights_fragment_begin:_d,lights_fragment_maps:Md,lights_fragment_end:Sd,logdepthbuf_fragment:bd,logdepthbuf_pars_fragment:Ed,logdepthbuf_pars_vertex:Td,logdepthbuf_vertex:Ad,map_fragment:Cd,map_pars_fragment:Rd,map_particle_fragment:Pd,map_particle_pars_fragment:Ld,metalnessmap_fragment:Id,metalnessmap_pars_fragment:Dd,morphcolor_vertex:Ud,morphnormal_vertex:Nd,morphtarget_pars_vertex:Bd,morphtarget_vertex:Fd,normal_fragment_begin:Od,normal_fragment_maps:zd,normal_pars_fragment:kd,normal_pars_vertex:Gd,normal_vertex:Hd,normalmap_pars_fragment:Vd,clearcoat_normal_fragment_begin:Wd,clearcoat_normal_fragment_maps:Xd,clearcoat_pars_fragment:qd,iridescence_pars_fragment:Yd,opaque_fragment:$d,packing:jd,premultiplied_alpha_fragment:Zd,project_vertex:Kd,dithering_fragment:Jd,dithering_pars_fragment:Qd,roughnessmap_fragment:tu,roughnessmap_pars_fragment:eu,shadowmap_pars_fragment:nu,shadowmap_pars_vertex:iu,shadowmap_vertex:su,shadowmask_pars_fragment:ou,skinbase_vertex:au,skinning_pars_vertex:ru,skinning_vertex:cu,skinnormal_vertex:lu,specularmap_fragment:hu,specularmap_pars_fragment:du,tonemapping_fragment:uu,tonemapping_pars_fragment:fu,transmission_fragment:pu,transmission_pars_fragment:mu,uv_pars_fragment:gu,uv_pars_vertex:yu,uv_vertex:wu,worldpos_vertex:xu,background_vert:vu,background_frag:_u,backgroundCube_vert:Mu,backgroundCube_frag:Su,cube_vert:bu,cube_frag:Eu,depth_vert:Tu,depth_frag:Au,distanceRGBA_vert:Cu,distanceRGBA_frag:Ru,equirect_vert:Pu,equirect_frag:Lu,linedashed_vert:Iu,linedashed_frag:Du,meshbasic_vert:Uu,meshbasic_frag:Nu,meshlambert_vert:Bu,meshlambert_frag:Fu,meshmatcap_vert:Ou,meshmatcap_frag:zu,meshnormal_vert:ku,meshnormal_frag:Gu,meshphong_vert:Hu,meshphong_frag:Vu,meshphysical_vert:Wu,meshphysical_frag:Xu,meshtoon_vert:qu,meshtoon_frag:Yu,points_vert:$u,points_frag:ju,shadow_vert:Zu,shadow_frag:Ku,sprite_vert:Ju,sprite_frag:Qu},yt={common:{diffuse:{value:new Xt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Zt},alphaMap:{value:null},alphaMapTransform:{value:new Zt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Zt}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Zt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Zt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Zt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Zt},normalScale:{value:new ut(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Zt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Zt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Zt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Zt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Xt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Xt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Zt},alphaTest:{value:0},uvTransform:{value:new Zt}},sprite:{diffuse:{value:new Xt(16777215)},opacity:{value:1},center:{value:new ut(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Zt},alphaMap:{value:null},alphaMapTransform:{value:new Zt},alphaTest:{value:0}}},tn={basic:{uniforms:De([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.fog]),vertexShader:jt.meshbasic_vert,fragmentShader:jt.meshbasic_frag},lambert:{uniforms:De([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)}}]),vertexShader:jt.meshlambert_vert,fragmentShader:jt.meshlambert_frag},phong:{uniforms:De([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)},specular:{value:new Xt(1118481)},shininess:{value:30}}]),vertexShader:jt.meshphong_vert,fragmentShader:jt.meshphong_frag},standard:{uniforms:De([yt.common,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.roughnessmap,yt.metalnessmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag},toon:{uniforms:De([yt.common,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.gradientmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)}}]),vertexShader:jt.meshtoon_vert,fragmentShader:jt.meshtoon_frag},matcap:{uniforms:De([yt.common,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,{matcap:{value:null}}]),vertexShader:jt.meshmatcap_vert,fragmentShader:jt.meshmatcap_frag},points:{uniforms:De([yt.points,yt.fog]),vertexShader:jt.points_vert,fragmentShader:jt.points_frag},dashed:{uniforms:De([yt.common,yt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:jt.linedashed_vert,fragmentShader:jt.linedashed_frag},depth:{uniforms:De([yt.common,yt.displacementmap]),vertexShader:jt.depth_vert,fragmentShader:jt.depth_frag},normal:{uniforms:De([yt.common,yt.bumpmap,yt.normalmap,yt.displacementmap,{opacity:{value:1}}]),vertexShader:jt.meshnormal_vert,fragmentShader:jt.meshnormal_frag},sprite:{uniforms:De([yt.sprite,yt.fog]),vertexShader:jt.sprite_vert,fragmentShader:jt.sprite_frag},background:{uniforms:{uvTransform:{value:new Zt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:jt.background_vert,fragmentShader:jt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:jt.backgroundCube_vert,fragmentShader:jt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:jt.cube_vert,fragmentShader:jt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:jt.equirect_vert,fragmentShader:jt.equirect_frag},distanceRGBA:{uniforms:De([yt.common,yt.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:jt.distanceRGBA_vert,fragmentShader:jt.distanceRGBA_frag},shadow:{uniforms:De([yt.lights,yt.fog,{color:{value:new Xt(0)},opacity:{value:1}}]),vertexShader:jt.shadow_vert,fragmentShader:jt.shadow_frag}};tn.physical={uniforms:De([tn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Zt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Zt},clearcoatNormalScale:{value:new ut(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Zt},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Zt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Zt},sheen:{value:0},sheenColor:{value:new Xt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Zt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Zt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Zt},transmissionSamplerSize:{value:new ut},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Zt},attenuationDistance:{value:0},attenuationColor:{value:new Xt(0)},specularColor:{value:new Xt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Zt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Zt},anisotropyVector:{value:new ut},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Zt}}]),vertexShader:jt.meshphysical_vert,fragmentShader:jt.meshphysical_frag};const Ss={r:0,b:0,g:0};function tf(o,t,e,n,i,s,a){const r=new Xt(0);let c=s===!0?0:1,l,h,d=null,u=0,f=null;function g(m,p){let _=!1,w=p.isScene===!0?p.background:null;w&&w.isTexture&&(w=(p.backgroundBlurriness>0?e:t).get(w)),w===null?y(r,c):w&&w.isColor&&(y(w,1),_=!0);const v=o.xr.getEnvironmentBlendMode();v==="additive"?n.buffers.color.setClear(0,0,0,1,a):v==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(o.autoClear||_)&&o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil),w&&(w.isCubeTexture||w.mapping===qs)?(h===void 0&&(h=new x(new O(1,1,1),new Wn({name:"BackgroundCubeMaterial",uniforms:Ei(tn.backgroundCube.uniforms),vertexShader:tn.backgroundCube.vertexShader,fragmentShader:tn.backgroundCube.fragmentShader,side:Fe,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(R,T,E){this.matrixWorld.copyPosition(E.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),h.material.uniforms.envMap.value=w,h.material.uniforms.flipEnvMap.value=w.isCubeTexture&&w.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=p.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,h.material.toneMapped=oe.getTransfer(w.colorSpace)!==le,(d!==w||u!==w.version||f!==o.toneMapping)&&(h.material.needsUpdate=!0,d=w,u=w.version,f=o.toneMapping),h.layers.enableAll(),m.unshift(h,h.geometry,h.material,0,0,null)):w&&w.isTexture&&(l===void 0&&(l=new x(new nn(2,2),new Wn({name:"BackgroundMaterial",uniforms:Ei(tn.background.uniforms),vertexShader:tn.background.vertexShader,fragmentShader:tn.background.fragmentShader,side:An,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=w,l.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,l.material.toneMapped=oe.getTransfer(w.colorSpace)!==le,w.matrixAutoUpdate===!0&&w.updateMatrix(),l.material.uniforms.uvTransform.value.copy(w.matrix),(d!==w||u!==w.version||f!==o.toneMapping)&&(l.material.needsUpdate=!0,d=w,u=w.version,f=o.toneMapping),l.layers.enableAll(),m.unshift(l,l.geometry,l.material,0,0,null))}function y(m,p){m.getRGB(Ss,Sc(o)),n.buffers.color.setClear(Ss.r,Ss.g,Ss.b,p,a)}return{getClearColor:function(){return r},setClearColor:function(m,p=1){r.set(m),c=p,y(r,c)},getClearAlpha:function(){return c},setClearAlpha:function(m){c=m,y(r,c)},render:g}}function ef(o,t,e,n){const i=o.getParameter(o.MAX_VERTEX_ATTRIBS),s=n.isWebGL2?null:t.get("OES_vertex_array_object"),a=n.isWebGL2||s!==null,r={},c=m(null);let l=c,h=!1;function d(I,B,k,Y,$){let q=!1;if(a){const Q=y(Y,k,B);l!==Q&&(l=Q,f(l.object)),q=p(I,Y,k,$),q&&_(I,Y,k,$)}else{const Q=B.wireframe===!0;(l.geometry!==Y.id||l.program!==k.id||l.wireframe!==Q)&&(l.geometry=Y.id,l.program=k.id,l.wireframe=Q,q=!0)}$!==null&&e.update($,o.ELEMENT_ARRAY_BUFFER),(q||h)&&(h=!1,U(I,B,k,Y),$!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,e.get($).buffer))}function u(){return n.isWebGL2?o.createVertexArray():s.createVertexArrayOES()}function f(I){return n.isWebGL2?o.bindVertexArray(I):s.bindVertexArrayOES(I)}function g(I){return n.isWebGL2?o.deleteVertexArray(I):s.deleteVertexArrayOES(I)}function y(I,B,k){const Y=k.wireframe===!0;let $=r[I.id];$===void 0&&($={},r[I.id]=$);let q=$[B.id];q===void 0&&(q={},$[B.id]=q);let Q=q[Y];return Q===void 0&&(Q=m(u()),q[Y]=Q),Q}function m(I){const B=[],k=[],Y=[];for(let $=0;$<i;$++)B[$]=0,k[$]=0,Y[$]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:B,enabledAttributes:k,attributeDivisors:Y,object:I,attributes:{},index:null}}function p(I,B,k,Y){const $=l.attributes,q=B.attributes;let Q=0;const it=k.getAttributes();for(const rt in it)if(it[rt].location>=0){const et=$[rt];let ft=q[rt];if(ft===void 0&&(rt==="instanceMatrix"&&I.instanceMatrix&&(ft=I.instanceMatrix),rt==="instanceColor"&&I.instanceColor&&(ft=I.instanceColor)),et===void 0||et.attribute!==ft||ft&&et.data!==ft.data)return!0;Q++}return l.attributesNum!==Q||l.index!==Y}function _(I,B,k,Y){const $={},q=B.attributes;let Q=0;const it=k.getAttributes();for(const rt in it)if(it[rt].location>=0){let et=q[rt];et===void 0&&(rt==="instanceMatrix"&&I.instanceMatrix&&(et=I.instanceMatrix),rt==="instanceColor"&&I.instanceColor&&(et=I.instanceColor));const ft={};ft.attribute=et,et&&et.data&&(ft.data=et.data),$[rt]=ft,Q++}l.attributes=$,l.attributesNum=Q,l.index=Y}function w(){const I=l.newAttributes;for(let B=0,k=I.length;B<k;B++)I[B]=0}function v(I){R(I,0)}function R(I,B){const k=l.newAttributes,Y=l.enabledAttributes,$=l.attributeDivisors;k[I]=1,Y[I]===0&&(o.enableVertexAttribArray(I),Y[I]=1),$[I]!==B&&((n.isWebGL2?o:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](I,B),$[I]=B)}function T(){const I=l.newAttributes,B=l.enabledAttributes;for(let k=0,Y=B.length;k<Y;k++)B[k]!==I[k]&&(o.disableVertexAttribArray(k),B[k]=0)}function E(I,B,k,Y,$,q,Q){Q===!0?o.vertexAttribIPointer(I,B,k,$,q):o.vertexAttribPointer(I,B,k,Y,$,q)}function U(I,B,k,Y){if(n.isWebGL2===!1&&(I.isInstancedMesh||Y.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;w();const $=Y.attributes,q=k.getAttributes(),Q=B.defaultAttributeValues;for(const it in q){const rt=q[it];if(rt.location>=0){let V=$[it];if(V===void 0&&(it==="instanceMatrix"&&I.instanceMatrix&&(V=I.instanceMatrix),it==="instanceColor"&&I.instanceColor&&(V=I.instanceColor)),V!==void 0){const et=V.normalized,ft=V.itemSize,Et=e.get(V);if(Et===void 0)continue;const _t=Et.buffer,Nt=Et.type,zt=Et.bytesPerElement,Tt=n.isWebGL2===!0&&(Nt===o.INT||Nt===o.UNSIGNED_INT||V.gpuType===ac);if(V.isInterleavedBufferAttribute){const Ft=V.data,D=Ft.stride,pt=V.offset;if(Ft.isInstancedInterleavedBuffer){for(let K=0;K<rt.locationSize;K++)R(rt.location+K,Ft.meshPerAttribute);I.isInstancedMesh!==!0&&Y._maxInstanceCount===void 0&&(Y._maxInstanceCount=Ft.meshPerAttribute*Ft.count)}else for(let K=0;K<rt.locationSize;K++)v(rt.location+K);o.bindBuffer(o.ARRAY_BUFFER,_t);for(let K=0;K<rt.locationSize;K++)E(rt.location+K,ft/rt.locationSize,Nt,et,D*zt,(pt+ft/rt.locationSize*K)*zt,Tt)}else{if(V.isInstancedBufferAttribute){for(let Ft=0;Ft<rt.locationSize;Ft++)R(rt.location+Ft,V.meshPerAttribute);I.isInstancedMesh!==!0&&Y._maxInstanceCount===void 0&&(Y._maxInstanceCount=V.meshPerAttribute*V.count)}else for(let Ft=0;Ft<rt.locationSize;Ft++)v(rt.location+Ft);o.bindBuffer(o.ARRAY_BUFFER,_t);for(let Ft=0;Ft<rt.locationSize;Ft++)E(rt.location+Ft,ft/rt.locationSize,Nt,et,ft*zt,ft/rt.locationSize*Ft*zt,Tt)}}else if(Q!==void 0){const et=Q[it];if(et!==void 0)switch(et.length){case 2:o.vertexAttrib2fv(rt.location,et);break;case 3:o.vertexAttrib3fv(rt.location,et);break;case 4:o.vertexAttrib4fv(rt.location,et);break;default:o.vertexAttrib1fv(rt.location,et)}}}}T()}function M(){F();for(const I in r){const B=r[I];for(const k in B){const Y=B[k];for(const $ in Y)g(Y[$].object),delete Y[$];delete B[k]}delete r[I]}}function S(I){if(r[I.id]===void 0)return;const B=r[I.id];for(const k in B){const Y=B[k];for(const $ in Y)g(Y[$].object),delete Y[$];delete B[k]}delete r[I.id]}function L(I){for(const B in r){const k=r[B];if(k[I.id]===void 0)continue;const Y=k[I.id];for(const $ in Y)g(Y[$].object),delete Y[$];delete k[I.id]}}function F(){Z(),h=!0,l!==c&&(l=c,f(l.object))}function Z(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:d,reset:F,resetDefaultState:Z,dispose:M,releaseStatesOfGeometry:S,releaseStatesOfProgram:L,initAttributes:w,enableAttribute:v,disableUnusedAttributes:T}}function nf(o,t,e,n){const i=n.isWebGL2;let s;function a(h){s=h}function r(h,d){o.drawArrays(s,h,d),e.update(d,s,1)}function c(h,d,u){if(u===0)return;let f,g;if(i)f=o,g="drawArraysInstanced";else if(f=t.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",f===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}f[g](s,h,d,u),e.update(d,s,u)}function l(h,d,u){if(u===0)return;const f=t.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<u;g++)this.render(h[g],d[g]);else{f.multiDrawArraysWEBGL(s,h,0,d,0,u);let g=0;for(let y=0;y<u;y++)g+=d[y];e.update(g,s,1)}}this.setMode=a,this.render=r,this.renderInstances=c,this.renderMultiDraw=l}function sf(o,t,e){let n;function i(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){const E=t.get("EXT_texture_filter_anisotropic");n=o.getParameter(E.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function s(E){if(E==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";E="mediump"}return E==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&o.constructor.name==="WebGL2RenderingContext";let r=e.precision!==void 0?e.precision:"highp";const c=s(r);c!==r&&(console.warn("THREE.WebGLRenderer:",r,"not supported, using",c,"instead."),r=c);const l=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,d=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),u=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),f=o.getParameter(o.MAX_TEXTURE_SIZE),g=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),y=o.getParameter(o.MAX_VERTEX_ATTRIBS),m=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),p=o.getParameter(o.MAX_VARYING_VECTORS),_=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),w=u>0,v=a||t.has("OES_texture_float"),R=w&&v,T=a?o.getParameter(o.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:i,getMaxPrecision:s,precision:r,logarithmicDepthBuffer:h,maxTextures:d,maxVertexTextures:u,maxTextureSize:f,maxCubemapSize:g,maxAttributes:y,maxVertexUniforms:m,maxVaryings:p,maxFragmentUniforms:_,vertexTextures:w,floatFragmentTextures:v,floatVertexTextures:R,maxSamples:T}}function of(o){const t=this;let e=null,n=0,i=!1,s=!1;const a=new Bn,r=new Zt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,u){const f=d.length!==0||u||n!==0||i;return i=u,n=d.length,f},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(d,u){e=h(d,u,0)},this.setState=function(d,u,f){const g=d.clippingPlanes,y=d.clipIntersection,m=d.clipShadows,p=o.get(d);if(!i||g===null||g.length===0||s&&!m)s?h(null):l();else{const _=s?0:n,w=_*4;let v=p.clippingState||null;c.value=v,v=h(g,u,w,f);for(let R=0;R!==w;++R)v[R]=e[R];p.clippingState=v,this.numIntersection=y?this.numPlanes:0,this.numPlanes+=_}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(d,u,f,g){const y=d!==null?d.length:0;let m=null;if(y!==0){if(m=c.value,g!==!0||m===null){const p=f+y*4,_=u.matrixWorldInverse;r.getNormalMatrix(_),(m===null||m.length<p)&&(m=new Float32Array(p));for(let w=0,v=f;w!==y;++w,v+=4)a.copy(d[w]).applyMatrix4(_,r),a.normal.toArray(m,v),m[v+3]=a.constant}c.value=m,c.needsUpdate=!0}return t.numPlanes=y,t.numIntersection=0,m}}function af(o){let t=new WeakMap;function e(a,r){return r===Xo?a.mapping=Mi:r===qo&&(a.mapping=Si),a}function n(a){if(a&&a.isTexture){const r=a.mapping;if(r===Xo||r===qo)if(t.has(a)){const c=t.get(a).texture;return e(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new yh(c.height/2);return l.fromEquirectangularTexture(o,a),t.set(a,l),a.addEventListener("dispose",i),e(l.texture,a.mapping)}else return null}}return a}function i(a){const r=a.target;r.removeEventListener("dispose",i);const c=t.get(r);c!==void 0&&(t.delete(r),c.dispose())}function s(){t=new WeakMap}return{get:n,dispose:s}}class Ac extends bc{constructor(t=-1,e=1,n=1,i=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let s=n-t,a=n+t,r=i+e,c=i-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,a=s+l*this.view.width,r-=h*this.view.offsetY,c=r-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,r,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}const yi=4,gr=[.125,.215,.35,.446,.526,.582],zn=20,Po=new Ac,yr=new Xt;let Lo=null,Io=0,Do=0;const Fn=(1+Math.sqrt(5))/2,hi=1/Fn,wr=[new P(1,1,1),new P(-1,1,1),new P(1,1,-1),new P(-1,1,-1),new P(0,Fn,hi),new P(0,Fn,-hi),new P(hi,0,Fn),new P(-hi,0,Fn),new P(Fn,hi,0),new P(-Fn,hi,0)];class xr{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100){Lo=this._renderer.getRenderTarget(),Io=this._renderer.getActiveCubeFace(),Do=this._renderer.getActiveMipmapLevel(),this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(t,n,i,s),e>0&&this._blur(s,0,0,e),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Mr(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=_r(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Lo,Io,Do),t.scissorTest=!1,bs(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Mi||t.mapping===Si?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Lo=this._renderer.getRenderTarget(),Io=this._renderer.getActiveCubeFace(),Do=this._renderer.getActiveMipmapLevel();const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Xe,minFilter:Xe,generateMipmaps:!1,type:Wi,format:Qe,colorSpace:mn,depthBuffer:!1},i=vr(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=vr(t,e,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=rf(s)),this._blurMaterial=cf(s,t,e)}return i}_compileMaterial(t){const e=new x(this._lodPlanes[0],t);this._renderer.compile(e,Po)}_sceneToCubeUV(t,e,n,i){const r=new Be(90,1,e,n),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,d=h.autoClear,u=h.toneMapping;h.getClearColor(yr),h.toneMapping=En,h.autoClear=!1;const f=new Mt({name:"PMREM.Background",side:Fe,depthWrite:!1,depthTest:!1}),g=new x(new O,f);let y=!1;const m=t.background;m?m.isColor&&(f.color.copy(m),t.background=null,y=!0):(f.color.copy(yr),y=!0);for(let p=0;p<6;p++){const _=p%3;_===0?(r.up.set(0,c[p],0),r.lookAt(l[p],0,0)):_===1?(r.up.set(0,0,c[p]),r.lookAt(0,l[p],0)):(r.up.set(0,c[p],0),r.lookAt(0,0,l[p]));const w=this._cubeSize;bs(i,_*w,p>2?w:0,w,w),h.setRenderTarget(i),y&&h.render(g,r),h.render(t,r)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=u,h.autoClear=d,t.background=m}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===Mi||t.mapping===Si;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=Mr()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=_r());const s=i?this._cubemapMaterial:this._equirectMaterial,a=new x(this._lodPlanes[0],s),r=s.uniforms;r.envMap.value=t;const c=this._cubeSize;bs(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(a,Po)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let i=1;i<this._lodPlanes.length;i++){const s=Math.sqrt(this._sigmas[i]*this._sigmas[i]-this._sigmas[i-1]*this._sigmas[i-1]),a=wr[(i-1)%wr.length];this._blur(t,i-1,i,s,a)}e.autoClear=n}_blur(t,e,n,i,s){const a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,i,"latitudinal",s),this._halfBlur(a,t,n,n,i,"longitudinal",s)}_halfBlur(t,e,n,i,s,a,r){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,d=new x(this._lodPlanes[i],l),u=l.uniforms,f=this._sizeLods[n]-1,g=isFinite(s)?Math.PI/(2*f):2*Math.PI/(2*zn-1),y=s/g,m=isFinite(s)?1+Math.floor(h*y):zn;m>zn&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${zn}`);const p=[];let _=0;for(let E=0;E<zn;++E){const U=E/y,M=Math.exp(-U*U/2);p.push(M),E===0?_+=M:E<m&&(_+=2*M)}for(let E=0;E<p.length;E++)p[E]=p[E]/_;u.envMap.value=t.texture,u.samples.value=m,u.weights.value=p,u.latitudinal.value=a==="latitudinal",r&&(u.poleAxis.value=r);const{_lodMax:w}=this;u.dTheta.value=g,u.mipInt.value=w-n;const v=this._sizeLods[i],R=3*v*(i>w-yi?i-w+yi:0),T=4*(this._cubeSize-v);bs(e,R,T,3*v,2*v),c.setRenderTarget(e),c.render(d,Po)}}function rf(o){const t=[],e=[],n=[];let i=o;const s=o-yi+1+gr.length;for(let a=0;a<s;a++){const r=Math.pow(2,i);e.push(r);let c=1/r;a>o-yi?c=gr[a-o+yi-1]:a===0&&(c=0),n.push(c);const l=1/(r-2),h=-l,d=1+l,u=[h,h,d,h,d,d,h,h,d,d,h,d],f=6,g=6,y=3,m=2,p=1,_=new Float32Array(y*g*f),w=new Float32Array(m*g*f),v=new Float32Array(p*g*f);for(let T=0;T<f;T++){const E=T%3*2/3-1,U=T>2?0:-1,M=[E,U,0,E+2/3,U,0,E+2/3,U+1,0,E,U,0,E+2/3,U+1,0,E,U+1,0];_.set(M,y*g*T),w.set(u,m*g*T);const S=[T,T,T,T,T,T];v.set(S,p*g*T)}const R=new _e;R.setAttribute("position",new $e(_,y)),R.setAttribute("uv",new $e(w,m)),R.setAttribute("faceIndex",new $e(v,p)),t.push(R),i>yi&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function vr(o,t,e){const n=new Vn(o,t,e);return n.texture.mapping=qs,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function bs(o,t,e,n,i){o.viewport.set(t,e,n,i),o.scissor.set(t,e,n,i)}function cf(o,t,e){const n=new Float32Array(zn),i=new P(0,1,0);return new Wn({name:"SphericalGaussianBlur",defines:{n:zn,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:ha(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:bn,depthTest:!1,depthWrite:!1})}function _r(){return new Wn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:ha(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:bn,depthTest:!1,depthWrite:!1})}function Mr(){return new Wn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:ha(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:bn,depthTest:!1,depthWrite:!1})}function ha(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function lf(o){let t=new WeakMap,e=null;function n(r){if(r&&r.isTexture){const c=r.mapping,l=c===Xo||c===qo,h=c===Mi||c===Si;if(l||h)if(r.isRenderTargetTexture&&r.needsPMREMUpdate===!0){r.needsPMREMUpdate=!1;let d=t.get(r);return e===null&&(e=new xr(o)),d=l?e.fromEquirectangular(r,d):e.fromCubemap(r,d),t.set(r,d),d.texture}else{if(t.has(r))return t.get(r).texture;{const d=r.image;if(l&&d&&d.height>0||h&&d&&i(d)){e===null&&(e=new xr(o));const u=l?e.fromEquirectangular(r):e.fromCubemap(r);return t.set(r,u),r.addEventListener("dispose",s),u.texture}else return null}}}return r}function i(r){let c=0;const l=6;for(let h=0;h<l;h++)r[h]!==void 0&&c++;return c===l}function s(r){const c=r.target;c.removeEventListener("dispose",s);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function hf(o){const t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=o.getExtension("WEBGL_depth_texture")||o.getExtension("MOZ_WEBGL_depth_texture")||o.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=o.getExtension("EXT_texture_filter_anisotropic")||o.getExtension("MOZ_EXT_texture_filter_anisotropic")||o.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=o.getExtension("WEBGL_compressed_texture_s3tc")||o.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=o.getExtension("WEBGL_compressed_texture_pvrtc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=o.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){const i=e(n);return i===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function df(o,t,e,n){const i={},s=new WeakMap;function a(d){const u=d.target;u.index!==null&&t.remove(u.index);for(const g in u.attributes)t.remove(u.attributes[g]);for(const g in u.morphAttributes){const y=u.morphAttributes[g];for(let m=0,p=y.length;m<p;m++)t.remove(y[m])}u.removeEventListener("dispose",a),delete i[u.id];const f=s.get(u);f&&(t.remove(f),s.delete(u)),n.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,e.memory.geometries--}function r(d,u){return i[u.id]===!0||(u.addEventListener("dispose",a),i[u.id]=!0,e.memory.geometries++),u}function c(d){const u=d.attributes;for(const g in u)t.update(u[g],o.ARRAY_BUFFER);const f=d.morphAttributes;for(const g in f){const y=f[g];for(let m=0,p=y.length;m<p;m++)t.update(y[m],o.ARRAY_BUFFER)}}function l(d){const u=[],f=d.index,g=d.attributes.position;let y=0;if(f!==null){const _=f.array;y=f.version;for(let w=0,v=_.length;w<v;w+=3){const R=_[w+0],T=_[w+1],E=_[w+2];u.push(R,T,T,E,E,R)}}else if(g!==void 0){const _=g.array;y=g.version;for(let w=0,v=_.length/3-1;w<v;w+=3){const R=w+0,T=w+1,E=w+2;u.push(R,T,T,E,E,R)}}else return;const m=new(gc(u)?Mc:_c)(u,1);m.version=y;const p=s.get(d);p&&t.remove(p),s.set(d,m)}function h(d){const u=s.get(d);if(u){const f=d.index;f!==null&&u.version<f.version&&l(d)}else l(d);return s.get(d)}return{get:r,update:c,getWireframeAttribute:h}}function uf(o,t,e,n){const i=n.isWebGL2;let s;function a(f){s=f}let r,c;function l(f){r=f.type,c=f.bytesPerElement}function h(f,g){o.drawElements(s,g,r,f*c),e.update(g,s,1)}function d(f,g,y){if(y===0)return;let m,p;if(i)m=o,p="drawElementsInstanced";else if(m=t.get("ANGLE_instanced_arrays"),p="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[p](s,g,r,f*c,y),e.update(g,s,y)}function u(f,g,y){if(y===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<y;p++)this.render(f[p]/c,g[p]);else{m.multiDrawElementsWEBGL(s,g,0,r,f,0,y);let p=0;for(let _=0;_<y;_++)p+=g[_];e.update(p,s,1)}}this.setMode=a,this.setIndex=l,this.render=h,this.renderInstances=d,this.renderMultiDraw=u}function ff(o){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,r){switch(e.calls++,a){case o.TRIANGLES:e.triangles+=r*(s/3);break;case o.LINES:e.lines+=r*(s/2);break;case o.LINE_STRIP:e.lines+=r*(s-1);break;case o.LINE_LOOP:e.lines+=r*s;break;case o.POINTS:e.points+=r*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function pf(o,t){return o[0]-t[0]}function mf(o,t){return Math.abs(t[1])-Math.abs(o[1])}function gf(o,t,e){const n={},i=new Float32Array(8),s=new WeakMap,a=new ue,r=[];for(let l=0;l<8;l++)r[l]=[l,0];function c(l,h,d){const u=l.morphTargetInfluences;if(t.isWebGL2===!0){const f=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,g=f!==void 0?f.length:0;let y=s.get(h);if(y===void 0||y.count!==g){let I=function(){F.dispose(),s.delete(h),h.removeEventListener("dispose",I)};y!==void 0&&y.texture.dispose();const _=h.morphAttributes.position!==void 0,w=h.morphAttributes.normal!==void 0,v=h.morphAttributes.color!==void 0,R=h.morphAttributes.position||[],T=h.morphAttributes.normal||[],E=h.morphAttributes.color||[];let U=0;_===!0&&(U=1),w===!0&&(U=2),v===!0&&(U=3);let M=h.attributes.position.count*U,S=1;M>t.maxTextureSize&&(S=Math.ceil(M/t.maxTextureSize),M=t.maxTextureSize);const L=new Float32Array(M*S*4*g),F=new xc(L,M,S,g);F.type=Mn,F.needsUpdate=!0;const Z=U*4;for(let B=0;B<g;B++){const k=R[B],Y=T[B],$=E[B],q=M*S*4*B;for(let Q=0;Q<k.count;Q++){const it=Q*Z;_===!0&&(a.fromBufferAttribute(k,Q),L[q+it+0]=a.x,L[q+it+1]=a.y,L[q+it+2]=a.z,L[q+it+3]=0),w===!0&&(a.fromBufferAttribute(Y,Q),L[q+it+4]=a.x,L[q+it+5]=a.y,L[q+it+6]=a.z,L[q+it+7]=0),v===!0&&(a.fromBufferAttribute($,Q),L[q+it+8]=a.x,L[q+it+9]=a.y,L[q+it+10]=a.z,L[q+it+11]=$.itemSize===4?a.w:1)}}y={count:g,texture:F,size:new ut(M,S)},s.set(h,y),h.addEventListener("dispose",I)}let m=0;for(let _=0;_<u.length;_++)m+=u[_];const p=h.morphTargetsRelative?1:1-m;d.getUniforms().setValue(o,"morphTargetBaseInfluence",p),d.getUniforms().setValue(o,"morphTargetInfluences",u),d.getUniforms().setValue(o,"morphTargetsTexture",y.texture,e),d.getUniforms().setValue(o,"morphTargetsTextureSize",y.size)}else{const f=u===void 0?0:u.length;let g=n[h.id];if(g===void 0||g.length!==f){g=[];for(let w=0;w<f;w++)g[w]=[w,0];n[h.id]=g}for(let w=0;w<f;w++){const v=g[w];v[0]=w,v[1]=u[w]}g.sort(mf);for(let w=0;w<8;w++)w<f&&g[w][1]?(r[w][0]=g[w][0],r[w][1]=g[w][1]):(r[w][0]=Number.MAX_SAFE_INTEGER,r[w][1]=0);r.sort(pf);const y=h.morphAttributes.position,m=h.morphAttributes.normal;let p=0;for(let w=0;w<8;w++){const v=r[w],R=v[0],T=v[1];R!==Number.MAX_SAFE_INTEGER&&T?(y&&h.getAttribute("morphTarget"+w)!==y[R]&&h.setAttribute("morphTarget"+w,y[R]),m&&h.getAttribute("morphNormal"+w)!==m[R]&&h.setAttribute("morphNormal"+w,m[R]),i[w]=T,p+=T):(y&&h.hasAttribute("morphTarget"+w)===!0&&h.deleteAttribute("morphTarget"+w),m&&h.hasAttribute("morphNormal"+w)===!0&&h.deleteAttribute("morphNormal"+w),i[w]=0)}const _=h.morphTargetsRelative?1:1-p;d.getUniforms().setValue(o,"morphTargetBaseInfluence",_),d.getUniforms().setValue(o,"morphTargetInfluences",i)}}return{update:c}}function yf(o,t,e,n){let i=new WeakMap;function s(c){const l=n.render.frame,h=c.geometry,d=t.get(c,h);if(i.get(d)!==l&&(t.update(d),i.set(d,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",r)===!1&&c.addEventListener("dispose",r),i.get(c)!==l&&(e.update(c.instanceMatrix,o.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,o.ARRAY_BUFFER),i.set(c,l))),c.isSkinnedMesh){const u=c.skeleton;i.get(u)!==l&&(u.update(),i.set(u,l))}return d}function a(){i=new WeakMap}function r(c){const l=c.target;l.removeEventListener("dispose",r),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:s,dispose:a}}class Cc extends Oe{constructor(t,e,n,i,s,a,r,c,l,h){if(h=h!==void 0?h:Gn,h!==Gn&&h!==bi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===Gn&&(n=_n),n===void 0&&h===bi&&(n=kn),super(null,i,s,a,r,c,h,n,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=r!==void 0?r:Ue,this.minFilter=c!==void 0?c:Ue,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}const Rc=new Oe,Pc=new Cc(1,1);Pc.compareFunction=mc;const Lc=new xc,Ic=new th,Dc=new Ec,Sr=[],br=[],Er=new Float32Array(16),Tr=new Float32Array(9),Ar=new Float32Array(4);function Ai(o,t,e){const n=o[0];if(n<=0||n>0)return o;const i=t*e;let s=Sr[i];if(s===void 0&&(s=new Float32Array(i),Sr[i]=s),t!==0){n.toArray(s,0);for(let a=1,r=0;a!==t;++a)r+=e,o[a].toArray(s,r)}return s}function Me(o,t){if(o.length!==t.length)return!1;for(let e=0,n=o.length;e<n;e++)if(o[e]!==t[e])return!1;return!0}function Se(o,t){for(let e=0,n=t.length;e<n;e++)o[e]=t[e]}function Zs(o,t){let e=br[t];e===void 0&&(e=new Int32Array(t),br[t]=e);for(let n=0;n!==t;++n)e[n]=o.allocateTextureUnit();return e}function wf(o,t){const e=this.cache;e[0]!==t&&(o.uniform1f(this.addr,t),e[0]=t)}function xf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Me(e,t))return;o.uniform2fv(this.addr,t),Se(e,t)}}function vf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(o.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Me(e,t))return;o.uniform3fv(this.addr,t),Se(e,t)}}function _f(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Me(e,t))return;o.uniform4fv(this.addr,t),Se(e,t)}}function Mf(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(Me(e,t))return;o.uniformMatrix2fv(this.addr,!1,t),Se(e,t)}else{if(Me(e,n))return;Ar.set(n),o.uniformMatrix2fv(this.addr,!1,Ar),Se(e,n)}}function Sf(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(Me(e,t))return;o.uniformMatrix3fv(this.addr,!1,t),Se(e,t)}else{if(Me(e,n))return;Tr.set(n),o.uniformMatrix3fv(this.addr,!1,Tr),Se(e,n)}}function bf(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(Me(e,t))return;o.uniformMatrix4fv(this.addr,!1,t),Se(e,t)}else{if(Me(e,n))return;Er.set(n),o.uniformMatrix4fv(this.addr,!1,Er),Se(e,n)}}function Ef(o,t){const e=this.cache;e[0]!==t&&(o.uniform1i(this.addr,t),e[0]=t)}function Tf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Me(e,t))return;o.uniform2iv(this.addr,t),Se(e,t)}}function Af(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Me(e,t))return;o.uniform3iv(this.addr,t),Se(e,t)}}function Cf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Me(e,t))return;o.uniform4iv(this.addr,t),Se(e,t)}}function Rf(o,t){const e=this.cache;e[0]!==t&&(o.uniform1ui(this.addr,t),e[0]=t)}function Pf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Me(e,t))return;o.uniform2uiv(this.addr,t),Se(e,t)}}function Lf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Me(e,t))return;o.uniform3uiv(this.addr,t),Se(e,t)}}function If(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Me(e,t))return;o.uniform4uiv(this.addr,t),Se(e,t)}}function Df(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i);const s=this.type===o.SAMPLER_2D_SHADOW?Pc:Rc;e.setTexture2D(t||s,i)}function Uf(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Ic,i)}function Nf(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||Dc,i)}function Bf(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||Lc,i)}function Ff(o){switch(o){case 5126:return wf;case 35664:return xf;case 35665:return vf;case 35666:return _f;case 35674:return Mf;case 35675:return Sf;case 35676:return bf;case 5124:case 35670:return Ef;case 35667:case 35671:return Tf;case 35668:case 35672:return Af;case 35669:case 35673:return Cf;case 5125:return Rf;case 36294:return Pf;case 36295:return Lf;case 36296:return If;case 35678:case 36198:case 36298:case 36306:case 35682:return Df;case 35679:case 36299:case 36307:return Uf;case 35680:case 36300:case 36308:case 36293:return Nf;case 36289:case 36303:case 36311:case 36292:return Bf}}function Of(o,t){o.uniform1fv(this.addr,t)}function zf(o,t){const e=Ai(t,this.size,2);o.uniform2fv(this.addr,e)}function kf(o,t){const e=Ai(t,this.size,3);o.uniform3fv(this.addr,e)}function Gf(o,t){const e=Ai(t,this.size,4);o.uniform4fv(this.addr,e)}function Hf(o,t){const e=Ai(t,this.size,4);o.uniformMatrix2fv(this.addr,!1,e)}function Vf(o,t){const e=Ai(t,this.size,9);o.uniformMatrix3fv(this.addr,!1,e)}function Wf(o,t){const e=Ai(t,this.size,16);o.uniformMatrix4fv(this.addr,!1,e)}function Xf(o,t){o.uniform1iv(this.addr,t)}function qf(o,t){o.uniform2iv(this.addr,t)}function Yf(o,t){o.uniform3iv(this.addr,t)}function $f(o,t){o.uniform4iv(this.addr,t)}function jf(o,t){o.uniform1uiv(this.addr,t)}function Zf(o,t){o.uniform2uiv(this.addr,t)}function Kf(o,t){o.uniform3uiv(this.addr,t)}function Jf(o,t){o.uniform4uiv(this.addr,t)}function Qf(o,t,e){const n=this.cache,i=t.length,s=Zs(e,i);Me(n,s)||(o.uniform1iv(this.addr,s),Se(n,s));for(let a=0;a!==i;++a)e.setTexture2D(t[a]||Rc,s[a])}function tp(o,t,e){const n=this.cache,i=t.length,s=Zs(e,i);Me(n,s)||(o.uniform1iv(this.addr,s),Se(n,s));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||Ic,s[a])}function ep(o,t,e){const n=this.cache,i=t.length,s=Zs(e,i);Me(n,s)||(o.uniform1iv(this.addr,s),Se(n,s));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||Dc,s[a])}function np(o,t,e){const n=this.cache,i=t.length,s=Zs(e,i);Me(n,s)||(o.uniform1iv(this.addr,s),Se(n,s));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||Lc,s[a])}function ip(o){switch(o){case 5126:return Of;case 35664:return zf;case 35665:return kf;case 35666:return Gf;case 35674:return Hf;case 35675:return Vf;case 35676:return Wf;case 5124:case 35670:return Xf;case 35667:case 35671:return qf;case 35668:case 35672:return Yf;case 35669:case 35673:return $f;case 5125:return jf;case 36294:return Zf;case 36295:return Kf;case 36296:return Jf;case 35678:case 36198:case 36298:case 36306:case 35682:return Qf;case 35679:case 36299:case 36307:return tp;case 35680:case 36300:case 36308:case 36293:return ep;case 36289:case 36303:case 36311:case 36292:return np}}class sp{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Ff(e.type)}}class op{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=ip(e.type)}}class ap{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let s=0,a=i.length;s!==a;++s){const r=i[s];r.setValue(t,e[r.id],n)}}}const Uo=/(\w+)(\])?(\[|\.)?/g;function Cr(o,t){o.seq.push(t),o.map[t.id]=t}function rp(o,t,e){const n=o.name,i=n.length;for(Uo.lastIndex=0;;){const s=Uo.exec(n),a=Uo.lastIndex;let r=s[1];const c=s[2]==="]",l=s[3];if(c&&(r=r|0),l===void 0||l==="["&&a+2===i){Cr(e,l===void 0?new sp(r,o,t):new op(r,o,t));break}else{let d=e.map[r];d===void 0&&(d=new ap(r),Cr(e,d)),e=d}}}class Us{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const s=t.getActiveUniform(e,i),a=t.getUniformLocation(e,s.name);rp(s,a,this)}}setValue(t,e,n,i){const s=this.map[e];s!==void 0&&s.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let s=0,a=e.length;s!==a;++s){const r=e[s],c=n[r.id];c.needsUpdate!==!1&&r.setValue(t,c.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,s=t.length;i!==s;++i){const a=t[i];a.id in e&&n.push(a)}return n}}function Rr(o,t,e){const n=o.createShader(t);return o.shaderSource(n,e),o.compileShader(n),n}const cp=37297;let lp=0;function hp(o,t){const e=o.split(`
`),n=[],i=Math.max(t-6,0),s=Math.min(t+6,e.length);for(let a=i;a<s;a++){const r=a+1;n.push(`${r===t?">":" "} ${r}: ${e[a]}`)}return n.join(`
`)}function dp(o){const t=oe.getPrimaries(oe.workingColorSpace),e=oe.getPrimaries(o);let n;switch(t===e?n="":t===zs&&e===Os?n="LinearDisplayP3ToLinearSRGB":t===Os&&e===zs&&(n="LinearSRGBToLinearDisplayP3"),o){case mn:case Ys:return[n,"LinearTransferOETF"];case Te:case ra:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",o),[n,"LinearTransferOETF"]}}function Pr(o,t,e){const n=o.getShaderParameter(t,o.COMPILE_STATUS),i=o.getShaderInfoLog(t).trim();if(n&&i==="")return"";const s=/ERROR: 0:(\d+)/.exec(i);if(s){const a=parseInt(s[1]);return e.toUpperCase()+`

`+i+`

`+hp(o.getShaderSource(t),a)}else return i}function up(o,t){const e=dp(t);return`vec4 ${o}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function fp(o,t){let e;switch(t){case sc:e="Linear";break;case bl:e="Reinhard";break;case El:e="OptimizedCineon";break;case Tl:e="ACESFilmic";break;case Cl:e="AgX";break;case Al:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+o+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function pp(o){return[o.extensionDerivatives||o.envMapCubeUVHeight||o.bumpMap||o.normalMapTangentSpace||o.clearcoatNormalMap||o.flatShading||o.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(o.extensionFragDepth||o.logarithmicDepthBuffer)&&o.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",o.extensionDrawBuffers&&o.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(o.extensionShaderTextureLOD||o.envMap||o.transmission)&&o.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(wi).join(`
`)}function mp(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(wi).join(`
`)}function gp(o){const t=[];for(const e in o){const n=o[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function yp(o,t){const e={},n=o.getProgramParameter(t,o.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const s=o.getActiveAttrib(t,i),a=s.name;let r=1;s.type===o.FLOAT_MAT2&&(r=2),s.type===o.FLOAT_MAT3&&(r=3),s.type===o.FLOAT_MAT4&&(r=4),e[a]={type:s.type,location:o.getAttribLocation(t,a),locationSize:r}}return e}function wi(o){return o!==""}function Lr(o,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Ir(o,t){return o.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const wp=/^[ \t]*#include +<([\w\d./]+)>/gm;function Jo(o){return o.replace(wp,vp)}const xp=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function vp(o,t){let e=jt[t];if(e===void 0){const n=xp.get(t);if(n!==void 0)e=jt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Jo(e)}const _p=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Dr(o){return o.replace(_p,Mp)}function Mp(o,t,e,n){let i="";for(let s=parseInt(t);s<parseInt(e);s++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return i}function Ur(o){let t="precision "+o.precision+` float;
precision `+o.precision+" int;";return o.precision==="highp"?t+=`
#define HIGH_PRECISION`:o.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Sp(o){let t="SHADOWMAP_TYPE_BASIC";return o.shadowMapType===sa?t="SHADOWMAP_TYPE_PCF":o.shadowMapType===ic?t="SHADOWMAP_TYPE_PCF_SOFT":o.shadowMapType===dn&&(t="SHADOWMAP_TYPE_VSM"),t}function bp(o){let t="ENVMAP_TYPE_CUBE";if(o.envMap)switch(o.envMapMode){case Mi:case Si:t="ENVMAP_TYPE_CUBE";break;case qs:t="ENVMAP_TYPE_CUBE_UV";break}return t}function Ep(o){let t="ENVMAP_MODE_REFLECTION";if(o.envMap)switch(o.envMapMode){case Si:t="ENVMAP_MODE_REFRACTION";break}return t}function Tp(o){let t="ENVMAP_BLENDING_NONE";if(o.envMap)switch(o.combine){case oa:t="ENVMAP_BLENDING_MULTIPLY";break;case Ml:t="ENVMAP_BLENDING_MIX";break;case Sl:t="ENVMAP_BLENDING_ADD";break}return t}function Ap(o){const t=o.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function Cp(o,t,e,n){const i=o.getContext(),s=e.defines;let a=e.vertexShader,r=e.fragmentShader;const c=Sp(e),l=bp(e),h=Ep(e),d=Tp(e),u=Ap(e),f=e.isWebGL2?"":pp(e),g=mp(e),y=gp(s),m=i.createProgram();let p,_,w=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(wi).join(`
`),p.length>0&&(p+=`
`),_=[f,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(wi).join(`
`),_.length>0&&(_+=`
`)):(p=[Ur(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(wi).join(`
`),_=[f,Ur(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+d:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==En?"#define TONE_MAPPING":"",e.toneMapping!==En?jt.tonemapping_pars_fragment:"",e.toneMapping!==En?fp("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",jt.colorspace_pars_fragment,up("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(wi).join(`
`)),a=Jo(a),a=Lr(a,e),a=Ir(a,e),r=Jo(r),r=Lr(r,e),r=Ir(r,e),a=Dr(a),r=Dr(r),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(w=`#version 300 es
`,p=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,_=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===Ja?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Ja?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+_);const v=w+p+a,R=w+_+r,T=Rr(i,i.VERTEX_SHADER,v),E=Rr(i,i.FRAGMENT_SHADER,R);i.attachShader(m,T),i.attachShader(m,E),e.index0AttributeName!==void 0?i.bindAttribLocation(m,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(m,0,"position"),i.linkProgram(m);function U(F){if(o.debug.checkShaderErrors){const Z=i.getProgramInfoLog(m).trim(),I=i.getShaderInfoLog(T).trim(),B=i.getShaderInfoLog(E).trim();let k=!0,Y=!0;if(i.getProgramParameter(m,i.LINK_STATUS)===!1)if(k=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(i,m,T,E);else{const $=Pr(i,T,"vertex"),q=Pr(i,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(m,i.VALIDATE_STATUS)+`

Program Info Log: `+Z+`
`+$+`
`+q)}else Z!==""?console.warn("THREE.WebGLProgram: Program Info Log:",Z):(I===""||B==="")&&(Y=!1);Y&&(F.diagnostics={runnable:k,programLog:Z,vertexShader:{log:I,prefix:p},fragmentShader:{log:B,prefix:_}})}i.deleteShader(T),i.deleteShader(E),M=new Us(i,m),S=yp(i,m)}let M;this.getUniforms=function(){return M===void 0&&U(this),M};let S;this.getAttributes=function(){return S===void 0&&U(this),S};let L=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return L===!1&&(L=i.getProgramParameter(m,cp)),L},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(m),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=lp++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=T,this.fragmentShader=E,this}let Rp=0;class Pp{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),s=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new Lp(t),e.set(t,n)),n}}class Lp{constructor(t){this.id=Rp++,this.code=t,this.usedTimes=0}}function Ip(o,t,e,n,i,s,a){const r=new ca,c=new Pp,l=[],h=i.isWebGL2,d=i.logarithmicDepthBuffer,u=i.vertexTextures;let f=i.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(M){return M===0?"uv":`uv${M}`}function m(M,S,L,F,Z){const I=F.fog,B=Z.geometry,k=M.isMeshStandardMaterial?F.environment:null,Y=(M.isMeshStandardMaterial?e:t).get(M.envMap||k),$=Y&&Y.mapping===qs?Y.image.height:null,q=g[M.type];M.precision!==null&&(f=i.getMaxPrecision(M.precision),f!==M.precision&&console.warn("THREE.WebGLProgram.getParameters:",M.precision,"not supported, using",f,"instead."));const Q=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,it=Q!==void 0?Q.length:0;let rt=0;B.morphAttributes.position!==void 0&&(rt=1),B.morphAttributes.normal!==void 0&&(rt=2),B.morphAttributes.color!==void 0&&(rt=3);let V,et,ft,Et;if(q){const be=tn[q];V=be.vertexShader,et=be.fragmentShader}else V=M.vertexShader,et=M.fragmentShader,c.update(M),ft=c.getVertexShaderID(M),Et=c.getFragmentShaderID(M);const _t=o.getRenderTarget(),Nt=Z.isInstancedMesh===!0,zt=Z.isBatchedMesh===!0,Tt=!!M.map,Ft=!!M.matcap,D=!!Y,pt=!!M.aoMap,K=!!M.lightMap,ct=!!M.bumpMap,tt=!!M.normalMap,It=!!M.displacementMap,mt=!!M.emissiveMap,A=!!M.metalnessMap,b=!!M.roughnessMap,z=M.anisotropy>0,st=M.clearcoat>0,ot=M.iridescence>0,nt=M.sheen>0,At=M.transmission>0,wt=z&&!!M.anisotropyMap,St=st&&!!M.clearcoatMap,kt=st&&!!M.clearcoatNormalMap,Ht=st&&!!M.clearcoatRoughnessMap,at=ot&&!!M.iridescenceMap,Qt=ot&&!!M.iridescenceThicknessMap,Yt=nt&&!!M.sheenColorMap,Vt=nt&&!!M.sheenRoughnessMap,Bt=!!M.specularMap,Ct=!!M.specularColorMap,Wt=!!M.specularIntensityMap,Kt=At&&!!M.transmissionMap,ne=At&&!!M.thicknessMap,qt=!!M.gradientMap,gt=!!M.alphaMap,N=M.alphaTest>0,xt=!!M.alphaHash,vt=!!M.extensions,Gt=!!B.attributes.uv1,Ot=!!B.attributes.uv2,te=!!B.attributes.uv3;let ie=En;return M.toneMapped&&(_t===null||_t.isXRRenderTarget===!0)&&(ie=o.toneMapping),{isWebGL2:h,shaderID:q,shaderType:M.type,shaderName:M.name,vertexShader:V,fragmentShader:et,defines:M.defines,customVertexShaderID:ft,customFragmentShaderID:Et,isRawShaderMaterial:M.isRawShaderMaterial===!0,glslVersion:M.glslVersion,precision:f,batching:zt,instancing:Nt,instancingColor:Nt&&Z.instanceColor!==null,supportsVertexTextures:u,outputColorSpace:_t===null?o.outputColorSpace:_t.isXRRenderTarget===!0?_t.texture.colorSpace:mn,map:Tt,matcap:Ft,envMap:D,envMapMode:D&&Y.mapping,envMapCubeUVHeight:$,aoMap:pt,lightMap:K,bumpMap:ct,normalMap:tt,displacementMap:u&&It,emissiveMap:mt,normalMapObjectSpace:tt&&M.normalMapType===kl,normalMapTangentSpace:tt&&M.normalMapType===pc,metalnessMap:A,roughnessMap:b,anisotropy:z,anisotropyMap:wt,clearcoat:st,clearcoatMap:St,clearcoatNormalMap:kt,clearcoatRoughnessMap:Ht,iridescence:ot,iridescenceMap:at,iridescenceThicknessMap:Qt,sheen:nt,sheenColorMap:Yt,sheenRoughnessMap:Vt,specularMap:Bt,specularColorMap:Ct,specularIntensityMap:Wt,transmission:At,transmissionMap:Kt,thicknessMap:ne,gradientMap:qt,opaque:M.transparent===!1&&M.blending===vi,alphaMap:gt,alphaTest:N,alphaHash:xt,combine:M.combine,mapUv:Tt&&y(M.map.channel),aoMapUv:pt&&y(M.aoMap.channel),lightMapUv:K&&y(M.lightMap.channel),bumpMapUv:ct&&y(M.bumpMap.channel),normalMapUv:tt&&y(M.normalMap.channel),displacementMapUv:It&&y(M.displacementMap.channel),emissiveMapUv:mt&&y(M.emissiveMap.channel),metalnessMapUv:A&&y(M.metalnessMap.channel),roughnessMapUv:b&&y(M.roughnessMap.channel),anisotropyMapUv:wt&&y(M.anisotropyMap.channel),clearcoatMapUv:St&&y(M.clearcoatMap.channel),clearcoatNormalMapUv:kt&&y(M.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ht&&y(M.clearcoatRoughnessMap.channel),iridescenceMapUv:at&&y(M.iridescenceMap.channel),iridescenceThicknessMapUv:Qt&&y(M.iridescenceThicknessMap.channel),sheenColorMapUv:Yt&&y(M.sheenColorMap.channel),sheenRoughnessMapUv:Vt&&y(M.sheenRoughnessMap.channel),specularMapUv:Bt&&y(M.specularMap.channel),specularColorMapUv:Ct&&y(M.specularColorMap.channel),specularIntensityMapUv:Wt&&y(M.specularIntensityMap.channel),transmissionMapUv:Kt&&y(M.transmissionMap.channel),thicknessMapUv:ne&&y(M.thicknessMap.channel),alphaMapUv:gt&&y(M.alphaMap.channel),vertexTangents:!!B.attributes.tangent&&(tt||z),vertexColors:M.vertexColors,vertexAlphas:M.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,vertexUv1s:Gt,vertexUv2s:Ot,vertexUv3s:te,pointsUvs:Z.isPoints===!0&&!!B.attributes.uv&&(Tt||gt),fog:!!I,useFog:M.fog===!0,fogExp2:I&&I.isFogExp2,flatShading:M.flatShading===!0,sizeAttenuation:M.sizeAttenuation===!0,logarithmicDepthBuffer:d,skinning:Z.isSkinnedMesh===!0,morphTargets:B.morphAttributes.position!==void 0,morphNormals:B.morphAttributes.normal!==void 0,morphColors:B.morphAttributes.color!==void 0,morphTargetsCount:it,morphTextureStride:rt,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:M.dithering,shadowMapEnabled:o.shadowMap.enabled&&L.length>0,shadowMapType:o.shadowMap.type,toneMapping:ie,useLegacyLights:o._useLegacyLights,decodeVideoTexture:Tt&&M.map.isVideoTexture===!0&&oe.getTransfer(M.map.colorSpace)===le,premultipliedAlpha:M.premultipliedAlpha,doubleSided:M.side===he,flipSided:M.side===Fe,useDepthPacking:M.depthPacking>=0,depthPacking:M.depthPacking||0,index0AttributeName:M.index0AttributeName,extensionDerivatives:vt&&M.extensions.derivatives===!0,extensionFragDepth:vt&&M.extensions.fragDepth===!0,extensionDrawBuffers:vt&&M.extensions.drawBuffers===!0,extensionShaderTextureLOD:vt&&M.extensions.shaderTextureLOD===!0,extensionClipCullDistance:vt&&M.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:M.customProgramCacheKey()}}function p(M){const S=[];if(M.shaderID?S.push(M.shaderID):(S.push(M.customVertexShaderID),S.push(M.customFragmentShaderID)),M.defines!==void 0)for(const L in M.defines)S.push(L),S.push(M.defines[L]);return M.isRawShaderMaterial===!1&&(_(S,M),w(S,M),S.push(o.outputColorSpace)),S.push(M.customProgramCacheKey),S.join()}function _(M,S){M.push(S.precision),M.push(S.outputColorSpace),M.push(S.envMapMode),M.push(S.envMapCubeUVHeight),M.push(S.mapUv),M.push(S.alphaMapUv),M.push(S.lightMapUv),M.push(S.aoMapUv),M.push(S.bumpMapUv),M.push(S.normalMapUv),M.push(S.displacementMapUv),M.push(S.emissiveMapUv),M.push(S.metalnessMapUv),M.push(S.roughnessMapUv),M.push(S.anisotropyMapUv),M.push(S.clearcoatMapUv),M.push(S.clearcoatNormalMapUv),M.push(S.clearcoatRoughnessMapUv),M.push(S.iridescenceMapUv),M.push(S.iridescenceThicknessMapUv),M.push(S.sheenColorMapUv),M.push(S.sheenRoughnessMapUv),M.push(S.specularMapUv),M.push(S.specularColorMapUv),M.push(S.specularIntensityMapUv),M.push(S.transmissionMapUv),M.push(S.thicknessMapUv),M.push(S.combine),M.push(S.fogExp2),M.push(S.sizeAttenuation),M.push(S.morphTargetsCount),M.push(S.morphAttributeCount),M.push(S.numDirLights),M.push(S.numPointLights),M.push(S.numSpotLights),M.push(S.numSpotLightMaps),M.push(S.numHemiLights),M.push(S.numRectAreaLights),M.push(S.numDirLightShadows),M.push(S.numPointLightShadows),M.push(S.numSpotLightShadows),M.push(S.numSpotLightShadowsWithMaps),M.push(S.numLightProbes),M.push(S.shadowMapType),M.push(S.toneMapping),M.push(S.numClippingPlanes),M.push(S.numClipIntersection),M.push(S.depthPacking)}function w(M,S){r.disableAll(),S.isWebGL2&&r.enable(0),S.supportsVertexTextures&&r.enable(1),S.instancing&&r.enable(2),S.instancingColor&&r.enable(3),S.matcap&&r.enable(4),S.envMap&&r.enable(5),S.normalMapObjectSpace&&r.enable(6),S.normalMapTangentSpace&&r.enable(7),S.clearcoat&&r.enable(8),S.iridescence&&r.enable(9),S.alphaTest&&r.enable(10),S.vertexColors&&r.enable(11),S.vertexAlphas&&r.enable(12),S.vertexUv1s&&r.enable(13),S.vertexUv2s&&r.enable(14),S.vertexUv3s&&r.enable(15),S.vertexTangents&&r.enable(16),S.anisotropy&&r.enable(17),S.alphaHash&&r.enable(18),S.batching&&r.enable(19),M.push(r.mask),r.disableAll(),S.fog&&r.enable(0),S.useFog&&r.enable(1),S.flatShading&&r.enable(2),S.logarithmicDepthBuffer&&r.enable(3),S.skinning&&r.enable(4),S.morphTargets&&r.enable(5),S.morphNormals&&r.enable(6),S.morphColors&&r.enable(7),S.premultipliedAlpha&&r.enable(8),S.shadowMapEnabled&&r.enable(9),S.useLegacyLights&&r.enable(10),S.doubleSided&&r.enable(11),S.flipSided&&r.enable(12),S.useDepthPacking&&r.enable(13),S.dithering&&r.enable(14),S.transmission&&r.enable(15),S.sheen&&r.enable(16),S.opaque&&r.enable(17),S.pointsUvs&&r.enable(18),S.decodeVideoTexture&&r.enable(19),M.push(r.mask)}function v(M){const S=g[M.type];let L;if(S){const F=tn[S];L=fh.clone(F.uniforms)}else L=M.uniforms;return L}function R(M,S){let L;for(let F=0,Z=l.length;F<Z;F++){const I=l[F];if(I.cacheKey===S){L=I,++L.usedTimes;break}}return L===void 0&&(L=new Cp(o,S,M,s),l.push(L)),L}function T(M){if(--M.usedTimes===0){const S=l.indexOf(M);l[S]=l[l.length-1],l.pop(),M.destroy()}}function E(M){c.remove(M)}function U(){c.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:v,acquireProgram:R,releaseProgram:T,releaseShaderCache:E,programs:l,dispose:U}}function Dp(){let o=new WeakMap;function t(s){let a=o.get(s);return a===void 0&&(a={},o.set(s,a)),a}function e(s){o.delete(s)}function n(s,a,r){o.get(s)[a]=r}function i(){o=new WeakMap}return{get:t,remove:e,update:n,dispose:i}}function Up(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.material.id!==t.material.id?o.material.id-t.material.id:o.z!==t.z?o.z-t.z:o.id-t.id}function Nr(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.z!==t.z?t.z-o.z:o.id-t.id}function Br(){const o=[];let t=0;const e=[],n=[],i=[];function s(){t=0,e.length=0,n.length=0,i.length=0}function a(d,u,f,g,y,m){let p=o[t];return p===void 0?(p={id:d.id,object:d,geometry:u,material:f,groupOrder:g,renderOrder:d.renderOrder,z:y,group:m},o[t]=p):(p.id=d.id,p.object=d,p.geometry=u,p.material=f,p.groupOrder=g,p.renderOrder=d.renderOrder,p.z=y,p.group=m),t++,p}function r(d,u,f,g,y,m){const p=a(d,u,f,g,y,m);f.transmission>0?n.push(p):f.transparent===!0?i.push(p):e.push(p)}function c(d,u,f,g,y,m){const p=a(d,u,f,g,y,m);f.transmission>0?n.unshift(p):f.transparent===!0?i.unshift(p):e.unshift(p)}function l(d,u){e.length>1&&e.sort(d||Up),n.length>1&&n.sort(u||Nr),i.length>1&&i.sort(u||Nr)}function h(){for(let d=t,u=o.length;d<u;d++){const f=o[d];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:i,init:s,push:r,unshift:c,finish:h,sort:l}}function Np(){let o=new WeakMap;function t(n,i){const s=o.get(n);let a;return s===void 0?(a=new Br,o.set(n,[a])):i>=s.length?(a=new Br,s.push(a)):a=s[i],a}function e(){o=new WeakMap}return{get:t,dispose:e}}function Bp(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new P,color:new Xt};break;case"SpotLight":e={position:new P,direction:new P,color:new Xt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new P,color:new Xt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new P,skyColor:new Xt,groundColor:new Xt};break;case"RectAreaLight":e={color:new Xt,position:new P,halfWidth:new P,halfHeight:new P};break}return o[t.id]=e,e}}}function Fp(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ut,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[t.id]=e,e}}}let Op=0;function zp(o,t){return(t.castShadow?2:0)-(o.castShadow?2:0)+(t.map?1:0)-(o.map?1:0)}function kp(o,t){const e=new Bp,n=Fp(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)i.probe.push(new P);const s=new P,a=new fe,r=new fe;function c(h,d){let u=0,f=0,g=0;for(let F=0;F<9;F++)i.probe[F].set(0,0,0);let y=0,m=0,p=0,_=0,w=0,v=0,R=0,T=0,E=0,U=0,M=0;h.sort(zp);const S=d===!0?Math.PI:1;for(let F=0,Z=h.length;F<Z;F++){const I=h[F],B=I.color,k=I.intensity,Y=I.distance,$=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)u+=B.r*k*S,f+=B.g*k*S,g+=B.b*k*S;else if(I.isLightProbe){for(let q=0;q<9;q++)i.probe[q].addScaledVector(I.sh.coefficients[q],k);M++}else if(I.isDirectionalLight){const q=e.get(I);if(q.color.copy(I.color).multiplyScalar(I.intensity*S),I.castShadow){const Q=I.shadow,it=n.get(I);it.shadowBias=Q.bias,it.shadowNormalBias=Q.normalBias,it.shadowRadius=Q.radius,it.shadowMapSize=Q.mapSize,i.directionalShadow[y]=it,i.directionalShadowMap[y]=$,i.directionalShadowMatrix[y]=I.shadow.matrix,v++}i.directional[y]=q,y++}else if(I.isSpotLight){const q=e.get(I);q.position.setFromMatrixPosition(I.matrixWorld),q.color.copy(B).multiplyScalar(k*S),q.distance=Y,q.coneCos=Math.cos(I.angle),q.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),q.decay=I.decay,i.spot[p]=q;const Q=I.shadow;if(I.map&&(i.spotLightMap[E]=I.map,E++,Q.updateMatrices(I),I.castShadow&&U++),i.spotLightMatrix[p]=Q.matrix,I.castShadow){const it=n.get(I);it.shadowBias=Q.bias,it.shadowNormalBias=Q.normalBias,it.shadowRadius=Q.radius,it.shadowMapSize=Q.mapSize,i.spotShadow[p]=it,i.spotShadowMap[p]=$,T++}p++}else if(I.isRectAreaLight){const q=e.get(I);q.color.copy(B).multiplyScalar(k),q.halfWidth.set(I.width*.5,0,0),q.halfHeight.set(0,I.height*.5,0),i.rectArea[_]=q,_++}else if(I.isPointLight){const q=e.get(I);if(q.color.copy(I.color).multiplyScalar(I.intensity*S),q.distance=I.distance,q.decay=I.decay,I.castShadow){const Q=I.shadow,it=n.get(I);it.shadowBias=Q.bias,it.shadowNormalBias=Q.normalBias,it.shadowRadius=Q.radius,it.shadowMapSize=Q.mapSize,it.shadowCameraNear=Q.camera.near,it.shadowCameraFar=Q.camera.far,i.pointShadow[m]=it,i.pointShadowMap[m]=$,i.pointShadowMatrix[m]=I.shadow.matrix,R++}i.point[m]=q,m++}else if(I.isHemisphereLight){const q=e.get(I);q.skyColor.copy(I.color).multiplyScalar(k*S),q.groundColor.copy(I.groundColor).multiplyScalar(k*S),i.hemi[w]=q,w++}}_>0&&(t.isWebGL2?o.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=yt.LTC_FLOAT_1,i.rectAreaLTC2=yt.LTC_FLOAT_2):(i.rectAreaLTC1=yt.LTC_HALF_1,i.rectAreaLTC2=yt.LTC_HALF_2):o.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=yt.LTC_FLOAT_1,i.rectAreaLTC2=yt.LTC_FLOAT_2):o.has("OES_texture_half_float_linear")===!0?(i.rectAreaLTC1=yt.LTC_HALF_1,i.rectAreaLTC2=yt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),i.ambient[0]=u,i.ambient[1]=f,i.ambient[2]=g;const L=i.hash;(L.directionalLength!==y||L.pointLength!==m||L.spotLength!==p||L.rectAreaLength!==_||L.hemiLength!==w||L.numDirectionalShadows!==v||L.numPointShadows!==R||L.numSpotShadows!==T||L.numSpotMaps!==E||L.numLightProbes!==M)&&(i.directional.length=y,i.spot.length=p,i.rectArea.length=_,i.point.length=m,i.hemi.length=w,i.directionalShadow.length=v,i.directionalShadowMap.length=v,i.pointShadow.length=R,i.pointShadowMap.length=R,i.spotShadow.length=T,i.spotShadowMap.length=T,i.directionalShadowMatrix.length=v,i.pointShadowMatrix.length=R,i.spotLightMatrix.length=T+E-U,i.spotLightMap.length=E,i.numSpotLightShadowsWithMaps=U,i.numLightProbes=M,L.directionalLength=y,L.pointLength=m,L.spotLength=p,L.rectAreaLength=_,L.hemiLength=w,L.numDirectionalShadows=v,L.numPointShadows=R,L.numSpotShadows=T,L.numSpotMaps=E,L.numLightProbes=M,i.version=Op++)}function l(h,d){let u=0,f=0,g=0,y=0,m=0;const p=d.matrixWorldInverse;for(let _=0,w=h.length;_<w;_++){const v=h[_];if(v.isDirectionalLight){const R=i.directional[u];R.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(p),u++}else if(v.isSpotLight){const R=i.spot[g];R.position.setFromMatrixPosition(v.matrixWorld),R.position.applyMatrix4(p),R.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(p),g++}else if(v.isRectAreaLight){const R=i.rectArea[y];R.position.setFromMatrixPosition(v.matrixWorld),R.position.applyMatrix4(p),r.identity(),a.copy(v.matrixWorld),a.premultiply(p),r.extractRotation(a),R.halfWidth.set(v.width*.5,0,0),R.halfHeight.set(0,v.height*.5,0),R.halfWidth.applyMatrix4(r),R.halfHeight.applyMatrix4(r),y++}else if(v.isPointLight){const R=i.point[f];R.position.setFromMatrixPosition(v.matrixWorld),R.position.applyMatrix4(p),f++}else if(v.isHemisphereLight){const R=i.hemi[m];R.direction.setFromMatrixPosition(v.matrixWorld),R.direction.transformDirection(p),m++}}}return{setup:c,setupView:l,state:i}}function Fr(o,t){const e=new kp(o,t),n=[],i=[];function s(){n.length=0,i.length=0}function a(d){n.push(d)}function r(d){i.push(d)}function c(d){e.setup(n,d)}function l(d){e.setupView(n,d)}return{init:s,state:{lightsArray:n,shadowsArray:i,lights:e},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:r}}function Gp(o,t){let e=new WeakMap;function n(s,a=0){const r=e.get(s);let c;return r===void 0?(c=new Fr(o,t),e.set(s,[c])):a>=r.length?(c=new Fr(o,t),r.push(c)):c=r[a],c}function i(){e=new WeakMap}return{get:n,dispose:i}}class Hp extends Cn{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Ol,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class Vp extends Cn{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const Wp=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Xp=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function qp(o,t,e){let n=new la;const i=new ut,s=new ut,a=new ue,r=new Hp({depthPacking:zl}),c=new Vp,l={},h=e.maxTextureSize,d={[An]:Fe,[Fe]:An,[he]:he},u=new Wn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ut},radius:{value:4}},vertexShader:Wp,fragmentShader:Xp}),f=u.clone();f.defines.HORIZONTAL_PASS=1;const g=new _e;g.setAttribute("position",new $e(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const y=new x(g,u),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=sa;let p=this.type;this.render=function(T,E,U){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||T.length===0)return;const M=o.getRenderTarget(),S=o.getActiveCubeFace(),L=o.getActiveMipmapLevel(),F=o.state;F.setBlending(bn),F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const Z=p!==dn&&this.type===dn,I=p===dn&&this.type!==dn;for(let B=0,k=T.length;B<k;B++){const Y=T[B],$=Y.shadow;if($===void 0){console.warn("THREE.WebGLShadowMap:",Y,"has no shadow.");continue}if($.autoUpdate===!1&&$.needsUpdate===!1)continue;i.copy($.mapSize);const q=$.getFrameExtents();if(i.multiply(q),s.copy($.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(s.x=Math.floor(h/q.x),i.x=s.x*q.x,$.mapSize.x=s.x),i.y>h&&(s.y=Math.floor(h/q.y),i.y=s.y*q.y,$.mapSize.y=s.y)),$.map===null||Z===!0||I===!0){const it=this.type!==dn?{minFilter:Ue,magFilter:Ue}:{};$.map!==null&&$.map.dispose(),$.map=new Vn(i.x,i.y,it),$.map.texture.name=Y.name+".shadowMap",$.camera.updateProjectionMatrix()}o.setRenderTarget($.map),o.clear();const Q=$.getViewportCount();for(let it=0;it<Q;it++){const rt=$.getViewport(it);a.set(s.x*rt.x,s.y*rt.y,s.x*rt.z,s.y*rt.w),F.viewport(a),$.updateMatrices(Y,it),n=$.getFrustum(),v(E,U,$.camera,Y,this.type)}$.isPointLightShadow!==!0&&this.type===dn&&_($,U),$.needsUpdate=!1}p=this.type,m.needsUpdate=!1,o.setRenderTarget(M,S,L)};function _(T,E){const U=t.update(y);u.defines.VSM_SAMPLES!==T.blurSamples&&(u.defines.VSM_SAMPLES=T.blurSamples,f.defines.VSM_SAMPLES=T.blurSamples,u.needsUpdate=!0,f.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new Vn(i.x,i.y)),u.uniforms.shadow_pass.value=T.map.texture,u.uniforms.resolution.value=T.mapSize,u.uniforms.radius.value=T.radius,o.setRenderTarget(T.mapPass),o.clear(),o.renderBufferDirect(E,null,U,u,y,null),f.uniforms.shadow_pass.value=T.mapPass.texture,f.uniforms.resolution.value=T.mapSize,f.uniforms.radius.value=T.radius,o.setRenderTarget(T.map),o.clear(),o.renderBufferDirect(E,null,U,f,y,null)}function w(T,E,U,M){let S=null;const L=U.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(L!==void 0)S=L;else if(S=U.isPointLight===!0?c:r,o.localClippingEnabled&&E.clipShadows===!0&&Array.isArray(E.clippingPlanes)&&E.clippingPlanes.length!==0||E.displacementMap&&E.displacementScale!==0||E.alphaMap&&E.alphaTest>0||E.map&&E.alphaTest>0){const F=S.uuid,Z=E.uuid;let I=l[F];I===void 0&&(I={},l[F]=I);let B=I[Z];B===void 0&&(B=S.clone(),I[Z]=B,E.addEventListener("dispose",R)),S=B}if(S.visible=E.visible,S.wireframe=E.wireframe,M===dn?S.side=E.shadowSide!==null?E.shadowSide:E.side:S.side=E.shadowSide!==null?E.shadowSide:d[E.side],S.alphaMap=E.alphaMap,S.alphaTest=E.alphaTest,S.map=E.map,S.clipShadows=E.clipShadows,S.clippingPlanes=E.clippingPlanes,S.clipIntersection=E.clipIntersection,S.displacementMap=E.displacementMap,S.displacementScale=E.displacementScale,S.displacementBias=E.displacementBias,S.wireframeLinewidth=E.wireframeLinewidth,S.linewidth=E.linewidth,U.isPointLight===!0&&S.isMeshDistanceMaterial===!0){const F=o.properties.get(S);F.light=U}return S}function v(T,E,U,M,S){if(T.visible===!1)return;if(T.layers.test(E.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&S===dn)&&(!T.frustumCulled||n.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,T.matrixWorld);const Z=t.update(T),I=T.material;if(Array.isArray(I)){const B=Z.groups;for(let k=0,Y=B.length;k<Y;k++){const $=B[k],q=I[$.materialIndex];if(q&&q.visible){const Q=w(T,q,M,S);T.onBeforeShadow(o,T,E,U,Z,Q,$),o.renderBufferDirect(U,null,Z,Q,T,$),T.onAfterShadow(o,T,E,U,Z,Q,$)}}}else if(I.visible){const B=w(T,I,M,S);T.onBeforeShadow(o,T,E,U,Z,B,null),o.renderBufferDirect(U,null,Z,B,T,null),T.onAfterShadow(o,T,E,U,Z,B,null)}}const F=T.children;for(let Z=0,I=F.length;Z<I;Z++)v(F[Z],E,U,M,S)}function R(T){T.target.removeEventListener("dispose",R);for(const U in l){const M=l[U],S=T.target.uuid;S in M&&(M[S].dispose(),delete M[S])}}}function Yp(o,t,e){const n=e.isWebGL2;function i(){let N=!1;const xt=new ue;let vt=null;const Gt=new ue(0,0,0,0);return{setMask:function(Ot){vt!==Ot&&!N&&(o.colorMask(Ot,Ot,Ot,Ot),vt=Ot)},setLocked:function(Ot){N=Ot},setClear:function(Ot,te,ie,we,be){be===!0&&(Ot*=we,te*=we,ie*=we),xt.set(Ot,te,ie,we),Gt.equals(xt)===!1&&(o.clearColor(Ot,te,ie,we),Gt.copy(xt))},reset:function(){N=!1,vt=null,Gt.set(-1,0,0,0)}}}function s(){let N=!1,xt=null,vt=null,Gt=null;return{setTest:function(Ot){Ot?zt(o.DEPTH_TEST):Tt(o.DEPTH_TEST)},setMask:function(Ot){xt!==Ot&&!N&&(o.depthMask(Ot),xt=Ot)},setFunc:function(Ot){if(vt!==Ot){switch(Ot){case ml:o.depthFunc(o.NEVER);break;case gl:o.depthFunc(o.ALWAYS);break;case yl:o.depthFunc(o.LESS);break;case Bs:o.depthFunc(o.LEQUAL);break;case wl:o.depthFunc(o.EQUAL);break;case xl:o.depthFunc(o.GEQUAL);break;case vl:o.depthFunc(o.GREATER);break;case _l:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}vt=Ot}},setLocked:function(Ot){N=Ot},setClear:function(Ot){Gt!==Ot&&(o.clearDepth(Ot),Gt=Ot)},reset:function(){N=!1,xt=null,vt=null,Gt=null}}}function a(){let N=!1,xt=null,vt=null,Gt=null,Ot=null,te=null,ie=null,we=null,be=null;return{setTest:function(ee){N||(ee?zt(o.STENCIL_TEST):Tt(o.STENCIL_TEST))},setMask:function(ee){xt!==ee&&!N&&(o.stencilMask(ee),xt=ee)},setFunc:function(ee,xe,ze){(vt!==ee||Gt!==xe||Ot!==ze)&&(o.stencilFunc(ee,xe,ze),vt=ee,Gt=xe,Ot=ze)},setOp:function(ee,xe,ze){(te!==ee||ie!==xe||we!==ze)&&(o.stencilOp(ee,xe,ze),te=ee,ie=xe,we=ze)},setLocked:function(ee){N=ee},setClear:function(ee){be!==ee&&(o.clearStencil(ee),be=ee)},reset:function(){N=!1,xt=null,vt=null,Gt=null,Ot=null,te=null,ie=null,we=null,be=null}}}const r=new i,c=new s,l=new a,h=new WeakMap,d=new WeakMap;let u={},f={},g=new WeakMap,y=[],m=null,p=!1,_=null,w=null,v=null,R=null,T=null,E=null,U=null,M=new Xt(0,0,0),S=0,L=!1,F=null,Z=null,I=null,B=null,k=null;const Y=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let $=!1,q=0;const Q=o.getParameter(o.VERSION);Q.indexOf("WebGL")!==-1?(q=parseFloat(/^WebGL (\d)/.exec(Q)[1]),$=q>=1):Q.indexOf("OpenGL ES")!==-1&&(q=parseFloat(/^OpenGL ES (\d)/.exec(Q)[1]),$=q>=2);let it=null,rt={};const V=o.getParameter(o.SCISSOR_BOX),et=o.getParameter(o.VIEWPORT),ft=new ue().fromArray(V),Et=new ue().fromArray(et);function _t(N,xt,vt,Gt){const Ot=new Uint8Array(4),te=o.createTexture();o.bindTexture(N,te),o.texParameteri(N,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(N,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let ie=0;ie<vt;ie++)n&&(N===o.TEXTURE_3D||N===o.TEXTURE_2D_ARRAY)?o.texImage3D(xt,0,o.RGBA,1,1,Gt,0,o.RGBA,o.UNSIGNED_BYTE,Ot):o.texImage2D(xt+ie,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,Ot);return te}const Nt={};Nt[o.TEXTURE_2D]=_t(o.TEXTURE_2D,o.TEXTURE_2D,1),Nt[o.TEXTURE_CUBE_MAP]=_t(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(Nt[o.TEXTURE_2D_ARRAY]=_t(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),Nt[o.TEXTURE_3D]=_t(o.TEXTURE_3D,o.TEXTURE_3D,1,1)),r.setClear(0,0,0,1),c.setClear(1),l.setClear(0),zt(o.DEPTH_TEST),c.setFunc(Bs),mt(!1),A(va),zt(o.CULL_FACE),tt(bn);function zt(N){u[N]!==!0&&(o.enable(N),u[N]=!0)}function Tt(N){u[N]!==!1&&(o.disable(N),u[N]=!1)}function Ft(N,xt){return f[N]!==xt?(o.bindFramebuffer(N,xt),f[N]=xt,n&&(N===o.DRAW_FRAMEBUFFER&&(f[o.FRAMEBUFFER]=xt),N===o.FRAMEBUFFER&&(f[o.DRAW_FRAMEBUFFER]=xt)),!0):!1}function D(N,xt){let vt=y,Gt=!1;if(N)if(vt=g.get(xt),vt===void 0&&(vt=[],g.set(xt,vt)),N.isWebGLMultipleRenderTargets){const Ot=N.texture;if(vt.length!==Ot.length||vt[0]!==o.COLOR_ATTACHMENT0){for(let te=0,ie=Ot.length;te<ie;te++)vt[te]=o.COLOR_ATTACHMENT0+te;vt.length=Ot.length,Gt=!0}}else vt[0]!==o.COLOR_ATTACHMENT0&&(vt[0]=o.COLOR_ATTACHMENT0,Gt=!0);else vt[0]!==o.BACK&&(vt[0]=o.BACK,Gt=!0);Gt&&(e.isWebGL2?o.drawBuffers(vt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(vt))}function pt(N){return m!==N?(o.useProgram(N),m=N,!0):!1}const K={[On]:o.FUNC_ADD,[tl]:o.FUNC_SUBTRACT,[el]:o.FUNC_REVERSE_SUBTRACT};if(n)K[Sa]=o.MIN,K[ba]=o.MAX;else{const N=t.get("EXT_blend_minmax");N!==null&&(K[Sa]=N.MIN_EXT,K[ba]=N.MAX_EXT)}const ct={[nl]:o.ZERO,[il]:o.ONE,[sl]:o.SRC_COLOR,[Vo]:o.SRC_ALPHA,[hl]:o.SRC_ALPHA_SATURATE,[cl]:o.DST_COLOR,[al]:o.DST_ALPHA,[ol]:o.ONE_MINUS_SRC_COLOR,[Wo]:o.ONE_MINUS_SRC_ALPHA,[ll]:o.ONE_MINUS_DST_COLOR,[rl]:o.ONE_MINUS_DST_ALPHA,[dl]:o.CONSTANT_COLOR,[ul]:o.ONE_MINUS_CONSTANT_COLOR,[fl]:o.CONSTANT_ALPHA,[pl]:o.ONE_MINUS_CONSTANT_ALPHA};function tt(N,xt,vt,Gt,Ot,te,ie,we,be,ee){if(N===bn){p===!0&&(Tt(o.BLEND),p=!1);return}if(p===!1&&(zt(o.BLEND),p=!0),N!==Qc){if(N!==_||ee!==L){if((w!==On||T!==On)&&(o.blendEquation(o.FUNC_ADD),w=On,T=On),ee)switch(N){case vi:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case Ns:o.blendFunc(o.ONE,o.ONE);break;case _a:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case Ma:o.blendFuncSeparate(o.ZERO,o.SRC_COLOR,o.ZERO,o.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}else switch(N){case vi:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case Ns:o.blendFunc(o.SRC_ALPHA,o.ONE);break;case _a:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case Ma:o.blendFunc(o.ZERO,o.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}v=null,R=null,E=null,U=null,M.set(0,0,0),S=0,_=N,L=ee}return}Ot=Ot||xt,te=te||vt,ie=ie||Gt,(xt!==w||Ot!==T)&&(o.blendEquationSeparate(K[xt],K[Ot]),w=xt,T=Ot),(vt!==v||Gt!==R||te!==E||ie!==U)&&(o.blendFuncSeparate(ct[vt],ct[Gt],ct[te],ct[ie]),v=vt,R=Gt,E=te,U=ie),(we.equals(M)===!1||be!==S)&&(o.blendColor(we.r,we.g,we.b,be),M.copy(we),S=be),_=N,L=!1}function It(N,xt){N.side===he?Tt(o.CULL_FACE):zt(o.CULL_FACE);let vt=N.side===Fe;xt&&(vt=!vt),mt(vt),N.blending===vi&&N.transparent===!1?tt(bn):tt(N.blending,N.blendEquation,N.blendSrc,N.blendDst,N.blendEquationAlpha,N.blendSrcAlpha,N.blendDstAlpha,N.blendColor,N.blendAlpha,N.premultipliedAlpha),c.setFunc(N.depthFunc),c.setTest(N.depthTest),c.setMask(N.depthWrite),r.setMask(N.colorWrite);const Gt=N.stencilWrite;l.setTest(Gt),Gt&&(l.setMask(N.stencilWriteMask),l.setFunc(N.stencilFunc,N.stencilRef,N.stencilFuncMask),l.setOp(N.stencilFail,N.stencilZFail,N.stencilZPass)),z(N.polygonOffset,N.polygonOffsetFactor,N.polygonOffsetUnits),N.alphaToCoverage===!0?zt(o.SAMPLE_ALPHA_TO_COVERAGE):Tt(o.SAMPLE_ALPHA_TO_COVERAGE)}function mt(N){F!==N&&(N?o.frontFace(o.CW):o.frontFace(o.CCW),F=N)}function A(N){N!==Kc?(zt(o.CULL_FACE),N!==Z&&(N===va?o.cullFace(o.BACK):N===Jc?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):Tt(o.CULL_FACE),Z=N}function b(N){N!==I&&($&&o.lineWidth(N),I=N)}function z(N,xt,vt){N?(zt(o.POLYGON_OFFSET_FILL),(B!==xt||k!==vt)&&(o.polygonOffset(xt,vt),B=xt,k=vt)):Tt(o.POLYGON_OFFSET_FILL)}function st(N){N?zt(o.SCISSOR_TEST):Tt(o.SCISSOR_TEST)}function ot(N){N===void 0&&(N=o.TEXTURE0+Y-1),it!==N&&(o.activeTexture(N),it=N)}function nt(N,xt,vt){vt===void 0&&(it===null?vt=o.TEXTURE0+Y-1:vt=it);let Gt=rt[vt];Gt===void 0&&(Gt={type:void 0,texture:void 0},rt[vt]=Gt),(Gt.type!==N||Gt.texture!==xt)&&(it!==vt&&(o.activeTexture(vt),it=vt),o.bindTexture(N,xt||Nt[N]),Gt.type=N,Gt.texture=xt)}function At(){const N=rt[it];N!==void 0&&N.type!==void 0&&(o.bindTexture(N.type,null),N.type=void 0,N.texture=void 0)}function wt(){try{o.compressedTexImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function St(){try{o.compressedTexImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function kt(){try{o.texSubImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ht(){try{o.texSubImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function at(){try{o.compressedTexSubImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Qt(){try{o.compressedTexSubImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Yt(){try{o.texStorage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Vt(){try{o.texStorage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Bt(){try{o.texImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ct(){try{o.texImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Wt(N){ft.equals(N)===!1&&(o.scissor(N.x,N.y,N.z,N.w),ft.copy(N))}function Kt(N){Et.equals(N)===!1&&(o.viewport(N.x,N.y,N.z,N.w),Et.copy(N))}function ne(N,xt){let vt=d.get(xt);vt===void 0&&(vt=new WeakMap,d.set(xt,vt));let Gt=vt.get(N);Gt===void 0&&(Gt=o.getUniformBlockIndex(xt,N.name),vt.set(N,Gt))}function qt(N,xt){const Gt=d.get(xt).get(N);h.get(xt)!==Gt&&(o.uniformBlockBinding(xt,Gt,N.__bindingPointIndex),h.set(xt,Gt))}function gt(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),n===!0&&(o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null)),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),u={},it=null,rt={},f={},g=new WeakMap,y=[],m=null,p=!1,_=null,w=null,v=null,R=null,T=null,E=null,U=null,M=new Xt(0,0,0),S=0,L=!1,F=null,Z=null,I=null,B=null,k=null,ft.set(0,0,o.canvas.width,o.canvas.height),Et.set(0,0,o.canvas.width,o.canvas.height),r.reset(),c.reset(),l.reset()}return{buffers:{color:r,depth:c,stencil:l},enable:zt,disable:Tt,bindFramebuffer:Ft,drawBuffers:D,useProgram:pt,setBlending:tt,setMaterial:It,setFlipSided:mt,setCullFace:A,setLineWidth:b,setPolygonOffset:z,setScissorTest:st,activeTexture:ot,bindTexture:nt,unbindTexture:At,compressedTexImage2D:wt,compressedTexImage3D:St,texImage2D:Bt,texImage3D:Ct,updateUBOMapping:ne,uniformBlockBinding:qt,texStorage2D:Yt,texStorage3D:Vt,texSubImage2D:kt,texSubImage3D:Ht,compressedTexSubImage2D:at,compressedTexSubImage3D:Qt,scissor:Wt,viewport:Kt,reset:gt}}function $p(o,t,e,n,i,s,a){const r=i.isWebGL2,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap;let d;const u=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(A,b){return f?new OffscreenCanvas(A,b):Hs("canvas")}function y(A,b,z,st){let ot=1;if((A.width>st||A.height>st)&&(ot=st/Math.max(A.width,A.height)),ot<1||b===!0)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){const nt=b?Ko:Math.floor,At=nt(ot*A.width),wt=nt(ot*A.height);d===void 0&&(d=g(At,wt));const St=z?g(At,wt):d;return St.width=At,St.height=wt,St.getContext("2d").drawImage(A,0,0,At,wt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+At+"x"+wt+")."),St}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A;return A}function m(A){return Qa(A.width)&&Qa(A.height)}function p(A){return r?!1:A.wrapS!==Je||A.wrapT!==Je||A.minFilter!==Ue&&A.minFilter!==Xe}function _(A,b){return A.generateMipmaps&&b&&A.minFilter!==Ue&&A.minFilter!==Xe}function w(A){o.generateMipmap(A)}function v(A,b,z,st,ot=!1){if(r===!1)return b;if(A!==null){if(o[A]!==void 0)return o[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let nt=b;if(b===o.RED&&(z===o.FLOAT&&(nt=o.R32F),z===o.HALF_FLOAT&&(nt=o.R16F),z===o.UNSIGNED_BYTE&&(nt=o.R8)),b===o.RED_INTEGER&&(z===o.UNSIGNED_BYTE&&(nt=o.R8UI),z===o.UNSIGNED_SHORT&&(nt=o.R16UI),z===o.UNSIGNED_INT&&(nt=o.R32UI),z===o.BYTE&&(nt=o.R8I),z===o.SHORT&&(nt=o.R16I),z===o.INT&&(nt=o.R32I)),b===o.RG&&(z===o.FLOAT&&(nt=o.RG32F),z===o.HALF_FLOAT&&(nt=o.RG16F),z===o.UNSIGNED_BYTE&&(nt=o.RG8)),b===o.RGBA){const At=ot?Fs:oe.getTransfer(st);z===o.FLOAT&&(nt=o.RGBA32F),z===o.HALF_FLOAT&&(nt=o.RGBA16F),z===o.UNSIGNED_BYTE&&(nt=At===le?o.SRGB8_ALPHA8:o.RGBA8),z===o.UNSIGNED_SHORT_4_4_4_4&&(nt=o.RGBA4),z===o.UNSIGNED_SHORT_5_5_5_1&&(nt=o.RGB5_A1)}return(nt===o.R16F||nt===o.R32F||nt===o.RG16F||nt===o.RG32F||nt===o.RGBA16F||nt===o.RGBA32F)&&t.get("EXT_color_buffer_float"),nt}function R(A,b,z){return _(A,z)===!0||A.isFramebufferTexture&&A.minFilter!==Ue&&A.minFilter!==Xe?Math.log2(Math.max(b.width,b.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?b.mipmaps.length:1}function T(A){return A===Ue||A===Ea||A===so?o.NEAREST:o.LINEAR}function E(A){const b=A.target;b.removeEventListener("dispose",E),M(b),b.isVideoTexture&&h.delete(b)}function U(A){const b=A.target;b.removeEventListener("dispose",U),L(b)}function M(A){const b=n.get(A);if(b.__webglInit===void 0)return;const z=A.source,st=u.get(z);if(st){const ot=st[b.__cacheKey];ot.usedTimes--,ot.usedTimes===0&&S(A),Object.keys(st).length===0&&u.delete(z)}n.remove(A)}function S(A){const b=n.get(A);o.deleteTexture(b.__webglTexture);const z=A.source,st=u.get(z);delete st[b.__cacheKey],a.memory.textures--}function L(A){const b=A.texture,z=n.get(A),st=n.get(b);if(st.__webglTexture!==void 0&&(o.deleteTexture(st.__webglTexture),a.memory.textures--),A.depthTexture&&A.depthTexture.dispose(),A.isWebGLCubeRenderTarget)for(let ot=0;ot<6;ot++){if(Array.isArray(z.__webglFramebuffer[ot]))for(let nt=0;nt<z.__webglFramebuffer[ot].length;nt++)o.deleteFramebuffer(z.__webglFramebuffer[ot][nt]);else o.deleteFramebuffer(z.__webglFramebuffer[ot]);z.__webglDepthbuffer&&o.deleteRenderbuffer(z.__webglDepthbuffer[ot])}else{if(Array.isArray(z.__webglFramebuffer))for(let ot=0;ot<z.__webglFramebuffer.length;ot++)o.deleteFramebuffer(z.__webglFramebuffer[ot]);else o.deleteFramebuffer(z.__webglFramebuffer);if(z.__webglDepthbuffer&&o.deleteRenderbuffer(z.__webglDepthbuffer),z.__webglMultisampledFramebuffer&&o.deleteFramebuffer(z.__webglMultisampledFramebuffer),z.__webglColorRenderbuffer)for(let ot=0;ot<z.__webglColorRenderbuffer.length;ot++)z.__webglColorRenderbuffer[ot]&&o.deleteRenderbuffer(z.__webglColorRenderbuffer[ot]);z.__webglDepthRenderbuffer&&o.deleteRenderbuffer(z.__webglDepthRenderbuffer)}if(A.isWebGLMultipleRenderTargets)for(let ot=0,nt=b.length;ot<nt;ot++){const At=n.get(b[ot]);At.__webglTexture&&(o.deleteTexture(At.__webglTexture),a.memory.textures--),n.remove(b[ot])}n.remove(b),n.remove(A)}let F=0;function Z(){F=0}function I(){const A=F;return A>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+i.maxTextures),F+=1,A}function B(A){const b=[];return b.push(A.wrapS),b.push(A.wrapT),b.push(A.wrapR||0),b.push(A.magFilter),b.push(A.minFilter),b.push(A.anisotropy),b.push(A.internalFormat),b.push(A.format),b.push(A.type),b.push(A.generateMipmaps),b.push(A.premultiplyAlpha),b.push(A.flipY),b.push(A.unpackAlignment),b.push(A.colorSpace),b.join()}function k(A,b){const z=n.get(A);if(A.isVideoTexture&&It(A),A.isRenderTargetTexture===!1&&A.version>0&&z.__version!==A.version){const st=A.image;if(st===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(st.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ft(z,A,b);return}}e.bindTexture(o.TEXTURE_2D,z.__webglTexture,o.TEXTURE0+b)}function Y(A,b){const z=n.get(A);if(A.version>0&&z.__version!==A.version){ft(z,A,b);return}e.bindTexture(o.TEXTURE_2D_ARRAY,z.__webglTexture,o.TEXTURE0+b)}function $(A,b){const z=n.get(A);if(A.version>0&&z.__version!==A.version){ft(z,A,b);return}e.bindTexture(o.TEXTURE_3D,z.__webglTexture,o.TEXTURE0+b)}function q(A,b){const z=n.get(A);if(A.version>0&&z.__version!==A.version){Et(z,A,b);return}e.bindTexture(o.TEXTURE_CUBE_MAP,z.__webglTexture,o.TEXTURE0+b)}const Q={[Yo]:o.REPEAT,[Je]:o.CLAMP_TO_EDGE,[$o]:o.MIRRORED_REPEAT},it={[Ue]:o.NEAREST,[Ea]:o.NEAREST_MIPMAP_NEAREST,[so]:o.NEAREST_MIPMAP_LINEAR,[Xe]:o.LINEAR,[Rl]:o.LINEAR_MIPMAP_NEAREST,[Vi]:o.LINEAR_MIPMAP_LINEAR},rt={[Gl]:o.NEVER,[Yl]:o.ALWAYS,[Hl]:o.LESS,[mc]:o.LEQUAL,[Vl]:o.EQUAL,[ql]:o.GEQUAL,[Wl]:o.GREATER,[Xl]:o.NOTEQUAL};function V(A,b,z){if(z?(o.texParameteri(A,o.TEXTURE_WRAP_S,Q[b.wrapS]),o.texParameteri(A,o.TEXTURE_WRAP_T,Q[b.wrapT]),(A===o.TEXTURE_3D||A===o.TEXTURE_2D_ARRAY)&&o.texParameteri(A,o.TEXTURE_WRAP_R,Q[b.wrapR]),o.texParameteri(A,o.TEXTURE_MAG_FILTER,it[b.magFilter]),o.texParameteri(A,o.TEXTURE_MIN_FILTER,it[b.minFilter])):(o.texParameteri(A,o.TEXTURE_WRAP_S,o.CLAMP_TO_EDGE),o.texParameteri(A,o.TEXTURE_WRAP_T,o.CLAMP_TO_EDGE),(A===o.TEXTURE_3D||A===o.TEXTURE_2D_ARRAY)&&o.texParameteri(A,o.TEXTURE_WRAP_R,o.CLAMP_TO_EDGE),(b.wrapS!==Je||b.wrapT!==Je)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),o.texParameteri(A,o.TEXTURE_MAG_FILTER,T(b.magFilter)),o.texParameteri(A,o.TEXTURE_MIN_FILTER,T(b.minFilter)),b.minFilter!==Ue&&b.minFilter!==Xe&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),b.compareFunction&&(o.texParameteri(A,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(A,o.TEXTURE_COMPARE_FUNC,rt[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){const st=t.get("EXT_texture_filter_anisotropic");if(b.magFilter===Ue||b.minFilter!==so&&b.minFilter!==Vi||b.type===Mn&&t.has("OES_texture_float_linear")===!1||r===!1&&b.type===Wi&&t.has("OES_texture_half_float_linear")===!1)return;(b.anisotropy>1||n.get(b).__currentAnisotropy)&&(o.texParameterf(A,st.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,i.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy)}}function et(A,b){let z=!1;A.__webglInit===void 0&&(A.__webglInit=!0,b.addEventListener("dispose",E));const st=b.source;let ot=u.get(st);ot===void 0&&(ot={},u.set(st,ot));const nt=B(b);if(nt!==A.__cacheKey){ot[nt]===void 0&&(ot[nt]={texture:o.createTexture(),usedTimes:0},a.memory.textures++,z=!0),ot[nt].usedTimes++;const At=ot[A.__cacheKey];At!==void 0&&(ot[A.__cacheKey].usedTimes--,At.usedTimes===0&&S(b)),A.__cacheKey=nt,A.__webglTexture=ot[nt].texture}return z}function ft(A,b,z){let st=o.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(st=o.TEXTURE_2D_ARRAY),b.isData3DTexture&&(st=o.TEXTURE_3D);const ot=et(A,b),nt=b.source;e.bindTexture(st,A.__webglTexture,o.TEXTURE0+z);const At=n.get(nt);if(nt.version!==At.__version||ot===!0){e.activeTexture(o.TEXTURE0+z);const wt=oe.getPrimaries(oe.workingColorSpace),St=b.colorSpace===Ye?null:oe.getPrimaries(b.colorSpace),kt=b.colorSpace===Ye||wt===St?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,b.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,b.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,kt);const Ht=p(b)&&m(b.image)===!1;let at=y(b.image,Ht,!1,i.maxTextureSize);at=mt(b,at);const Qt=m(at)||r,Yt=s.convert(b.format,b.colorSpace);let Vt=s.convert(b.type),Bt=v(b.internalFormat,Yt,Vt,b.colorSpace,b.isVideoTexture);V(st,b,Qt);let Ct;const Wt=b.mipmaps,Kt=r&&b.isVideoTexture!==!0&&Bt!==uc,ne=At.__version===void 0||ot===!0,qt=R(b,at,Qt);if(b.isDepthTexture)Bt=o.DEPTH_COMPONENT,r?b.type===Mn?Bt=o.DEPTH_COMPONENT32F:b.type===_n?Bt=o.DEPTH_COMPONENT24:b.type===kn?Bt=o.DEPTH24_STENCIL8:Bt=o.DEPTH_COMPONENT16:b.type===Mn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),b.format===Gn&&Bt===o.DEPTH_COMPONENT&&b.type!==aa&&b.type!==_n&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),b.type=_n,Vt=s.convert(b.type)),b.format===bi&&Bt===o.DEPTH_COMPONENT&&(Bt=o.DEPTH_STENCIL,b.type!==kn&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),b.type=kn,Vt=s.convert(b.type))),ne&&(Kt?e.texStorage2D(o.TEXTURE_2D,1,Bt,at.width,at.height):e.texImage2D(o.TEXTURE_2D,0,Bt,at.width,at.height,0,Yt,Vt,null));else if(b.isDataTexture)if(Wt.length>0&&Qt){Kt&&ne&&e.texStorage2D(o.TEXTURE_2D,qt,Bt,Wt[0].width,Wt[0].height);for(let gt=0,N=Wt.length;gt<N;gt++)Ct=Wt[gt],Kt?e.texSubImage2D(o.TEXTURE_2D,gt,0,0,Ct.width,Ct.height,Yt,Vt,Ct.data):e.texImage2D(o.TEXTURE_2D,gt,Bt,Ct.width,Ct.height,0,Yt,Vt,Ct.data);b.generateMipmaps=!1}else Kt?(ne&&e.texStorage2D(o.TEXTURE_2D,qt,Bt,at.width,at.height),e.texSubImage2D(o.TEXTURE_2D,0,0,0,at.width,at.height,Yt,Vt,at.data)):e.texImage2D(o.TEXTURE_2D,0,Bt,at.width,at.height,0,Yt,Vt,at.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){Kt&&ne&&e.texStorage3D(o.TEXTURE_2D_ARRAY,qt,Bt,Wt[0].width,Wt[0].height,at.depth);for(let gt=0,N=Wt.length;gt<N;gt++)Ct=Wt[gt],b.format!==Qe?Yt!==null?Kt?e.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,gt,0,0,0,Ct.width,Ct.height,at.depth,Yt,Ct.data,0,0):e.compressedTexImage3D(o.TEXTURE_2D_ARRAY,gt,Bt,Ct.width,Ct.height,at.depth,0,Ct.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Kt?e.texSubImage3D(o.TEXTURE_2D_ARRAY,gt,0,0,0,Ct.width,Ct.height,at.depth,Yt,Vt,Ct.data):e.texImage3D(o.TEXTURE_2D_ARRAY,gt,Bt,Ct.width,Ct.height,at.depth,0,Yt,Vt,Ct.data)}else{Kt&&ne&&e.texStorage2D(o.TEXTURE_2D,qt,Bt,Wt[0].width,Wt[0].height);for(let gt=0,N=Wt.length;gt<N;gt++)Ct=Wt[gt],b.format!==Qe?Yt!==null?Kt?e.compressedTexSubImage2D(o.TEXTURE_2D,gt,0,0,Ct.width,Ct.height,Yt,Ct.data):e.compressedTexImage2D(o.TEXTURE_2D,gt,Bt,Ct.width,Ct.height,0,Ct.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Kt?e.texSubImage2D(o.TEXTURE_2D,gt,0,0,Ct.width,Ct.height,Yt,Vt,Ct.data):e.texImage2D(o.TEXTURE_2D,gt,Bt,Ct.width,Ct.height,0,Yt,Vt,Ct.data)}else if(b.isDataArrayTexture)Kt?(ne&&e.texStorage3D(o.TEXTURE_2D_ARRAY,qt,Bt,at.width,at.height,at.depth),e.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,at.width,at.height,at.depth,Yt,Vt,at.data)):e.texImage3D(o.TEXTURE_2D_ARRAY,0,Bt,at.width,at.height,at.depth,0,Yt,Vt,at.data);else if(b.isData3DTexture)Kt?(ne&&e.texStorage3D(o.TEXTURE_3D,qt,Bt,at.width,at.height,at.depth),e.texSubImage3D(o.TEXTURE_3D,0,0,0,0,at.width,at.height,at.depth,Yt,Vt,at.data)):e.texImage3D(o.TEXTURE_3D,0,Bt,at.width,at.height,at.depth,0,Yt,Vt,at.data);else if(b.isFramebufferTexture){if(ne)if(Kt)e.texStorage2D(o.TEXTURE_2D,qt,Bt,at.width,at.height);else{let gt=at.width,N=at.height;for(let xt=0;xt<qt;xt++)e.texImage2D(o.TEXTURE_2D,xt,Bt,gt,N,0,Yt,Vt,null),gt>>=1,N>>=1}}else if(Wt.length>0&&Qt){Kt&&ne&&e.texStorage2D(o.TEXTURE_2D,qt,Bt,Wt[0].width,Wt[0].height);for(let gt=0,N=Wt.length;gt<N;gt++)Ct=Wt[gt],Kt?e.texSubImage2D(o.TEXTURE_2D,gt,0,0,Yt,Vt,Ct):e.texImage2D(o.TEXTURE_2D,gt,Bt,Yt,Vt,Ct);b.generateMipmaps=!1}else Kt?(ne&&e.texStorage2D(o.TEXTURE_2D,qt,Bt,at.width,at.height),e.texSubImage2D(o.TEXTURE_2D,0,0,0,Yt,Vt,at)):e.texImage2D(o.TEXTURE_2D,0,Bt,Yt,Vt,at);_(b,Qt)&&w(st),At.__version=nt.version,b.onUpdate&&b.onUpdate(b)}A.__version=b.version}function Et(A,b,z){if(b.image.length!==6)return;const st=et(A,b),ot=b.source;e.bindTexture(o.TEXTURE_CUBE_MAP,A.__webglTexture,o.TEXTURE0+z);const nt=n.get(ot);if(ot.version!==nt.__version||st===!0){e.activeTexture(o.TEXTURE0+z);const At=oe.getPrimaries(oe.workingColorSpace),wt=b.colorSpace===Ye?null:oe.getPrimaries(b.colorSpace),St=b.colorSpace===Ye||At===wt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,b.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,b.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,St);const kt=b.isCompressedTexture||b.image[0].isCompressedTexture,Ht=b.image[0]&&b.image[0].isDataTexture,at=[];for(let gt=0;gt<6;gt++)!kt&&!Ht?at[gt]=y(b.image[gt],!1,!0,i.maxCubemapSize):at[gt]=Ht?b.image[gt].image:b.image[gt],at[gt]=mt(b,at[gt]);const Qt=at[0],Yt=m(Qt)||r,Vt=s.convert(b.format,b.colorSpace),Bt=s.convert(b.type),Ct=v(b.internalFormat,Vt,Bt,b.colorSpace),Wt=r&&b.isVideoTexture!==!0,Kt=nt.__version===void 0||st===!0;let ne=R(b,Qt,Yt);V(o.TEXTURE_CUBE_MAP,b,Yt);let qt;if(kt){Wt&&Kt&&e.texStorage2D(o.TEXTURE_CUBE_MAP,ne,Ct,Qt.width,Qt.height);for(let gt=0;gt<6;gt++){qt=at[gt].mipmaps;for(let N=0;N<qt.length;N++){const xt=qt[N];b.format!==Qe?Vt!==null?Wt?e.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N,0,0,xt.width,xt.height,Vt,xt.data):e.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N,Ct,xt.width,xt.height,0,xt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N,0,0,xt.width,xt.height,Vt,Bt,xt.data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N,Ct,xt.width,xt.height,0,Vt,Bt,xt.data)}}}else{qt=b.mipmaps,Wt&&Kt&&(qt.length>0&&ne++,e.texStorage2D(o.TEXTURE_CUBE_MAP,ne,Ct,at[0].width,at[0].height));for(let gt=0;gt<6;gt++)if(Ht){Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,0,0,at[gt].width,at[gt].height,Vt,Bt,at[gt].data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,Ct,at[gt].width,at[gt].height,0,Vt,Bt,at[gt].data);for(let N=0;N<qt.length;N++){const vt=qt[N].image[gt].image;Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N+1,0,0,vt.width,vt.height,Vt,Bt,vt.data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N+1,Ct,vt.width,vt.height,0,Vt,Bt,vt.data)}}else{Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,0,0,Vt,Bt,at[gt]):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,Ct,Vt,Bt,at[gt]);for(let N=0;N<qt.length;N++){const xt=qt[N];Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N+1,0,0,Vt,Bt,xt.image[gt]):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,N+1,Ct,Vt,Bt,xt.image[gt])}}}_(b,Yt)&&w(o.TEXTURE_CUBE_MAP),nt.__version=ot.version,b.onUpdate&&b.onUpdate(b)}A.__version=b.version}function _t(A,b,z,st,ot,nt){const At=s.convert(z.format,z.colorSpace),wt=s.convert(z.type),St=v(z.internalFormat,At,wt,z.colorSpace);if(!n.get(b).__hasExternalTextures){const Ht=Math.max(1,b.width>>nt),at=Math.max(1,b.height>>nt);ot===o.TEXTURE_3D||ot===o.TEXTURE_2D_ARRAY?e.texImage3D(ot,nt,St,Ht,at,b.depth,0,At,wt,null):e.texImage2D(ot,nt,St,Ht,at,0,At,wt,null)}e.bindFramebuffer(o.FRAMEBUFFER,A),tt(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,st,ot,n.get(z).__webglTexture,0,ct(b)):(ot===o.TEXTURE_2D||ot>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&ot<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,st,ot,n.get(z).__webglTexture,nt),e.bindFramebuffer(o.FRAMEBUFFER,null)}function Nt(A,b,z){if(o.bindRenderbuffer(o.RENDERBUFFER,A),b.depthBuffer&&!b.stencilBuffer){let st=r===!0?o.DEPTH_COMPONENT24:o.DEPTH_COMPONENT16;if(z||tt(b)){const ot=b.depthTexture;ot&&ot.isDepthTexture&&(ot.type===Mn?st=o.DEPTH_COMPONENT32F:ot.type===_n&&(st=o.DEPTH_COMPONENT24));const nt=ct(b);tt(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,nt,st,b.width,b.height):o.renderbufferStorageMultisample(o.RENDERBUFFER,nt,st,b.width,b.height)}else o.renderbufferStorage(o.RENDERBUFFER,st,b.width,b.height);o.framebufferRenderbuffer(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.RENDERBUFFER,A)}else if(b.depthBuffer&&b.stencilBuffer){const st=ct(b);z&&tt(b)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,st,o.DEPTH24_STENCIL8,b.width,b.height):tt(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,st,o.DEPTH24_STENCIL8,b.width,b.height):o.renderbufferStorage(o.RENDERBUFFER,o.DEPTH_STENCIL,b.width,b.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.RENDERBUFFER,A)}else{const st=b.isWebGLMultipleRenderTargets===!0?b.texture:[b.texture];for(let ot=0;ot<st.length;ot++){const nt=st[ot],At=s.convert(nt.format,nt.colorSpace),wt=s.convert(nt.type),St=v(nt.internalFormat,At,wt,nt.colorSpace),kt=ct(b);z&&tt(b)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,kt,St,b.width,b.height):tt(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,kt,St,b.width,b.height):o.renderbufferStorage(o.RENDERBUFFER,St,b.width,b.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function zt(A,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(o.FRAMEBUFFER,A),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(b.depthTexture).__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),k(b.depthTexture,0);const st=n.get(b.depthTexture).__webglTexture,ot=ct(b);if(b.depthTexture.format===Gn)tt(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,st,0,ot):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,st,0);else if(b.depthTexture.format===bi)tt(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,st,0,ot):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,st,0);else throw new Error("Unknown depthTexture format")}function Tt(A){const b=n.get(A),z=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!b.__autoAllocateDepthBuffer){if(z)throw new Error("target.depthTexture not supported in Cube render targets");zt(b.__webglFramebuffer,A)}else if(z){b.__webglDepthbuffer=[];for(let st=0;st<6;st++)e.bindFramebuffer(o.FRAMEBUFFER,b.__webglFramebuffer[st]),b.__webglDepthbuffer[st]=o.createRenderbuffer(),Nt(b.__webglDepthbuffer[st],A,!1)}else e.bindFramebuffer(o.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer=o.createRenderbuffer(),Nt(b.__webglDepthbuffer,A,!1);e.bindFramebuffer(o.FRAMEBUFFER,null)}function Ft(A,b,z){const st=n.get(A);b!==void 0&&_t(st.__webglFramebuffer,A,A.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),z!==void 0&&Tt(A)}function D(A){const b=A.texture,z=n.get(A),st=n.get(b);A.addEventListener("dispose",U),A.isWebGLMultipleRenderTargets!==!0&&(st.__webglTexture===void 0&&(st.__webglTexture=o.createTexture()),st.__version=b.version,a.memory.textures++);const ot=A.isWebGLCubeRenderTarget===!0,nt=A.isWebGLMultipleRenderTargets===!0,At=m(A)||r;if(ot){z.__webglFramebuffer=[];for(let wt=0;wt<6;wt++)if(r&&b.mipmaps&&b.mipmaps.length>0){z.__webglFramebuffer[wt]=[];for(let St=0;St<b.mipmaps.length;St++)z.__webglFramebuffer[wt][St]=o.createFramebuffer()}else z.__webglFramebuffer[wt]=o.createFramebuffer()}else{if(r&&b.mipmaps&&b.mipmaps.length>0){z.__webglFramebuffer=[];for(let wt=0;wt<b.mipmaps.length;wt++)z.__webglFramebuffer[wt]=o.createFramebuffer()}else z.__webglFramebuffer=o.createFramebuffer();if(nt)if(i.drawBuffers){const wt=A.texture;for(let St=0,kt=wt.length;St<kt;St++){const Ht=n.get(wt[St]);Ht.__webglTexture===void 0&&(Ht.__webglTexture=o.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(r&&A.samples>0&&tt(A)===!1){const wt=nt?b:[b];z.__webglMultisampledFramebuffer=o.createFramebuffer(),z.__webglColorRenderbuffer=[],e.bindFramebuffer(o.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let St=0;St<wt.length;St++){const kt=wt[St];z.__webglColorRenderbuffer[St]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,z.__webglColorRenderbuffer[St]);const Ht=s.convert(kt.format,kt.colorSpace),at=s.convert(kt.type),Qt=v(kt.internalFormat,Ht,at,kt.colorSpace,A.isXRRenderTarget===!0),Yt=ct(A);o.renderbufferStorageMultisample(o.RENDERBUFFER,Yt,Qt,A.width,A.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+St,o.RENDERBUFFER,z.__webglColorRenderbuffer[St])}o.bindRenderbuffer(o.RENDERBUFFER,null),A.depthBuffer&&(z.__webglDepthRenderbuffer=o.createRenderbuffer(),Nt(z.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(o.FRAMEBUFFER,null)}}if(ot){e.bindTexture(o.TEXTURE_CUBE_MAP,st.__webglTexture),V(o.TEXTURE_CUBE_MAP,b,At);for(let wt=0;wt<6;wt++)if(r&&b.mipmaps&&b.mipmaps.length>0)for(let St=0;St<b.mipmaps.length;St++)_t(z.__webglFramebuffer[wt][St],A,b,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+wt,St);else _t(z.__webglFramebuffer[wt],A,b,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+wt,0);_(b,At)&&w(o.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(nt){const wt=A.texture;for(let St=0,kt=wt.length;St<kt;St++){const Ht=wt[St],at=n.get(Ht);e.bindTexture(o.TEXTURE_2D,at.__webglTexture),V(o.TEXTURE_2D,Ht,At),_t(z.__webglFramebuffer,A,Ht,o.COLOR_ATTACHMENT0+St,o.TEXTURE_2D,0),_(Ht,At)&&w(o.TEXTURE_2D)}e.unbindTexture()}else{let wt=o.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(r?wt=A.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(wt,st.__webglTexture),V(wt,b,At),r&&b.mipmaps&&b.mipmaps.length>0)for(let St=0;St<b.mipmaps.length;St++)_t(z.__webglFramebuffer[St],A,b,o.COLOR_ATTACHMENT0,wt,St);else _t(z.__webglFramebuffer,A,b,o.COLOR_ATTACHMENT0,wt,0);_(b,At)&&w(wt),e.unbindTexture()}A.depthBuffer&&Tt(A)}function pt(A){const b=m(A)||r,z=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let st=0,ot=z.length;st<ot;st++){const nt=z[st];if(_(nt,b)){const At=A.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:o.TEXTURE_2D,wt=n.get(nt).__webglTexture;e.bindTexture(At,wt),w(At),e.unbindTexture()}}}function K(A){if(r&&A.samples>0&&tt(A)===!1){const b=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],z=A.width,st=A.height;let ot=o.COLOR_BUFFER_BIT;const nt=[],At=A.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,wt=n.get(A),St=A.isWebGLMultipleRenderTargets===!0;if(St)for(let kt=0;kt<b.length;kt++)e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+kt,o.RENDERBUFFER,null),e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+kt,o.TEXTURE_2D,null,0);e.bindFramebuffer(o.READ_FRAMEBUFFER,wt.__webglMultisampledFramebuffer),e.bindFramebuffer(o.DRAW_FRAMEBUFFER,wt.__webglFramebuffer);for(let kt=0;kt<b.length;kt++){nt.push(o.COLOR_ATTACHMENT0+kt),A.depthBuffer&&nt.push(At);const Ht=wt.__ignoreDepthValues!==void 0?wt.__ignoreDepthValues:!1;if(Ht===!1&&(A.depthBuffer&&(ot|=o.DEPTH_BUFFER_BIT),A.stencilBuffer&&(ot|=o.STENCIL_BUFFER_BIT)),St&&o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,wt.__webglColorRenderbuffer[kt]),Ht===!0&&(o.invalidateFramebuffer(o.READ_FRAMEBUFFER,[At]),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[At])),St){const at=n.get(b[kt]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,at,0)}o.blitFramebuffer(0,0,z,st,0,0,z,st,ot,o.NEAREST),l&&o.invalidateFramebuffer(o.READ_FRAMEBUFFER,nt)}if(e.bindFramebuffer(o.READ_FRAMEBUFFER,null),e.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),St)for(let kt=0;kt<b.length;kt++){e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+kt,o.RENDERBUFFER,wt.__webglColorRenderbuffer[kt]);const Ht=n.get(b[kt]).__webglTexture;e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+kt,o.TEXTURE_2D,Ht,0)}e.bindFramebuffer(o.DRAW_FRAMEBUFFER,wt.__webglMultisampledFramebuffer)}}function ct(A){return Math.min(i.maxSamples,A.samples)}function tt(A){const b=n.get(A);return r&&A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function It(A){const b=a.render.frame;h.get(A)!==b&&(h.set(A,b),A.update())}function mt(A,b){const z=A.colorSpace,st=A.format,ot=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===Zo||z!==mn&&z!==Ye&&(oe.getTransfer(z)===le?r===!1?t.has("EXT_sRGB")===!0&&st===Qe?(A.format=Zo,A.minFilter=Xe,A.generateMipmaps=!1):b=yc.sRGBToLinear(b):(st!==Qe||ot!==Tn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",z)),b}this.allocateTextureUnit=I,this.resetTextureUnits=Z,this.setTexture2D=k,this.setTexture2DArray=Y,this.setTexture3D=$,this.setTextureCube=q,this.rebindTextures=Ft,this.setupRenderTarget=D,this.updateRenderTargetMipmap=pt,this.updateMultisampleRenderTarget=K,this.setupDepthRenderbuffer=Tt,this.setupFrameBufferTexture=_t,this.useMultisampledRTT=tt}function jp(o,t,e){const n=e.isWebGL2;function i(s,a=Ye){let r;const c=oe.getTransfer(a);if(s===Tn)return o.UNSIGNED_BYTE;if(s===rc)return o.UNSIGNED_SHORT_4_4_4_4;if(s===cc)return o.UNSIGNED_SHORT_5_5_5_1;if(s===Pl)return o.BYTE;if(s===Ll)return o.SHORT;if(s===aa)return o.UNSIGNED_SHORT;if(s===ac)return o.INT;if(s===_n)return o.UNSIGNED_INT;if(s===Mn)return o.FLOAT;if(s===Wi)return n?o.HALF_FLOAT:(r=t.get("OES_texture_half_float"),r!==null?r.HALF_FLOAT_OES:null);if(s===Il)return o.ALPHA;if(s===Qe)return o.RGBA;if(s===Dl)return o.LUMINANCE;if(s===Ul)return o.LUMINANCE_ALPHA;if(s===Gn)return o.DEPTH_COMPONENT;if(s===bi)return o.DEPTH_STENCIL;if(s===Zo)return r=t.get("EXT_sRGB"),r!==null?r.SRGB_ALPHA_EXT:null;if(s===Nl)return o.RED;if(s===lc)return o.RED_INTEGER;if(s===Bl)return o.RG;if(s===hc)return o.RG_INTEGER;if(s===dc)return o.RGBA_INTEGER;if(s===oo||s===ao||s===ro||s===co)if(c===le)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(s===oo)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===ao)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===ro)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===co)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(s===oo)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===ao)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===ro)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===co)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===Ta||s===Aa||s===Ca||s===Ra)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(s===Ta)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===Aa)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Ca)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===Ra)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===uc)return r=t.get("WEBGL_compressed_texture_etc1"),r!==null?r.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===Pa||s===La)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(s===Pa)return c===le?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(s===La)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===Ia||s===Da||s===Ua||s===Na||s===Ba||s===Fa||s===Oa||s===za||s===ka||s===Ga||s===Ha||s===Va||s===Wa||s===Xa)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(s===Ia)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Da)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Ua)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Na)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Ba)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Fa)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Oa)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===za)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===ka)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Ga)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Ha)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Va)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Wa)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Xa)return c===le?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===lo||s===qa||s===Ya)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(s===lo)return c===le?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===qa)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Ya)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===Fl||s===$a||s===ja||s===Za)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(s===lo)return r.COMPRESSED_RED_RGTC1_EXT;if(s===$a)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===ja)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Za)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===kn?n?o.UNSIGNED_INT_24_8:(r=t.get("WEBGL_depth_texture"),r!==null?r.UNSIGNED_INT_24_8_WEBGL:null):o[s]!==void 0?o[s]:null}return{convert:i}}class Zp extends Be{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}}class lt extends ye{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Kp={type:"move"};class No{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new lt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new lt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new lt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,s=null,a=null;const r=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(const y of t.hand.values()){const m=e.getJointPose(y,n),p=this._getHandJoint(l,y);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const h=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],u=h.position.distanceTo(d.position),f=.02,g=.005;l.inputState.pinching&&u>f+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&u<=f-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(s=e.getPose(t.gripSpace,n),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));r!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&s!==null&&(i=s),i!==null&&(r.matrix.fromArray(i.transform.matrix),r.matrix.decompose(r.position,r.rotation,r.scale),r.matrixWorldNeedsUpdate=!0,i.linearVelocity?(r.hasLinearVelocity=!0,r.linearVelocity.copy(i.linearVelocity)):r.hasLinearVelocity=!1,i.angularVelocity?(r.hasAngularVelocity=!0,r.angularVelocity.copy(i.angularVelocity)):r.hasAngularVelocity=!1,this.dispatchEvent(Kp)))}return r!==null&&(r.visible=i!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new lt;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}class Jp extends Ti{constructor(t,e){super();const n=this;let i=null,s=1,a=null,r="local-floor",c=1,l=null,h=null,d=null,u=null,f=null,g=null;const y=e.getContextAttributes();let m=null,p=null;const _=[],w=[],v=new ut;let R=null;const T=new Be;T.layers.enable(1),T.viewport=new ue;const E=new Be;E.layers.enable(2),E.viewport=new ue;const U=[T,E],M=new Zp;M.layers.enable(1),M.layers.enable(2);let S=null,L=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(V){let et=_[V];return et===void 0&&(et=new No,_[V]=et),et.getTargetRaySpace()},this.getControllerGrip=function(V){let et=_[V];return et===void 0&&(et=new No,_[V]=et),et.getGripSpace()},this.getHand=function(V){let et=_[V];return et===void 0&&(et=new No,_[V]=et),et.getHandSpace()};function F(V){const et=w.indexOf(V.inputSource);if(et===-1)return;const ft=_[et];ft!==void 0&&(ft.update(V.inputSource,V.frame,l||a),ft.dispatchEvent({type:V.type,data:V.inputSource}))}function Z(){i.removeEventListener("select",F),i.removeEventListener("selectstart",F),i.removeEventListener("selectend",F),i.removeEventListener("squeeze",F),i.removeEventListener("squeezestart",F),i.removeEventListener("squeezeend",F),i.removeEventListener("end",Z),i.removeEventListener("inputsourceschange",I);for(let V=0;V<_.length;V++){const et=w[V];et!==null&&(w[V]=null,_[V].disconnect(et))}S=null,L=null,t.setRenderTarget(m),f=null,u=null,d=null,i=null,p=null,rt.stop(),n.isPresenting=!1,t.setPixelRatio(R),t.setSize(v.width,v.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(V){s=V,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(V){r=V,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(V){l=V},this.getBaseLayer=function(){return u!==null?u:f},this.getBinding=function(){return d},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(V){if(i=V,i!==null){if(m=t.getRenderTarget(),i.addEventListener("select",F),i.addEventListener("selectstart",F),i.addEventListener("selectend",F),i.addEventListener("squeeze",F),i.addEventListener("squeezestart",F),i.addEventListener("squeezeend",F),i.addEventListener("end",Z),i.addEventListener("inputsourceschange",I),y.xrCompatible!==!0&&await e.makeXRCompatible(),R=t.getPixelRatio(),t.getSize(v),i.renderState.layers===void 0||t.capabilities.isWebGL2===!1){const et={antialias:i.renderState.layers===void 0?y.antialias:!0,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(i,e,et),i.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),p=new Vn(f.framebufferWidth,f.framebufferHeight,{format:Qe,type:Tn,colorSpace:t.outputColorSpace,stencilBuffer:y.stencil})}else{let et=null,ft=null,Et=null;y.depth&&(Et=y.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,et=y.stencil?bi:Gn,ft=y.stencil?kn:_n);const _t={colorFormat:e.RGBA8,depthFormat:Et,scaleFactor:s};d=new XRWebGLBinding(i,e),u=d.createProjectionLayer(_t),i.updateRenderState({layers:[u]}),t.setPixelRatio(1),t.setSize(u.textureWidth,u.textureHeight,!1),p=new Vn(u.textureWidth,u.textureHeight,{format:Qe,type:Tn,depthTexture:new Cc(u.textureWidth,u.textureHeight,ft,void 0,void 0,void 0,void 0,void 0,void 0,et),stencilBuffer:y.stencil,colorSpace:t.outputColorSpace,samples:y.antialias?4:0});const Nt=t.properties.get(p);Nt.__ignoreDepthValues=u.ignoreDepthValues}p.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await i.requestReferenceSpace(r),rt.setContext(i),rt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode};function I(V){for(let et=0;et<V.removed.length;et++){const ft=V.removed[et],Et=w.indexOf(ft);Et>=0&&(w[Et]=null,_[Et].disconnect(ft))}for(let et=0;et<V.added.length;et++){const ft=V.added[et];let Et=w.indexOf(ft);if(Et===-1){for(let Nt=0;Nt<_.length;Nt++)if(Nt>=w.length){w.push(ft),Et=Nt;break}else if(w[Nt]===null){w[Nt]=ft,Et=Nt;break}if(Et===-1)break}const _t=_[Et];_t&&_t.connect(ft)}}const B=new P,k=new P;function Y(V,et,ft){B.setFromMatrixPosition(et.matrixWorld),k.setFromMatrixPosition(ft.matrixWorld);const Et=B.distanceTo(k),_t=et.projectionMatrix.elements,Nt=ft.projectionMatrix.elements,zt=_t[14]/(_t[10]-1),Tt=_t[14]/(_t[10]+1),Ft=(_t[9]+1)/_t[5],D=(_t[9]-1)/_t[5],pt=(_t[8]-1)/_t[0],K=(Nt[8]+1)/Nt[0],ct=zt*pt,tt=zt*K,It=Et/(-pt+K),mt=It*-pt;et.matrixWorld.decompose(V.position,V.quaternion,V.scale),V.translateX(mt),V.translateZ(It),V.matrixWorld.compose(V.position,V.quaternion,V.scale),V.matrixWorldInverse.copy(V.matrixWorld).invert();const A=zt+It,b=Tt+It,z=ct-mt,st=tt+(Et-mt),ot=Ft*Tt/b*A,nt=D*Tt/b*A;V.projectionMatrix.makePerspective(z,st,ot,nt,A,b),V.projectionMatrixInverse.copy(V.projectionMatrix).invert()}function $(V,et){et===null?V.matrixWorld.copy(V.matrix):V.matrixWorld.multiplyMatrices(et.matrixWorld,V.matrix),V.matrixWorldInverse.copy(V.matrixWorld).invert()}this.updateCamera=function(V){if(i===null)return;M.near=E.near=T.near=V.near,M.far=E.far=T.far=V.far,(S!==M.near||L!==M.far)&&(i.updateRenderState({depthNear:M.near,depthFar:M.far}),S=M.near,L=M.far);const et=V.parent,ft=M.cameras;$(M,et);for(let Et=0;Et<ft.length;Et++)$(ft[Et],et);ft.length===2?Y(M,T,E):M.projectionMatrix.copy(T.projectionMatrix),q(V,M,et)};function q(V,et,ft){ft===null?V.matrix.copy(et.matrixWorld):(V.matrix.copy(ft.matrixWorld),V.matrix.invert(),V.matrix.multiply(et.matrixWorld)),V.matrix.decompose(V.position,V.quaternion,V.scale),V.updateMatrixWorld(!0),V.projectionMatrix.copy(et.projectionMatrix),V.projectionMatrixInverse.copy(et.projectionMatrixInverse),V.isPerspectiveCamera&&(V.fov=Gs*2*Math.atan(1/V.projectionMatrix.elements[5]),V.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(u===null&&f===null))return c},this.setFoveation=function(V){c=V,u!==null&&(u.fixedFoveation=V),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=V)};let Q=null;function it(V,et){if(h=et.getViewerPose(l||a),g=et,h!==null){const ft=h.views;f!==null&&(t.setRenderTargetFramebuffer(p,f.framebuffer),t.setRenderTarget(p));let Et=!1;ft.length!==M.cameras.length&&(M.cameras.length=0,Et=!0);for(let _t=0;_t<ft.length;_t++){const Nt=ft[_t];let zt=null;if(f!==null)zt=f.getViewport(Nt);else{const Ft=d.getViewSubImage(u,Nt);zt=Ft.viewport,_t===0&&(t.setRenderTargetTextures(p,Ft.colorTexture,u.ignoreDepthValues?void 0:Ft.depthStencilTexture),t.setRenderTarget(p))}let Tt=U[_t];Tt===void 0&&(Tt=new Be,Tt.layers.enable(_t),Tt.viewport=new ue,U[_t]=Tt),Tt.matrix.fromArray(Nt.transform.matrix),Tt.matrix.decompose(Tt.position,Tt.quaternion,Tt.scale),Tt.projectionMatrix.fromArray(Nt.projectionMatrix),Tt.projectionMatrixInverse.copy(Tt.projectionMatrix).invert(),Tt.viewport.set(zt.x,zt.y,zt.width,zt.height),_t===0&&(M.matrix.copy(Tt.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),Et===!0&&M.cameras.push(Tt)}}for(let ft=0;ft<_.length;ft++){const Et=w[ft],_t=_[ft];Et!==null&&_t!==void 0&&_t.update(Et,et,l||a)}Q&&Q(V,et),et.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:et}),g=null}const rt=new Tc;rt.setAnimationLoop(it),this.setAnimationLoop=function(V){Q=V},this.dispose=function(){}}}function Qp(o,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,Sc(o)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function i(m,p,_,w,v){p.isMeshBasicMaterial||p.isMeshLambertMaterial?s(m,p):p.isMeshToonMaterial?(s(m,p),d(m,p)):p.isMeshPhongMaterial?(s(m,p),h(m,p)):p.isMeshStandardMaterial?(s(m,p),u(m,p),p.isMeshPhysicalMaterial&&f(m,p,v)):p.isMeshMatcapMaterial?(s(m,p),g(m,p)):p.isMeshDepthMaterial?s(m,p):p.isMeshDistanceMaterial?(s(m,p),y(m,p)):p.isMeshNormalMaterial?s(m,p):p.isLineBasicMaterial?(a(m,p),p.isLineDashedMaterial&&r(m,p)):p.isPointsMaterial?c(m,p,_,w):p.isSpriteMaterial?l(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Fe&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Fe&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const _=t.get(p).envMap;if(_&&(m.envMap.value=_,m.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap){m.lightMap.value=p.lightMap;const w=o._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=p.lightMapIntensity*w,e(p.lightMap,m.lightMapTransform)}p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function a(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function r(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function c(m,p,_,w){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*_,m.scale.value=w*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function l(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function d(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function u(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),t.get(p).envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,_){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Fe&&m.clearcoatNormalScale.value.negate())),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=_.texture,m.transmissionSamplerSize.value.set(_.width,_.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function y(m,p){const _=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(_.matrixWorld),m.nearDistance.value=_.shadow.camera.near,m.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function tm(o,t,e,n){let i={},s={},a=[];const r=e.isWebGL2?o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(_,w){const v=w.program;n.uniformBlockBinding(_,v)}function l(_,w){let v=i[_.id];v===void 0&&(g(_),v=h(_),i[_.id]=v,_.addEventListener("dispose",m));const R=w.program;n.updateUBOMapping(_,R);const T=t.render.frame;s[_.id]!==T&&(u(_),s[_.id]=T)}function h(_){const w=d();_.__bindingPointIndex=w;const v=o.createBuffer(),R=_.__size,T=_.usage;return o.bindBuffer(o.UNIFORM_BUFFER,v),o.bufferData(o.UNIFORM_BUFFER,R,T),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,w,v),v}function d(){for(let _=0;_<r;_++)if(a.indexOf(_)===-1)return a.push(_),_;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(_){const w=i[_.id],v=_.uniforms,R=_.__cache;o.bindBuffer(o.UNIFORM_BUFFER,w);for(let T=0,E=v.length;T<E;T++){const U=Array.isArray(v[T])?v[T]:[v[T]];for(let M=0,S=U.length;M<S;M++){const L=U[M];if(f(L,T,M,R)===!0){const F=L.__offset,Z=Array.isArray(L.value)?L.value:[L.value];let I=0;for(let B=0;B<Z.length;B++){const k=Z[B],Y=y(k);typeof k=="number"||typeof k=="boolean"?(L.__data[0]=k,o.bufferSubData(o.UNIFORM_BUFFER,F+I,L.__data)):k.isMatrix3?(L.__data[0]=k.elements[0],L.__data[1]=k.elements[1],L.__data[2]=k.elements[2],L.__data[3]=0,L.__data[4]=k.elements[3],L.__data[5]=k.elements[4],L.__data[6]=k.elements[5],L.__data[7]=0,L.__data[8]=k.elements[6],L.__data[9]=k.elements[7],L.__data[10]=k.elements[8],L.__data[11]=0):(k.toArray(L.__data,I),I+=Y.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,F,L.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function f(_,w,v,R){const T=_.value,E=w+"_"+v;if(R[E]===void 0)return typeof T=="number"||typeof T=="boolean"?R[E]=T:R[E]=T.clone(),!0;{const U=R[E];if(typeof T=="number"||typeof T=="boolean"){if(U!==T)return R[E]=T,!0}else if(U.equals(T)===!1)return U.copy(T),!0}return!1}function g(_){const w=_.uniforms;let v=0;const R=16;for(let E=0,U=w.length;E<U;E++){const M=Array.isArray(w[E])?w[E]:[w[E]];for(let S=0,L=M.length;S<L;S++){const F=M[S],Z=Array.isArray(F.value)?F.value:[F.value];for(let I=0,B=Z.length;I<B;I++){const k=Z[I],Y=y(k),$=v%R;$!==0&&R-$<Y.boundary&&(v+=R-$),F.__data=new Float32Array(Y.storage/Float32Array.BYTES_PER_ELEMENT),F.__offset=v,v+=Y.storage}}}const T=v%R;return T>0&&(v+=R-T),_.__size=v,_.__cache={},this}function y(_){const w={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(w.boundary=4,w.storage=4):_.isVector2?(w.boundary=8,w.storage=8):_.isVector3||_.isColor?(w.boundary=16,w.storage=12):_.isVector4?(w.boundary=16,w.storage=16):_.isMatrix3?(w.boundary=48,w.storage=48):_.isMatrix4?(w.boundary=64,w.storage=64):_.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",_),w}function m(_){const w=_.target;w.removeEventListener("dispose",m);const v=a.indexOf(w.__bindingPointIndex);a.splice(v,1),o.deleteBuffer(i[w.id]),delete i[w.id],delete s[w.id]}function p(){for(const _ in i)o.deleteBuffer(i[_]);a=[],i={},s={}}return{bind:c,update:l,dispose:p}}class Uc{constructor(t={}){const{canvas:e=jl(),context:n=null,depth:i=!0,stencil:s=!0,alpha:a=!1,antialias:r=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1}=t;this.isWebGLRenderer=!0;let u;n!==null?u=n.getContextAttributes().alpha:u=a;const f=new Uint32Array(4),g=new Int32Array(4);let y=null,m=null;const p=[],_=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Te,this._useLegacyLights=!1,this.toneMapping=En,this.toneMappingExposure=1;const w=this;let v=!1,R=0,T=0,E=null,U=-1,M=null;const S=new ue,L=new ue;let F=null;const Z=new Xt(0);let I=0,B=e.width,k=e.height,Y=1,$=null,q=null;const Q=new ue(0,0,B,k),it=new ue(0,0,B,k);let rt=!1;const V=new la;let et=!1,ft=!1,Et=null;const _t=new fe,Nt=new ut,zt=new P,Tt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function Ft(){return E===null?Y:1}let D=n;function pt(C,G){for(let X=0;X<C.length;X++){const j=C[X],W=e.getContext(j,G);if(W!==null)return W}return null}try{const C={alpha:!0,depth:i,stencil:s,antialias:r,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${ia}`),e.addEventListener("webglcontextlost",gt,!1),e.addEventListener("webglcontextrestored",N,!1),e.addEventListener("webglcontextcreationerror",xt,!1),D===null){const G=["webgl2","webgl","experimental-webgl"];if(w.isWebGL1Renderer===!0&&G.shift(),D=pt(G,C),D===null)throw pt(G)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&D instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),D.getShaderPrecisionFormat===void 0&&(D.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let K,ct,tt,It,mt,A,b,z,st,ot,nt,At,wt,St,kt,Ht,at,Qt,Yt,Vt,Bt,Ct,Wt,Kt;function ne(){K=new hf(D),ct=new sf(D,K,t),K.init(ct),Ct=new jp(D,K,ct),tt=new Yp(D,K,ct),It=new ff(D),mt=new Dp,A=new $p(D,K,tt,mt,ct,Ct,It),b=new af(w),z=new lf(w),st=new vh(D,ct),Wt=new ef(D,K,st,ct),ot=new df(D,st,It,Wt),nt=new yf(D,ot,st,It),Yt=new gf(D,ct,A),Ht=new of(mt),At=new Ip(w,b,z,K,ct,Wt,Ht),wt=new Qp(w,mt),St=new Np,kt=new Gp(K,ct),Qt=new tf(w,b,z,tt,nt,u,c),at=new qp(w,nt,ct),Kt=new tm(D,It,ct,tt),Vt=new nf(D,K,It,ct),Bt=new uf(D,K,It,ct),It.programs=At.programs,w.capabilities=ct,w.extensions=K,w.properties=mt,w.renderLists=St,w.shadowMap=at,w.state=tt,w.info=It}ne();const qt=new Jp(w,D);this.xr=qt,this.getContext=function(){return D},this.getContextAttributes=function(){return D.getContextAttributes()},this.forceContextLoss=function(){const C=K.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=K.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return Y},this.setPixelRatio=function(C){C!==void 0&&(Y=C,this.setSize(B,k,!1))},this.getSize=function(C){return C.set(B,k)},this.setSize=function(C,G,X=!0){if(qt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}B=C,k=G,e.width=Math.floor(C*Y),e.height=Math.floor(G*Y),X===!0&&(e.style.width=C+"px",e.style.height=G+"px"),this.setViewport(0,0,C,G)},this.getDrawingBufferSize=function(C){return C.set(B*Y,k*Y).floor()},this.setDrawingBufferSize=function(C,G,X){B=C,k=G,Y=X,e.width=Math.floor(C*X),e.height=Math.floor(G*X),this.setViewport(0,0,C,G)},this.getCurrentViewport=function(C){return C.copy(S)},this.getViewport=function(C){return C.copy(Q)},this.setViewport=function(C,G,X,j){C.isVector4?Q.set(C.x,C.y,C.z,C.w):Q.set(C,G,X,j),tt.viewport(S.copy(Q).multiplyScalar(Y).floor())},this.getScissor=function(C){return C.copy(it)},this.setScissor=function(C,G,X,j){C.isVector4?it.set(C.x,C.y,C.z,C.w):it.set(C,G,X,j),tt.scissor(L.copy(it).multiplyScalar(Y).floor())},this.getScissorTest=function(){return rt},this.setScissorTest=function(C){tt.setScissorTest(rt=C)},this.setOpaqueSort=function(C){$=C},this.setTransparentSort=function(C){q=C},this.getClearColor=function(C){return C.copy(Qt.getClearColor())},this.setClearColor=function(){Qt.setClearColor.apply(Qt,arguments)},this.getClearAlpha=function(){return Qt.getClearAlpha()},this.setClearAlpha=function(){Qt.setClearAlpha.apply(Qt,arguments)},this.clear=function(C=!0,G=!0,X=!0){let j=0;if(C){let W=!1;if(E!==null){const bt=E.texture.format;W=bt===dc||bt===hc||bt===lc}if(W){const bt=E.texture.type,Ut=bt===Tn||bt===_n||bt===aa||bt===kn||bt===rc||bt===cc,ht=Qt.getClearColor(),dt=Qt.getClearAlpha(),Pt=ht.r,Dt=ht.g,Rt=ht.b;Ut?(f[0]=Pt,f[1]=Dt,f[2]=Rt,f[3]=dt,D.clearBufferuiv(D.COLOR,0,f)):(g[0]=Pt,g[1]=Dt,g[2]=Rt,g[3]=dt,D.clearBufferiv(D.COLOR,0,g))}else j|=D.COLOR_BUFFER_BIT}G&&(j|=D.DEPTH_BUFFER_BIT),X&&(j|=D.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),D.clear(j)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",gt,!1),e.removeEventListener("webglcontextrestored",N,!1),e.removeEventListener("webglcontextcreationerror",xt,!1),St.dispose(),kt.dispose(),mt.dispose(),b.dispose(),z.dispose(),nt.dispose(),Wt.dispose(),Kt.dispose(),At.dispose(),qt.dispose(),qt.removeEventListener("sessionstart",be),qt.removeEventListener("sessionend",ee),Et&&(Et.dispose(),Et=null),xe.stop()};function gt(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),v=!0}function N(){console.log("THREE.WebGLRenderer: Context Restored."),v=!1;const C=It.autoReset,G=at.enabled,X=at.autoUpdate,j=at.needsUpdate,W=at.type;ne(),It.autoReset=C,at.enabled=G,at.autoUpdate=X,at.needsUpdate=j,at.type=W}function xt(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function vt(C){const G=C.target;G.removeEventListener("dispose",vt),Gt(G)}function Gt(C){Ot(C),mt.remove(C)}function Ot(C){const G=mt.get(C).programs;G!==void 0&&(G.forEach(function(X){At.releaseProgram(X)}),C.isShaderMaterial&&At.releaseShaderCache(C))}this.renderBufferDirect=function(C,G,X,j,W,bt){G===null&&(G=Tt);const Ut=W.isMesh&&W.matrixWorld.determinant()<0,ht=Qs(C,G,X,j,W);tt.setMaterial(j,Ut);let dt=X.index,Pt=1;if(j.wireframe===!0){if(dt=ot.getWireframeAttribute(X),dt===void 0)return;Pt=2}const Dt=X.drawRange,Rt=X.attributes.position;let se=Dt.start*Pt,pe=(Dt.start+Dt.count)*Pt;bt!==null&&(se=Math.max(se,bt.start*Pt),pe=Math.min(pe,(bt.start+bt.count)*Pt)),dt!==null?(se=Math.max(se,0),pe=Math.min(pe,dt.count)):Rt!=null&&(se=Math.max(se,0),pe=Math.min(pe,Rt.count));const de=pe-se;if(de<0||de===1/0)return;Wt.setup(W,j,ht,X,dt);let ke,ce=Vt;if(dt!==null&&(ke=st.get(dt),ce=Bt,ce.setIndex(ke)),W.isMesh)j.wireframe===!0?(tt.setLineWidth(j.wireframeLinewidth*Ft()),ce.setMode(D.LINES)):ce.setMode(D.TRIANGLES);else if(W.isLine){let $t=j.linewidth;$t===void 0&&($t=1),tt.setLineWidth($t*Ft()),W.isLineSegments?ce.setMode(D.LINES):W.isLineLoop?ce.setMode(D.LINE_LOOP):ce.setMode(D.LINE_STRIP)}else W.isPoints?ce.setMode(D.POINTS):W.isSprite&&ce.setMode(D.TRIANGLES);if(W.isBatchedMesh)ce.renderMultiDraw(W._multiDrawStarts,W._multiDrawCounts,W._multiDrawCount);else if(W.isInstancedMesh)ce.renderInstances(se,de,W.count);else if(X.isInstancedBufferGeometry){const $t=X._maxInstanceCount!==void 0?X._maxInstanceCount:1/0,Yn=Math.min(X.instanceCount,$t);ce.renderInstances(se,de,Yn)}else ce.render(se,de)};function te(C,G,X){C.transparent===!0&&C.side===he&&C.forceSinglePass===!1?(C.side=Fe,C.needsUpdate=!0,on(C,G,X),C.side=An,C.needsUpdate=!0,on(C,G,X),C.side=he):on(C,G,X)}this.compile=function(C,G,X=null){X===null&&(X=C),m=kt.get(X),m.init(),_.push(m),X.traverseVisible(function(W){W.isLight&&W.layers.test(G.layers)&&(m.pushLight(W),W.castShadow&&m.pushShadow(W))}),C!==X&&C.traverseVisible(function(W){W.isLight&&W.layers.test(G.layers)&&(m.pushLight(W),W.castShadow&&m.pushShadow(W))}),m.setupLights(w._useLegacyLights);const j=new Set;return C.traverse(function(W){const bt=W.material;if(bt)if(Array.isArray(bt))for(let Ut=0;Ut<bt.length;Ut++){const ht=bt[Ut];te(ht,X,W),j.add(ht)}else te(bt,X,W),j.add(bt)}),_.pop(),m=null,j},this.compileAsync=function(C,G,X=null){const j=this.compile(C,G,X);return new Promise(W=>{function bt(){if(j.forEach(function(Ut){mt.get(Ut).currentProgram.isReady()&&j.delete(Ut)}),j.size===0){W(C);return}setTimeout(bt,10)}K.get("KHR_parallel_shader_compile")!==null?bt():setTimeout(bt,10)})};let ie=null;function we(C){ie&&ie(C)}function be(){xe.stop()}function ee(){xe.start()}const xe=new Tc;xe.setAnimationLoop(we),typeof self<"u"&&xe.setContext(self),this.setAnimationLoop=function(C){ie=C,qt.setAnimationLoop(C),C===null?xe.stop():xe.start()},qt.addEventListener("sessionstart",be),qt.addEventListener("sessionend",ee),this.render=function(C,G){if(G!==void 0&&G.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(v===!0)return;C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),G.parent===null&&G.matrixWorldAutoUpdate===!0&&G.updateMatrixWorld(),qt.enabled===!0&&qt.isPresenting===!0&&(qt.cameraAutoUpdate===!0&&qt.updateCamera(G),G=qt.getCamera()),C.isScene===!0&&C.onBeforeRender(w,C,G,E),m=kt.get(C,_.length),m.init(),_.push(m),_t.multiplyMatrices(G.projectionMatrix,G.matrixWorldInverse),V.setFromProjectionMatrix(_t),ft=this.localClippingEnabled,et=Ht.init(this.clippingPlanes,ft),y=St.get(C,p.length),y.init(),p.push(y),ze(C,G,0,w.sortObjects),y.finish(),w.sortObjects===!0&&y.sort($,q),this.info.render.frame++,et===!0&&Ht.beginShadows();const X=m.state.shadowsArray;if(at.render(X,C,G),et===!0&&Ht.endShadows(),this.info.autoReset===!0&&this.info.reset(),Qt.render(y,C),m.setupLights(w._useLegacyLights),G.isArrayCamera){const j=G.cameras;for(let W=0,bt=j.length;W<bt;W++){const Ut=j[W];Ci(y,C,Ut,Ut.viewport)}}else Ci(y,C,G);E!==null&&(A.updateMultisampleRenderTarget(E),A.updateRenderTargetMipmap(E)),C.isScene===!0&&C.onAfterRender(w,C,G),Wt.resetDefaultState(),U=-1,M=null,_.pop(),_.length>0?m=_[_.length-1]:m=null,p.pop(),p.length>0?y=p[p.length-1]:y=null};function ze(C,G,X,j){if(C.visible===!1)return;if(C.layers.test(G.layers)){if(C.isGroup)X=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(G);else if(C.isLight)m.pushLight(C),C.castShadow&&m.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||V.intersectsSprite(C)){j&&zt.setFromMatrixPosition(C.matrixWorld).applyMatrix4(_t);const Ut=nt.update(C),ht=C.material;ht.visible&&y.push(C,Ut,ht,X,zt.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||V.intersectsObject(C))){const Ut=nt.update(C),ht=C.material;if(j&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),zt.copy(C.boundingSphere.center)):(Ut.boundingSphere===null&&Ut.computeBoundingSphere(),zt.copy(Ut.boundingSphere.center)),zt.applyMatrix4(C.matrixWorld).applyMatrix4(_t)),Array.isArray(ht)){const dt=Ut.groups;for(let Pt=0,Dt=dt.length;Pt<Dt;Pt++){const Rt=dt[Pt],se=ht[Rt.materialIndex];se&&se.visible&&y.push(C,Ut,se,X,zt.z,Rt)}}else ht.visible&&y.push(C,Ut,ht,X,zt.z,null)}}const bt=C.children;for(let Ut=0,ht=bt.length;Ut<ht;Ut++)ze(bt[Ut],G,X,j)}function Ci(C,G,X,j){const W=C.opaque,bt=C.transmissive,Ut=C.transparent;m.setupLightsView(X),et===!0&&Ht.setGlobalState(w.clippingPlanes,X),bt.length>0&&ts(W,bt,G,X),j&&tt.viewport(S.copy(j)),W.length>0&&Ae(W,G,X),bt.length>0&&Ae(bt,G,X),Ut.length>0&&Ae(Ut,G,X),tt.buffers.depth.setTest(!0),tt.buffers.depth.setMask(!0),tt.buffers.color.setMask(!0),tt.setPolygonOffset(!1)}function ts(C,G,X,j){if((X.isScene===!0?X.overrideMaterial:null)!==null)return;const bt=ct.isWebGL2;Et===null&&(Et=new Vn(1,1,{generateMipmaps:!0,type:K.has("EXT_color_buffer_half_float")?Wi:Tn,minFilter:Vi,samples:bt?4:0})),w.getDrawingBufferSize(Nt),bt?Et.setSize(Nt.x,Nt.y):Et.setSize(Ko(Nt.x),Ko(Nt.y));const Ut=w.getRenderTarget();w.setRenderTarget(Et),w.getClearColor(Z),I=w.getClearAlpha(),I<1&&w.setClearColor(16777215,.5),w.clear();const ht=w.toneMapping;w.toneMapping=En,Ae(C,X,j),A.updateMultisampleRenderTarget(Et),A.updateRenderTargetMipmap(Et);let dt=!1;for(let Pt=0,Dt=G.length;Pt<Dt;Pt++){const Rt=G[Pt],se=Rt.object,pe=Rt.geometry,de=Rt.material,ke=Rt.group;if(de.side===he&&se.layers.test(j.layers)){const ce=de.side;de.side=Fe,de.needsUpdate=!0,Rn(se,X,j,pe,de,ke),de.side=ce,de.needsUpdate=!0,dt=!0}}dt===!0&&(A.updateMultisampleRenderTarget(Et),A.updateRenderTargetMipmap(Et)),w.setRenderTarget(Ut),w.setClearColor(Z,I),w.toneMapping=ht}function Ae(C,G,X){const j=G.isScene===!0?G.overrideMaterial:null;for(let W=0,bt=C.length;W<bt;W++){const Ut=C[W],ht=Ut.object,dt=Ut.geometry,Pt=j===null?Ut.material:j,Dt=Ut.group;ht.layers.test(X.layers)&&Rn(ht,G,X,dt,Pt,Dt)}}function Rn(C,G,X,j,W,bt){C.onBeforeRender(w,G,X,j,W,bt),C.modelViewMatrix.multiplyMatrices(X.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),W.onBeforeRender(w,G,X,j,C,bt),W.transparent===!0&&W.side===he&&W.forceSinglePass===!1?(W.side=Fe,W.needsUpdate=!0,w.renderBufferDirect(X,G,j,W,C,bt),W.side=An,W.needsUpdate=!0,w.renderBufferDirect(X,G,j,W,C,bt),W.side=he):w.renderBufferDirect(X,G,j,W,C,bt),C.onAfterRender(w,G,X,j,W,bt)}function on(C,G,X){G.isScene!==!0&&(G=Tt);const j=mt.get(C),W=m.state.lights,bt=m.state.shadowsArray,Ut=W.state.version,ht=At.getParameters(C,W.state,bt,G,X),dt=At.getProgramCacheKey(ht);let Pt=j.programs;j.environment=C.isMeshStandardMaterial?G.environment:null,j.fog=G.fog,j.envMap=(C.isMeshStandardMaterial?z:b).get(C.envMap||j.environment),Pt===void 0&&(C.addEventListener("dispose",vt),Pt=new Map,j.programs=Pt);let Dt=Pt.get(dt);if(Dt!==void 0){if(j.currentProgram===Dt&&j.lightsStateVersion===Ut)return es(C,ht),Dt}else ht.uniforms=At.getUniforms(C),C.onBuild(X,ht,w),C.onBeforeCompile(ht,w),Dt=At.acquireProgram(ht,dt),Pt.set(dt,Dt),j.uniforms=ht.uniforms;const Rt=j.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(Rt.clippingPlanes=Ht.uniform),es(C,ht),j.needsLights=to(C),j.lightsStateVersion=Ut,j.needsLights&&(Rt.ambientLightColor.value=W.state.ambient,Rt.lightProbe.value=W.state.probe,Rt.directionalLights.value=W.state.directional,Rt.directionalLightShadows.value=W.state.directionalShadow,Rt.spotLights.value=W.state.spot,Rt.spotLightShadows.value=W.state.spotShadow,Rt.rectAreaLights.value=W.state.rectArea,Rt.ltc_1.value=W.state.rectAreaLTC1,Rt.ltc_2.value=W.state.rectAreaLTC2,Rt.pointLights.value=W.state.point,Rt.pointLightShadows.value=W.state.pointShadow,Rt.hemisphereLights.value=W.state.hemi,Rt.directionalShadowMap.value=W.state.directionalShadowMap,Rt.directionalShadowMatrix.value=W.state.directionalShadowMatrix,Rt.spotShadowMap.value=W.state.spotShadowMap,Rt.spotLightMatrix.value=W.state.spotLightMatrix,Rt.spotLightMap.value=W.state.spotLightMap,Rt.pointShadowMap.value=W.state.pointShadowMap,Rt.pointShadowMatrix.value=W.state.pointShadowMatrix),j.currentProgram=Dt,j.uniformsList=null,Dt}function qn(C){if(C.uniformsList===null){const G=C.currentProgram.getUniforms();C.uniformsList=Us.seqWithValue(G.seq,C.uniforms)}return C.uniformsList}function es(C,G){const X=mt.get(C);X.outputColorSpace=G.outputColorSpace,X.batching=G.batching,X.instancing=G.instancing,X.instancingColor=G.instancingColor,X.skinning=G.skinning,X.morphTargets=G.morphTargets,X.morphNormals=G.morphNormals,X.morphColors=G.morphColors,X.morphTargetsCount=G.morphTargetsCount,X.numClippingPlanes=G.numClippingPlanes,X.numIntersection=G.numClipIntersection,X.vertexAlphas=G.vertexAlphas,X.vertexTangents=G.vertexTangents,X.toneMapping=G.toneMapping}function Qs(C,G,X,j,W){G.isScene!==!0&&(G=Tt),A.resetTextureUnits();const bt=G.fog,Ut=j.isMeshStandardMaterial?G.environment:null,ht=E===null?w.outputColorSpace:E.isXRRenderTarget===!0?E.texture.colorSpace:mn,dt=(j.isMeshStandardMaterial?z:b).get(j.envMap||Ut),Pt=j.vertexColors===!0&&!!X.attributes.color&&X.attributes.color.itemSize===4,Dt=!!X.attributes.tangent&&(!!j.normalMap||j.anisotropy>0),Rt=!!X.morphAttributes.position,se=!!X.morphAttributes.normal,pe=!!X.morphAttributes.color;let de=En;j.toneMapped&&(E===null||E.isXRRenderTarget===!0)&&(de=w.toneMapping);const ke=X.morphAttributes.position||X.morphAttributes.normal||X.morphAttributes.color,ce=ke!==void 0?ke.length:0,$t=mt.get(j),Yn=m.state.lights;if(et===!0&&(ft===!0||C!==M)){const Ve=C===M&&j.id===U;Ht.setState(j,C,Ve)}let ge=!1;j.version===$t.__version?($t.needsLights&&$t.lightsStateVersion!==Yn.state.version||$t.outputColorSpace!==ht||W.isBatchedMesh&&$t.batching===!1||!W.isBatchedMesh&&$t.batching===!0||W.isInstancedMesh&&$t.instancing===!1||!W.isInstancedMesh&&$t.instancing===!0||W.isSkinnedMesh&&$t.skinning===!1||!W.isSkinnedMesh&&$t.skinning===!0||W.isInstancedMesh&&$t.instancingColor===!0&&W.instanceColor===null||W.isInstancedMesh&&$t.instancingColor===!1&&W.instanceColor!==null||$t.envMap!==dt||j.fog===!0&&$t.fog!==bt||$t.numClippingPlanes!==void 0&&($t.numClippingPlanes!==Ht.numPlanes||$t.numIntersection!==Ht.numIntersection)||$t.vertexAlphas!==Pt||$t.vertexTangents!==Dt||$t.morphTargets!==Rt||$t.morphNormals!==se||$t.morphColors!==pe||$t.toneMapping!==de||ct.isWebGL2===!0&&$t.morphTargetsCount!==ce)&&(ge=!0):(ge=!0,$t.__version=j.version);let Pn=$t.currentProgram;ge===!0&&(Pn=on(j,G,W));let wa=!1,Ri=!1,eo=!1;const Ce=Pn.getUniforms(),Ln=$t.uniforms;if(tt.useProgram(Pn.program)&&(wa=!0,Ri=!0,eo=!0),j.id!==U&&(U=j.id,Ri=!0),wa||M!==C){Ce.setValue(D,"projectionMatrix",C.projectionMatrix),Ce.setValue(D,"viewMatrix",C.matrixWorldInverse);const Ve=Ce.map.cameraPosition;Ve!==void 0&&Ve.setValue(D,zt.setFromMatrixPosition(C.matrixWorld)),ct.logarithmicDepthBuffer&&Ce.setValue(D,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(j.isMeshPhongMaterial||j.isMeshToonMaterial||j.isMeshLambertMaterial||j.isMeshBasicMaterial||j.isMeshStandardMaterial||j.isShaderMaterial)&&Ce.setValue(D,"isOrthographic",C.isOrthographicCamera===!0),M!==C&&(M=C,Ri=!0,eo=!0)}if(W.isSkinnedMesh){Ce.setOptional(D,W,"bindMatrix"),Ce.setOptional(D,W,"bindMatrixInverse");const Ve=W.skeleton;Ve&&(ct.floatVertexTextures?(Ve.boneTexture===null&&Ve.computeBoneTexture(),Ce.setValue(D,"boneTexture",Ve.boneTexture,A)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}W.isBatchedMesh&&(Ce.setOptional(D,W,"batchingTexture"),Ce.setValue(D,"batchingTexture",W._matricesTexture,A));const no=X.morphAttributes;if((no.position!==void 0||no.normal!==void 0||no.color!==void 0&&ct.isWebGL2===!0)&&Yt.update(W,X,Pn),(Ri||$t.receiveShadow!==W.receiveShadow)&&($t.receiveShadow=W.receiveShadow,Ce.setValue(D,"receiveShadow",W.receiveShadow)),j.isMeshGouraudMaterial&&j.envMap!==null&&(Ln.envMap.value=dt,Ln.flipEnvMap.value=dt.isCubeTexture&&dt.isRenderTargetTexture===!1?-1:1),Ri&&(Ce.setValue(D,"toneMappingExposure",w.toneMappingExposure),$t.needsLights&&ns(Ln,eo),bt&&j.fog===!0&&wt.refreshFogUniforms(Ln,bt),wt.refreshMaterialUniforms(Ln,j,Y,k,Et),Us.upload(D,qn($t),Ln,A)),j.isShaderMaterial&&j.uniformsNeedUpdate===!0&&(Us.upload(D,qn($t),Ln,A),j.uniformsNeedUpdate=!1),j.isSpriteMaterial&&Ce.setValue(D,"center",W.center),Ce.setValue(D,"modelViewMatrix",W.modelViewMatrix),Ce.setValue(D,"normalMatrix",W.normalMatrix),Ce.setValue(D,"modelMatrix",W.matrixWorld),j.isShaderMaterial||j.isRawShaderMaterial){const Ve=j.uniformsGroups;for(let io=0,jc=Ve.length;io<jc;io++)if(ct.isWebGL2){const xa=Ve[io];Kt.update(xa,Pn),Kt.bind(xa,Pn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Pn}function ns(C,G){C.ambientLightColor.needsUpdate=G,C.lightProbe.needsUpdate=G,C.directionalLights.needsUpdate=G,C.directionalLightShadows.needsUpdate=G,C.pointLights.needsUpdate=G,C.pointLightShadows.needsUpdate=G,C.spotLights.needsUpdate=G,C.spotLightShadows.needsUpdate=G,C.rectAreaLights.needsUpdate=G,C.hemisphereLights.needsUpdate=G}function to(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return E},this.setRenderTargetTextures=function(C,G,X){mt.get(C.texture).__webglTexture=G,mt.get(C.depthTexture).__webglTexture=X;const j=mt.get(C);j.__hasExternalTextures=!0,j.__hasExternalTextures&&(j.__autoAllocateDepthBuffer=X===void 0,j.__autoAllocateDepthBuffer||K.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),j.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(C,G){const X=mt.get(C);X.__webglFramebuffer=G,X.__useDefaultFramebuffer=G===void 0},this.setRenderTarget=function(C,G=0,X=0){E=C,R=G,T=X;let j=!0,W=null,bt=!1,Ut=!1;if(C){const dt=mt.get(C);dt.__useDefaultFramebuffer!==void 0?(tt.bindFramebuffer(D.FRAMEBUFFER,null),j=!1):dt.__webglFramebuffer===void 0?A.setupRenderTarget(C):dt.__hasExternalTextures&&A.rebindTextures(C,mt.get(C.texture).__webglTexture,mt.get(C.depthTexture).__webglTexture);const Pt=C.texture;(Pt.isData3DTexture||Pt.isDataArrayTexture||Pt.isCompressedArrayTexture)&&(Ut=!0);const Dt=mt.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(Dt[G])?W=Dt[G][X]:W=Dt[G],bt=!0):ct.isWebGL2&&C.samples>0&&A.useMultisampledRTT(C)===!1?W=mt.get(C).__webglMultisampledFramebuffer:Array.isArray(Dt)?W=Dt[X]:W=Dt,S.copy(C.viewport),L.copy(C.scissor),F=C.scissorTest}else S.copy(Q).multiplyScalar(Y).floor(),L.copy(it).multiplyScalar(Y).floor(),F=rt;if(tt.bindFramebuffer(D.FRAMEBUFFER,W)&&ct.drawBuffers&&j&&tt.drawBuffers(C,W),tt.viewport(S),tt.scissor(L),tt.setScissorTest(F),bt){const dt=mt.get(C.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_CUBE_MAP_POSITIVE_X+G,dt.__webglTexture,X)}else if(Ut){const dt=mt.get(C.texture),Pt=G||0;D.framebufferTextureLayer(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,dt.__webglTexture,X||0,Pt)}U=-1},this.readRenderTargetPixels=function(C,G,X,j,W,bt,Ut){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ht=mt.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ut!==void 0&&(ht=ht[Ut]),ht){tt.bindFramebuffer(D.FRAMEBUFFER,ht);try{const dt=C.texture,Pt=dt.format,Dt=dt.type;if(Pt!==Qe&&Ct.convert(Pt)!==D.getParameter(D.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const Rt=Dt===Wi&&(K.has("EXT_color_buffer_half_float")||ct.isWebGL2&&K.has("EXT_color_buffer_float"));if(Dt!==Tn&&Ct.convert(Dt)!==D.getParameter(D.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Dt===Mn&&(ct.isWebGL2||K.has("OES_texture_float")||K.has("WEBGL_color_buffer_float")))&&!Rt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}G>=0&&G<=C.width-j&&X>=0&&X<=C.height-W&&D.readPixels(G,X,j,W,Ct.convert(Pt),Ct.convert(Dt),bt)}finally{const dt=E!==null?mt.get(E).__webglFramebuffer:null;tt.bindFramebuffer(D.FRAMEBUFFER,dt)}}},this.copyFramebufferToTexture=function(C,G,X=0){const j=Math.pow(2,-X),W=Math.floor(G.image.width*j),bt=Math.floor(G.image.height*j);A.setTexture2D(G,0),D.copyTexSubImage2D(D.TEXTURE_2D,X,0,0,C.x,C.y,W,bt),tt.unbindTexture()},this.copyTextureToTexture=function(C,G,X,j=0){const W=G.image.width,bt=G.image.height,Ut=Ct.convert(X.format),ht=Ct.convert(X.type);A.setTexture2D(X,0),D.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,X.flipY),D.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,X.premultiplyAlpha),D.pixelStorei(D.UNPACK_ALIGNMENT,X.unpackAlignment),G.isDataTexture?D.texSubImage2D(D.TEXTURE_2D,j,C.x,C.y,W,bt,Ut,ht,G.image.data):G.isCompressedTexture?D.compressedTexSubImage2D(D.TEXTURE_2D,j,C.x,C.y,G.mipmaps[0].width,G.mipmaps[0].height,Ut,G.mipmaps[0].data):D.texSubImage2D(D.TEXTURE_2D,j,C.x,C.y,Ut,ht,G.image),j===0&&X.generateMipmaps&&D.generateMipmap(D.TEXTURE_2D),tt.unbindTexture()},this.copyTextureToTexture3D=function(C,G,X,j,W=0){if(w.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const bt=C.max.x-C.min.x+1,Ut=C.max.y-C.min.y+1,ht=C.max.z-C.min.z+1,dt=Ct.convert(j.format),Pt=Ct.convert(j.type);let Dt;if(j.isData3DTexture)A.setTexture3D(j,0),Dt=D.TEXTURE_3D;else if(j.isDataArrayTexture||j.isCompressedArrayTexture)A.setTexture2DArray(j,0),Dt=D.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}D.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,j.flipY),D.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,j.premultiplyAlpha),D.pixelStorei(D.UNPACK_ALIGNMENT,j.unpackAlignment);const Rt=D.getParameter(D.UNPACK_ROW_LENGTH),se=D.getParameter(D.UNPACK_IMAGE_HEIGHT),pe=D.getParameter(D.UNPACK_SKIP_PIXELS),de=D.getParameter(D.UNPACK_SKIP_ROWS),ke=D.getParameter(D.UNPACK_SKIP_IMAGES),ce=X.isCompressedTexture?X.mipmaps[W]:X.image;D.pixelStorei(D.UNPACK_ROW_LENGTH,ce.width),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,ce.height),D.pixelStorei(D.UNPACK_SKIP_PIXELS,C.min.x),D.pixelStorei(D.UNPACK_SKIP_ROWS,C.min.y),D.pixelStorei(D.UNPACK_SKIP_IMAGES,C.min.z),X.isDataTexture||X.isData3DTexture?D.texSubImage3D(Dt,W,G.x,G.y,G.z,bt,Ut,ht,dt,Pt,ce.data):X.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),D.compressedTexSubImage3D(Dt,W,G.x,G.y,G.z,bt,Ut,ht,dt,ce.data)):D.texSubImage3D(Dt,W,G.x,G.y,G.z,bt,Ut,ht,dt,Pt,ce),D.pixelStorei(D.UNPACK_ROW_LENGTH,Rt),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,se),D.pixelStorei(D.UNPACK_SKIP_PIXELS,pe),D.pixelStorei(D.UNPACK_SKIP_ROWS,de),D.pixelStorei(D.UNPACK_SKIP_IMAGES,ke),W===0&&j.generateMipmaps&&D.generateMipmap(Dt),tt.unbindTexture()},this.initTexture=function(C){C.isCubeTexture?A.setTextureCube(C,0):C.isData3DTexture?A.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?A.setTexture2DArray(C,0):A.setTexture2D(C,0),tt.unbindTexture()},this.resetState=function(){R=0,T=0,E=null,tt.reset(),Wt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return fn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=t===ra?"display-p3":"srgb",e.unpackColorSpace=oe.workingColorSpace===Ys?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Te?Hn:fc}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===Hn?Te:mn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}}class em extends Uc{}em.prototype.isWebGL1Renderer=!0;class da{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new Xt(t),this.density=e}clone(){return new da(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class nm extends ye{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}}class im{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=jo,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=pn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let i=0,s=this.stride;i<s;i++)this.array[t+i]=e.array[n+i];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=pn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=pn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Ie=new P;class Vs{constructor(t,e,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyMatrix4(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyNormalMatrix(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.transformDirection(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}setX(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=un(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=un(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=un(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=un(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this}setXYZW(t,e,n,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array),s=ae(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this.data.array[t+3]=s,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[i+s])}return new $e(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new Vs(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Nc extends Cn{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Xt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let di;const Ui=new P,ui=new P,fi=new P,pi=new ut,Ni=new ut,Bc=new fe,Es=new P,Bi=new P,Ts=new P,Or=new ut,Bo=new ut,zr=new ut;class sm extends ye{constructor(t=new Nc){if(super(),this.isSprite=!0,this.type="Sprite",di===void 0){di=new _e;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new im(e,5);di.setIndex([0,1,2,0,2,3]),di.setAttribute("position",new Vs(n,3,0,!1)),di.setAttribute("uv",new Vs(n,2,3,!1))}this.geometry=di,this.material=t,this.center=new ut(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),ui.setFromMatrixScale(this.matrixWorld),Bc.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),fi.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&ui.multiplyScalar(-fi.z);const n=this.material.rotation;let i,s;n!==0&&(s=Math.cos(n),i=Math.sin(n));const a=this.center;As(Es.set(-.5,-.5,0),fi,a,ui,i,s),As(Bi.set(.5,-.5,0),fi,a,ui,i,s),As(Ts.set(.5,.5,0),fi,a,ui,i,s),Or.set(0,0),Bo.set(1,0),zr.set(1,1);let r=t.ray.intersectTriangle(Es,Bi,Ts,!1,Ui);if(r===null&&(As(Bi.set(-.5,.5,0),fi,a,ui,i,s),Bo.set(0,1),r=t.ray.intersectTriangle(Es,Ts,Bi,!1,Ui),r===null))return;const c=t.ray.origin.distanceTo(Ui);c<t.near||c>t.far||e.push({distance:c,point:Ui.clone(),uv:qe.getInterpolation(Ui,Es,Bi,Ts,Or,Bo,zr,new ut),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}}function As(o,t,e,n,i,s){pi.subVectors(o,e).addScalar(.5).multiply(n),i!==void 0?(Ni.x=s*pi.x-i*pi.y,Ni.y=i*pi.x+s*pi.y):Ni.copy(pi),o.copy(t),o.x+=Ni.x,o.y+=Ni.y,o.applyMatrix4(Bc)}class Fc extends Cn{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Xt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const kr=new P,Gr=new P,Hr=new fe,Fo=new $s,Cs=new Ji;class om extends ye{constructor(t=new _e,e=new Fc){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let i=1,s=e.count;i<s;i++)kr.fromBufferAttribute(e,i-1),Gr.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=kr.distanceTo(Gr);t.setAttribute("lineDistance",new Jt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Cs.copy(n.boundingSphere),Cs.applyMatrix4(i),Cs.radius+=s,t.ray.intersectsSphere(Cs)===!1)return;Hr.copy(i).invert(),Fo.copy(t.ray).applyMatrix4(Hr);const r=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=r*r,l=new P,h=new P,d=new P,u=new P,f=this.isLineSegments?2:1,g=n.index,m=n.attributes.position;if(g!==null){const p=Math.max(0,a.start),_=Math.min(g.count,a.start+a.count);for(let w=p,v=_-1;w<v;w+=f){const R=g.getX(w),T=g.getX(w+1);if(l.fromBufferAttribute(m,R),h.fromBufferAttribute(m,T),Fo.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);const U=t.ray.origin.distanceTo(u);U<t.near||U>t.far||e.push({distance:U,point:d.clone().applyMatrix4(this.matrixWorld),index:w,face:null,faceIndex:null,object:this})}}else{const p=Math.max(0,a.start),_=Math.min(m.count,a.start+a.count);for(let w=p,v=_-1;w<v;w+=f){if(l.fromBufferAttribute(m,w),h.fromBufferAttribute(m,w+1),Fo.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);const T=t.ray.origin.distanceTo(u);T<t.near||T>t.far||e.push({distance:T,point:d.clone().applyMatrix4(this.matrixWorld),index:w,face:null,faceIndex:null,object:this})}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}}const Vr=new P,Wr=new P;class am extends om{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let i=0,s=e.count;i<s;i+=2)Vr.fromBufferAttribute(e,i),Wr.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+Vr.distanceTo(Wr);t.setAttribute("lineDistance",new Jt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Oc extends Cn{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Xt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const Xr=new fe,Qo=new $s,Rs=new Ji,Ps=new P;class rm extends ye{constructor(t=new _e,e=new Oc){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Rs.copy(n.boundingSphere),Rs.applyMatrix4(i),Rs.radius+=s,t.ray.intersectsSphere(Rs)===!1)return;Xr.copy(i).invert(),Qo.copy(t.ray).applyMatrix4(Xr);const r=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=r*r,l=n.index,d=n.attributes.position;if(l!==null){const u=Math.max(0,a.start),f=Math.min(l.count,a.start+a.count);for(let g=u,y=f;g<y;g++){const m=l.getX(g);Ps.fromBufferAttribute(d,m),qr(Ps,m,c,i,t,e,this)}}else{const u=Math.max(0,a.start),f=Math.min(d.count,a.start+a.count);for(let g=u,y=f;g<y;g++)Ps.fromBufferAttribute(d,g),qr(Ps,g,c,i,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}}function qr(o,t,e,n,i,s,a){const r=Qo.distanceSqToPoint(o);if(r<e){const c=new P;Qo.closestPointToPoint(o,c),c.applyMatrix4(n);const l=i.ray.origin.distanceTo(c);if(l<i.near||l>i.far)return;s.push({distance:l,distanceToRay:Math.sqrt(r),point:c,index:t,face:null,object:a})}}class zc extends Oe{constructor(t,e,n,i,s,a,r,c,l){super(t,e,n,i,s,a,r,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class sn{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){const n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const e=[];let n,i=this.getPoint(0),s=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),s+=n.distanceTo(i),e.push(s),i=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){const n=this.getLengths();let i=0;const s=n.length;let a;e?a=e:a=t*n[s-1];let r=0,c=s-1,l;for(;r<=c;)if(i=Math.floor(r+(c-r)/2),l=n[i]-a,l<0)r=i+1;else if(l>0)c=i-1;else{c=i;break}if(i=c,n[i]===a)return i/(s-1);const h=n[i],u=n[i+1]-h,f=(a-h)/u;return(i+f)/(s-1)}getTangent(t,e){let i=t-1e-4,s=t+1e-4;i<0&&(i=0),s>1&&(s=1);const a=this.getPoint(i),r=this.getPoint(s),c=e||(a.isVector2?new ut:new P);return c.copy(r).sub(a).normalize(),c}getTangentAt(t,e){const n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){const n=new P,i=[],s=[],a=[],r=new P,c=new fe;for(let f=0;f<=t;f++){const g=f/t;i[f]=this.getTangentAt(g,new P)}s[0]=new P,a[0]=new P;let l=Number.MAX_VALUE;const h=Math.abs(i[0].x),d=Math.abs(i[0].y),u=Math.abs(i[0].z);h<=l&&(l=h,n.set(1,0,0)),d<=l&&(l=d,n.set(0,1,0)),u<=l&&n.set(0,0,1),r.crossVectors(i[0],n).normalize(),s[0].crossVectors(i[0],r),a[0].crossVectors(i[0],s[0]);for(let f=1;f<=t;f++){if(s[f]=s[f-1].clone(),a[f]=a[f-1].clone(),r.crossVectors(i[f-1],i[f]),r.length()>Number.EPSILON){r.normalize();const g=Math.acos(Le(i[f-1].dot(i[f]),-1,1));s[f].applyMatrix4(c.makeRotationAxis(r,g))}a[f].crossVectors(i[f],s[f])}if(e===!0){let f=Math.acos(Le(s[0].dot(s[t]),-1,1));f/=t,i[0].dot(r.crossVectors(s[0],s[t]))>0&&(f=-f);for(let g=1;g<=t;g++)s[g].applyMatrix4(c.makeRotationAxis(i[g],f*g)),a[g].crossVectors(i[g],s[g])}return{tangents:i,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){const t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}}class ua extends sn{constructor(t=0,e=0,n=1,i=1,s=0,a=Math.PI*2,r=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=i,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=r,this.aRotation=c}getPoint(t,e){const n=e||new ut,i=Math.PI*2;let s=this.aEndAngle-this.aStartAngle;const a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=i;for(;s>i;)s-=i;s<Number.EPSILON&&(a?s=0:s=i),this.aClockwise===!0&&!a&&(s===i?s=-i:s=s-i);const r=this.aStartAngle+t*s;let c=this.aX+this.xRadius*Math.cos(r),l=this.aY+this.yRadius*Math.sin(r);if(this.aRotation!==0){const h=Math.cos(this.aRotation),d=Math.sin(this.aRotation),u=c-this.aX,f=l-this.aY;c=u*h-f*d+this.aX,l=u*d+f*h+this.aY}return n.set(c,l)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){const t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}}class cm extends ua{constructor(t,e,n,i,s,a){super(t,e,n,n,i,s,a),this.isArcCurve=!0,this.type="ArcCurve"}}function fa(){let o=0,t=0,e=0,n=0;function i(s,a,r,c){o=s,t=r,e=-3*s+3*a-2*r-c,n=2*s-2*a+r+c}return{initCatmullRom:function(s,a,r,c,l){i(a,r,l*(r-s),l*(c-a))},initNonuniformCatmullRom:function(s,a,r,c,l,h,d){let u=(a-s)/l-(r-s)/(l+h)+(r-a)/h,f=(r-a)/h-(c-a)/(h+d)+(c-r)/d;u*=h,f*=h,i(a,r,u,f)},calc:function(s){const a=s*s,r=a*s;return o+t*s+e*a+n*r}}}const Ls=new P,Oo=new fa,zo=new fa,ko=new fa;class kc extends sn{constructor(t=[],e=!1,n="centripetal",i=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=i}getPoint(t,e=new P){const n=e,i=this.points,s=i.length,a=(s-(this.closed?0:1))*t;let r=Math.floor(a),c=a-r;this.closed?r+=r>0?0:(Math.floor(Math.abs(r)/s)+1)*s:c===0&&r===s-1&&(r=s-2,c=1);let l,h;this.closed||r>0?l=i[(r-1)%s]:(Ls.subVectors(i[0],i[1]).add(i[0]),l=Ls);const d=i[r%s],u=i[(r+1)%s];if(this.closed||r+2<s?h=i[(r+2)%s]:(Ls.subVectors(i[s-1],i[s-2]).add(i[s-1]),h=Ls),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let g=Math.pow(l.distanceToSquared(d),f),y=Math.pow(d.distanceToSquared(u),f),m=Math.pow(u.distanceToSquared(h),f);y<1e-4&&(y=1),g<1e-4&&(g=y),m<1e-4&&(m=y),Oo.initNonuniformCatmullRom(l.x,d.x,u.x,h.x,g,y,m),zo.initNonuniformCatmullRom(l.y,d.y,u.y,h.y,g,y,m),ko.initNonuniformCatmullRom(l.z,d.z,u.z,h.z,g,y,m)}else this.curveType==="catmullrom"&&(Oo.initCatmullRom(l.x,d.x,u.x,h.x,this.tension),zo.initCatmullRom(l.y,d.y,u.y,h.y,this.tension),ko.initCatmullRom(l.z,d.z,u.z,h.z,this.tension));return n.set(Oo.calc(c),zo.calc(c),ko.calc(c)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(i.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const i=this.points[e];t.points.push(i.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(new P().fromArray(i))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}function Yr(o,t,e,n,i){const s=(n-t)*.5,a=(i-e)*.5,r=o*o,c=o*r;return(2*e-2*n+s+a)*c+(-3*e+3*n-2*s-a)*r+s*o+e}function lm(o,t){const e=1-o;return e*e*t}function hm(o,t){return 2*(1-o)*o*t}function dm(o,t){return o*o*t}function zi(o,t,e,n){return lm(o,t)+hm(o,e)+dm(o,n)}function um(o,t){const e=1-o;return e*e*e*t}function fm(o,t){const e=1-o;return 3*e*e*o*t}function pm(o,t){return 3*(1-o)*o*o*t}function mm(o,t){return o*o*o*t}function ki(o,t,e,n,i){return um(o,t)+fm(o,e)+pm(o,n)+mm(o,i)}class Gc extends sn{constructor(t=new ut,e=new ut,n=new ut,i=new ut){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new ut){const n=e,i=this.v0,s=this.v1,a=this.v2,r=this.v3;return n.set(ki(t,i.x,s.x,a.x,r.x),ki(t,i.y,s.y,a.y,r.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class gm extends sn{constructor(t=new P,e=new P,n=new P,i=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new P){const n=e,i=this.v0,s=this.v1,a=this.v2,r=this.v3;return n.set(ki(t,i.x,s.x,a.x,r.x),ki(t,i.y,s.y,a.y,r.y),ki(t,i.z,s.z,a.z,r.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class Hc extends sn{constructor(t=new ut,e=new ut){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new ut){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new ut){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class ym extends sn{constructor(t=new P,e=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new P){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new P){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Vc extends sn{constructor(t=new ut,e=new ut,n=new ut){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new ut){const n=e,i=this.v0,s=this.v1,a=this.v2;return n.set(zi(t,i.x,s.x,a.x),zi(t,i.y,s.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Wc extends sn{constructor(t=new P,e=new P,n=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new P){const n=e,i=this.v0,s=this.v1,a=this.v2;return n.set(zi(t,i.x,s.x,a.x),zi(t,i.y,s.y,a.y),zi(t,i.z,s.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Xc extends sn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new ut){const n=e,i=this.points,s=(i.length-1)*t,a=Math.floor(s),r=s-a,c=i[a===0?a:a-1],l=i[a],h=i[a>i.length-2?i.length-1:a+1],d=i[a>i.length-3?i.length-1:a+2];return n.set(Yr(r,c.x,l.x,h.x,d.x),Yr(r,c.y,l.y,h.y,d.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(i.clone())}return this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const i=this.points[e];t.points.push(i.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(new ut().fromArray(i))}return this}}var Ws=Object.freeze({__proto__:null,ArcCurve:cm,CatmullRomCurve3:kc,CubicBezierCurve:Gc,CubicBezierCurve3:gm,EllipseCurve:ua,LineCurve:Hc,LineCurve3:ym,QuadraticBezierCurve:Vc,QuadraticBezierCurve3:Wc,SplineCurve:Xc});class wm extends sn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){const t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){const n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Ws[n](e,t))}return this}getPoint(t,e){const n=t*this.getLength(),i=this.getCurveLengths();let s=0;for(;s<i.length;){if(i[s]>=n){const a=i[s]-n,r=this.curves[s],c=r.getLength(),l=c===0?0:1-a/c;return r.getPointAt(l,e)}s++}return null}getLength(){const t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const t=[];let e=0;for(let n=0,i=this.curves.length;n<i;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){const e=[];let n;for(let i=0,s=this.curves;i<s.length;i++){const a=s[i],r=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,c=a.getPoints(r);for(let l=0;l<c.length;l++){const h=c[l];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){const i=t.curves[e];this.curves.push(i.clone())}return this.autoClose=t.autoClose,this}toJSON(){const t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){const i=this.curves[e];t.curves.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){const i=t.curves[e];this.curves.push(new Ws[i.type]().fromJSON(i))}return this}}class $r extends wm{constructor(t){super(),this.type="Path",this.currentPoint=new ut,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){const n=new Hc(this.currentPoint.clone(),new ut(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,i){const s=new Vc(this.currentPoint.clone(),new ut(t,e),new ut(n,i));return this.curves.push(s),this.currentPoint.set(n,i),this}bezierCurveTo(t,e,n,i,s,a){const r=new Gc(this.currentPoint.clone(),new ut(t,e),new ut(n,i),new ut(s,a));return this.curves.push(r),this.currentPoint.set(s,a),this}splineThru(t){const e=[this.currentPoint.clone()].concat(t),n=new Xc(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,i,s,a){const r=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(t+r,e+c,n,i,s,a),this}absarc(t,e,n,i,s,a){return this.absellipse(t,e,n,n,i,s,a),this}ellipse(t,e,n,i,s,a,r,c){const l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+l,e+h,n,i,s,a,r,c),this}absellipse(t,e,n,i,s,a,r,c){const l=new ua(t,e,n,i,s,a,r,c);if(this.curves.length>0){const d=l.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(l);const h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){const t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}}class en extends _e{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);const s=[],a=[],r=[],c=[],l=new P,h=new ut;a.push(0,0,0),r.push(0,0,1),c.push(.5,.5);for(let d=0,u=3;d<=e;d++,u+=3){const f=n+d/e*i;l.x=t*Math.cos(f),l.y=t*Math.sin(f),a.push(l.x,l.y,l.z),r.push(0,0,1),h.x=(a[u]/t+1)/2,h.y=(a[u+1]/t+1)/2,c.push(h.x,h.y)}for(let d=1;d<=e;d++)s.push(d,d+1,0);this.setIndex(s),this.setAttribute("position",new Jt(a,3)),this.setAttribute("normal",new Jt(r,3)),this.setAttribute("uv",new Jt(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new en(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class J extends _e{constructor(t=1,e=1,n=1,i=32,s=1,a=!1,r=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:s,openEnded:a,thetaStart:r,thetaLength:c};const l=this;i=Math.floor(i),s=Math.floor(s);const h=[],d=[],u=[],f=[];let g=0;const y=[],m=n/2;let p=0;_(),a===!1&&(t>0&&w(!0),e>0&&w(!1)),this.setIndex(h),this.setAttribute("position",new Jt(d,3)),this.setAttribute("normal",new Jt(u,3)),this.setAttribute("uv",new Jt(f,2));function _(){const v=new P,R=new P;let T=0;const E=(e-t)/n;for(let U=0;U<=s;U++){const M=[],S=U/s,L=S*(e-t)+t;for(let F=0;F<=i;F++){const Z=F/i,I=Z*c+r,B=Math.sin(I),k=Math.cos(I);R.x=L*B,R.y=-S*n+m,R.z=L*k,d.push(R.x,R.y,R.z),v.set(B,E,k).normalize(),u.push(v.x,v.y,v.z),f.push(Z,1-S),M.push(g++)}y.push(M)}for(let U=0;U<i;U++)for(let M=0;M<s;M++){const S=y[M][U],L=y[M+1][U],F=y[M+1][U+1],Z=y[M][U+1];h.push(S,L,Z),h.push(L,F,Z),T+=6}l.addGroup(p,T,0),p+=T}function w(v){const R=g,T=new ut,E=new P;let U=0;const M=v===!0?t:e,S=v===!0?1:-1;for(let F=1;F<=i;F++)d.push(0,m*S,0),u.push(0,S,0),f.push(.5,.5),g++;const L=g;for(let F=0;F<=i;F++){const I=F/i*c+r,B=Math.cos(I),k=Math.sin(I);E.x=M*k,E.y=m*S,E.z=M*B,d.push(E.x,E.y,E.z),u.push(0,S,0),T.x=B*.5+.5,T.y=k*.5*S+.5,f.push(T.x,T.y),g++}for(let F=0;F<i;F++){const Z=R+F,I=L+F;v===!0?h.push(I,I+1,Z):h.push(I+1,I,Z),U+=3}l.addGroup(p,U,v===!0?1:2),p+=U}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new J(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class re extends J{constructor(t=1,e=1,n=32,i=1,s=!1,a=0,r=Math.PI*2){super(0,t,e,n,i,s,a,r),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:s,thetaStart:a,thetaLength:r}}static fromJSON(t){return new re(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Qi extends _e{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};const s=[],a=[];r(i),l(n),h(),this.setAttribute("position",new Jt(s,3)),this.setAttribute("normal",new Jt(s.slice(),3)),this.setAttribute("uv",new Jt(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function r(_){const w=new P,v=new P,R=new P;for(let T=0;T<e.length;T+=3)f(e[T+0],w),f(e[T+1],v),f(e[T+2],R),c(w,v,R,_)}function c(_,w,v,R){const T=R+1,E=[];for(let U=0;U<=T;U++){E[U]=[];const M=_.clone().lerp(v,U/T),S=w.clone().lerp(v,U/T),L=T-U;for(let F=0;F<=L;F++)F===0&&U===T?E[U][F]=M:E[U][F]=M.clone().lerp(S,F/L)}for(let U=0;U<T;U++)for(let M=0;M<2*(T-U)-1;M++){const S=Math.floor(M/2);M%2===0?(u(E[U][S+1]),u(E[U+1][S]),u(E[U][S])):(u(E[U][S+1]),u(E[U+1][S+1]),u(E[U+1][S]))}}function l(_){const w=new P;for(let v=0;v<s.length;v+=3)w.x=s[v+0],w.y=s[v+1],w.z=s[v+2],w.normalize().multiplyScalar(_),s[v+0]=w.x,s[v+1]=w.y,s[v+2]=w.z}function h(){const _=new P;for(let w=0;w<s.length;w+=3){_.x=s[w+0],_.y=s[w+1],_.z=s[w+2];const v=m(_)/2/Math.PI+.5,R=p(_)/Math.PI+.5;a.push(v,1-R)}g(),d()}function d(){for(let _=0;_<a.length;_+=6){const w=a[_+0],v=a[_+2],R=a[_+4],T=Math.max(w,v,R),E=Math.min(w,v,R);T>.9&&E<.1&&(w<.2&&(a[_+0]+=1),v<.2&&(a[_+2]+=1),R<.2&&(a[_+4]+=1))}}function u(_){s.push(_.x,_.y,_.z)}function f(_,w){const v=_*3;w.x=t[v+0],w.y=t[v+1],w.z=t[v+2]}function g(){const _=new P,w=new P,v=new P,R=new P,T=new ut,E=new ut,U=new ut;for(let M=0,S=0;M<s.length;M+=9,S+=6){_.set(s[M+0],s[M+1],s[M+2]),w.set(s[M+3],s[M+4],s[M+5]),v.set(s[M+6],s[M+7],s[M+8]),T.set(a[S+0],a[S+1]),E.set(a[S+2],a[S+3]),U.set(a[S+4],a[S+5]),R.copy(_).add(w).add(v).divideScalar(3);const L=m(R);y(T,S+0,_,L),y(E,S+2,w,L),y(U,S+4,v,L)}}function y(_,w,v,R){R<0&&_.x===1&&(a[w]=_.x-1),v.x===0&&v.z===0&&(a[w]=R/2/Math.PI+.5)}function m(_){return Math.atan2(_.z,-_.x)}function p(_){return Math.atan2(-_.y,Math.sqrt(_.x*_.x+_.z*_.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Qi(t.vertices,t.indices,t.radius,t.details)}}class Gi extends Qi{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,i=1/n,s=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-i,-n,0,-i,n,0,i,-n,0,i,n,-i,-n,0,-i,n,0,i,-n,0,i,n,0,-n,0,-i,n,0,-i,-n,0,i,n,0,i],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(s,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Gi(t.radius,t.detail)}}class pa extends $r{constructor(t){super(t),this.uuid=pn(),this.type="Shape",this.holes=[]}getPointsHoles(t){const e=[];for(let n=0,i=this.holes.length;n<i;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){const i=t.holes[e];this.holes.push(i.clone())}return this}toJSON(){const t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){const i=this.holes[e];t.holes.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){const i=t.holes[e];this.holes.push(new $r().fromJSON(i))}return this}}const xm={triangulate:function(o,t,e=2){const n=t&&t.length,i=n?t[0]*e:o.length;let s=qc(o,0,i,e,!0);const a=[];if(!s||s.next===s.prev)return a;let r,c,l,h,d,u,f;if(n&&(s=bm(o,t,s,e)),o.length>80*e){r=l=o[0],c=h=o[1];for(let g=e;g<i;g+=e)d=o[g],u=o[g+1],d<r&&(r=d),u<c&&(c=u),d>l&&(l=d),u>h&&(h=u);f=Math.max(l-r,h-c),f=f!==0?32767/f:0}return Xi(s,a,e,r,c,f,0),a}};function qc(o,t,e,n,i){let s,a;if(i===Nm(o,t,e,n)>0)for(s=t;s<e;s+=n)a=jr(s,o[s],o[s+1],a);else for(s=e-n;s>=t;s-=n)a=jr(s,o[s],o[s+1],a);return a&&Ks(a,a.next)&&(Yi(a),a=a.next),a}function Xn(o,t){if(!o)return o;t||(t=o);let e=o,n;do if(n=!1,!e.steiner&&(Ks(e,e.next)||me(e.prev,e,e.next)===0)){if(Yi(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function Xi(o,t,e,n,i,s,a){if(!o)return;!a&&s&&Rm(o,n,i,s);let r=o,c,l;for(;o.prev!==o.next;){if(c=o.prev,l=o.next,s?_m(o,n,i,s):vm(o)){t.push(c.i/e|0),t.push(o.i/e|0),t.push(l.i/e|0),Yi(o),o=l.next,r=l.next;continue}if(o=l,o===r){a?a===1?(o=Mm(Xn(o),t,e),Xi(o,t,e,n,i,s,2)):a===2&&Sm(o,t,e,n,i,s):Xi(Xn(o),t,e,n,i,s,1);break}}}function vm(o){const t=o.prev,e=o,n=o.next;if(me(t,e,n)>=0)return!1;const i=t.x,s=e.x,a=n.x,r=t.y,c=e.y,l=n.y,h=i<s?i<a?i:a:s<a?s:a,d=r<c?r<l?r:l:c<l?c:l,u=i>s?i>a?i:a:s>a?s:a,f=r>c?r>l?r:l:c>l?c:l;let g=n.next;for(;g!==t;){if(g.x>=h&&g.x<=u&&g.y>=d&&g.y<=f&&xi(i,r,s,c,a,l,g.x,g.y)&&me(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function _m(o,t,e,n){const i=o.prev,s=o,a=o.next;if(me(i,s,a)>=0)return!1;const r=i.x,c=s.x,l=a.x,h=i.y,d=s.y,u=a.y,f=r<c?r<l?r:l:c<l?c:l,g=h<d?h<u?h:u:d<u?d:u,y=r>c?r>l?r:l:c>l?c:l,m=h>d?h>u?h:u:d>u?d:u,p=ta(f,g,t,e,n),_=ta(y,m,t,e,n);let w=o.prevZ,v=o.nextZ;for(;w&&w.z>=p&&v&&v.z<=_;){if(w.x>=f&&w.x<=y&&w.y>=g&&w.y<=m&&w!==i&&w!==a&&xi(r,h,c,d,l,u,w.x,w.y)&&me(w.prev,w,w.next)>=0||(w=w.prevZ,v.x>=f&&v.x<=y&&v.y>=g&&v.y<=m&&v!==i&&v!==a&&xi(r,h,c,d,l,u,v.x,v.y)&&me(v.prev,v,v.next)>=0))return!1;v=v.nextZ}for(;w&&w.z>=p;){if(w.x>=f&&w.x<=y&&w.y>=g&&w.y<=m&&w!==i&&w!==a&&xi(r,h,c,d,l,u,w.x,w.y)&&me(w.prev,w,w.next)>=0)return!1;w=w.prevZ}for(;v&&v.z<=_;){if(v.x>=f&&v.x<=y&&v.y>=g&&v.y<=m&&v!==i&&v!==a&&xi(r,h,c,d,l,u,v.x,v.y)&&me(v.prev,v,v.next)>=0)return!1;v=v.nextZ}return!0}function Mm(o,t,e){let n=o;do{const i=n.prev,s=n.next.next;!Ks(i,s)&&Yc(i,n,n.next,s)&&qi(i,s)&&qi(s,i)&&(t.push(i.i/e|0),t.push(n.i/e|0),t.push(s.i/e|0),Yi(n),Yi(n.next),n=o=s),n=n.next}while(n!==o);return Xn(n)}function Sm(o,t,e,n,i,s){let a=o;do{let r=a.next.next;for(;r!==a.prev;){if(a.i!==r.i&&Im(a,r)){let c=$c(a,r);a=Xn(a,a.next),c=Xn(c,c.next),Xi(a,t,e,n,i,s,0),Xi(c,t,e,n,i,s,0);return}r=r.next}a=a.next}while(a!==o)}function bm(o,t,e,n){const i=[];let s,a,r,c,l;for(s=0,a=t.length;s<a;s++)r=t[s]*n,c=s<a-1?t[s+1]*n:o.length,l=qc(o,r,c,n,!1),l===l.next&&(l.steiner=!0),i.push(Lm(l));for(i.sort(Em),s=0;s<i.length;s++)e=Tm(i[s],e);return e}function Em(o,t){return o.x-t.x}function Tm(o,t){const e=Am(o,t);if(!e)return t;const n=$c(e,o);return Xn(n,n.next),Xn(e,e.next)}function Am(o,t){let e=t,n=-1/0,i;const s=o.x,a=o.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){const u=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(u<=s&&u>n&&(n=u,i=e.x<e.next.x?e:e.next,u===s))return i}e=e.next}while(e!==t);if(!i)return null;const r=i,c=i.x,l=i.y;let h=1/0,d;e=i;do s>=e.x&&e.x>=c&&s!==e.x&&xi(a<l?s:n,a,c,l,a<l?n:s,a,e.x,e.y)&&(d=Math.abs(a-e.y)/(s-e.x),qi(e,o)&&(d<h||d===h&&(e.x>i.x||e.x===i.x&&Cm(i,e)))&&(i=e,h=d)),e=e.next;while(e!==r);return i}function Cm(o,t){return me(o.prev,o,t.prev)<0&&me(t.next,o,o.next)<0}function Rm(o,t,e,n){let i=o;do i.z===0&&(i.z=ta(i.x,i.y,t,e,n)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==o);i.prevZ.nextZ=null,i.prevZ=null,Pm(i)}function Pm(o){let t,e,n,i,s,a,r,c,l=1;do{for(e=o,o=null,s=null,a=0;e;){for(a++,n=e,r=0,t=0;t<l&&(r++,n=n.nextZ,!!n);t++);for(c=l;r>0||c>0&&n;)r!==0&&(c===0||!n||e.z<=n.z)?(i=e,e=e.nextZ,r--):(i=n,n=n.nextZ,c--),s?s.nextZ=i:o=i,i.prevZ=s,s=i;e=n}s.nextZ=null,l*=2}while(a>1);return o}function ta(o,t,e,n,i){return o=(o-e)*i|0,t=(t-n)*i|0,o=(o|o<<8)&16711935,o=(o|o<<4)&252645135,o=(o|o<<2)&858993459,o=(o|o<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,o|t<<1}function Lm(o){let t=o,e=o;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==o);return e}function xi(o,t,e,n,i,s,a,r){return(i-a)*(t-r)>=(o-a)*(s-r)&&(o-a)*(n-r)>=(e-a)*(t-r)&&(e-a)*(s-r)>=(i-a)*(n-r)}function Im(o,t){return o.next.i!==t.i&&o.prev.i!==t.i&&!Dm(o,t)&&(qi(o,t)&&qi(t,o)&&Um(o,t)&&(me(o.prev,o,t.prev)||me(o,t.prev,t))||Ks(o,t)&&me(o.prev,o,o.next)>0&&me(t.prev,t,t.next)>0)}function me(o,t,e){return(t.y-o.y)*(e.x-t.x)-(t.x-o.x)*(e.y-t.y)}function Ks(o,t){return o.x===t.x&&o.y===t.y}function Yc(o,t,e,n){const i=Ds(me(o,t,e)),s=Ds(me(o,t,n)),a=Ds(me(e,n,o)),r=Ds(me(e,n,t));return!!(i!==s&&a!==r||i===0&&Is(o,e,t)||s===0&&Is(o,n,t)||a===0&&Is(e,o,n)||r===0&&Is(e,t,n))}function Is(o,t,e){return t.x<=Math.max(o.x,e.x)&&t.x>=Math.min(o.x,e.x)&&t.y<=Math.max(o.y,e.y)&&t.y>=Math.min(o.y,e.y)}function Ds(o){return o>0?1:o<0?-1:0}function Dm(o,t){let e=o;do{if(e.i!==o.i&&e.next.i!==o.i&&e.i!==t.i&&e.next.i!==t.i&&Yc(e,e.next,o,t))return!0;e=e.next}while(e!==o);return!1}function qi(o,t){return me(o.prev,o,o.next)<0?me(o,t,o.next)>=0&&me(o,o.prev,t)>=0:me(o,t,o.prev)<0||me(o,o.next,t)<0}function Um(o,t){let e=o,n=!1;const i=(o.x+t.x)/2,s=(o.y+t.y)/2;do e.y>s!=e.next.y>s&&e.next.y!==e.y&&i<(e.next.x-e.x)*(s-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==o);return n}function $c(o,t){const e=new ea(o.i,o.x,o.y),n=new ea(t.i,t.x,t.y),i=o.next,s=t.prev;return o.next=t,t.prev=o,e.next=i,i.prev=e,n.next=e,e.prev=n,s.next=n,n.prev=s,n}function jr(o,t,e,n){const i=new ea(o,t,e);return n?(i.next=n.next,i.prev=n,n.next.prev=i,n.next=i):(i.prev=i,i.next=i),i}function Yi(o){o.next.prev=o.prev,o.prev.next=o.next,o.prevZ&&(o.prevZ.nextZ=o.nextZ),o.nextZ&&(o.nextZ.prevZ=o.prevZ)}function ea(o,t,e){this.i=o,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function Nm(o,t,e,n){let i=0;for(let s=t,a=e-n;s<e;s+=n)i+=(o[a]-o[s])*(o[s+1]+o[a+1]),a=s;return i}class Hi{static area(t){const e=t.length;let n=0;for(let i=e-1,s=0;s<e;i=s++)n+=t[i].x*t[s].y-t[s].x*t[i].y;return n*.5}static isClockWise(t){return Hi.area(t)<0}static triangulateShape(t,e){const n=[],i=[],s=[];Zr(t),Kr(n,t);let a=t.length;e.forEach(Zr);for(let c=0;c<e.length;c++)i.push(a),a+=e[c].length,Kr(n,e[c]);const r=xm.triangulate(n,i);for(let c=0;c<r.length;c+=3)s.push(r.slice(c,c+3));return s}}function Zr(o){const t=o.length;t>2&&o[t-1].equals(o[0])&&o.pop()}function Kr(o,t){for(let e=0;e<t.length;e++)o.push(t[e].x),o.push(t[e].y)}class $i extends _e{constructor(t=new pa([new ut(.5,.5),new ut(-.5,.5),new ut(-.5,-.5),new ut(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];const n=this,i=[],s=[];for(let r=0,c=t.length;r<c;r++){const l=t[r];a(l)}this.setAttribute("position",new Jt(i,3)),this.setAttribute("uv",new Jt(s,2)),this.computeVertexNormals();function a(r){const c=[],l=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,d=e.depth!==void 0?e.depth:1;let u=e.bevelEnabled!==void 0?e.bevelEnabled:!0,f=e.bevelThickness!==void 0?e.bevelThickness:.2,g=e.bevelSize!==void 0?e.bevelSize:f-.1,y=e.bevelOffset!==void 0?e.bevelOffset:0,m=e.bevelSegments!==void 0?e.bevelSegments:3;const p=e.extrudePath,_=e.UVGenerator!==void 0?e.UVGenerator:Bm;let w,v=!1,R,T,E,U;p&&(w=p.getSpacedPoints(h),v=!0,u=!1,R=p.computeFrenetFrames(h,!1),T=new P,E=new P,U=new P),u||(m=0,f=0,g=0,y=0);const M=r.extractPoints(l);let S=M.shape;const L=M.holes;if(!Hi.isClockWise(S)){S=S.reverse();for(let D=0,pt=L.length;D<pt;D++){const K=L[D];Hi.isClockWise(K)&&(L[D]=K.reverse())}}const Z=Hi.triangulateShape(S,L),I=S;for(let D=0,pt=L.length;D<pt;D++){const K=L[D];S=S.concat(K)}function B(D,pt,K){return pt||console.error("THREE.ExtrudeGeometry: vec does not exist"),D.clone().addScaledVector(pt,K)}const k=S.length,Y=Z.length;function $(D,pt,K){let ct,tt,It;const mt=D.x-pt.x,A=D.y-pt.y,b=K.x-D.x,z=K.y-D.y,st=mt*mt+A*A,ot=mt*z-A*b;if(Math.abs(ot)>Number.EPSILON){const nt=Math.sqrt(st),At=Math.sqrt(b*b+z*z),wt=pt.x-A/nt,St=pt.y+mt/nt,kt=K.x-z/At,Ht=K.y+b/At,at=((kt-wt)*z-(Ht-St)*b)/(mt*z-A*b);ct=wt+mt*at-D.x,tt=St+A*at-D.y;const Qt=ct*ct+tt*tt;if(Qt<=2)return new ut(ct,tt);It=Math.sqrt(Qt/2)}else{let nt=!1;mt>Number.EPSILON?b>Number.EPSILON&&(nt=!0):mt<-Number.EPSILON?b<-Number.EPSILON&&(nt=!0):Math.sign(A)===Math.sign(z)&&(nt=!0),nt?(ct=-A,tt=mt,It=Math.sqrt(st)):(ct=mt,tt=A,It=Math.sqrt(st/2))}return new ut(ct/It,tt/It)}const q=[];for(let D=0,pt=I.length,K=pt-1,ct=D+1;D<pt;D++,K++,ct++)K===pt&&(K=0),ct===pt&&(ct=0),q[D]=$(I[D],I[K],I[ct]);const Q=[];let it,rt=q.concat();for(let D=0,pt=L.length;D<pt;D++){const K=L[D];it=[];for(let ct=0,tt=K.length,It=tt-1,mt=ct+1;ct<tt;ct++,It++,mt++)It===tt&&(It=0),mt===tt&&(mt=0),it[ct]=$(K[ct],K[It],K[mt]);Q.push(it),rt=rt.concat(it)}for(let D=0;D<m;D++){const pt=D/m,K=f*Math.cos(pt*Math.PI/2),ct=g*Math.sin(pt*Math.PI/2)+y;for(let tt=0,It=I.length;tt<It;tt++){const mt=B(I[tt],q[tt],ct);_t(mt.x,mt.y,-K)}for(let tt=0,It=L.length;tt<It;tt++){const mt=L[tt];it=Q[tt];for(let A=0,b=mt.length;A<b;A++){const z=B(mt[A],it[A],ct);_t(z.x,z.y,-K)}}}const V=g+y;for(let D=0;D<k;D++){const pt=u?B(S[D],rt[D],V):S[D];v?(E.copy(R.normals[0]).multiplyScalar(pt.x),T.copy(R.binormals[0]).multiplyScalar(pt.y),U.copy(w[0]).add(E).add(T),_t(U.x,U.y,U.z)):_t(pt.x,pt.y,0)}for(let D=1;D<=h;D++)for(let pt=0;pt<k;pt++){const K=u?B(S[pt],rt[pt],V):S[pt];v?(E.copy(R.normals[D]).multiplyScalar(K.x),T.copy(R.binormals[D]).multiplyScalar(K.y),U.copy(w[D]).add(E).add(T),_t(U.x,U.y,U.z)):_t(K.x,K.y,d/h*D)}for(let D=m-1;D>=0;D--){const pt=D/m,K=f*Math.cos(pt*Math.PI/2),ct=g*Math.sin(pt*Math.PI/2)+y;for(let tt=0,It=I.length;tt<It;tt++){const mt=B(I[tt],q[tt],ct);_t(mt.x,mt.y,d+K)}for(let tt=0,It=L.length;tt<It;tt++){const mt=L[tt];it=Q[tt];for(let A=0,b=mt.length;A<b;A++){const z=B(mt[A],it[A],ct);v?_t(z.x,z.y+w[h-1].y,w[h-1].x+K):_t(z.x,z.y,d+K)}}}et(),ft();function et(){const D=i.length/3;if(u){let pt=0,K=k*pt;for(let ct=0;ct<Y;ct++){const tt=Z[ct];Nt(tt[2]+K,tt[1]+K,tt[0]+K)}pt=h+m*2,K=k*pt;for(let ct=0;ct<Y;ct++){const tt=Z[ct];Nt(tt[0]+K,tt[1]+K,tt[2]+K)}}else{for(let pt=0;pt<Y;pt++){const K=Z[pt];Nt(K[2],K[1],K[0])}for(let pt=0;pt<Y;pt++){const K=Z[pt];Nt(K[0]+k*h,K[1]+k*h,K[2]+k*h)}}n.addGroup(D,i.length/3-D,0)}function ft(){const D=i.length/3;let pt=0;Et(I,pt),pt+=I.length;for(let K=0,ct=L.length;K<ct;K++){const tt=L[K];Et(tt,pt),pt+=tt.length}n.addGroup(D,i.length/3-D,1)}function Et(D,pt){let K=D.length;for(;--K>=0;){const ct=K;let tt=K-1;tt<0&&(tt=D.length-1);for(let It=0,mt=h+m*2;It<mt;It++){const A=k*It,b=k*(It+1),z=pt+ct+A,st=pt+tt+A,ot=pt+tt+b,nt=pt+ct+b;zt(z,st,ot,nt)}}}function _t(D,pt,K){c.push(D),c.push(pt),c.push(K)}function Nt(D,pt,K){Tt(D),Tt(pt),Tt(K);const ct=i.length/3,tt=_.generateTopUV(n,i,ct-3,ct-2,ct-1);Ft(tt[0]),Ft(tt[1]),Ft(tt[2])}function zt(D,pt,K,ct){Tt(D),Tt(pt),Tt(ct),Tt(pt),Tt(K),Tt(ct);const tt=i.length/3,It=_.generateSideWallUV(n,i,tt-6,tt-3,tt-2,tt-1);Ft(It[0]),Ft(It[1]),Ft(It[3]),Ft(It[1]),Ft(It[2]),Ft(It[3])}function Tt(D){i.push(c[D*3+0]),i.push(c[D*3+1]),i.push(c[D*3+2])}function Ft(D){s.push(D.x),s.push(D.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON(),e=this.parameters.shapes,n=this.parameters.options;return Fm(e,n,t)}static fromJSON(t,e){const n=[];for(let s=0,a=t.shapes.length;s<a;s++){const r=e[t.shapes[s]];n.push(r)}const i=t.options.extrudePath;return i!==void 0&&(t.options.extrudePath=new Ws[i.type]().fromJSON(i)),new $i(n,t.options)}}const Bm={generateTopUV:function(o,t,e,n,i){const s=t[e*3],a=t[e*3+1],r=t[n*3],c=t[n*3+1],l=t[i*3],h=t[i*3+1];return[new ut(s,a),new ut(r,c),new ut(l,h)]},generateSideWallUV:function(o,t,e,n,i,s){const a=t[e*3],r=t[e*3+1],c=t[e*3+2],l=t[n*3],h=t[n*3+1],d=t[n*3+2],u=t[i*3],f=t[i*3+1],g=t[i*3+2],y=t[s*3],m=t[s*3+1],p=t[s*3+2];return Math.abs(r-h)<Math.abs(a-l)?[new ut(a,1-c),new ut(l,1-d),new ut(u,1-g),new ut(y,1-p)]:[new ut(r,1-c),new ut(h,1-d),new ut(f,1-g),new ut(m,1-p)]}};function Fm(o,t,e){if(e.shapes=[],Array.isArray(o))for(let n=0,i=o.length;n<i;n++){const s=o[n];e.shapes.push(s.uuid)}else e.shapes.push(o.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}class Xs extends Qi{constructor(t=1,e=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],i=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,i,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Xs(t.radius,t.detail)}}class ji extends _e{constructor(t=.5,e=1,n=32,i=1,s=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:i,thetaStart:s,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);const r=[],c=[],l=[],h=[];let d=t;const u=(e-t)/i,f=new P,g=new ut;for(let y=0;y<=i;y++){for(let m=0;m<=n;m++){const p=s+m/n*a;f.x=d*Math.cos(p),f.y=d*Math.sin(p),c.push(f.x,f.y,f.z),l.push(0,0,1),g.x=(f.x/e+1)/2,g.y=(f.y/e+1)/2,h.push(g.x,g.y)}d+=u}for(let y=0;y<i;y++){const m=y*(n+1);for(let p=0;p<n;p++){const _=p+m,w=_,v=_+n+1,R=_+n+2,T=_+1;r.push(w,v,T),r.push(v,R,T)}}this.setIndex(r),this.setAttribute("position",new Jt(c,3)),this.setAttribute("normal",new Jt(l,3)),this.setAttribute("uv",new Jt(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ji(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Lt extends _e{constructor(t=1,e=32,n=16,i=0,s=Math.PI*2,a=0,r=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:s,thetaStart:a,thetaLength:r},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const c=Math.min(a+r,Math.PI);let l=0;const h=[],d=new P,u=new P,f=[],g=[],y=[],m=[];for(let p=0;p<=n;p++){const _=[],w=p/n;let v=0;p===0&&a===0?v=.5/e:p===n&&c===Math.PI&&(v=-.5/e);for(let R=0;R<=e;R++){const T=R/e;d.x=-t*Math.cos(i+T*s)*Math.sin(a+w*r),d.y=t*Math.cos(a+w*r),d.z=t*Math.sin(i+T*s)*Math.sin(a+w*r),g.push(d.x,d.y,d.z),u.copy(d).normalize(),y.push(u.x,u.y,u.z),m.push(T+v,1-w),_.push(l++)}h.push(_)}for(let p=0;p<n;p++)for(let _=0;_<e;_++){const w=h[p][_+1],v=h[p][_],R=h[p+1][_],T=h[p+1][_+1];(p!==0||a>0)&&f.push(w,v,T),(p!==n-1||c<Math.PI)&&f.push(v,R,T)}this.setIndex(f),this.setAttribute("position",new Jt(g,3)),this.setAttribute("normal",new Jt(y,3)),this.setAttribute("uv",new Jt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Lt(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class ma extends Qi{constructor(t=1,e=0){const n=[1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],i=[2,1,0,0,3,2,1,3,0,2,3,1];super(n,i,t,e),this.type="TetrahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new ma(t.radius,t.detail)}}class Sn extends _e{constructor(t=1,e=.4,n=12,i=48,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:i,arc:s},n=Math.floor(n),i=Math.floor(i);const a=[],r=[],c=[],l=[],h=new P,d=new P,u=new P;for(let f=0;f<=n;f++)for(let g=0;g<=i;g++){const y=g/i*s,m=f/n*Math.PI*2;d.x=(t+e*Math.cos(m))*Math.cos(y),d.y=(t+e*Math.cos(m))*Math.sin(y),d.z=e*Math.sin(m),r.push(d.x,d.y,d.z),h.x=t*Math.cos(y),h.y=t*Math.sin(y),u.subVectors(d,h).normalize(),c.push(u.x,u.y,u.z),l.push(g/i),l.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=i;g++){const y=(i+1)*f+g-1,m=(i+1)*(f-1)+g-1,p=(i+1)*(f-1)+g,_=(i+1)*f+g;a.push(y,m,_),a.push(m,p,_)}this.setIndex(a),this.setAttribute("position",new Jt(r,3)),this.setAttribute("normal",new Jt(c,3)),this.setAttribute("uv",new Jt(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Sn(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}class ga extends _e{constructor(t=new Wc(new P(-1,-1,0),new P(-1,1,0),new P(1,1,0)),e=64,n=1,i=8,s=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:n,radialSegments:i,closed:s};const a=t.computeFrenetFrames(e,s);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;const r=new P,c=new P,l=new ut;let h=new P;const d=[],u=[],f=[],g=[];y(),this.setIndex(g),this.setAttribute("position",new Jt(d,3)),this.setAttribute("normal",new Jt(u,3)),this.setAttribute("uv",new Jt(f,2));function y(){for(let w=0;w<e;w++)m(w);m(s===!1?e:0),_(),p()}function m(w){h=t.getPointAt(w/e,h);const v=a.normals[w],R=a.binormals[w];for(let T=0;T<=i;T++){const E=T/i*Math.PI*2,U=Math.sin(E),M=-Math.cos(E);c.x=M*v.x+U*R.x,c.y=M*v.y+U*R.y,c.z=M*v.z+U*R.z,c.normalize(),u.push(c.x,c.y,c.z),r.x=h.x+n*c.x,r.y=h.y+n*c.y,r.z=h.z+n*c.z,d.push(r.x,r.y,r.z)}}function p(){for(let w=1;w<=e;w++)for(let v=1;v<=i;v++){const R=(i+1)*(w-1)+(v-1),T=(i+1)*w+(v-1),E=(i+1)*w+v,U=(i+1)*(w-1)+v;g.push(R,T,U),g.push(T,E,U)}}function _(){for(let w=0;w<=e;w++)for(let v=0;v<=i;v++)l.x=w/e,l.y=v/i,f.push(l.x,l.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new ga(new Ws[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}}class H extends Cn{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Xt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Xt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=pc,this.normalScale=new ut(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=oa,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class Js extends ye{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Xt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}}class Om extends Js{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ye.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Xt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}}const Go=new fe,Jr=new P,Qr=new P;class ya{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ut(512,512),this.map=null,this.mapPass=null,this.matrix=new fe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new la,this._frameExtents=new ut(1,1),this._viewportCount=1,this._viewports=[new ue(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera,n=this.matrix;Jr.setFromMatrixPosition(t.matrixWorld),e.position.copy(Jr),Qr.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Qr),e.updateMatrixWorld(),Go.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Go),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Go)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}class zm extends ya{constructor(){super(new Be(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(t){const e=this.camera,n=Gs*2*t.angle*this.focus,i=this.mapSize.width/this.mapSize.height,s=t.distance||e.far;(n!==e.fov||i!==e.aspect||s!==e.far)&&(e.fov=n,e.aspect=i,e.far=s,e.updateProjectionMatrix()),super.updateMatrices(t)}copy(t){return super.copy(t),this.focus=t.focus,this}}class km extends Js{constructor(t,e,n=0,i=Math.PI/3,s=0,a=2){super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(ye.DEFAULT_UP),this.updateMatrix(),this.target=new ye,this.distance=n,this.angle=i,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new zm}get power(){return this.intensity*Math.PI}set power(t){this.intensity=t/Math.PI}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}const tc=new fe,Fi=new P,Ho=new P;class Gm extends ya{constructor(){super(new Be(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new ut(4,2),this._viewportCount=6,this._viewports=[new ue(2,1,1,1),new ue(0,1,1,1),new ue(3,1,1,1),new ue(1,1,1,1),new ue(3,0,1,1),new ue(1,0,1,1)],this._cubeDirections=[new P(1,0,0),new P(-1,0,0),new P(0,0,1),new P(0,0,-1),new P(0,1,0),new P(0,-1,0)],this._cubeUps=[new P(0,1,0),new P(0,1,0),new P(0,1,0),new P(0,1,0),new P(0,0,1),new P(0,0,-1)]}updateMatrices(t,e=0){const n=this.camera,i=this.matrix,s=t.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),Fi.setFromMatrixPosition(t.matrixWorld),n.position.copy(Fi),Ho.copy(n.position),Ho.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(Ho),n.updateMatrixWorld(),i.makeTranslation(-Fi.x,-Fi.y,-Fi.z),tc.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(tc)}}class Ne extends Js{constructor(t,e,n=0,i=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new Gm}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}}class Hm extends ya{constructor(){super(new Ac(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Vm extends Js{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ye.DEFAULT_UP),this.updateMatrix(),this.target=new ye,this.shadow=new Hm}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class Wm{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=ec(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const e=ec();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}}function ec(){return(typeof performance>"u"?Date:performance).now()}class Xm{constructor(t,e,n=0,i=1/0){this.ray=new $s(t,e),this.near=n,this.far=i,this.camera=null,this.layers=new ca,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}intersectObject(t,e=!0,n=[]){return na(t,this,n,e),n.sort(nc),n}intersectObjects(t,e=!0,n=[]){for(let i=0,s=t.length;i<s;i++)na(t[i],this,n,e);return n.sort(nc),n}}function nc(o,t){return o.distance-t.distance}function na(o,t,e,n){if(o.layers.test(t.layers)&&o.raycast(t,e),n===!0){const i=o.children;for(let s=0,a=i.length;s<a;s++)na(i[s],t,e,!0)}}class qm extends am{constructor(t=10,e=10,n=4473924,i=8947848){n=new Xt(n),i=new Xt(i);const s=e/2,a=t/e,r=t/2,c=[],l=[];for(let u=0,f=0,g=-r;u<=e;u++,g+=a){c.push(-r,0,g,r,0,g),c.push(g,0,-r,g,0,r);const y=u===s?n:i;y.toArray(l,f),f+=3,y.toArray(l,f),f+=3,y.toArray(l,f),f+=3,y.toArray(l,f),f+=3}const h=new _e;h.setAttribute("position",new Jt(c,3)),h.setAttribute("color",new Jt(l,3));const d=new Fc({vertexColors:!0,toneMapped:!1});super(h,d),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:ia}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=ia);class Ym{constructor(){this.modals={about:document.getElementById("modal-about"),skills:document.getElementById("modal-skills"),projects:document.getElementById("modal-projects"),arcade:document.getElementById("modal-arcade"),easel:document.getElementById("modal-easel"),wardrobe:document.getElementById("modal-wardrobe"),leaderboard:document.getElementById("modal-leaderboard"),tasks:document.getElementById("modal-tasks"),farm:document.getElementById("modal-farm"),pk:document.getElementById("modal-pk"),bag:document.getElementById("modal-bag"),home:document.getElementById("modal-home"),exit:document.getElementById("modal-exit"),map:document.getElementById("modal-map"),shop:document.getElementById("modal-shop"),piano:document.getElementById("modal-piano")},this.iframe=document.getElementById("arcade-iframe"),this.arcadeLobby=document.getElementById("arcade-lobby"),this.arcadeTitle=document.getElementById("arcade-title"),this.arcadeBackBtn=document.getElementById("btn-arcade-back"),this.closeButtons=document.querySelectorAll(".modal-close"),this.overlayList=document.querySelectorAll(".modal-overlay"),this.isAnyModalOpen=!1,this.init(),this.hydrateFromConfig()}init(){this.closeButtons.forEach(t=>{t.addEventListener("click",e=>{let n=t.getAttribute("data-close");n&&n.startsWith("modal-")&&(n=n.replace("modal-","")),this.closeModal(n)})}),this.overlayList.forEach(t=>{t.addEventListener("click",e=>{if(e.target===t){const n=t.id.replace("modal-","");this.closeModal(n)}})}),window.addEventListener("keydown",t=>{t.key==="Escape"&&this.isAnyModalOpen&&this.closeAllModals()})}async hydrateFromConfig(){try{const e=(await Zc(()=>import("./site-config-CqbHk6xq.js"),[],import.meta.url)).siteConfig;if(e.developer){const s=e.developer,a=document.querySelector("#modal-about .avatar-placeholder");a&&(a.textContent=s.avatar||"🌻");const r=document.querySelector("#modal-about .profile-info");r&&(r.innerHTML=`
            <h3>${s.name}</h3>
            <p class="tagline">${s.tagline}</p>
          `);const c=document.querySelector("#modal-about .bio-text");c&&(c.innerHTML=`
            <p>${s.bio}</p>
            <p><strong>联系邮箱:</strong> ${s.email}</p>
            <div style="margin-top: 20px; display: flex; gap: 12px; pointer-events: auto;">
              <a href="../../class.html" class="hud-btn" style="padding: 8px 16px; font-size: 0.8rem; text-decoration: none;">我的课表</a>
              <a href="../../album.html" class="hud-btn" style="padding: 8px 16px; font-size: 0.8rem; text-decoration: none;">我的相册</a>
            </div>
          `)}const n=document.querySelector("#modal-projects .projects-grid");n&&e.games&&(n.innerHTML="",e.games.forEach(s=>{const a=document.createElement("div");a.className="project-item",a.innerHTML=`
            <div class="project-img">${s.emoji||"🎮"}</div>
            <div class="project-detail">
              <h3>${s.name}</h3>
              <p>运行于网页主页“韭菜盒子”工具箱板块下的经典互动小游戏，适配桌面端与移动端。</p>
              <button class="tag play-btn" style="margin-top: 6px; display: inline-block; text-decoration: none; cursor: pointer; border: none; background: none; color: inherit; padding: 0; font-family: inherit; text-align: left;">直接游玩</button>
            </div>
          `;const r=a.querySelector(".play-btn");r&&r.addEventListener("click",c=>{c.preventDefault(),this.launchGame(s)}),n.appendChild(a)}));const i=document.querySelector(".arcade-games-grid");i&&e.games&&(i.innerHTML="",e.games.forEach(s=>{const a=document.createElement("div");a.className="arcade-game-card",a.innerHTML=`
            <div class="arcade-game-icon">${s.emoji||"🕹️"}</div>
            <div class="arcade-game-title">${s.name}</div>
          `,a.addEventListener("click",()=>{this.launchGame(s)}),i.appendChild(a)})),this.arcadeBackBtn&&this.arcadeBackBtn.addEventListener("click",()=>{this.showLobby()})}catch(t){console.error("Failed to dynamically import site config:",t)}}launchGame(t){let e=t.path;const n=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1";t.id==="21dian"&&(e=n?`http://${window.location.hostname}:8080/games/21dian/index.html`:t.path);let i;e.startsWith("http://")||e.startsWith("https://")?i=e:i="../../"+e.replace(/^\.\//,"");const s=localStorage.getItem("sso_access_token"),a=localStorage.getItem("sso_user");if(s&&a)try{const r=new URL(i,window.location.href);r.searchParams.set("sso_access_token",s),r.searchParams.set("sso_user",a),i=r.toString()}catch{i.includes("?")?i+=`&sso_access_token=${s}&sso_user=${encodeURIComponent(a)}`:i+=`?sso_access_token=${s}&sso_user=${encodeURIComponent(a)}`}window.open(i,"_blank")}showLobby(){this.iframe&&(this.iframe.src="",this.iframe.style.display="none"),this.arcadeLobby&&(this.arcadeLobby.style.display="block"),this.arcadeTitle&&(this.arcadeTitle.textContent="复古街机 · 游戏大厅"),this.arcadeBackBtn&&(this.arcadeBackBtn.style.display="none")}openModal(t){const e=this.modals[t];if(e){if(t==="arcade"&&this.showLobby(),t==="easel"){const n=document.getElementById("easel-iframe");n&&(n.src="./paint.html")}e.classList.add("open"),this.isAnyModalOpen=!0,window.dispatchEvent(new CustomEvent("modal-opened",{detail:{modalId:t}})),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalOpened=="function"&&window.parent.appShell.onModalOpened(t)}}closeModal(t){const e=this.modals[t];if(e){if(e.classList.remove("open"),t==="arcade"&&this.iframe&&(this.iframe.src=""),t==="easel"){const n=document.getElementById("easel-iframe");n&&(n.src="")}this.isAnyModalOpen=Array.from(this.overlayList).some(n=>n.classList.contains("open")),this.isAnyModalOpen||(window.dispatchEvent(new CustomEvent("modal-closed",{detail:{modalId:t}})),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed(t))}}closeAllModals(){Object.keys(this.modals).forEach(t=>this.closeModal(t))}}class $m{constructor(t,e){this.scene=t,this.themeConfig=e,this.particles=null,this.particleCount=150,this.particleGeometry=null,this.particleMaterial=null,this.isNight=!1,this.isIndoor=!1,this.initLights(),this.initFog(),this.initParticles()}setIndoorMode(t){this.isIndoor=t,this.particles&&(this.particles.visible=!t)}initLights(){const t=this.themeConfig.colors.sky===330776,e=t?14544639:16777215,n=t?4128:58879,i=t?.75:1.1,s=new Om(e,n,i);s.position.set(0,50,0),this.scene.add(s),this.hemiLight=s;const a=t?14280949:16776679,r=t?.95:1.75,c=new Vm(a,r);c.position.set(20,40,20),c.castShadow=!0;const l="ontouchstart"in window||navigator.maxTouchPoints>0;c.shadow.mapSize.width=l?1024:2048,c.shadow.mapSize.height=l?1024:2048,c.shadow.camera.near=.5,c.shadow.camera.far=100;const h=30;c.shadow.camera.left=-h,c.shadow.camera.right=h,c.shadow.camera.top=h,c.shadow.camera.bottom=-h,c.shadow.bias=-5e-4,this.scene.add(c),this.sun=c}initFog(){const t=this.themeConfig.colors.fog||14743546,n=this.themeConfig.colors.sky===330776?.012:.009;this.scene.fog=new da(t,n)}initParticles(){const t=this.themeConfig.colors.sky===330776;this.particleGeometry=new _e;const e=new Float32Array(this.particleCount*3),n=[];for(let c=0;c<this.particleCount;c++)e[c*3]=(Math.random()-.5)*60,e[c*3+1]=Math.random()*(t?30:22),e[c*3+2]=(Math.random()-.5)*60,n.push({y:t?.08+Math.random()*.08:.05+Math.random()*.05,x:(Math.random()-.5)*.04,z:(Math.random()-.5)*.04});this.particleGeometry.setAttribute("position",new $e(e,3)),this.particleSpeeds=n;const i=document.createElement("canvas");i.width=16,i.height=16;const s=i.getContext("2d"),a=s.createRadialGradient(8,8,0,8,8,8);t?(a.addColorStop(0,"rgba(255, 255, 255, 0.95)"),a.addColorStop(.4,"rgba(255, 255, 255, 0.7)"),a.addColorStop(1,"rgba(255, 255, 255, 0)")):(a.addColorStop(0,"rgba(128, 222, 234, 0.85)"),a.addColorStop(1,"rgba(128, 222, 234, 0)")),s.fillStyle=a,s.fillRect(0,0,16,16);const r=new zc(i);this.particleMaterial=new Oc({size:t?.45:.6,map:r,transparent:!0,blending:Ns,depthWrite:!1}),this.particles=new rm(this.particleGeometry,this.particleMaterial),this.scene.add(this.particles)}update(t){if(!this.particles)return;const e=this.particleGeometry.attributes.position.array,n=this.themeConfig.colors.sky===330776;for(let l=0;l<this.particleCount;l++){const h=l*3,d=this.particleSpeeds[l];n?(e[h]+=d.x+Math.sin(t*5e-4+l)*.01,e[h+1]-=d.y*.5,e[h+2]+=d.z+Math.cos(t*5e-4+l)*.01,e[h+1]<.5&&(e[h]=(Math.random()-.5)*60,e[h+1]=25,e[h+2]=(Math.random()-.5)*60)):(e[h]+=d.x+Math.sin(t*.001+l)*.015,e[h+1]+=d.y*.4,e[h+2]+=d.z,e[h+1]>22&&(e[h]=(Math.random()-.5)*60,e[h+1]=-1,e[h+2]=(Math.random()-.5)*60))}this.particleGeometry.attributes.position.needsUpdate=!0;let i,s,a,r,c;this.isIndoor?(i=.75,s=.05,a=new Xt(16765312),r=new Xt(790036),c=new Xt(790036)):(i=this.isNight?.18:n?.75:1.1,s=this.isNight?.22:n?.95:1.75,a=new Xt(this.isNight?9479342:n?14280949:16776679),r=new Xt(this.isNight?461586:this.themeConfig.colors.sky),c=new Xt(this.isNight?461586:this.themeConfig.colors.fog)),this.hemiLight&&(this.hemiLight.intensity+=(i-this.hemiLight.intensity)*.04),this.sun&&(this.sun.intensity+=(s-this.sun.intensity)*.04,this.sun.color.lerp(a,.04)),this.scene.background.lerp(r,.04),this.scene.fog&&this.scene.fog.color.lerp(c,.04)}}class jm{constructor(t,e){this.scene=t,this.themeConfig=e,this.colliders=[],this.interactables=[],this.streetlights=[],this.group=new lt;const n=this.themeConfig.colors,i=n.sky===330776;this.materials={sand:new H({color:n.sand,flatShading:!0}),dirt:new H({color:n.dirt,flatShading:!0}),stone:new H({color:i?9479342:13619151,flatShading:!0}),wood:new H({color:i?5125166:10586239,flatShading:!0}),leaves:new H({color:i?1793568:5025616,flatShading:!0}),coconut:new H({color:6111287,flatShading:!0}),umbrellaRed:new H({color:i?13959168:16732754,flatShading:!0}),umbrellaWhite:new H({color:16777215,flatShading:!0}),seaWater:new Mt({color:n.seaWater,transparent:!0,opacity:i?.72:.58,side:he}),arcadeBody:new H({color:i?4073251:2503224,flatShading:!0}),arcadeScreen:new Mt({color:i?2733814:58998}),neonRed:new Mt({color:16732754}),neonBlue:new Mt({color:4244735})};const s=this.scene.add;this.scene.add=a=>{a.isLight?s.call(this.scene,a):this.group.add(a)},this.buildWorld(),this.scene.add=s,s.call(this.scene,this.group)}buildWorld(){this.themeConfig.colors.sky,this.createMainGround(0,0,0,22),this.createVastOcean(),this.createOuterBoundaries(),this.decorateAboutZone(),this.decorateSkillsZone(),this.decorateProjectsZone(),this.decorateArcadeZone(),this.createBeachDecorations(),this.createSwing(4.5,.6,6),this.createBallVendor(-5,.6,6),this.createSummerDecorations(),this.createCozyHouse(-10,.6,-9),this.createStreetlamps(),this.createPaimon(2.5,2.5),this.createLakePortal(-6.5,.6,-1.5),this.createCastlePortal(-7.5,.6,7.5)}createFarmField(t,e,n){this.farmGroup=new lt,this.farmGroup.position.set(t,e,n);const i=1.8,s=1.8;this.farmPlots3D=[];for(let a=0;a<2;a++)for(let r=0;r<3;r++){const c=(r-1)*i,l=(a-.5)*s,h=new O(1.4,.12,1.4),d=new x(h,this.materials.dirt);d.position.set(c,.06,l),d.receiveShadow=!0,d.castShadow=!0,this.farmGroup.add(d);const u=new O(1.5,.08,.08),f=this.materials.stone,g=new x(u,f);g.position.set(c,.12,l-.7),this.farmGroup.add(g);const y=new x(u,f);y.position.set(c,.12,l+.7),this.farmGroup.add(y);const m=new x(new O(.08,.08,1.4),f);m.position.set(c-.7,.12,l),this.farmGroup.add(m);const p=new x(new O(.08,.08,1.4),f);p.position.set(c+.7,.12,l),this.farmGroup.add(p);const _=new lt;_.position.set(c,.12,l),this.farmGroup.add(_),this.farmPlots3D.push({row:a,col:r,index:a*3+r,mesh:d,plantGroup:_,x:t+c,z:n+l}),this.interactables.push({id:`farm_plot_${a*3+r}`,name:"农田格子",x:t+c,y:e,z:n+l,triggerRadius:1.2})}this.scene.add(this.farmGroup)}createMainGround(t,e,n,i){const s=new lt;s.position.set(t,e,n);const a=new J(i,i-.2,.6,12),r=new x(a,this.materials.sand);r.position.y=.3,r.receiveShadow=!0,r.castShadow=!0,s.add(r);const c=new J(i-.2,i-1.5,1.8,12),l=new x(c,this.materials.dirt);l.position.y=-.9,l.castShadow=!0,s.add(l),this.scene.add(s),this.colliders.push({mesh:r,radius:i,worldX:t,worldZ:n,worldY:.6,type:"floor"})}createVastOcean(){const t=new nn(160,160),e=new x(t,this.materials.seaWater);e.rotation.x=-Math.PI/2,e.position.y=.18,e.receiveShadow=!0,this.scene.add(e)}createOuterBoundaries(){const n=this.themeConfig.colors.sky===330776;for(let i=0;i<20;i++){const s=i/20*Math.PI*2;if(Math.abs(s)<.2||Math.abs(s-Math.PI)<.2||Math.abs(s-Math.PI/2)<.2)continue;const a=Math.sin(s)*21.2,r=Math.cos(s)*21.2;n?this.createPineTree(a,.6,r,1.1+Math.random()*.3):this.createPalmTree(a,.6,r,1.2+Math.random()*.4)}}createPalmTree(t,e,n,i){const s=new lt;s.position.set(t,e,n),s.scale.set(i,i,i);const a=new lt,r=5;let c=0,l=0;const h=new J(.08,.12,.4,5);for(let g=0;g<r;g++){const y=new x(h,this.materials.wood);y.position.set(l,c+.2,0);const m=.08*g;y.rotation.z=m,y.castShadow=!0,a.add(y),c+=.36*Math.cos(m),l-=.36*Math.sin(m)}s.add(a);const d=new lt;d.position.set(l,c,0);const u=new O(.8,.02,.25);u.translate(.4,0,0);const f=6;for(let g=0;g<f;g++){const y=new x(u,this.materials.leaves);y.rotation.y=g/f*Math.PI*2,y.rotation.z=-.22,y.castShadow=!0,d.add(y)}s.add(d),this.scene.add(s)}createPineTree(t,e,n,i){const s=new lt;s.position.set(t,e,n),s.scale.set(i,i,i);const a=new J(.12,.18,.6,5),r=new x(a,this.materials.wood);r.position.y=.3,r.castShadow=!0,s.add(r);for(let d=0;d<3;d++){const u=new re(.55-d*.12,.6,6),f=new x(u,this.materials.leaves);f.position.y=.7+d*.4,f.castShadow=!0,s.add(f)}const c=new Lt(.06,5,5),l=new Mt({color:16776679}),h=new x(c,l);h.position.y=1.7,s.add(h),this.scene.add(s)}decorateAboutZone(){const t=this.themeConfig.colors.sky===330776,e=new lt;e.position.set(0,.6,0);const n=new J(.07,.07,.6,5);n.translate(0,-.3,0),n.rotateZ(.95);for(let d=0;d<3;d++){const u=new x(n,this.materials.wood);u.position.set(-1.8,.35,1.8),u.rotation.y=d*Math.PI*2/3,u.castShadow=!0,e.add(u)}const i=new lt;i.position.set(-1.8,.15,1.8);const s=new Mt({color:16733986}),a=new re(.18,.45,5),r=new x(a,s);r.position.set(0,.2,0),i.add(r);const c=new x(a,new Mt({color:16748800}));c.position.set(.08,.15,-.05),c.rotation.z=.2,c.scale.set(.8,.8,.8),i.add(c);const l=new x(a,new Mt({color:16766464}));l.position.set(-.08,.12,.06),l.rotation.z=-.2,l.scale.set(.7,.7,.7),i.add(l),e.add(i);const h=new Ne(16733986,0,10,1.2);if(h.position.set(-1.8,.8,1.8),this.scene.add(h),this.streetlights.push(h),t){this.createSnowman(1.8,.6,-1.3);const d=new lt;d.position.set(1.5,.04,-2.2),d.rotation.y=-.45;const u=new x(new O(1.2,.08,.4),this.materials.wood);u.position.y=.25,u.castShadow=!0,d.add(u);const f=new x(new O(.08,.25,.35),this.materials.wood);f.position.set(-.5,.125,0),f.castShadow=!0,d.add(f);const g=new x(new O(.08,.25,.35),this.materials.wood);g.position.set(.5,.125,0),g.castShadow=!0,d.add(g),e.add(d)}else{const d=new x(new O(.5,.08,1.1),this.materials.umbrellaWhite);d.position.set(1.5,.04,-1.2),d.rotation.y=-.4,d.castShadow=!0,e.add(d);const u=new x(new O(.48,.1,.25),this.materials.umbrellaRed);u.position.set(1.5,.12,-1.6),u.rotation.y=-.4,e.add(u);const f=new lt;f.position.set(2.4,0,-2.4);const g=new x(new J(.04,.04,2.2,5),this.materials.wood);g.position.y=1.1,g.castShadow=!0,f.add(g);const y=new re(1.2,.5,8),m=new x(y,this.materials.umbrellaRed);m.position.y=2.1,m.castShadow=!0,f.add(m);const p=new x(new re(1.22,.48,8),this.materials.umbrellaWhite);p.position.y=2.1,p.rotation.y=Math.PI/8,f.add(p),e.add(f)}this.scene.add(e),this.interactables.push({id:"about",name:"关于我",x:0,y:.6,z:0,triggerRadius:3.5})}createSnowman(t,e,n){const i=new lt;i.position.set(t,e,n);const s=new x(new Lt(.4,8,8),this.materials.umbrellaWhite);s.position.y=.4,s.castShadow=!0,i.add(s);const a=new x(new Lt(.26,8,8),this.materials.umbrellaWhite);a.position.y=.9,a.castShadow=!0,i.add(a);const r=new re(.04,.12,4);r.rotateX(Math.PI/2);const c=new x(r,new H({color:16754470}));c.position.set(0,.9,.26),i.add(c);const l=new Lt(.03,4,4),h=new Mt({color:1118481}),d=new x(l,h);d.position.set(-.08,.96,.23);const u=new x(l,h);u.position.set(.08,.96,.23),i.add(d),i.add(u);const f=new x(new J(.24,.24,.08,8),this.materials.umbrellaRed);f.position.y=.7,i.add(f);const g=new x(new J(.15,.18,.2,8),this.materials.arcadeBody);g.position.y=1.18,g.castShadow=!0,i.add(g),this.scene.add(i)}decorateSkillsZone(){const t=this.themeConfig.colors.sky===330776,e=-12,n=-3,i=.6;if(t){const s=new lt;s.position.set(e,i,n);const a=new x(new J(.3,.4,1.8,8),this.materials.wood);a.position.y=.9,a.castShadow=!0,s.add(a);for(let h=0;h<4;h++){const d=new x(new re(1.6-h*.35,1.6,8),this.materials.leaves);d.position.y=1.8+h*.9,d.castShadow=!0,s.add(d)}const r=new x(new Lt(.18,6,6),new Mt({color:16771899}));r.position.y=5.2,s.add(r);const c=[16732754,4244735,16771899,14696699];for(let h=0;h<12;h++){const d=new x(new Lt(.12,5,5),new Mt({color:c[h%c.length]})),u=1.8+Math.floor(h/3)*.9,f=1.3-Math.floor(h/3)*.3,g=h%3*(Math.PI*2/3)+u*.5;d.position.set(Math.cos(g)*f,u+.2,Math.sin(g)*f),s.add(d)}const l=[16732754,4244735,14696699];for(let h=0;h<3;h++){const d=new x(new O(.4,.4,.4),new H({color:l[h],flatShading:!0}));d.position.set(.6-h*.5,.2,.5+h*.2),d.rotation.y=h*.4,d.castShadow=!0,s.add(d)}this.scene.add(s)}else{const s=new lt;s.position.set(e,i,n);const a=new J(.24,.4,4.2,7),r=new x(a,this.materials.wood);r.position.y=2.1,r.rotation.z=-.1,r.castShadow=!0,s.add(r);const c=new lt;c.position.set(-.2,4.1,0);const l=new O(2,.02,.45);l.translate(1,0,0);const h=8;for(let u=0;u<h;u++){const f=new x(l,this.materials.leaves);f.rotation.y=u/h*Math.PI*2,f.rotation.z=-.25,f.castShadow=!0,c.add(f)}s.add(c);const d=new Lt(.24,5,5);for(let u=0;u<3;u++){const f=new x(d,this.materials.coconut),g=u/3*Math.PI*2;f.position.set(-.2+Math.cos(g)*.3,3.8,Math.sin(g)*.3),f.castShadow=!0,s.add(f)}this.scene.add(s)}this.interactables.push({id:"skills",name:"技术栈",x:-12,y:.6,z:-1,triggerRadius:3})}decorateProjectsZone(){const t=this.themeConfig.colors.sky===330776,e=12,n=-3,i=.6,s=new lt;s.position.set(e,i,n);const a=new J(.08,.08,2.5,5),r=new x(a,this.materials.wood);r.position.set(-1.8,1.25,0),r.castShadow=!0,s.add(r);const c=new x(a,this.materials.wood);c.position.set(1.8,1.25,0),c.castShadow=!0,s.add(c);const l=new x(new O(3.6,2,.15),this.materials.wood);l.position.y=2.25,l.castShadow=!0,s.add(l);const h=new x(new O(3.2,1.7,.08),this.materials.stone);h.position.set(0,2.25,.06),s.add(h);const d=new H({color:t?13959168:4244735,flatShading:!0}),u=new H({color:t?3046706:16754470,flatShading:!0}),f=new Lt(.32,8,8);f.scale(1,2.4,.12);const g=new x(f,d);g.position.set(-1.2,.6,.2),g.rotation.set(.1,.2,-.15),g.castShadow=!0,s.add(g);const y=new x(f,u);y.position.set(1.2,.6,.2),y.rotation.set(.1,-.2,.15),y.castShadow=!0,s.add(y);const m=new Lt(.08,5,5),p=new Mt({color:16774557}),_=new x(m,p);_.position.set(-1.8,3.3,.1),s.add(_);const w=new x(m,p);w.position.set(1.8,3.3,.1),s.add(w);const v=new Ne(16774557,0,6,1.2);v.position.set(e-1.8,i+3.3,n+.1),this.scene.add(v),this.streetlights.push(v);const R=new Ne(16774557,0,6,1.2);R.position.set(e+1.8,i+3.3,n+.1),this.scene.add(R),this.streetlights.push(R),this.scene.add(s),this.interactables.push({id:"projects",name:"项目展示",x:12,y:.6,z:-1,triggerRadius:3})}decorateArcadeZone(){const t=this.themeConfig.colors.sky===330776,e=0,n=-12,i=.6,s=new lt;s.position.set(e,i,n);const a=new x(new O(1.2,1,1),this.materials.arcadeBody);a.position.y=.5,a.castShadow=!0,s.add(a);const r=new x(new O(1.2,1.2,.8),this.materials.arcadeBody);r.position.set(0,1.4,-.1),r.castShadow=!0,s.add(r);const c=new nn(.95,.72);c.rotateX(-.1);const l=new x(c,this.materials.arcadeScreen);l.position.set(0,1.4,.31),s.add(l);const h=new x(new O(1.3,.2,.5),this.materials.arcadeBody);h.position.set(0,.95,.3),h.rotation.x=.15,h.castShadow=!0,s.add(h);const d=new x(new J(.015,.015,.18,4),this.materials.stone);d.position.set(-.3,1.05,.4),d.rotation.x=.15,s.add(d);const u=new x(new Lt(.05,5,5),this.materials.neonRed);u.position.set(-.3,1.14,.42),s.add(u);const f=new J(.035,.035,.03,5);f.rotateX(.15);for(let L=0;L<3;L++){const F=new x(f,L%2===0?this.materials.neonRed:this.materials.neonBlue);F.position.set(.15+L*.12,1,.4),s.add(F)}const g=new x(new O(1.2,.25,.85),this.materials.arcadeBody);g.position.set(0,2.05,-.05),s.add(g);const y=new x(new nn(1,.18),new Mt({color:t?2733814:16754470}));y.position.set(0,2.05,.38),s.add(y);const m=new J(.04,.04,1.5,5),p=new x(m,this.materials.wood);p.position.set(-.9,.75,.2),p.castShadow=!0,s.add(p);const _=new x(m,this.materials.wood);_.position.set(.9,.75,.2),_.castShadow=!0,s.add(_);const w=new re(.08,.22,5),v=new Mt({color:16740419}),R=new x(w,v);R.position.set(-.9,1.62,.2),s.add(R);const T=new x(w,v);T.position.set(.9,1.62,.2),s.add(T);const E=new Ne(16733986,0,5,1.2);E.position.set(e-.9,i+1.62,n+.2),this.scene.add(E),this.streetlights.push(E);const U=new Ne(16733986,0,5,1.2);U.position.set(e+.9,i+1.62,n+.2),this.scene.add(U),this.streetlights.push(U),this.scene.add(s);const M=t?2733814:65280,S=new km(M,2,6,Math.PI/6,.5,1);S.position.set(0,4,-12),S.target=a,this.scene.add(S),this.interactables.push({id:"arcade",name:"复古街机",x:0,y:.6,z:-10.4,triggerRadius:2.2})}createBeachDecorations(){const t=this.themeConfig.colors.sky===330776,e=new ji(21.8,22.2,32);e.rotateX(-Math.PI/2);const n=new Mt({color:16777215,transparent:!0,opacity:t?.95:.8,side:he}),i=new x(e,n);i.position.y=.22,this.scene.add(i),this.createBeachBall(.6,.6,-1.8,.24,t?16777215:16732754),this.createBeachBall(10,.6,-1.5,.26,t?16777215:4244735),t?(this.createSnowHeap(3.5,.61,2.5,.2),this.createSnowHeap(-10.5,.61,1.5,.28),this.createSnowHeap(-3.5,.61,-1.5,.18),this.createSnowHeap(8.5,.61,3.5,.24)):(this.createStarfish(3.5,.61,2.5,16740419),this.createStarfish(-10.5,.61,1.5,16740419),this.createShell(-3.5,.61,-1.5,16775620),this.createShell(8.5,.61,3.5,16775620),this.createExtraUmbrella(-5.8,.6,-5,4244735),this.createExtraUmbrella(8,.6,-7,16771899))}createBeachBall(t,e,n,i,s){const a=new lt;a.position.set(t,e+i,n);const r=new Lt(i,8,8),c=new H({color:s,flatShading:!0}),l=new x(r,c);l.castShadow=!0,a.add(l);const h=new J(i+.005,i+.005,i*.4,8,1,!0),d=s===16777215?13959168:16777215,u=new H({color:d,flatShading:!0}),f=new x(h,u);f.rotation.z=Math.PI/4,a.add(f),this.scene.add(a)}createStarfish(t,e,n,i){const s=new re(.18,.05,5),a=new H({color:i,flatShading:!0}),r=new x(s,a);r.position.set(t,e,n),r.rotation.x=Math.PI/2,r.rotation.z=Math.random()*Math.PI,r.castShadow=!0,this.scene.add(r)}createShell(t,e,n,i){const s=new ma(.12,1);s.scale(1.2,.8,.8);const a=new H({color:i,flatShading:!0}),r=new x(s,a);r.position.set(t,e,n),r.rotation.set(Math.random()*.4,Math.random()*Math.PI,Math.random()*.4),r.castShadow=!0,this.scene.add(r)}createSnowHeap(t,e,n,i){const s=new Lt(i,5,4);s.scale(1.2,.5,1.2);const a=new x(s,this.materials.umbrellaWhite);a.position.set(t,e+i*.25,n),a.castShadow=!0,this.scene.add(a)}createExtraUmbrella(t,e,n,i){const s=new lt;s.position.set(t,e,n);const a=new x(new J(.03,.03,1.8,5),this.materials.wood);a.position.y=.9,a.castShadow=!0,s.add(a);const r=new H({color:i,flatShading:!0}),c=new H({color:16777215,flatShading:!0}),l=new x(new re(.9,.4,8),r);l.position.y=1.7,l.castShadow=!0,s.add(l);const h=new x(new re(.92,.38,8),c);h.position.y=1.7,h.rotation.y=Math.PI/8,s.add(h),this.scene.add(s)}createSwing(t,e,n){const i=new lt;i.position.set(t,e,n);const s=new J(.05,.05,2.1,6);s.translate(0,-1.05,0);const a=new x(s,this.materials.wood);a.position.set(-1,2.05,0),a.rotation.set(-.19,0,-.15),a.castShadow=!0,i.add(a);const r=new x(s,this.materials.wood);r.position.set(-1,2.05,0),r.rotation.set(.19,0,-.15),r.castShadow=!0,i.add(r);const c=new x(s,this.materials.wood);c.position.set(1,2.05,0),c.rotation.set(-.19,0,.15),c.castShadow=!0,i.add(c);const l=new x(s,this.materials.wood);l.position.set(1,2.05,0),l.rotation.set(.19,0,.15),l.castShadow=!0,i.add(l);const h=new x(new J(.05,.05,2.25,6),this.materials.wood);h.rotation.z=Math.PI/2,h.position.set(0,2.05,0),h.castShadow=!0,i.add(h),this.swingSeat=new lt,this.swingSeat.position.set(0,2.05,0);const d=new x(new O(.6,.03,.22),this.materials.wood);d.position.set(0,-1.1,0),d.castShadow=!0,this.swingSeat.add(d);const u=new x(new J(.01,.01,1.1),this.materials.stone);u.position.set(-.24,-.55,0),this.swingSeat.add(u);const f=new x(new J(.01,.01,1.1),this.materials.stone);f.position.set(.24,-.55,0),this.swingSeat.add(f),i.add(this.swingSeat),this.scene.add(i),this.interactables.push({id:"swing",name:"秋千",x:t,y:e,z:n+.6,triggerRadius:1.8})}createBallVendor(t,e,n){const i=this.themeConfig.colors.sky===330776,s=new lt;s.position.set(t,e,n);const a=new x(new O(1.6,.8,.8),this.materials.wood);a.position.y=.4,a.castShadow=!0,a.receiveShadow=!0,s.add(a);const r=new x(new O(1.7,.08,.9),this.materials.sand);r.position.y=.84,r.castShadow=!0,s.add(r);const c=new J(.03,.03,1.4,5),l=new x(c,this.materials.wood);l.position.set(-.7,1.4,-.3),l.castShadow=!0,s.add(l);const h=new x(c,this.materials.wood);h.position.set(.7,1.4,-.3),h.castShadow=!0,s.add(h);const d=new x(new O(1.8,.06,1.1),this.materials.umbrellaRed);d.position.set(0,2.15,.1),d.rotation.x=.28,d.castShadow=!0,s.add(d);const u=new x(new O(1.82,.05,.3),this.materials.umbrellaWhite);u.position.set(0,2.15,.1),u.rotation.x=.28,s.add(u);const f=new x(new O(.6,.25,.5),this.materials.coconut);f.position.set(-.35,.98,.05),f.castShadow=!0,s.add(f);const g=new Lt(.12,6,6),y=i?[16777215,16777215,16777215]:[16732754,4244735,16771899];for(let _=0;_<3;_++){const w=new x(g,new H({color:y[_],flatShading:!0}));w.position.set(-.42+_*.12,1.08,.05+_%2*.05),s.add(w)}const m=new x(new O(.6,.25,.05),this.materials.umbrellaWhite);m.position.set(.35,1.2,.15),m.rotation.y=-.15,m.castShadow=!0,s.add(m);const p=new x(new O(.4,.08,.06),new H({color:i?13959168:5025616}));p.position.set(.35,1.2,.16),p.rotation.y=-.15,s.add(p),this.scene.add(s),this.interactables.push({id:"ball_vendor",name:i?"领雪球":"领沙滩球",x:t,y:e,z:n+.8,triggerRadius:1.8})}createCozyHouse(t,e,n){const i=this.themeConfig.colors.sky===330776,s=new lt;s.position.set(t,e,n);const a=new O(4,.12,4),r=new x(a,this.materials.wood);r.position.y=.06,r.receiveShadow=!0,r.castShadow=!0,s.add(r),this.colliders.push({mesh:r,radius:2.2,worldX:t,worldZ:n,worldY:e+.12,type:"floor"});const c=new O(.2,3.2,.2);[{x:-1.9,z:-1.9},{x:1.9,z:-1.9},{x:-1.9,z:1.9},{x:1.9,z:1.9}].forEach(L=>{const F=new x(c,this.materials.wood);F.position.set(L.x,1.6,L.z),F.castShadow=!0,s.add(F)});const h=new H({color:i?6323595:14742257,flatShading:!0}),d=new x(new O(3.8,3.2,.08),h);d.position.set(0,1.6,-1.9),d.castShadow=!0,s.add(d);const u=new x(new O(.08,3.2,3.8),h);u.position.set(-1.9,1.6,0),u.castShadow=!0,s.add(u);const f=new x(new O(.08,3.2,3.8),h);f.position.set(1.9,1.6,0),f.castShadow=!0,s.add(f);const g=new x(new O(1.3,3.2,.08),h);g.position.set(-1.25,1.6,1.9),g.castShadow=!0,s.add(g);const y=new x(new O(1.3,3.2,.08),h);y.position.set(1.25,1.6,1.9),y.castShadow=!0,s.add(y);const m=new x(new O(1.2,1,.08),h);m.position.set(0,2.7,1.9),m.castShadow=!0,s.add(m);const p=new pa;p.moveTo(-1.9,3.2),p.lineTo(1.9,3.2),p.lineTo(0,4.15),p.closePath();const _=new $i(p,{depth:.08,bevelEnabled:!1}),w=new x(_,h);w.position.set(0,0,1.9-.08),w.castShadow=!0,s.add(w);const v=new x(_,h);v.position.set(0,0,-1.9),v.castShadow=!0,s.add(v);const R=i?13959168:16740419,T=new H({color:R,flatShading:!0}),E=new x(new O(2.5,.08,4),T);E.position.set(-1.05,3.68,0),E.rotation.z=.48,E.castShadow=!0,s.add(E);const U=new x(new O(2.5,.08,4),T);U.position.set(1.05,3.68,0),U.rotation.z=-.48,U.castShadow=!0,s.add(U);const M=new x(new O(.7,.22,.03),this.materials.wood);M.position.set(0,2.4,1.92),s.add(M);const S=new x(new O(.4,.08,.04),new H({color:5025616}));S.position.set(0,2.4,1.94),s.add(S),this.interactables.push({id:"enter_house",name:"进入房子",x:t,y:e+.12,z:n+1.9,triggerRadius:1.5}),this.scene.add(s)}createSummerDecorations(){const t=this.themeConfig.colors.sky===330776;if(this.swimRings=[],t){const a=new O(.8,.38,.8),r=new H({color:16119285,flatShading:!0}),c=new x(a,r);c.position.set(13,.18,13),c.castShadow=!0,this.scene.add(c),this.swimRings.push({mesh:c,baseX:13,baseZ:13,phase:0});const l=new x(a,r);l.position.set(-13,.18,12),l.castShadow=!0,this.scene.add(l),this.swimRings.push({mesh:l,baseX:-13,baseZ:12,phase:Math.PI})}else{const a=new Sn(.3,.08,6,12);a.rotateX(Math.PI/2);const r=new H({color:16728193,flatShading:!0}),c=new H({color:16771899,flatShading:!0}),l=new x(a,r);l.position.set(-2.2,.62,-2.5),l.rotation.set(.1,0,.15),l.castShadow=!0,this.scene.add(l);const h=new x(a,c);h.position.set(13,.18,13),this.scene.add(h),this.swimRings.push({mesh:h,baseX:13,baseZ:13,phase:0});const d=new x(a,r);d.position.set(-13,.18,12),this.scene.add(d),this.swimRings.push({mesh:d,baseX:-13,baseZ:12,phase:Math.PI})}const e=new lt;e.position.set(2.4,0,-2.4);const n=t?[16732754,5025616,16771899]:[16732754,4244735,16771899],i=new Lt(.18,6,6);i.scale(1,1.25,1);const s=new J(.005,.005,.8,4);for(let a=0;a<3;a++){const r=new H({color:n[a],flatShading:!0}),c=new x(i,r),l=a/3*Math.PI*2,h=Math.cos(l)*.22,d=Math.sin(l)*.22,u=1.3+Math.random()*.25;c.position.set(h,u,d),c.rotation.z=(Math.random()-.5)*.2,c.castShadow=!0,e.add(c);const f=new x(s,this.materials.stone);f.position.set(h/2,u-.4,d/2),f.lookAt(new P(h,u,d)),f.rotateX(Math.PI/2),e.add(f)}this.scene.add(e),this.balloons=e}update(t,e){if(this.swingSeat&&(this.swingSeat.rotation.x=Math.sin(t*.002)*.18),this.swimRings&&this.swimRings.forEach(n=>{n.mesh.position.y=.18+Math.sin(t*.0016+n.phase)*.04,n.mesh.rotation.y=t*3e-4+n.phase}),this.balloons&&(this.balloons.rotation.z=Math.sin(t*.0015)*.06,this.balloons.rotation.x=Math.cos(t*.001)*.04),this.streetlights){const n=e&&e.isNight?1.4:0;this.streetlights.forEach(i=>{let s=n;i.color.getHex()===16733986&&e&&e.isNight&&(s=1.4+Math.sin(t*.02)*.25+(Math.random()-.5)*.12),i.intensity+=(s-i.intensity)*.08})}this.paimon&&(this.paimon.position.y=1.25+Math.sin(t*.0025)*.08,this.paimon.rotation.y=t*6e-4)}createStreetlamps(){this.streetlights=[],this.createStreetlamp(-8,-4,16711807),this.createStreetlamp(-4,-11,62975),this.createStreetlamp(2,4,3800852),this.createFairyLightsDecoration()}createStreetlamp(t,e,n=16771899){const i=new lt;i.position.set(t,.6,e);const s=new J(.06,.08,2.2,4),a=new x(s,this.materials.wood);a.position.y=1.1,a.castShadow=!0,i.add(a);const r=new Mt({color:n}),c=new x(new O(.4,.06,.06),r);c.position.set(.18,2.1,0),i.add(c);const l=new x(new J(.1,.16,.28,5),this.materials.arcadeBody);l.position.set(.36,1.9,0),l.castShadow=!0,i.add(l);const h=new Mt({color:n}),d=new x(new Lt(.08,5,5),h);d.position.set(.36,1.76,0),i.add(d),this.scene.add(i);const u=new Ne(n,0,9,1.3);u.position.set(t+.36,2.3,e),this.scene.add(u),this.streetlights.push(u)}createFairyLightString(t,e,n=12,i=.4){const s=[16711765,62975,3800852,16771899,12386559,16748800],a=[],r=20;for(let f=0;f<=r;f++){const g=f/r,y=t.x+(e.x-t.x)*g,m=t.z+(e.z-t.z)*g,p=t.y+(e.y-t.y)*g-i*Math.sin(g*Math.PI);a.push(new P(y,p,m))}const c=new kc(a),l=new ga(c,20,.012,4,!1),h=new H({color:2236962}),d=new x(l,h);this.scene.add(d);const u=new Lt(.06,5,5);for(let f=0;f<n;f++){const g=(f+.5)/n,y=c.getPointAt(g),m=s[f%s.length],p=new Mt({color:m}),_=new x(u,p);if(_.position.copy(y),this.scene.add(_),f%3===1){const w=new Ne(m,0,4,1.5);w.position.copy(y),w.userData={maxIntensity:.85},this.scene.add(w),this.streetlights.push(w)}}}createFairyLightsDecoration(){this.createFairyLightString(new P(-11.9,3.8,-7.1),new P(-8.1,3.8,-7.1),10,.35),this.createFairyLightString(new P(-8.1,3.65,-6.9),new P(-8,2.8,-4),12,.5),this.createFairyLightString(new P(3.5,2.65,6),new P(5.5,2.65,6),8,.25)}createPaimon(t,e){this.themeConfig.colors.sky;const n=new lt;n.position.set(t,1.25,e);const i=new H({color:16769202,flatShading:!0}),s=new x(new Lt(.18,8,8),i);s.position.y=.18,s.castShadow=!0,n.add(s);const a=new H({color:16776432,flatShading:!0}),r=new x(new Lt(.2,6,6),a);r.position.set(0,.22,-.02),n.add(r);const c=new re(.06,.25,4);c.rotateX(Math.PI/6);const l=new x(c,a);l.position.set(-.16,.08,-.04),l.rotation.z=.3,l.castShadow=!0,n.add(l);const h=new x(c,a);h.position.set(.16,.08,-.04),h.rotation.z=-.3,h.castShadow=!0,n.add(h);const d=new Mt({color:1710618}),u=new x(new J(.08,.1,.05,5),d);u.position.y=.36,n.add(u);const f=new H({color:16777215,flatShading:!0}),g=new x(new re(.12,.32,5),f);g.position.y=-.08,g.rotation.x=Math.PI,g.castShadow=!0,n.add(g);const y=new Mt({color:870305}),m=new x(new O(.14,.04,.04),y);m.position.set(0,.06,.1),n.add(m);const p=new H({color:2503224,flatShading:!0}),_=new x(new O(.24,.35,.04),p);_.position.set(0,-.1,-.1),_.rotation.x=.1,n.add(_),this.scene.add(n),this.paimon=n,this.interactables.push({id:"paimon",name:"派蒙 (打开菜单)",x:t,y:.6,z:e,triggerRadius:2.2})}createLakePortal(t,e,n){const i=new lt;i.position.set(t,e,n);const s=11583173,a=new H({color:s,flatShading:!0}),r=new x(new J(.9,1,.22,12),a);r.position.y=.11,r.castShadow=!0,r.receiveShadow=!0,i.add(r);const c=new x(new J(.75,.65,.35,12),a);c.position.y=.38,c.castShadow=!0,c.receiveShadow=!0,i.add(c);const l=new Mt({color:45311,transparent:!0,opacity:.65,side:he}),h=new x(new en(.7,12),l);h.rotateX(-Math.PI/2),h.position.y=.54,i.add(h);const d=new J(.08,.16,.9,8),u=new Mt({color:14743546,transparent:!0,opacity:.82}),f=new x(d,u);f.position.y=.95,i.add(f);const g=new Mt({color:16777215}),y=new x(new O(.08,.08,.08),g);y.position.set(.12,1.35,.08),i.add(y);const m=y.clone();m.position.set(-.14,1.4,-.1),i.add(m);const p=y.clone();p.position.set(.05,1.25,-.15),i.add(p);const _=new x(new J(.03,.03,.8,8),new H({color:5125166}));_.position.set(1,.4,.4),_.rotation.z=.15,_.castShadow=!0,i.add(_);const w=new x(new O(.55,.16,.03),new H({color:9268835}));w.position.set(1.05,.72,.4),w.rotation.z=.15,w.rotation.y=.2,w.castShadow=!0,i.add(w);const v=new x(new O(.38,.06,.04),new Mt({color:58879}));v.position.set(1.04,.72,.42),v.rotation.z=.15,v.rotation.y=.2,i.add(v),this.scene.add(i),this.interactables.push({id:"enter_lake",name:"前往云顶天池",x:t,y:e,z:n,triggerRadius:1.8})}createCastlePortal(t,e,n){const i=new lt;i.position.set(t,e,n);const s=16764117,a=new H({color:s,flatShading:!0}),r=new x(new J(.9,1,.22,12),a);r.position.y=.11,r.castShadow=!0,r.receiveShadow=!0,i.add(r);const c=new x(new J(.75,.65,.35,12),a);c.position.y=.38,c.castShadow=!0,c.receiveShadow=!0,i.add(c);const l=new Mt({color:16739211,transparent:!0,opacity:.7,side:he}),h=new x(new en(.7,12),l);h.rotateX(-Math.PI/2),h.position.y=.54,i.add(h);const d=new J(.08,.16,.9,8),u=new Mt({color:16773363,transparent:!0,opacity:.85}),f=new x(d,u);f.position.y=.95,i.add(f);const g=new Mt({color:16777215}),y=new x(new O(.08,.08,.08),g);y.position.set(.12,1.35,.08),i.add(y);const m=y.clone();m.position.set(-.14,1.4,-.1),i.add(m);const p=y.clone();p.position.set(.05,1.25,-.15),i.add(p);const _=new x(new J(.03,.03,.8,8),new H({color:6111287}));_.position.set(1,.4,.4),_.rotation.z=.15,_.castShadow=!0,i.add(_);const w=new x(new O(.55,.16,.03),new H({color:16747937}));w.position.set(1.05,.72,.4),w.rotation.z=.15,w.rotation.y=.2,w.castShadow=!0,i.add(w);const v=new x(new O(.38,.06,.04),new Mt({color:16728193}));v.position.set(1.04,.72,.42),v.rotation.z=.15,v.rotation.y=.2,i.add(v),this.scene.add(i),this.interactables.push({id:"enter_castle",name:"前往粉色庄园",x:t,y:e,z:n,triggerRadius:1.8})}}class Zm{constructor(t,e){this.scene=t,this.themeConfig=e,this.colliders=[],this.interactables=[],this.group=new lt,this.materials={wood:new H({color:7951688,flatShading:!0}),woodLight:new H({color:14142664,flatShading:!0}),wall:new H({color:16448250,flatShading:!0}),wallTrim:new H({color:15723497,flatShading:!0}),glass:new Mt({color:14743546,transparent:!0,opacity:.25,side:he}),leaves:new H({color:4431943,flatShading:!0}),coconut:new H({color:4073251,flatShading:!0}),carpet:new H({color:16772275,flatShading:!0}),sofaBody:new H({color:12310267,flatShading:!0}),sofaCushion:new H({color:14938877,flatShading:!0}),metalGold:new H({color:16763432,flatShading:!0}),white:new H({color:16777215,flatShading:!0}),paintingSun:new Mt({color:16771899}),paintingArt:new Mt({color:16740419}),bedSpread:new H({color:16747136,flatShading:!0})},this.buildHouseMap(),this.scene.add(this.group)}buildHouseMap(){const t=new O(24,.12,24),e=new x(t,this.materials.woodLight);e.position.y=.06,e.receiveShadow=!0,e.castShadow=!0,this.group.add(e),this.colliders.push({mesh:e,radius:16,worldX:0,worldZ:0,worldY:.12,type:"floor"});const n=new O(.4,5.5,.4);[{x:-11.8,z:-11.8},{x:11.8,z:-11.8},{x:-11.8,z:11.8},{x:11.8,z:11.8}].forEach(v=>{const R=new x(n,this.materials.wood);R.position.set(v.x,2.75,v.z),R.castShadow=!0,this.group.add(R)});for(let v=-10;v<=10;v+=5){const R=new O(23.6,.15,.25),T=new x(R,this.materials.wood);T.position.set(0,5.4,v),this.group.add(T)}const s=new x(new O(23.6,5.5,.1),this.materials.wall);s.position.set(0,2.75,-11.8),s.castShadow=!0,s.receiveShadow=!0,this.group.add(s);const a=new x(new O(.1,5.5,23.6),this.materials.wall);a.position.set(11.8,2.75,0),a.castShadow=!0,a.receiveShadow=!0,this.group.add(a);const r=new x(new O(.1,5.5,5.8),this.materials.wall);r.position.set(-11.8,2.75,-8.9),r.castShadow=!0,this.group.add(r);const c=new x(new O(.1,5.5,5.8),this.materials.wall);c.position.set(-11.8,2.75,8.9),c.castShadow=!0,this.group.add(c);const l=new x(new O(.1,1.6,12),this.materials.wall);l.position.set(-11.8,.8,0),l.castShadow=!0,this.group.add(l);const h=new x(new O(.1,1.4,12),this.materials.wall);h.position.set(-11.8,4.8,0),h.castShadow=!0,this.group.add(h);const d=new x(new O(.04,2.4,12),this.materials.glass);d.position.set(-11.8,2.8,0),this.group.add(d);const u=new x(new O(10.6,5.5,.1),this.materials.wall);u.position.set(-6.5,2.75,11.8),u.castShadow=!0,this.group.add(u);const f=new x(new O(10.6,5.5,.1),this.materials.wall);f.position.set(6.5,2.75,11.8),f.castShadow=!0,this.group.add(f);const g=new x(new O(2.4,2.5,.1),this.materials.wall);g.position.set(0,4.25,11.8),g.castShadow=!0,this.group.add(g);const y=new x(new O(2.5,3.1,.2),this.materials.wood);y.position.set(0,1.5,11.8),this.group.add(y);const m=new x(new O(1.3,.35,.05),this.materials.wood);m.position.set(0,3.25,11.68),m.castShadow=!0,this.group.add(m);const p=new x(new O(.8,.12,.06),new H({color:16732754}));p.position.set(0,3.25,11.7),this.group.add(p),this.interactables.push({id:"exit_house",name:"离开房子",x:0,y:.12,z:11.2,triggerRadius:1.6}),this.createBed(-8,-7),this.createEasel(8,-8),this.createWardrobe(11,0),this.createSofaLounge(0,-2),this.createDiningTable(-10.5,0),this.createMonstera(-9.5,9.5);const _=new J(4,4,.01,24),w=new x(_,this.materials.carpet);w.position.set(0,.125,3),w.receiveShadow=!0,this.group.add(w),this.createSunsetPainting(0,-11.73),this.createReservedSpot(8.5,8.5),this.createCeilingLight(),this.createWindowScenery(),this.createFloorLamp(1.8,-3.2)}createBed(t,e){const n=new lt;n.position.set(t,.12,e);const i=new x(new O(2.6,.32,3),this.materials.wood);i.castShadow=!0,n.add(i);const s=new x(new O(2.4,.28,2.8),this.materials.white);s.position.y=.24,n.add(s);const a=new x(new O(2.42,.29,2),this.materials.bedSpread);a.position.set(0,.26,.4),a.castShadow=!0,n.add(a);const r=new x(new O(.9,.16,.5),this.materials.white);r.position.set(-.55,.4,-1),n.add(r);const c=new x(new O(.9,.16,.5),this.materials.white);c.position.set(.55,.4,-1),n.add(c);const l=new x(new O(.7,.5,.7),this.materials.wood);l.position.set(-1.8,.1,-1),l.castShadow=!0,n.add(l);const h=new x(new O(.7,.5,.7),this.materials.wood);h.position.set(1.8,.1,-1),h.castShadow=!0,n.add(h);const d=new x(new J(.08,.08,.18,4),this.materials.metalGold);d.position.set(-1.8,.44,-1),n.add(d);const u=new x(new J(.12,.18,.2,8),this.materials.white);u.position.set(-1.8,.62,-1),n.add(u);const f=new Ne(16758605,.9,8,1.5);f.position.set(-1.8,.65,-1),n.add(f),this.group.add(n),this.interactables.push({id:"house_bed",name:"躺下",x:t,y:.12,z:e,triggerRadius:2})}createEasel(t,e){const n=new lt;n.position.set(t,.12,e),n.rotation.y=-Math.PI/4;const i=new x(new J(.035,.035,2.4,4),this.materials.wood);i.position.set(-.5,1.15,0),i.rotation.z=-.15,i.castShadow=!0,n.add(i);const s=new x(new J(.035,.035,2.4,4),this.materials.wood);s.position.set(.5,1.15,0),s.rotation.z=.15,s.castShadow=!0,n.add(s);const a=new x(new J(.035,.035,2.4,4),this.materials.wood);a.position.set(0,1.15,-.5),a.rotation.x=.22,a.castShadow=!0,n.add(a);const r=new x(new O(1.4,.07,.14),this.materials.wood);r.position.set(0,1.05,.08),r.castShadow=!0,n.add(r);const c=new x(new O(1.2,.9,.04),this.materials.white);c.position.set(0,1.5,.08),c.rotation.x=-.08,c.castShadow=!0,n.add(c);const l=new x(new nn(1.14,.84),new Mt({color:11725810}));l.position.set(0,1.5,.11),l.rotation.x=-.08,n.add(l);const h=new x(new Lt(.11,6,6),this.materials.paintingSun);h.position.set(.2,1.62,.12),n.add(h);const d=new x(new nn(1.14,.35),new Mt({color:48340}));d.position.set(0,1.28,.12),d.rotation.x=-.08,n.add(d),this.group.add(n),this.interactables.push({id:"house_easel",name:"写生",x:t,y:.12,z:e,triggerRadius:1.8})}createWardrobe(t,e){const n=new lt;n.position.set(t,.12,e);const i=new x(new O(.9,2.8,1.8),this.materials.wood);i.position.y=1.4,i.castShadow=!0,i.receiveShadow=!0,n.add(i);const s=new x(new O(.06,2.5,.82),this.materials.woodLight);s.position.set(-.46,1.4,-.42),n.add(s);const a=new x(new O(.06,2.5,.82),this.materials.woodLight);a.position.set(-.46,1.4,.42),n.add(a);const r=new x(new Lt(.06,4,4),this.materials.metalGold);r.position.set(-.52,1.4,-.08),n.add(r);const c=new x(new Lt(.06,4,4),this.materials.metalGold);c.position.set(-.52,1.4,.08),n.add(c);const l=new O(2,.01,1.8),h=new x(l,this.materials.carpet);h.position.set(-1.4,.005,0),h.receiveShadow=!0,n.add(h);const d=new lt;d.position.set(-2.4,0,1);const u=new x(new J(.25,.25,.05,6),this.materials.metalGold);u.position.y=.025,u.castShadow=!0,d.add(u);const f=new x(new J(.035,.035,2,4),this.materials.wood);f.position.y=1,f.castShadow=!0,d.add(f);const g=new x(new J(.18,.3,.35,8),this.materials.white);g.position.y=2,g.castShadow=!0,d.add(g);const y=new x(new Lt(.07,6,6),new Mt({color:16774557}));y.position.y=1.9,d.add(y);const m=new Ne(16772290,2.2,10,1.2);m.position.set(0,1.9,0),m.castShadow=!1,d.add(m),n.add(d),this.group.add(n),this.interactables.push({id:"house_wardrobe",name:"衣柜换装",x:t-1.4,y:.12,z:e,triggerRadius:2})}createSofaLounge(t,e){const n=new lt;n.position.set(t,.12,e);const i=new O(4.2,.01,2.8),s=new x(i,this.materials.carpet);s.position.y=.005,n.add(s);const a=new x(new O(3,.28,1.2),this.materials.sofaBody);a.position.y=.24,a.castShadow=!0,n.add(a);const r=new x(new O(3,.8,.25),this.materials.sofaBody);r.position.set(0,.72,-.475),r.castShadow=!0,n.add(r);const c=new x(new O(.25,.55,1.2),this.materials.sofaBody);c.position.set(-1.375,.42,0),c.castShadow=!0,n.add(c);const l=new x(new O(.25,.55,1.2),this.materials.sofaBody);l.position.set(1.375,.42,0),l.castShadow=!0,n.add(l);for(let p=0;p<3;p++){const _=new x(new O(.82,.15,.85),this.materials.sofaCushion);_.position.set(-.82+p*.82,.38,.05),_.castShadow=!0,n.add(_)}const h=new lt;h.position.set(0,0,.9);const d=new x(new O(1.6,.06,.8),this.materials.wood);d.position.y=.35,d.castShadow=!0,h.add(d);const u=new J(.04,.04,.35,4),f=new x(u,this.materials.wood);f.position.set(-.7,.175,0),f.castShadow=!0,h.add(f);const g=new x(u,this.materials.wood);g.position.set(.7,.175,0),g.castShadow=!0,h.add(g);const y=new x(new J(.08,.06,.12,5),this.materials.coconut);y.position.set(0,.44,0),y.castShadow=!0,h.add(y);const m=new x(new Lt(.1,5,5),this.materials.leaves);m.position.set(0,.52,0),h.add(m),n.add(h),this.group.add(n)}createDiningTable(t,e){const n=new lt;n.position.set(t,.12,e);const i=new x(new O(.9,.08,2.5),this.materials.wood);i.position.y=1,i.castShadow=!0,n.add(i);const s=new J(.035,.035,1,4);[{x:-.38,z:-1.1},{x:.38,z:-1.1},{x:-.38,z:1.1},{x:.38,z:1.1}].forEach(m=>{const p=new x(s,this.materials.wood);p.position.set(m.x,.5,m.z),p.castShadow=!0,n.add(p)});const r=new O(.42,.06,.42),c=new J(.02,.02,.5,4);for(let m=-1;m<=1;m+=2){const p=new lt;p.position.set(.68*m,0,0);const _=new x(r,this.materials.wood);_.position.y=.53,_.castShadow=!0,p.add(_);for(let v=-1;v<=1;v+=2)for(let R=-1;R<=1;R+=2){const T=new x(c,this.materials.wood);T.position.set(.16*v,.25,.16*R),T.castShadow=!0,p.add(T)}const w=new x(new O(.06,.5,.42),this.materials.wood);w.position.set(.18*m,.78,0),w.castShadow=!0,p.add(w),n.add(p)}const l=[13959168,2001125,16757504];for(let m=0;m<3;m++){const p=new x(new O(.38,.06,.3),new H({color:l[m],flatShading:!0}));p.position.set(-.06,1.07+m*.062,.3),p.rotation.y=.12*m-.08,p.castShadow=!0,n.add(p)}const h=new x(new J(.12,.09,.22,5),this.materials.white);h.position.set(0,1.15,-.5),h.castShadow=!0,n.add(h);const d=new x(new Lt(.16,6,6),this.materials.leaves);d.position.set(0,1.3,-.5),n.add(d);const u=new x(new J(.08,.08,.04,4),this.materials.metalGold);u.position.set(.2,1.06,.8),n.add(u);const f=new x(new J(.015,.015,.35,4),this.materials.metalGold);f.position.set(.2,1.22,.8),f.rotation.z=-.2,n.add(f);const g=new x(new J(.08,.14,.16,6),this.materials.white);g.position.set(.13,1.38,.8),n.add(g);const y=new Ne(16777184,.8,6,1.2);y.position.set(.13,1.34,.8),n.add(y),this.group.add(n)}createMonstera(t,e){const n=new lt;n.position.set(t,.12,e);const i=new x(new J(.35,.28,.6,6),this.materials.carpet);i.position.y=.3,i.castShadow=!0,n.add(i);const s=new J(.03,.03,.9,4);for(let a=0;a<5;a++){const r=new x(s,this.materials.wood),c=a/5*Math.PI*2;r.position.set(Math.cos(c)*.14,.6,Math.sin(c)*.14),r.rotation.z=Math.cos(c)*.45,r.rotation.x=Math.sin(c)*.45,n.add(r);const l=new x(new Lt(.35,5,5),this.materials.leaves);l.scale.set(1.3,.2,1.8),l.position.set(Math.cos(c)*.52,.96,Math.sin(c)*.52),l.rotation.y=c,l.rotation.x=.45,l.castShadow=!0,n.add(l)}this.group.add(n)}createSunsetPainting(t,e){const n=new x(new O(4.2,2,.05),this.materials.wood);n.position.set(t,3,e),n.castShadow=!0,this.group.add(n);const i=new x(new O(3.8,1.6,.02),this.materials.paintingArt);i.position.set(t,3,e+.035),this.group.add(i);const s=new x(new Lt(.24,6,6),this.materials.paintingSun);s.position.set(t+.8,3.2,e+.05),this.group.add(s)}createReservedSpot(t,e){const n=new lt;n.position.set(t,.12,e);const i=new x(new O(3,.02,3),new H({color:9479342,flatShading:!0,transparent:!0,opacity:.5}));i.position.y=.01,n.add(i);const s=new x(new J(.02,.02,.45,4),this.materials.wood);s.position.set(0,.22,0),s.castShadow=!0,n.add(s);const a=new x(new O(.6,.25,.03),this.materials.wood);a.position.set(0,.44,0),a.castShadow=!0,n.add(a),this.group.add(n)}createCeilingLight(){const t=new lt;t.position.set(0,5.4,0);const e=new x(new J(.2,.2,.06,6),this.materials.wood);t.add(e);const n=new x(new J(.015,.015,1.2,4),new H({color:1118481}));n.position.y=-.6,t.add(n);const i=new x(new J(.08,.35,.28,8),this.materials.metalGold);i.position.y=-1.34,i.castShadow=!0,t.add(i);const s=new x(new Lt(.12,6,6),new Mt({color:16775620}));s.position.y=-1.48,t.add(s),this.group.add(t);const a=new Ne(16772290,1.7,28,1.2);a.position.set(0,3.82,0),a.castShadow=!1,this.group.add(a)}createWindowScenery(){const t=new lt;t.position.set(-17.5,-1.2,0);const e=new J(3.5,2.5,1.5,8),n=new x(e,this.materials.wood);n.receiveShadow=!0,t.add(n);const i=new x(new J(3.5,3.4,.2,8),this.materials.woodLight);i.position.y=.85,i.receiveShadow=!0,t.add(i);const s=new lt;s.position.set(0,.95,-.6),s.scale.set(.65,.65,.65);const a=new x(new J(.18,.25,2.5,5),this.materials.wood);a.position.y=1.25,a.rotation.z=-.12,s.add(a);const r=new lt;r.position.set(-.15,2.5,0);const c=new O(1.4,.02,.35);c.translate(.7,0,0);for(let m=0;m<6;m++){const p=new x(c,this.materials.leaves);p.rotation.y=m/6*Math.PI*2,p.rotation.z=-.2,r.add(p)}s.add(r),t.add(s);const l=new x(new Lt(1.2,10,10),new Mt({color:16769154}));l.position.set(-4.5,7.8,-4.5),t.add(l);const h=new lt;h.position.set(1.5,4,3);const d=new H({color:16448250,flatShading:!0});for(let m=0;m<3;m++){const p=new x(new Lt(.35+m*.1,5,5),d);p.position.set(m*.4-.4,0,m%2*.1),h.add(p)}t.add(h);const u=new Ne(8445674,1.5,12,1.2);u.position.set(-1,3.2,-1),t.add(u);const f=new Lt(.06,4,4),g=new Mt({color:16772275});[{x:-3.5,y:5.5,z:-2},{x:-2,y:6.5,z:2},{x:1.5,y:5.2,z:-3},{x:2.5,y:7,z:1},{x:-1.2,y:4.5,z:3.5},{x:-5,y:6,z:0}].forEach(m=>{const p=new x(f,g);p.position.set(m.x,m.y,m.z),t.add(p)}),this.group.add(t)}createFloorLamp(t,e){const n=new lt;n.position.set(t,.12,e);const i=new x(new J(.3,.3,.05,6),this.materials.metalGold);i.castShadow=!0,n.add(i);const s=new x(new J(.04,.04,2.2,4),this.materials.wood);s.position.y=1.1,s.castShadow=!0,n.add(s);const a=new x(new J(.2,.35,.4,8),this.materials.white);a.position.y=2.2,a.castShadow=!0,n.add(a);const r=new x(new Lt(.08,6,6),new Mt({color:16771899}));r.position.y=2.1,n.add(r);const c=new Ne(16765312,1.2,12,1.2);c.position.set(0,2,0),c.castShadow=!1,n.add(c),this.group.add(n)}}class mi{constructor(t,e,n,i){this.scene=t,this.camera=e,this.colliders=n,this.themeConfig=i,this.position=new P(0,4,0),this.velocity=new P,this.speed=8,this.jumpForce=7,this.gravity=18,this.isGrounded=!1,this.radius=.6,this.controlsLocked=!1,this.targetRotation=0,this.keys={w:!1,a:!1,s:!1,d:!1,space:!1,shift:!1},this.cameraAngleH=Math.PI/2,this.cameraAngleV=.35,this.cameraDistance=8.5,this.isSitting=!1,this.swingRef=null,this.isLyingDown=!1,this.initMesh(),this.initControls()}initMesh(){this.group=new lt,this.group.position.copy(this.position),this.activeModel="girl";const t=this.themeConfig.player.hairColor||16747136,e=this.themeConfig.player.clothingColor||16777215,n=this.themeConfig.player.hatColor||16765312;this.rebuildMesh(t,e,n)}rebuildMesh(t,e,n){for(;this.group.children.length>0;){const T=this.group.children[0];this.group.remove(T),T.geometry&&T.geometry.dispose(),T.material&&(Array.isArray(T.material)?T.material.forEach(E=>E.dispose()):T.material.dispose())}this.tailL=null,this.tailR=null,this.catTail=null;const i=this.themeConfig.colors.sky===330776,s=new H({color:16769213,flatShading:!0}),a=new H({color:16777215,flatShading:!0}),r=new H({color:t,flatShading:!0});this.hairMat=r;const c=new J(.2,.24,.35,8),l=new H({color:e,flatShading:!0});this.clothingMat=l,this.body=new x(c,l),this.body.position.y=.55,this.body.castShadow=!0,this.group.add(this.body);const h=i?2503224:4149685,d=new J(.24,.3,.3,8),u=new H({color:h,flatShading:!0}),f=new x(d,u);f.position.y=.25,f.castShadow=!0,this.group.add(f);const g=new Lt(.34,8,8);this.head=new x(g,s),this.head.position.y=.94,this.head.castShadow=!0,this.group.add(this.head);const y=new J(.08,.08,.15,6),m=new x(y,s);m.position.y=.75,this.group.add(m);const p=i?6111287:this.activeModel==="boy"?16732754:16777215,_=new H({color:p,flatShading:!0}),w=new Lt(.09,6,6);if(w.scale(1,i?1:.7,1.3),this.footL=new x(w,_),this.footL.position.set(-.16,.04,0),this.footR=new x(w,_),this.footR.position.set(.16,.04,0),!i&&this.activeModel==="girl"){const T=new O(.12,.04,.08),E=new x(T,_);E.position.set(-.16,.06,.08);const U=new x(T,_);U.position.set(.16,.06,.08),this.group.add(E),this.group.add(U)}this.group.add(this.footL),this.group.add(this.footR),this.activeModel==="girl"?this.buildGirlModel(r,a,n,i):this.activeModel==="boy"?this.buildBoyModel(r,a,n,i):this.activeModel==="kitty"&&this.buildKittyModel(r,a,n,i);const v=i?13959168:16777215,R=new H({color:v,transparent:!i,opacity:i?1:.8,side:he,flatShading:!0});if(i){const T=new nn(.55,.7,2,4);this.cape=new x(T,R),this.cape.position.set(.05,.62,-.22),this.cape.rotation.x=.12,this.cape.rotation.y=.05,this.cape.castShadow=!0,this.group.add(this.cape)}else{const T=new nn(.65,.75,3,5);this.cape=new x(T,R),this.cape.position.set(0,.48,-.32),this.cape.rotation.x=.15,this.cape.castShadow=!0,this.group.add(this.cape)}this.scene.add(this.group)}buildGirlModel(t,e,n,i){const s=new Lt(.36,8,8),a=new x(s,t);a.position.set(0,.98,-.04),this.group.add(a);const r=new O(.18,.18,.12),c=new x(r,t);c.position.set(-.12,1.05,.26),c.rotation.z=-.2,c.rotation.y=.1,this.group.add(c);const l=new x(r,t);l.position.set(.12,1.05,.26),l.rotation.z=.2,l.rotation.y=-.1,this.group.add(l);const h=new re(.1,.52,6);if(h.rotateX(Math.PI),this.tailL=new x(h,t),this.tailL.position.set(-.35,.94,-.05),this.tailL.rotation.z=-.25,this.group.add(this.tailL),this.tailR=new x(h,t),this.tailR.position.set(.35,.94,-.05),this.tailR.rotation.z=.25,this.group.add(this.tailR),i){const L=new x(new O(.07,.07,.04),e);L.position.set(.24,1.12,.24),L.rotation.z=Math.PI/4,this.group.add(L)}else{const L=new x(new O(.08,.08,.04),new H({color:5025616}));L.position.set(.24,1.12,.24),L.rotation.z=-.4;const F=new x(new O(.06,.06,.04),new H({color:16732754}));F.position.set(.24,1.14,.26),F.rotation.z=-.4,this.group.add(L),this.group.add(F)}if(i){const L=new lt;L.position.set(0,1.25,-.04);const F=new re(.35,.6,8);F.translate(0,.3,0);const Z=new H({color:n,flatShading:!0});this.hatMat=Z;const I=new x(F,Z);I.rotation.z=-.15,I.rotation.x=-.1,I.castShadow=!0,L.add(I);const B=new J(.36,.36,.12,8),k=new x(B,e);k.position.y=.05,L.add(k);const Y=new Lt(.08,6,6),$=new x(Y,e);$.position.set(.08,.62,-.04),L.add($),this.group.add(L)}else{const L=new lt;L.position.set(0,1.28,-.04);const F=new J(.72,.72,.04,10),Z=new H({color:n,flatShading:!0});this.hatMat=Z;const I=new x(F,Z);I.castShadow=!0,L.add(I);const B=new J(.32,.38,.25,8),k=new x(B,Z);k.position.y=.14,k.castShadow=!0,L.add(k);const Y=new J(.39,.39,.06,8),$=new x(Y,e);$.position.y=.05,L.add($),this.group.add(L)}const d=new lt;d.position.set(0,1.22,.3),d.rotation.x=-.15;const u=new Lt(.12,6,6);u.scale(1,1,.2);const f=new Mt({color:1710618}),g=new x(u,f);g.position.x=-.16;const y=new x(u,f);y.position.x=.16,d.add(g),d.add(y);const m=i?16777215:16744619,p=new H({color:m,flatShading:!0});if(i){const L=new O(.48,.2,.06),F=new x(L,p);F.position.set(0,0,.02),d.add(F)}else{const L=new J(.15,.15,.05,8);L.rotateX(Math.PI/2);const F=new x(L,p);F.position.set(-.16,0,.02);const Z=new x(L,p);Z.position.set(.16,0,.02),d.add(F),d.add(Z)}this.group.add(d);const _=new lt;_.position.set(.1,i?1.55:1.48,-.06);const w=new Lt(.14,6,6);w.scale(1,.9,1.1);const v=i?11583173:16765312,R=new H({color:v,flatShading:!0}),T=new x(w,R);_.add(T);const E=new Lt(.04,4,4),U=new x(E,R);U.position.set(-.06,.09,.05);const M=new x(E,R);M.position.set(.06,.09,.05),_.add(U),_.add(M);const S=new x(new Lt(.02,4,4),new H({color:16747136}));if(S.position.set(.08,0,.11),_.add(S),i){const L=new J(.11,.11,.04,6),F=new x(L,new H({color:12986408}));F.position.y=-.06,_.add(F)}else{const L=new x(new Lt(.02,4,4),e);L.position.set(.06,.12,.08),_.add(L)}if(this.group.add(_),i){const L=new lt;L.position.set(0,.58,.3);const F=new x(new O(.25,.25,.25),new H({color:3046706,flatShading:!0}));F.castShadow=!0,L.add(F);const Z=new x(new O(.27,.05,.27),new H({color:13959168,flatShading:!0}));L.add(Z),this.group.add(L)}else{const L=new lt;L.position.set(0,.58,.35);const F=new O(.3,.16,.06),Z=new x(F,new H({color:16732754}));L.add(Z);const I=new O(.32,.04,.08),B=new x(I,new H({color:5025616}));B.position.y=-.09,L.add(B),this.group.add(L)}this.buildFaceDetails()}buildBoyModel(t,e,n,i){const s=new Lt(.35,8,8),a=new x(s,t);a.position.set(0,.98,-.04),this.group.add(a);const r=new re(.08,.22,4);r.rotateX(Math.PI/1.8);for(let et=0;et<4;et++){const ft=new x(r,t),Et=-.15+et*.1;ft.position.set(Et,1.08,.26),ft.rotation.y=Et*.5,ft.castShadow=!0,this.group.add(ft)}const c=new re(.07,.22,4);c.rotateX(-.3),[{x:-.14,y:1.25,z:-.08},{x:.14,y:1.25,z:-.08},{x:0,y:1.28,z:-.04},{x:-.08,y:1.24,z:-.2},{x:.08,y:1.24,z:-.2}].forEach(et=>{const ft=new x(c,t);ft.position.set(et.x,et.y,et.z),ft.castShadow=!0,this.group.add(ft)});const h=new lt;h.position.set(0,1.24,-.04);const d=new H({color:n,flatShading:!0});this.hatMat=d;const u=new J(.35,.36,.22,8),f=new x(u,d);f.castShadow=!0,h.add(f);const g=new O(.46,.02,.35),y=new x(g,d);y.position.set(0,-.06,.28),y.rotation.x=.14,y.castShadow=!0,h.add(y);const m=new Lt(.04,4,4),p=new x(m,e);p.position.y=.12,h.add(p),this.group.add(h);const _=new lt;_.position.set(0,1.22,.3);const w=new O(.14,.09,.02),v=new Mt({color:1118481}),R=new x(w,v);R.position.x=-.16;const T=new x(w,v);T.position.x=.16,_.add(R),_.add(T);const E=new H({color:i?16777215:2201331,flatShading:!0}),U=new x(new O(.18,.02,.03),E);U.position.set(0,0,.01),_.add(U);const M=new x(new O(.02,.11,.04),E);M.position.set(-.24,0,.01);const S=new x(new O(.02,.11,.04),E);S.position.set(.24,0,.01),_.add(M),_.add(S),this.group.add(_);const L=new lt;L.position.set(-.35,.65,.05),L.scale.set(.8,.8,.8);const F=new H({color:16732754,flatShading:!0}),Z=new x(new O(.22,.12,.15),F);Z.castShadow=!0,L.add(Z);const I=new Lt(.03,4,4),B=new x(I,new Mt({color:16777215}));B.position.set(-.05,.08,.08);const k=new x(I,new Mt({color:16777215}));k.position.set(.05,.08,.08),L.add(B),L.add(k);const Y=new Lt(.06,5,5);Y.scale(1.2,.8,1);const $=new x(Y,F);$.position.set(-.14,.04,.08);const q=new x(Y,F);q.position.set(.14,.04,.08),L.add($),L.add(q),this.group.add(L);const Q=new lt;Q.position.set(.25,.52,.28),Q.rotation.set(-.15,-.4,.35);const it=new H({color:58998,flatShading:!0}),rt=new x(new O(.15,.9,.04),it);rt.castShadow=!0,Q.add(rt);const V=new x(new O(.16,.2,.05),new H({color:16771899,flatShading:!0}));V.position.y=.05,Q.add(V),this.group.add(Q),this.buildFaceDetails()}buildKittyModel(t,e,n,i){const s=t,a=new Lt(.07,6,6);a.scale(1.3,.8,1);const r=new x(a,e);r.position.set(0,.86,.29),this.group.add(r);const c=new Lt(.035,4,4),l=new H({color:16747136}),h=new x(c,l);h.position.set(0,.89,.35),this.group.add(h);const d=new O(.26,.015,.015),u=new Mt({color:1118481});for(let rt=0;rt<3;rt++){const V=new x(d,u);V.position.set(-.26,.86+(rt-1)*.04,.25),V.rotation.z=-(rt-1)*.12-.05,V.rotation.y=.2,this.group.add(V);const et=new x(d,u);et.position.set(.26,.86+(rt-1)*.04,.25),et.rotation.z=(rt-1)*.12+.05,et.rotation.y=-.2,this.group.add(et)}const f=new re(.12,.28,4);f.rotateX(.1);const g=new x(f,s);g.position.set(-.22,1.2,.06),g.rotation.z=.25,g.castShadow=!0,this.group.add(g);const y=new x(f,s);y.position.set(.22,1.2,.06),y.rotation.z=-.25,y.castShadow=!0,this.group.add(y);const m=new H({color:16747136,flatShading:!0}),p=new re(.08,.2,4);p.rotateX(.1);const _=new x(p,m);_.position.set(-.21,1.21,.09),_.rotation.z=.25,this.group.add(_);const w=new x(p,m);w.position.set(.21,1.21,.09),w.rotation.z=-.25,this.group.add(w);const v=i?3046706:13959168,R=new H({color:v,flatShading:!0}),T=new J(.21,.21,.06,8),E=new x(T,R);E.position.y=.73,this.group.add(E);const U=new H({color:n,flatShading:!0});this.hatMat=U;const M=new Lt(.07,6,6),S=new x(M,U);S.position.set(0,.69,.28),this.group.add(S);const L=new Sn(.03,.01,4,8),F=new x(L,U);F.position.set(0,.74,.25),this.group.add(F),this.catTail=new lt,this.catTail.position.set(0,.22,-.28);let Z=this.catTail;const I=4,B=new J(.04,.04,.18,5);B.translate(0,.09,0);for(let rt=0;rt<I;rt++){const V=new x(B,s);V.position.set(0,rt===0?0:.15,rt===0?0:-.05),V.rotation.x=-.3,V.castShadow=!0,Z.add(V),Z=V}this.group.add(this.catTail);const k=new lt;k.position.set(0,.56,.32),k.rotation.set(.1,-.4,.2);const Y=new H({color:48340,flatShading:!0}),$=new x(new O(.18,.09,.05),Y);$.castShadow=!0,k.add($);const q=new re(.05,.08,3);q.rotateX(Math.PI/2);const Q=new x(q,Y);Q.position.set(-.11,0,0),k.add(Q);const it=new x(new Lt(.012,4,4),new Mt({color:16777215}));it.position.set(.06,.02,.03),k.add(it),this.group.add(k),this.buildFaceDetails()}buildFaceDetails(){const t=new Lt(.06,5,5),e=new Mt({color:5125166}),n=new x(t,e);n.position.set(-.11,.94,.27);const i=new x(t,e);i.position.set(.11,.94,.27),this.group.add(n),this.group.add(i);const s=new Lt(.05,4,4),a=new H({color:16747136,flatShading:!0}),r=new x(s,a);r.position.set(-.19,.87,.25);const c=new x(s,a);c.position.set(.19,.87,.25),this.group.add(r),this.group.add(c)}updateModel(t){if(this.activeModel===t)return;this.activeModel=t;const e=this.hairMat?this.hairMat.color.getHex():this.themeConfig.player.hairColor||16747136,n=this.clothingMat?this.clothingMat.color.getHex():this.themeConfig.player.clothingColor||16777215,i=this.hatMat?this.hatMat.color.getHex():this.themeConfig.player.hatColor||16765312;this.rebuildMesh(e,n,i)}initControls(){const t=(c,l)=>{if(this.isSitting||this.isLyingDown){l&&(c.key===" "||c.key==="Spacebar")&&this.standUp();return}if(this.controlsLocked)return;const h=c.key.toLowerCase();if((h==="w"||c.key==="ArrowUp")&&(this.keys.w=l),(h==="s"||c.key==="ArrowDown")&&(this.keys.s=l),(h==="a"||c.key==="ArrowLeft")&&(this.keys.a=l),(h==="d"||c.key==="ArrowRight")&&(this.keys.d=l),c.key===" "||c.key==="Spacebar"){const d=window.parent&&window.parent.isRadialMenuOpen;this.keys.space=d?!1:l}c.key==="Shift"&&(this.keys.shift=l)};window.addEventListener("keydown",c=>t(c,!0)),window.addEventListener("keyup",c=>t(c,!1));let e=!1,n={x:0,y:0};window.addEventListener("mousedown",c=>{e=!0,n={x:c.clientX,y:c.clientY}}),window.addEventListener("mousemove",c=>{if(!e)return;const l=c.clientX-n.x,h=c.clientY-n.y;this.cameraAngleH-=l*.005,this.cameraAngleV=Math.max(.1,Math.min(1.2,this.cameraAngleV+h*.005)),n={x:c.clientX,y:c.clientY}}),window.addEventListener("mouseup",()=>{e=!1});let i=null;document.addEventListener("touchstart",c=>{for(let l=0;l<c.changedTouches.length;l++){const h=c.changedTouches[l],d=h.target&&h.target.closest?h.target:null,u=d?d.closest("#mobile-controls")||d.closest(".hud-header")||d.closest(".modal-overlay")||d.closest(".modal-card")||d.closest(".sso-sidebar")||d.closest(".sidebar-overlay")||d.id==="audio-btn":!1,f=h.clientX<window.innerWidth*.45;if(!u&&!f&&i===null){e=!0,i=h.identifier,n={x:h.clientX,y:h.clientY};break}}}),document.addEventListener("touchmove",c=>{if(!e||i===null)return;let l=null;for(let u=0;u<c.touches.length;u++)if(c.touches[u].identifier===i){l=c.touches[u];break}if(!l)return;c.preventDefault();const h=l.clientX-n.x,d=l.clientY-n.y;this.cameraAngleH-=h*.005,this.cameraAngleV=Math.max(.1,Math.min(1.2,this.cameraAngleV+d*.005)),n={x:l.clientX,y:l.clientY}},{passive:!1});const s=c=>{if(i===null)return;let l=!1;for(let h=0;h<c.changedTouches.length;h++)if(c.changedTouches[h].identifier===i){l=!0;break}l&&(e=!1,i=null)};document.addEventListener("touchend",s),document.addEventListener("touchcancel",s),window.addEventListener("modal-opened",()=>{this.controlsLocked=!0,this.resetInputs()}),window.addEventListener("modal-closed",()=>{this.controlsLocked=!1});const a=document.getElementById("btn-jump");a&&(a.addEventListener("touchstart",c=>{if(c.preventDefault(),this.isSitting||this.isLyingDown){this.standUp();return}this.controlsLocked||(this.keys.space=!0)}),a.addEventListener("touchend",c=>{c.preventDefault(),this.keys.space=!1}));const r=document.getElementById("btn-run");r&&(r.addEventListener("touchstart",c=>{c.preventDefault(),this.controlsLocked||(this.keys.shift=!0)}),r.addEventListener("touchend",c=>{c.preventDefault(),this.keys.shift=!1}))}resetInputs(){this.keys={w:!1,a:!1,s:!1,d:!1,space:!1,shift:!1},this.velocity.set(0,this.velocity.y,0)}update(t,e){if(window.self!==window.top&&window.parent&&(window.parent.isRadialMenuOpen?(this.keys.space=!1,window.parent.keys&&(window.parent.keys.space=!1)):window.parent.keys&&(this.keys.space=this.keys.space||window.parent.keys.space),window.parent.keys&&(this.keys.shift=this.keys.shift||window.parent.keys.shift,this.keys.j=this.keys.j||window.parent.keys.j)),(this.isSitting||this.isLyingDown)&&this.keys.space&&(this.standUp(),window.parent&&window.parent.keys&&(window.parent.keys.space=!1),this.keys.space=!1),this.isLyingDown){this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.lyingRotation?(this.group.rotation.x=this.lyingRotation.x,this.group.rotation.y=this.lyingRotation.y,this.group.rotation.z=this.lyingRotation.z):(this.group.rotation.x=-Math.PI/2,this.group.rotation.y=0,this.group.rotation.z=0),this.body.rotation.x=0,this.footL.position.set(-.16,.05,0),this.footR.position.set(.16,.05,0),this.body.position.y=.38,this.head.position.y=.88,this.cape.rotation.x=.15;const v=this.cape.geometry.attributes.position;for(let M=0;M<v.count;M++)v.setZ(M,0);v.needsUpdate=!0;const R=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,T=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,E=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(R-this.camera.position.x)*.08,this.camera.position.y+=(T-this.camera.position.y)*.08,this.camera.position.z+=(E-this.camera.position.z)*.08;const U=this.position.clone().add(new P(0,.4,0));this.camera.lookAt(U);return}if(this.isSitting&&this.swingRef){if(this.swingRef.isStatic)this.position.copy(this.swingRef.position),this.position.y+=.22,this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.group.rotation.y=this.swingRef.rotationY;else{const M=this.swingRef.rotation.x,S=1.1;this.position.x=this.swingRef.parent.position.x+this.swingRef.position.x,this.position.y=this.swingRef.parent.position.y+this.swingRef.position.y-S*Math.cos(M)-.28,this.position.z=this.swingRef.parent.position.z+this.swingRef.position.z-S*Math.sin(M),this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.group.rotation.y=0}this.footL.position.set(-.16,.15,.18),this.footR.position.set(.16,.15,.18),this.body.position.y=.3,this.head.position.y=.8,this.cape.rotation.x=-.1+Math.sin(e*.002)*.05;const v=this.cape.geometry.attributes.position;for(let M=0;M<v.count;M++)v.setZ(M,0);v.needsUpdate=!0,this.tailL&&(this.tailL.rotation.z=-.2-Math.sin(e*.002)*.1),this.tailR&&(this.tailR.rotation.z=.2+Math.sin(e*.002)*.1),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.003)*.15);const R=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,T=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,E=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(R-this.camera.position.x)*.08,this.camera.position.y+=(T-this.camera.position.y)*.08,this.camera.position.z+=(E-this.camera.position.z)*.08;const U=this.position.clone().add(new P(0,.8,0));this.camera.lookAt(U);return}let n=0,i=0;if(!this.controlsLocked&&(this.keys.w&&(i-=1),this.keys.s&&(i+=1),this.keys.a&&(n-=1),this.keys.d&&(n+=1),window.self!==window.top&&window.parent&&window.parent.joystickDir)){const v=window.parent.joystickDir;(v.x!==0||v.y!==0)&&(n+=v.x,i+=v.y)}const a=new P(n,0,i).normalize().clone().applyAxisAngle(new P(0,1,0),this.cameraAngleH),r=this.keys.shift?this.speed*1.6:this.speed;if(this.velocity.x=a.x*r,this.velocity.z=a.z*r,this.isGrounded||(this.velocity.y-=this.gravity*t),this.position.addScaledVector(this.velocity,t),this.app&&this.app.currentMap==="house")this.position.x<-11.5&&(this.position.x=-11.5),this.position.x>11.5&&(this.position.x=11.5),this.position.z<-11.5&&(this.position.z=-11.5),this.position.z>11.5&&(this.position.z=11.5);else{const R=Math.sqrt(this.position.x*this.position.x+this.position.z*this.position.z);R>21.2&&(this.position.x=this.position.x/R*21.2,this.position.z=this.position.z/R*21.2)}let c=!1,l=-999;for(const v of this.colliders)if(v.type==="floor"){const R=this.position.x-v.worldX,T=this.position.z-v.worldZ;Math.sqrt(R*R+T*T)<v.radius+.1&&this.position.y>=v.worldY-.8&&this.position.y<=v.worldY+.1&&(l=Math.max(l,v.worldY),c=!0)}c?this.velocity.y<=0&&(this.position.y=l,this.velocity.y=0,this.isGrounded=!0):this.isGrounded=!1,this.position.y<-10&&(this.position.set(0,4,0),this.velocity.set(0,0,0),this.isGrounded=!1);const h=window.parent&&window.parent.isRadialMenuOpen;this.keys.space&&this.isGrounded&&!this.controlsLocked&&!h&&(this.velocity.y=this.jumpForce,this.isGrounded=!1,this.keys.space=!1,window.parent&&window.parent.keys&&(window.parent.keys.space=!1)),this.group.position.copy(this.position);const d=Math.sqrt(this.velocity.x*this.velocity.x+this.velocity.z*this.velocity.z);if(d>.1){this.targetRotation=Math.atan2(this.velocity.x,this.velocity.z);let v=this.targetRotation-this.group.rotation.y;v=Math.atan2(Math.sin(v),Math.cos(v)),this.group.rotation.y+=v*.15;const R=this.keys.shift?24:16;this.footL.position.z=Math.sin(e*.001*R)*.25,this.footL.position.y=.05+Math.max(0,Math.cos(e*.001*R))*.12,this.footR.position.z=-Math.sin(e*.001*R)*.25,this.footR.position.y=.05+Math.max(0,-Math.cos(e*.001*R))*.12,this.tailL&&(this.tailL.rotation.z=-.2-Math.abs(Math.sin(e*.001*R))*.18),this.tailR&&(this.tailR.rotation.z=.2+Math.abs(Math.sin(e*.001*R))*.18),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.001*R*1.5)*.35,this.catTail.rotation.z=Math.cos(e*.001*R*1.5)*.06),this.body.rotation.x=this.keys.shift?.22:.1,this.body.position.y=.38+Math.abs(Math.sin(e*.001*R))*.06,this.head.position.y=.88+Math.abs(Math.sin(e*.001*R))*.04}else this.body.rotation.x=0,this.footL.position.set(-.16,.05,0),this.footR.position.set(.16,.05,0),this.body.position.y=.38+Math.sin(e*.003)*.02,this.head.position.y=.88+Math.sin(e*.003)*.02,this.tailL&&(this.tailL.rotation.z=-.2+Math.sin(e*.003)*.04),this.tailR&&(this.tailR.rotation.z=.2-Math.sin(e*.003)*.04),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.003)*.15,this.catTail.rotation.z=Math.cos(e*.003)*.03);const u=this.cape.geometry.attributes.position,f=18,g=2.2,y=.08+d*.03;for(let v=0;v<u.count;v++){u.getX(v);const T=.4-u.getY(v),E=Math.sin(e*.001*f-T*g)*y*(T/.8);u.setZ(v,E)}u.needsUpdate=!0;const m=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,p=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,_=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(m-this.camera.position.x)*.08,this.camera.position.y+=(p-this.camera.position.y)*.08,this.camera.position.z+=(_-this.camera.position.z)*.08;const w=this.position.clone().add(new P(0,.8,0));this.camera.lookAt(w)}sit(t){this.isSitting=!0,this.swingRef=t,this.controlsLocked=!0}lieDown(t,e){this.isLyingDown=!0,this.controlsLocked=!0,this.position.copy(t),this.position.y=t.y+.58,e?this.lyingRotation=e:this.lyingRotation=null,window.parent&&window.parent.appShell&&typeof window.parent.appShell.hideMobileControls=="function"&&window.parent.appShell.hideMobileControls(),window.gameApp&&typeof window.gameApp.updateTaskProgress=="function"&&window.gameApp.updateTaskProgress("rest",1)}updateOutfit(t,e){const n=parseInt(e);t==="hair"&&this.hairMat?this.hairMat.color.setHex(n):t==="clothing"&&this.clothingMat?this.clothingMat.color.setHex(n):t==="hat"&&this.hatMat&&this.hatMat.color.setHex(n)}standUp(){if(this.isLyingDown){this.isLyingDown=!1,this.controlsLocked=!1,this.group.rotation.x=0,this.group.rotation.y=0,this.group.rotation.z=0,this.lyingRotation?(this.lyingRotation=null,this.position.x+=1):this.position.z+=1.4,this.position.y=.8;const n=document.getElementById("bed-hud");n&&(n.style.display="none"),window.parent&&window.parent.appShell&&typeof window.parent.appShell.showMobileControls=="function"&&window.parent.appShell.showMobileControls();return}const t=this.swingRef&&this.swingRef.isStatic;this.isSitting=!1,this.swingRef=null,this.controlsLocked=!1,t?(this.position.x>0?this.position.x+=.9:this.position.x-=.9,this.position.y=.6):(this.position.z+=1.2,this.position.y=.8);const e=document.getElementById("exit-sitting-hud");e&&(e.style.display="none")}}class gi{constructor(t,e,n,i){this.player=t,this.generator=e,this.modalManager=n,this.app=i,this.promptEl=document.getElementById("interact-prompt"),this.promptTextEl=this.promptEl?this.promptEl.querySelector(".prompt-text"):null,this.mobileInteractBtn=document.getElementById("btn-interact")||window.parent&&window.parent.document.getElementById("btn-interact"),this.activeInteractZone=null,this.isTransitioningCamera=!1,this.cameraSavedState=null,this.init()}init(){window.addEventListener("keydown",t=>{t.key.toLowerCase()==="e"&&this.triggerActiveInteraction()}),this.mobileInteractBtn&&(this.mobileInteractBtn.addEventListener("touchstart",t=>{t.preventDefault(),this.triggerActiveInteraction()},{passive:!1}),this.mobileInteractBtn.addEventListener("click",t=>{t.preventDefault(),this.triggerActiveInteraction()})),window.addEventListener("modal-closed",()=>{this.isTransitioningCamera&&this.cameraSavedState&&(this.isTransitioningCamera=!1,this.player.cameraDistance=this.cameraSavedState.distance,this.player.cameraAngleH=this.cameraSavedState.angleH,this.player.cameraAngleV=this.cameraSavedState.angleV,this.cameraSavedState.rotationY!==void 0&&(this.player.group.rotation.y=this.cameraSavedState.rotationY),this.cameraSavedState.controlsLocked!==void 0&&(this.player.controlsLocked=this.cameraSavedState.controlsLocked),this.activeInteractZone=null)})}update(){if(this.player.carriedBall){this.activeInteractZone={id:"drop_ball",name:"放下"},this.showPrompt("放下");return}if(this.player.controlsLocked)return;let t=null,e=999;const n=this.player.position;for(const i of this.generator.interactables){if(i.id.startsWith("farm_plot_")&&this.app&&this.app.gameData){const l=parseInt(i.id.replace("farm_plot_","")),h=this.app.gameData.farmPlots[l];if(h&&h.status!=="ready")continue}const s=n.x-i.x,a=n.y-i.y,r=n.z-i.z,c=Math.sqrt(s*s+a*a+r*r);if(c<i.triggerRadius&&c<e&&(e=c,t=i,i.id.startsWith("farm_plot_")&&this.app&&this.app.gameData)){const l=parseInt(i.id.replace("farm_plot_","")),h=this.app.gameData.farmPlots[l];if(h)if(h.status==="empty")i.name="种植农作物";else if(h.status==="ready")i.name="收割作物";else{const d=h.seedId==="sunflower_seed"?30:60,u=Math.floor((Date.now()-h.plantTime)/1e3),f=Math.max(0,d-u);i.name=`作物生长中 (${f}s)`}}}if(this.app&&this.app.beachBallsList)for(const i of this.app.beachBallsList){if(i.isCarried)continue;const s=n.x-i.position.x,a=n.y-i.position.y,r=n.z-i.position.z,c=Math.sqrt(s*s+a*a+r*r);c<1.6&&c<e&&(e=c,t={id:"pick_ball",name:"抱起",ball:i})}t?(this.activeInteractZone=t,this.showPrompt(t.name)):(this.activeInteractZone=null,this.hidePrompt())}showPrompt(t){if(this.promptEl&&this.promptEl.classList.add("visible"),this.mobileInteractBtn){this.mobileInteractBtn.style.display="flex";let e=!1;if(this.activeInteractZone&&this.activeInteractZone.id.startsWith("farm_plot_")&&this.app&&this.app.gameData){const s=parseInt(this.activeInteractZone.id.replace("farm_plot_","")),a=this.app.gameData.farmPlots[s];a&&a.status==="empty"&&(e=!0)}const n=`
<svg style="display: flex;" class="lucide lucide-sparkles" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275z"/>
  <path d="m5 3 1 2.5L8.5 6 6 7 5 9.5 4 7 1.5 6 4 5.5z"/>
  <path d="m19 17 1 2.5 2.5.5-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z"/>
</svg>`,i=`
<svg style="display: flex;" class="lucide lucide-sprout" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M7 20h10" />
  <path d="M10 20V12h4v8" />
  <path d="M12 12a5 5 0 0 0-5-5H4v2h3a3 3 0 0 1 3 3v0" />
  <path d="M12 8a5 5 0 0 1 5-5h3v2h-3a3 3 0 0 0-3 3v0" />
</svg>`;this.mobileInteractBtn.innerHTML=e?i:n}}hidePrompt(){this.promptEl&&this.promptEl.classList.remove("visible"),this.mobileInteractBtn&&(this.mobileInteractBtn.style.display="none")}pickUpBall(t){t.isCarried=!0,this.player.carriedBall=t,this.hidePrompt(),this.mobileInteractBtn&&(this.mobileInteractBtn.textContent="👐")}dropCarriedBall(){const t=this.player.carriedBall;if(!t)return;t.isCarried=!1,this.player.carriedBall=null,t.throwNoCollideTimer=.4;const e=new P(0,0,1).applyQuaternion(this.player.group.quaternion);t.velocity.copy(this.player.velocity),t.velocity.addScaledVector(e,5.5),t.velocity.y=2.8,t.isGrounded=!1,this.hidePrompt(),this.mobileInteractBtn&&(this.mobileInteractBtn.textContent="✨")}triggerActiveInteraction(){if(!this.activeInteractZone)return;const t=this.activeInteractZone;if(t.id==="drop_ball"){this.dropCarriedBall();return}if(t.id==="pick_ball"){this.pickUpBall(t.ball);return}if(t.id==="paimon"){try{window.parent&&window.parent.appShell&&typeof window.parent.appShell.toggleSidebar=="function"?window.parent.appShell.toggleSidebar():typeof window.openSSOSidebar=="function"&&window.openSSOSidebar()}catch(e){console.warn("[交互] 打开侧边栏失败:",e)}this.hidePrompt();return}if(t.id==="enter_house"){this.player.carriedBall&&this.dropCarriedBall(),this.app.switchMap("house");return}if(t.id==="enter_castle"){this.player.carriedBall&&this.dropCarriedBall(),this.app.switchMap("castle");return}if(t.id==="exit_house"){this.player.carriedBall&&this.dropCarriedBall(),this.app.modalMgr?this.app.modalMgr.openModal("exit"):this.app.switchMap("island");return}if(t.id==="swing"){this.player.isSitting?this.player.standUp():(this.player.carriedBall&&this.dropCarriedBall(),this.player.sit(this.generator.swingSeat),this.hidePrompt());return}if(t.id==="ball_vendor"){window.dispatchEvent(new CustomEvent("spawn-ball",{detail:{x:t.x,z:t.z}}));return}if(t.id==="house_bed"||t.id==="lie_bed"){if(this.player.isLyingDown)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e=new P(t.x,t.y,t.z);this.player.lieDown(e),this.hidePrompt();const n=document.getElementById("bed-hud")||document.getElementById("exit-sitting-hud");n&&(n.style.display="flex")}return}if(t.id==="lake_seat_1"||t.id==="lake_seat_2"){if(this.player.isSitting)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e=t.id==="lake_seat_1",n={isStatic:!0,position:new P(e?7.5:-7.5,.78,0),rotationY:e?-Math.PI/2:Math.PI/2};this.player.sit(n);const i=document.getElementById("exit-sitting-hud");if(i){const s=document.getElementById("exit-sitting-hud-text");s&&(s.textContent="🧘 您正在静坐观赏中"),i.style.display="flex"}this.hidePrompt()}return}if(t.id==="sit_sofa"){if(this.player.isSitting)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e={isStatic:!0,position:new P(0,.72+.1,-8.7),rotationY:Math.PI};this.player.sit(e);const n=document.getElementById("exit-sitting-hud");if(n){const i=document.getElementById("exit-sitting-hud-text");i&&(i.textContent="🧘 您正在沙发小憩中"),n.style.display="flex"}this.hidePrompt()}return}if(t.id==="lie_lounger_1"||t.id==="lie_lounger_2"){if(this.player.isLyingDown)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e=new P(t.x,t.y,t.z),n={x:-Math.PI/6,y:-Math.PI/2,z:0};this.player.lieDown(e,n);const i=document.getElementById("exit-sitting-hud");if(i){const s=document.getElementById("exit-sitting-hud-text");s&&(s.textContent="☀️ 您正在享受日光浴中"),i.style.display="flex"}this.hidePrompt()}return}if(t.id.startsWith("farm_plot_")){const e=parseInt(t.id.replace("farm_plot_",""));this.app&&typeof this.app.triggerPlotInteraction=="function"&&this.app.triggerPlotInteraction(e),this.hidePrompt();return}if(t.id==="pk_crystal"){this.modalManager.openModal("pk"),this.hidePrompt();return}if(t.id==="house_easel"){this.modalManager.openModal("easel"),this.hidePrompt();return}if(t.id==="house_wardrobe"||t.id==="wardrobe"){this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV,rotationY:this.player.group.rotation.y,controlsLocked:this.player.controlsLocked},this.isTransitioningCamera=!0,this.player.controlsLocked=!0,this.player.cameraDistance=2.4,this.player.cameraAngleH=0,this.player.cameraAngleV=.08,this.player.group.rotation.y=0,setTimeout(()=>{this.modalManager.openModal("wardrobe"),this.hidePrompt()},450);return}this.player.controlsLocked||(this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV},this.isTransitioningCamera=!0,t.id==="arcade"?(this.player.cameraDistance=2.4,this.player.cameraAngleH=0,this.player.cameraAngleV=.15):t.id==="skills"?(this.player.cameraDistance=9.5,this.player.cameraAngleV=.5):t.id==="projects"&&(this.player.cameraDistance=7,this.player.cameraAngleH=-Math.PI/2,this.player.cameraAngleV=.25),setTimeout(()=>{this.modalManager.openModal(t.id),this.hidePrompt()},450))}}class Km{constructor(t,e,n,i,s){this.scene=t,this.radius=.36,this.position=new P(e,n,i),this.velocity=new P((Math.random()-.5)*1.5,3.2,(Math.random()-.5)*1.5),this.gravity=15,this.friction=.985,this.bounceElasticity=.65,this.isGrounded=!1,this.throwNoCollideTimer=0,this.initMesh(s)}initMesh(t){this.group=new lt,this.group.position.copy(this.position);const e=new Lt(this.radius,12,12),n=new H({color:t,flatShading:!0});this.ballMesh=new x(e,n),this.ballMesh.castShadow=!0,this.ballMesh.receiveShadow=!0,this.group.add(this.ballMesh);const i=new H({color:16777215,flatShading:!0}),s=new J(this.radius+.005,this.radius+.005,this.radius*.25,12,1,!0),a=new x(s,i);a.rotation.x=Math.PI/2,this.group.add(a);const r=new J(this.radius+.004,this.radius+.004,this.radius*.25,12,1,!0),c=new x(r,i);c.rotation.z=Math.PI/2,this.group.add(c),this.scene.add(this.group)}update(t,e){if(this.throwNoCollideTimer>0&&(this.throwNoCollideTimer-=t),this.isCarried){const s=new P(0,0,1).applyQuaternion(e.group.quaternion);this.position.copy(e.position).addScaledVector(s,.65),this.position.y+=.65,this.velocity.set(0,0,0),this.isGrounded=!1,this.group.position.copy(this.position);return}this.isGrounded||(this.velocity.y-=this.gravity*t),this.velocity.x*=Math.pow(this.friction,t*60),this.velocity.z*=Math.pow(this.friction,t*60),this.position.addScaledVector(this.velocity,t);const n=this.app&&this.app.currentMap==="house"?.12:.6;if(this.position.y-this.radius<=n?(this.position.y=n+this.radius,this.velocity.y<-1.5?this.velocity.y=-this.velocity.y*this.bounceElasticity:(this.velocity.y=0,this.isGrounded=!0)):this.isGrounded=!1,this.app&&this.app.currentMap==="house"){const s=11.8-this.radius;this.position.x<-s?(this.position.x=-s,this.velocity.x=-this.velocity.x*this.bounceElasticity,this.playKickSound()):this.position.x>s&&(this.position.x=s,this.velocity.x=-this.velocity.x*this.bounceElasticity,this.playKickSound()),this.position.z<-s?(this.position.z=-s,this.velocity.z=-this.velocity.z*this.bounceElasticity,this.playKickSound()):this.position.z>s&&(this.position.z=s,this.velocity.z=-this.velocity.z*this.bounceElasticity,this.playKickSound())}else{const a=Math.sqrt(this.position.x*this.position.x+this.position.z*this.position.z);if(a+this.radius>21.5){const r=this.position.x/a,c=this.position.z/a,l=this.velocity.x*r+this.velocity.z*c;l>0&&(this.velocity.x-=2*l*r,this.velocity.z-=2*l*c,this.velocity.x*=.68,this.velocity.z*=.68),this.position.x=r*(21.5-this.radius),this.position.z=c*(21.5-this.radius)}}if(this.throwNoCollideTimer<=0){const s=this.position.x-e.position.x,a=this.position.z-e.position.z,r=Math.sqrt(s*s+a*a),c=(e.radius||.6)+this.radius-.05;if(r<c&&Math.abs(this.position.y-e.position.y)<1.3){const l=Math.atan2(s,a),h=new P(Math.sin(l),0,Math.cos(l)),d=c-r;this.position.x+=h.x*d,this.position.z+=h.z*d;const u=Math.sqrt(e.velocity.x*e.velocity.x+e.velocity.z*e.velocity.z),f=4.8,g=u*1.3,y=f+g;this.velocity.x=h.x*y,this.velocity.z=h.z*y,this.velocity.y=2.4+g*.45,this.isGrounded=!1,this.playKickSound()}}const i=Math.sqrt(this.velocity.x*this.velocity.x+this.velocity.z*this.velocity.z);if(i>.08){const s=-this.velocity.z/i,a=this.velocity.x/i,r=i/this.radius*t;this.ballMesh.rotateOnWorldAxis(new P(s,0,a),r)}this.group.position.copy(this.position)}playKickSound(){window.dispatchEvent(new CustomEvent("kick-sound",{detail:{freq:140+Math.random()*60}}))}destroy(){this.scene.remove(this.group),this.group.traverse(t=>{t.isMesh&&(t.geometry.dispose(),t.material&&t.material.dispose&&t.material.dispose())})}}class Jm{constructor(){if(document.addEventListener("dblclick",n=>{n.preventDefault()},{passive:!1}),document.addEventListener("selectstart",n=>{n.target.tagName!=="INPUT"&&n.target.tagName!=="TEXTAREA"&&n.preventDefault()}),"ontouchstart"in window||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0)document.body.classList.add("is-mobile");else{const n=()=>{document.body.classList.add("is-mobile"),window.removeEventListener("touchstart",n)};window.addEventListener("touchstart",n)}this.container=document.getElementById("canvas-container"),this.clock=new Wm,this.renderer=null,this.scene=null,this.camera=null,this.player=null,this.environment=null,this.islandGen=null,this.modalMgr=null,this.interactMgr=null,this.beachBallsList=[],this.activeBombs=[],this.activeExplosions=[],this.bombCooldownActive=!1;const e=$n.activeTheme||"beach";this.themeConfig=$n.themes[e],this.audioCtx=null,this.isPlayingMusic=!1,this.synthInterval=null,this.initEngine(),this.initWorld(),this.initSSO(),this.initGameSystems(),this.animate()}initSSO(){const t=new URLSearchParams(window.location.search),e=t.get("sso_access_token"),n=t.get("sso_user");if(e&&n){localStorage.setItem("sso_access_token",e),localStorage.setItem("sso_user",n),t.delete("sso_access_token"),t.delete("sso_user");const E=t.toString(),U=window.location.pathname+(E?"?"+E:"")+window.location.hash;window.history.replaceState({},document.title,U)}const i=document.getElementById("sso-login-btn"),s=document.getElementById("sso-user-info"),a=document.getElementById("sso-avatar");document.getElementById("sso-sidebar");const r=document.getElementById("sidebar-overlay"),c=document.getElementById("sidebar-close-btn"),l=document.getElementById("sidebar-avatar"),h=document.getElementById("sidebar-username"),d=document.getElementById("sidebar-user-status"),u=document.getElementById("sidebar-login-btn"),f=document.getElementById("sidebar-logout-btn");window.showMockToast=function(E){let U=document.querySelector(".mock-toast");U&&U.remove();const M=document.createElement("div");M.className="mock-toast",M.textContent=`${E} 功能正在开发中，敬请期待！😊`,document.body.appendChild(M),setTimeout(()=>{M.classList.add("show")},50),setTimeout(()=>{M.classList.remove("show"),setTimeout(()=>M.remove(),300)},2200)};const g=()=>{const E=document.getElementById("sso-sidebar"),U=document.getElementById("sidebar-overlay");E&&E.classList.add("open"),U&&U.classList.add("visible"),this.player&&(this.player.controlsLocked=!0,this.player.resetInputs())};window.openSSOSidebar=()=>{g()};const y=()=>{const E=document.getElementById("sso-sidebar"),U=document.getElementById("sidebar-overlay");E&&E.classList.remove("open"),U&&U.classList.remove("visible"),this.player&&(this.player.controlsLocked=!1)},m=E=>{E.stopPropagation(),g()};i&&i.addEventListener("click",m),s&&s.addEventListener("click",m),c&&c.addEventListener("click",E=>{E.stopPropagation(),y()}),r&&r.addEventListener("click",E=>{E.stopPropagation(),y()});const p=()=>{const E=localStorage.getItem("sso_access_token"),U=localStorage.getItem("sso_user");if(E&&U)try{const M=JSON.parse(U);i&&(i.style.display="none"),s&&(s.style.display="flex");const S=M.avatar||'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E';a&&(a.src=S),l&&(l.src=S),h&&(h.textContent=M.username),d&&(d.textContent="已登录",d.style.borderColor="rgba(100, 255, 150, 0.4)",d.style.color="#5aff8a"),u&&(u.style.display="none"),f&&(f.style.display="flex")}catch(M){console.error("Parse user failed",M)}else i&&(i.style.display="flex"),s&&(s.style.display="none"),l&&(l.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E'),h&&(h.textContent="未登录"),d&&(d.textContent="游客",d.style.borderColor="rgba(255, 140, 105, 0.25)",d.style.color="var(--primary)"),u&&(u.style.display="inline-block"),f&&(f.style.display="none")},_=document.getElementById("sidebar-back-2d-btn");if(_){const E=U=>{U.stopPropagation(),(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1")&&window.location.port==="3000"?window.location.href="http://127.0.0.1:8000/index.html":window.location.href="/index.html"};_.addEventListener("click",E)}u&&u.addEventListener("click",E=>{E.preventDefault();let M=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?"http://127.0.0.1:8000/index.html":"/index.html";if(document.referrer&&(document.referrer.includes("index.html")||document.referrer.endsWith("/")))try{const L=new URL(document.referrer);(L.pathname==="/"||L.pathname.endsWith("/index.html"))&&(M=L.origin+L.pathname)}catch{}const S=window.location.href;window.location.href=`${M}?sso_return_url=${encodeURIComponent(S)}`}),f&&f.addEventListener("click",E=>{E.preventDefault(),localStorage.removeItem("sso_access_token"),localStorage.removeItem("sso_user"),p(),y(),window.location.reload()});const w=document.getElementById("sidebar-stuck-btn");w&&w.addEventListener("click",E=>{E.stopPropagation(),this.unstuckPlayer(),y()});const v=document.getElementById("btn-map-island"),R=document.getElementById("btn-map-house");v&&v.addEventListener("click",E=>{E.stopPropagation(),this.switchMap("island"),y()}),R&&R.addEventListener("click",E=>{E.stopPropagation(),this.switchMap("house"),y()}),[{id:"btn-sidebar-leaderboard",name:"leaderboard"},{id:"btn-sidebar-tasks",name:"tasks"},{id:"btn-sidebar-farm",name:"farm"},{id:"btn-sidebar-pk",name:"pk"},{id:"btn-sidebar-bag",name:"bag"},{id:"btn-sidebar-home",name:"home"}].forEach(E=>{const U=document.getElementById(E.id);U&&U.addEventListener("click",M=>{M.stopPropagation(),y(),E.name==="farm"?(this.switchMap("farm"),setTimeout(()=>{if(window.showMockToast){let S=document.querySelector(".mock-toast");S&&S.remove();const L=document.createElement("div");L.className="mock-toast",L.textContent="已传送至您的 3D 农场岛！走近泥地格按 E 种植/收割 🌾",document.body.appendChild(L),setTimeout(()=>L.classList.add("show"),50),setTimeout(()=>{L.classList.remove("show"),setTimeout(()=>L.remove(),300)},2200)}},this.currentMap==="house"?600:50)):E.name==="pk"?(this.switchMap("pk_arena",new P(0,.6+.1,-6.5)),setTimeout(()=>{if(window.showMockToast){let S=document.querySelector(".mock-toast");S&&S.remove();const L=document.createElement("div");L.className="mock-toast",L.textContent="已传送至 3D 竞技大厅！走近前方蓝色的“决斗水晶”按 E 开启匹配决斗 ⚔️",document.body.appendChild(L),setTimeout(()=>L.classList.add("show"),50),setTimeout(()=>{L.classList.remove("show"),setTimeout(()=>L.remove(),300)},2500)}},this.currentMap==="house"?600:50)):this.modalMgr&&this.modalMgr.openModal(E.name)})}),p(),window.addEventListener("keydown",E=>{if(E.key==="Escape"){const U=document.activeElement;if(U&&(U.tagName==="INPUT"||U.tagName==="TEXTAREA"||U.isContentEditable))return;const M=document.getElementById("btn-settle-close");if(M){E.preventDefault(),M.click();return}if(this.modalMgr&&this.modalMgr.isAnyModalOpen){E.preventDefault(),this.modalMgr.closeAllModals();return}if(window.self!==window.top&&window.parent&&window.parent.appShell&&typeof window.parent.appShell.toggleSidebar=="function"){E.preventDefault(),window.parent.appShell.toggleSidebar();return}const S=document.getElementById("sso-sidebar");S&&(E.preventDefault(),S.classList.contains("open")?y():g())}}),document.addEventListener("touchmove",E=>{E.target.closest(".scrollable")||E.target.closest(".wardrobe-sidebar")||E.target.closest(".modal-body")||E.target.closest(".sso-sidebar")||E.cancelable&&E.preventDefault()},{passive:!1})}initEngine(){this.scene=new nm;const t=this.themeConfig.colors.sky||11725810;this.scene.background=new Xt(t),this.camera=new Be(45,window.innerWidth/window.innerHeight,.1,200),this.renderer=new Uc({antialias:!0,alpha:!1}),this.renderer.setSize(window.innerWidth,window.innerHeight);const e="ontouchstart"in window||navigator.maxTouchPoints>0;this.renderer.setPixelRatio(e?Math.min(window.devicePixelRatio,1.35):Math.min(window.devicePixelRatio,2)),this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=e?sa:ic,this.renderer.toneMapping=sc,this.renderer.toneMappingExposure=1.35,this.container.appendChild(this.renderer.domElement),window.addEventListener("resize",()=>this.onWindowResize())}initWorld(){this.currentMap="island",document.body.id==="page-lobby"?this.currentMap="island":document.body.id==="page-house"?this.currentMap="house":document.body.id==="page-farm"?this.currentMap="farm":document.body.id==="page-pvp"?this.currentMap="pk_arena":document.body.id==="page-lake"?this.currentMap="lake":document.body.id==="page-castle"&&(this.currentMap="castle"),this.modalMgr=new Ym,this.environment=new $m(this.scene,this.themeConfig),this.currentMap==="island"?(this.islandGen=new jm(this.scene,this.themeConfig),this.player=new mi(this.scene,this.camera,this.islandGen.colliders,this.themeConfig),this.interactMgr=new gi(this.player,this.islandGen,this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="house"?(this.houseGen=new Zm(this.scene,this.themeConfig),this.houseGen.group.visible=!0,this.player=new mi(this.scene,this.camera,this.houseGen.colliders,this.themeConfig),this.interactMgr=new gi(this.player,this.houseGen,this.modalMgr,this),this.environment.setIndoorMode(!0)):this.currentMap==="farm"?(this.farmGroup=new lt,this.scene.add(this.farmGroup),this.farmGroup.visible=!0,this.buildFarmPlatform(),this.player=new mi(this.scene,this.camera,this.farmColliders||[],this.themeConfig),this.interactMgr=new gi(this.player,{interactables:this.farmInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="pk_arena"?(this.pkArenaGroup=new lt,this.scene.add(this.pkArenaGroup),this.pkArenaGroup.visible=!0,this.buildPKPlatform(),this.player=new mi(this.scene,this.camera,this.pkArenaColliders||[],this.themeConfig),this.interactMgr=new gi(this.player,{interactables:this.pkArenaInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="lake"?(this.lakeGroup=new lt,this.scene.add(this.lakeGroup),this.lakeGroup.visible=!0,this.buildLakePlatform(),this.player=new mi(this.scene,this.camera,this.lakeColliders||[],this.themeConfig),this.interactMgr=new gi(this.player,{interactables:this.lakeInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1),window.addEventListener("piano-note-played",a=>{this.currentMap==="lake"&&this.spawnNoteParticle(a.detail.note)})):this.currentMap==="castle"&&(this.castleGroup=new lt,this.scene.add(this.castleGroup),this.castleGroup.visible=!0,this.buildCastlePlatform(),this.player=new mi(this.scene,this.camera,this.castleColliders||[],this.themeConfig),this.interactMgr=new gi(this.player,{interactables:this.castleInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)),this.player.app=this;const e=new URLSearchParams(window.location.search).get("spawn");if(e){const a=e.split(",").map(Number);a.length===3&&!a.some(isNaN)&&(this.player.position.set(a[0],a[1],a[2]),this.player.group.position.copy(this.player.position),this.currentMap==="house"||this.currentMap==="farm"||this.currentMap==="castle"?(this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="pk_arena"?a[2]<0?(this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):(this.player.group.rotation.y=-Math.PI/2,this.player.cameraAngleH=-Math.PI/2):(this.currentMap==="island"||this.currentMap==="lake")&&(this.player.group.rotation.y=0,this.player.cameraAngleH=0))}else this.currentMap==="house"?(this.player.position.set(0,.12+.1,9.5),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="farm"?(this.player.position.set(0,.6+.1,-8),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="pk_arena"?(this.player.position.set(-5,.6+.1,0),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=-Math.PI/2,this.player.cameraAngleH=-Math.PI/2):this.currentMap==="lake"?(this.player.position.set(0,.6+.1,8.5),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="castle"?(this.player.position.set(0,.6+.1,10),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):(this.player.position.set(0,4,0),this.player.group.position.copy(this.player.position));const n=$n.activeTheme==="christmas";window.addEventListener("spawn-ball",a=>{if(this.currentMap!=="island")return;const r=a.detail.x,c=a.detail.z+.6,l=n?[16777215,14743546,16120573]:[16732754,4244735,16771899,16747136,58998],h=l[Math.floor(Math.random()*l.length)],d=new Km(this.scene,r,1.3,c,h);if(d.app=this,this.beachBallsList.push(d),this.beachBallsList.length>5){let u=-1;for(let f=0;f<this.beachBallsList.length;f++)if(!this.beachBallsList[f].isCarried){u=f;break}u!==-1&&this.beachBallsList.splice(u,1)[0].destroy()}this.playCustomSound(n?320:450,.12,"sine",.08)}),window.addEventListener("kick-sound",a=>{this.playCustomSound(n?a.detail.freq*.6:a.detail.freq,.16,n?"sine":"triangle",.18)}),this.initWardrobeUI();const i=document.getElementById("btn-toggle-time");if(i){const a=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.environment&&(this.environment.isNight=!this.environment.isNight,this.playCustomSound(this.environment.isNight?220:440,.4,"sine",.08))};i.addEventListener("touchstart",a,{passive:!1}),i.addEventListener("click",a)}const s=document.getElementById("btn-stand-up");if(s){const a=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.player&&this.player.isLyingDown&&this.player.standUp()};s.addEventListener("touchstart",a,{passive:!1}),s.addEventListener("click",a)}window.parent&&window.parent.appShell&&typeof window.parent.appShell.onMapLoaded=="function"&&window.parent.appShell.onMapLoaded(this.currentMap)}initWardrobeUI(){const t=(n,i)=>{const s=document.getElementById(n);if(!s)return;s.querySelectorAll(".color-btn").forEach(r=>{r.addEventListener("click",()=>{var l;(l=s.querySelector(".color-btn.active"))==null||l.classList.remove("active"),r.classList.add("active");const c=r.getAttribute("data-color");this.player&&this.player.updateOutfit(i,c)})})};t("wardrobe-hair","hair"),t("wardrobe-clothes","clothing"),t("wardrobe-hat","hat"),document.querySelectorAll(".model-btn").forEach(n=>{n.addEventListener("click",()=>{var s;(s=document.querySelector(".model-btn.active"))==null||s.classList.remove("active"),n.classList.add("active");const i=n.getAttribute("data-model");if(this.player){this.player.updateModel(i);const a=document.getElementById("wardrobe-hair-title"),r=document.getElementById("wardrobe-clothing-title"),c=document.getElementById("wardrobe-hat-title");i==="kitty"?(a&&(a.textContent="毛皮颜色 (Fur Color)"),r&&(r.textContent="小猫背心 (Vest Color)"),c&&(c.textContent="金铃铛颜色 (Bell Color)")):(a&&(a.textContent="发发 / 毛毛"),r&&(r.textContent="服装颜色"),c&&(c.textContent="配饰 / 铃铛颜色")),this.playCustomSound(440,.15,"triangle",.06)}})})}playCustomSound(t,e,n="sine",i=.05){if(window.parent&&typeof window.parent.playCustomSound=="function"){window.parent.playCustomSound(t,e,n,i);return}try{this.audioCtx||(this.audioCtx=new(window.AudioContext||window.webkitAudioContext)),this.audioCtx.state==="suspended"&&this.audioCtx.resume();const s=this.audioCtx.createOscillator(),a=this.audioCtx.createGain();s.type=n,s.frequency.setValueAtTime(t,this.audioCtx.currentTime),a.gain.setValueAtTime(i,this.audioCtx.currentTime),a.gain.exponentialRampToValueAtTime(1e-4,this.audioCtx.currentTime+e),s.connect(a),a.connect(this.audioCtx.destination),s.start(),s.stop(this.audioCtx.currentTime+e)}catch(s){console.warn("Play custom sound failed",s)}}initMobileJoystick(){}initAudioSynth(){}playMelodyLoop(){}playMelodyLoop(){const t=$n.activeTheme==="christmas",e=t?1.2:1,n=[[130.81,196,261.63,329.63,392].map(r=>r*e),[146.83,220,293.66,349.23,440].map(r=>r*e),[164.81,246.94,329.63,392,493.88].map(r=>r*e),[116.54,174.61,233.08,293.66,349.23].map(r=>r*e)];let i=0,s=0;const a=(r,c,l="sine",h=.05)=>{if(!this.isPlayingMusic||!this.audioCtx)return;const d=this.audioCtx.createOscillator(),u=this.audioCtx.createGain();d.type=l,d.frequency.setValueAtTime(r,this.audioCtx.currentTime),u.gain.setValueAtTime(h,this.audioCtx.currentTime),u.gain.exponentialRampToValueAtTime(1e-4,this.audioCtx.currentTime+c),d.connect(u),u.connect(this.audioCtx.destination),d.start(),d.stop(this.audioCtx.currentTime+c)};this.synthInterval=setInterval(()=>{const r=n[i],c=[0,2,1,3,2,4,3,1],l=c[s%c.length],h=r[l];if(a(h,.9,"sine",t?.05:.08),s%4===0&&Math.random()>.3){const u=h*2;a(u,1.6,"sine",t?.04:.03)}s++,s%16===0&&(i=(i+1)%n.length)},320)}onWindowResize(){this.camera.aspect=window.innerWidth/window.innerHeight,this.camera.updateProjectionMatrix(),this.renderer.setSize(window.innerWidth,window.innerHeight)}switchMap(t,e=null,n=null,i=null){let s="";t==="island"?s="lobby.html":t==="house"?s="house.html":t==="farm"?s="farm.html":t==="pk_arena"?s="pvp.html":t==="lake"?s="lake.html":t==="castle"&&(s="castle.html");const a=[];e&&a.push(`spawn=${e.x.toFixed(2)},${e.y.toFixed(2)},${e.z.toFixed(2)}`),n&&a.push(`modal=${n}`),i&&a.push(`action=${i}`),a.length>0&&(s+="?"+a.join("&"));const r=document.getElementById("fade-overlay");r&&r.classList.add("fade-in"),setTimeout(()=>{window.location.href=s},450)}unstuckPlayer(){if(this.player&&((this.player.isSitting||this.player.isLyingDown)&&this.player.standUp(),this.currentMap==="house"?this.player.position.set(0,.12+.1,9.5):this.player.position.set(-10,.6+.1,-5.2),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=this.currentMap==="house"?Math.PI:0,this.player.cameraAngleH=this.currentMap==="house"?Math.PI:0,window.showMockToast)){let t=document.querySelector(".mock-toast");t&&t.remove();const e=document.createElement("div");e.className="mock-toast",e.textContent="重置成功！角色已脱离卡死 🌀",document.body.appendChild(e),setTimeout(()=>{e.classList.add("show")},50),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>e.remove(),300)},2200)}}animate(){if(requestAnimationFrame(()=>this.animate()),window.parent&&window.parent.keys){const n=!!window.parent.keys.j;n&&!this.lastParentJ&&typeof this.playerPerformAttack=="function"&&this.playerPerformAttack(),this.lastParentJ=n}const t=Math.min(this.clock.getDelta(),.1),e=this.clock.getElapsedTime()*1e3;this.player&&this.player.update(t,e),this.environment&&this.environment.update(e),this.islandGen&&this.islandGen.update(e,this.environment),this.interactMgr&&this.interactMgr.update(),this.beachBallsList&&this.player&&this.beachBallsList.forEach(n=>n.update(t,this.player)),this.updateGameSystemsFrame(t,e),this.currentMap==="lake"&&this.updateLakeFrame(t,e),this.currentMap==="castle"&&this.updateCastleFrame(t,e),this.renderer&&this.scene&&this.camera&&this.renderer.render(this.scene,this.camera)}getInitialGameData(){return{coins:200,level:1,exp:0,pkPoints:1e3,pkWins:0,pkLoses:0,onlineTime:0,backpack:[{id:"sunflower_seed",name:"向日葵种子",type:"seed",count:5,quality:"green",desc:"可在农田里种植，成熟后收割获得丰厚金币。"},{id:"strawberry_seed",name:"草莓种子",type:"seed",count:2,quality:"blue",desc:"可在农田里种植，成熟收割获得巨额回报。"}],farmPlots:[{id:0,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:1,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:2,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:3,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:4,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:5,status:"empty",seedId:null,plantTime:0,unlocked:!0}],homeFurnitures:[],ownedFurnitures:["painting_1","tree_1"],tasks:[{id:"kick_ball",name:"在群岛领取沙滩球或踢球 1 次",progress:0,target:1,reward:50,status:"ongoing",type:"kick"},{id:"rest_bed",name:"在温馨小屋床上休息 1 次",progress:0,target:1,reward:50,status:"ongoing",type:"rest"},{id:"play_billiards",name:"游玩 1 局弹射台球游戏",progress:0,target:1,reward:80,status:"ongoing",type:"game_billiards"},{id:"play_poker",name:"游玩 1 局 21点纸牌游戏",progress:0,target:1,reward:80,status:"ongoing",type:"game_poker"},{id:"crop_harvest",name:"收割成熟的农地作物 3 次",progress:0,target:3,reward:100,status:"ongoing",type:"harvest"}],dailyChestClaimed:!1,lastTaskResetDate:new Date().toLocaleDateString()}}async loadGameData(){const t=localStorage.getItem("sso_access_token"),e=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";let n=null;if(t)try{const a=await(await fetch(`${e}/api/game/data?game_id=3d-home-all`,{headers:{Authorization:`Bearer ${t}`}})).json();a.success&&a.data&&a.data.save_data&&(n=a.data.save_data)}catch(s){console.error("从云端加载存档失败，采用本地缓存",s)}if(!n){const s=localStorage.getItem("player_game_data");if(s)try{n=JSON.parse(s)}catch(a){console.error("本地存档解析失败",a)}}if(!n)n=this.getInitialGameData();else{const s=this.getInitialGameData();n=Object.assign({},s,n)}this.gameData=n;const i=new Date().toLocaleDateString();this.gameData.lastTaskResetDate!==i&&(this.gameData.tasks=this.getInitialGameData().tasks,this.gameData.dailyChestClaimed=!1,this.gameData.lastTaskResetDate=i,this.saveGameData()),this.updateBaseUI()}async saveGameData(){localStorage.setItem("player_game_data",JSON.stringify(this.gameData));const t=localStorage.getItem("sso_access_token"),e=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";if(t)try{await fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"3d-home-all",score:this.gameData.level,save_data:this.gameData})}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"pkPoints",score:this.gameData.pkPoints})}).catch(()=>{}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"coins",score:this.gameData.coins})}).catch(()=>{}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"level",score:this.gameData.level})}).catch(()=>{})}catch(n){console.error("云端存档同步失败",n)}this.updateBaseUI()}updateBaseUI(){const t=document.getElementById("farm-coins"),e=document.getElementById("home-coins"),n=document.getElementById("farm-level"),i=document.getElementById("farm-exp"),s=document.querySelector("#modal-bag .bag-coins-val");t&&(t.textContent=this.gameData.coins),e&&(e.textContent=this.gameData.coins),n&&(n.textContent=this.gameData.level),i&&(i.textContent=this.gameData.exp),s&&(s.textContent=this.gameData.coins)}initGameSystems(){this.gameData=this.getInitialGameData(),this.loadGameData(),setInterval(()=>{this.gameData.onlineTime++,this.gameData.onlineTime%60===0&&(this.gameData.exp+=15,this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,this.playCustomSound(523.25,.4,"triangle",.1)),this.saveGameData())},1e3),window.addEventListener("spawn-ball",()=>{this.updateTaskProgress("kick",1)}),window.addEventListener("modal-opened",i=>{const s=i.detail.modalId;s==="leaderboard"&&this.refreshLeaderboard(),s==="tasks"&&this.refreshTasks(),s==="farm"&&this.refreshFarm(),s==="pk"&&this.refreshPK(),s==="bag"&&this.refreshBag(),s==="home"&&this.refreshHome(),s==="shop"&&(this.updateShopCoins(),this.renderShopItems(this.getActiveShopTab()))}),this.initLeaderboardUI(),this.initTasksUI(),this.initFarmUI(),this.initPKUI(),this.initBagUI(),this.initHomeUI(),this.initMapUI(),this.initShopUI(),this.initRadialSeedMenu();const t=new URLSearchParams(window.location.search),e=t.get("modal");if(e&&this.modalMgr&&setTimeout(()=>{this.modalMgr.openModal(e)},500),t.get("action")==="edit"&&setTimeout(()=>{this.enterHomeEditMode()},500),this.currentMap==="pk_arena"&&setTimeout(()=>{this.modalMgr&&this.modalMgr.openModal("pk")},500),this.currentMap==="farm"){const i=document.createElement("div");i.id="farm-bubbles-container",i.style.position="absolute",i.style.top="0",i.style.left="0",i.style.width="100%",i.style.height="100%",i.style.pointerEvents="none",i.style.zIndex="10",document.body.appendChild(i)}window.addEventListener("kick-sound",()=>{this.updateTaskProgress("kick",1)}),this.currentMap==="house"&&(typeof this.renderHomeFurnitures=="function"&&this.renderHomeFurnitures(),this.initExitChoicesUI()),window.addEventListener("keydown",i=>{if(i.target.tagName==="INPUT"||i.target.tagName==="TEXTAREA")return;const s=i.key.toLowerCase();s==="b"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.bag.classList.contains("open")?this.modalMgr.closeModal("bag"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("bag")))):s==="j"?(i.preventDefault(),this.currentMap==="farm"?this.isRadialMenuOpen?this.closeRadialSeedMenu():this.openRadialSeedMenu():this.modalMgr&&(this.modalMgr.modals.tasks.classList.contains("open")?this.modalMgr.closeModal("tasks"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("tasks")))):s==="p"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.leaderboard.classList.contains("open")?this.modalMgr.closeModal("leaderboard"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("leaderboard")))):s==="m"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.map.classList.contains("open")?this.modalMgr.closeModal("map"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("map")))):s==="g"&&(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.shop.classList.contains("open")?this.modalMgr.closeModal("shop"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("shop"))))})}initLeaderboardUI(){const t=document.querySelectorAll("#modal-leaderboard .tab-btn");t.forEach(e=>{e.addEventListener("click",n=>{t.forEach(i=>i.classList.remove("active")),e.classList.add("active"),this.refreshLeaderboard(e.getAttribute("data-tab"))})})}getMockLeaderboard(t){const e=["浮云行者","琴海微风","金色沙滩","椰子冰沙","派蒙小跟班","晨曦守护","月见草","落樱纷飞","温馨秋千","大锤王二"],n=[];let i=t==="pkPoints"?1e3:t==="coins"?200:1,s=t==="pkPoints"?60:t==="coins"?50:2;for(let h=0;h<9;h++)n.push({username:e[h],avatar:"",score:i+(9-h)*s});let a=this.gameData.pkPoints;t==="coins"&&(a=this.gameData.coins),t==="level"&&(a=this.gameData.level);const r=localStorage.getItem("sso_user");let c="您自己",l="";if(r)try{const h=JSON.parse(r);c=h.username,l=h.avatar}catch{}return n.push({username:c,avatar:l,score:a,isMe:!0}),n.sort((h,d)=>d.score-h.score),n.slice(0,10)}async refreshLeaderboard(t="pkPoints"){const e=document.getElementById("leaderboard-list-view"),n=document.getElementById("leaderboard-my-rank");if(!e)return;e.innerHTML='<div style="text-align:center; padding: 20px; font-size: 0.85rem; color: var(--text-muted);">数据加载中...</div>';const i=localStorage.getItem("sso_access_token"),s=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";let a=[],r=!1;if(i)try{const f=await fetch(`${s}/api/game/leaderboard?game_id=${t}`).then(g=>g.json());f.success&&f.leaderboard&&f.leaderboard.length>0&&(a=f.leaderboard,r=!0)}catch(f){console.error("加载服务端排行榜失败",f)}r||(a=this.getMockLeaderboard(t)),e.innerHTML="";const c=localStorage.getItem("sso_user");let l="您自己";if(c)try{l=JSON.parse(c).username}catch{}a.forEach((f,g)=>{const y=f.username===l||f.isMe,m=document.createElement("div");m.className=`leaderboard-item rank-${g+1}`,y&&(m.style.background="rgba(255, 140, 105, 0.15)",m.style.borderColor="rgba(255, 140, 105, 0.3)");const p=f.avatar||'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E',_=t==="pkPoints"?" 积分":t==="coins"?" 金币":" 级";m.innerHTML=`
        <div class="leaderboard-rank" style="font-weight: bold; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%;">${g+1}</div>
        <img class="leaderboard-avatar" src="${p}" alt="头像" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1.5px solid rgba(255,255,255,0.2);">
        <div class="leaderboard-name" style="flex: 1; margin-left: 10px; font-size: 0.9rem; font-weight: 600;">${f.username}</div>
        <div class="leaderboard-score" style="font-size: 0.95rem; font-weight: bold; color: var(--primary);">${f.score}${_}</div>
      `,e.appendChild(m)});let h=this.gameData.pkPoints;t==="coins"&&(h=this.gameData.coins),t==="level"&&(h=this.gameData.level);let d="未上榜";const u=a.findIndex(f=>f.username===l||f.isMe);u!==-1&&(d=`第 ${u+1} 名`),n&&(n.innerHTML=`
        <span>当前名次: <strong style="color: var(--primary);">${d}</strong></span>
        <span style="margin-left: 20px;">我的数值: <strong style="color: var(--secondary);">${h}</strong></span>
      `)}initTasksUI(){const t=document.getElementById("btn-tasks-claim-chest"),e=document.getElementById("tasks-chest-btn"),n=i=>{if(i.stopPropagation(),this.gameData.tasks.filter(a=>a.progress>=a.target).length===5&&!this.gameData.dailyChestClaimed){this.gameData.dailyChestClaimed=!0,this.gameData.coins+=300,this.showCoinFloatText(300,i.clientX,i.clientY),this.gameData.exp+=100;let a=!1;this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,a=!0),this.saveGameData(),this.updateBaseUI(),this.refreshTasks(),a?setTimeout(()=>{this.playCustomSound(523.25,.4,"triangle",.1),this.showToast("恭喜升级啦！✨ 等级提升！")},300):(this.playCustomSound(880,.1,"sine",.05),setTimeout(()=>this.playCustomSound(1200,.2,"sine",.05),100))}};t&&t.addEventListener("click",n),e&&e.addEventListener("click",n)}updateTaskProgress(t,e=1){let n=!1;this.gameData.tasks.forEach(i=>{i.type===t&&i.status==="ongoing"&&(i.progress=Math.min(i.target,i.progress+e),i.progress>=i.target&&(i.status="claimable"),n=!0)}),n&&this.saveGameData()}refreshTasks(){const t=document.getElementById("tasks-list");if(!t)return;t.innerHTML="";const e=this.gameData.tasks.filter(c=>c.progress>=c.target).length,n=document.getElementById("tasks-progress-text"),i=document.getElementById("tasks-progress-bar"),s=document.getElementById("tasks-chest-btn"),a=document.getElementById("tasks-chest-tips"),r=document.getElementById("btn-tasks-claim-chest");n&&(n.textContent=`${e} / 5`),i&&(i.style.width=`${e/5*100}%`),this.gameData.dailyChestClaimed?(s&&(s.textContent="📦",s.style.animation="none",s.style.cursor="default"),a&&(a.innerHTML='<span style="color: #4caf50; font-weight: bold;">每日宝箱奖励已领取！📯</span><br><span style="font-size: 0.68rem;">获得了 300金币 + 100经验。明天再来吧！🌟</span>'),r&&(r.textContent="已领取",r.disabled=!0,r.style.background="rgba(255,255,255,0.08)",r.style.color="var(--text-muted)",r.style.borderColor="transparent")):e===5?(s&&(s.textContent="🎁",s.style.animation="chestBounce 1.2s infinite alternate ease-in-out",s.style.cursor="pointer"),a&&(a.innerHTML='<span style="color: #ffd700; font-weight: bold;">今日任务已全部达成！✨</span><br><span style="font-size: 0.68rem; color: #fff;">快点击宝箱或下方按钮领取额外大奖！</span>'),r&&(r.textContent="开启宝箱",r.disabled=!1,r.style.background="linear-gradient(135deg, #ffd700 0%, #ff9800 100%)",r.style.color="#000",r.style.borderColor="#ffd700")):(s&&(s.textContent="🎁",s.style.animation="none",s.style.cursor="default"),a&&(a.textContent="完成今日全部 5 个任务即可开启宝箱，获得 300 金币与 100 经验！"),r&&(r.textContent="未达成",r.disabled=!0,r.style.background="rgba(255,255,255,0.04)",r.style.color="var(--text-muted)",r.style.borderColor="transparent")),this.gameData.tasks.forEach(c=>{const l=document.createElement("div");l.className=`task-card-item ${c.status==="claimed"?"task-completed":""}`;let h="";c.status==="ongoing"?h=`<button class="task-btn-action" data-action="go" data-type="${c.type}">去完成</button>`:c.status==="claimable"?h=`<button class="task-btn-action task-btn-claim" data-action="claim" data-id="${c.id}">领取奖励</button>`:h='<button class="task-btn-action task-btn-done">已领取</button>';const d=Math.min(100,Math.floor(c.progress/c.target*100));l.innerHTML=`
        <div class="task-meta">
          <span class="task-title">${c.name}</span>
          <span class="task-reward">🎁 +${c.reward}金币</span>
        </div>
        <div class="task-progress-wrap" style="margin-top: 10px;">
          <div class="task-progress-bar">
            <div class="task-progress-fill" style="width: ${d}%;"></div>
          </div>
          <span class="task-progress-text">${c.progress}/${c.target}</span>
          ${h}
        </div>
      `;const u=l.querySelector(".task-btn-claim");u&&u.addEventListener("click",g=>{g.stopPropagation(),this.claimTaskReward(c.id,g.clientX,g.clientY)});const f=l.querySelector('.task-btn-action[data-action="go"]');f&&f.addEventListener("click",g=>{if(g.stopPropagation(),this.modalMgr.closeAllModals(),c.type==="game_billiards"){const y=$n.games.find(m=>m.id==="billiards");y&&this.modalMgr.launchGame(y),this.updateTaskProgress("game_billiards",1)}else if(c.type==="game_poker"){const y=$n.games.find(m=>m.id==="21dian");y&&this.modalMgr.launchGame(y),this.updateTaskProgress("game_poker",1)}else c.type==="kick"?this.switchMap("island",new P(-5,.7,5)):c.type==="rest"?this.switchMap("house",new P(2.8,.22,4)):c.type==="harvest"&&this.switchMap("farm",new P(0,.7,-8))}),t.appendChild(l)})}claimTaskReward(t,e,n){const i=this.gameData.tasks.find(s=>s.id===t);!i||i.status!=="claimable"||(i.status="claimed",this.gameData.coins+=i.reward,this.saveGameData(),this.showCoinFloatText(i.reward,e,n),this.refreshTasks())}showCoinFloatText(t,e,n){const i=document.createElement("div");i.className="coin-float-text";const s=e!==void 0?e:window.innerWidth/2,a=n!==void 0?n:window.innerHeight/2;i.style.left=`${s}px`,i.style.top=`${a}px`;const r=t>0;i.innerHTML=`${r?"+":""}${t} <span style="font-size: 1.1em; margin-left: 2px;">🪙</span>`,i.style.color=r?"#ffd700":"#ff8a80",i.style.textShadow=r?"0 0 10px rgba(255,215,0,0.6)":"0 0 10px rgba(255,138,128,0.6)",document.body.appendChild(i),r?(this.playCustomSound(987.77,.08,"square",.03),setTimeout(()=>this.playCustomSound(1318.51,.25,"square",.03),80)):this.playCustomSound(329.63,.15,"sawtooth",.04),setTimeout(()=>{i.remove()},1e3)}showToast(t){let e=document.querySelector(".mock-toast");e&&e.remove();const n=document.createElement("div");n.className="mock-toast",n.textContent=t,document.body.appendChild(n),setTimeout(()=>{n.classList.add("show")},50),setTimeout(()=>{n.classList.remove("show"),setTimeout(()=>n.remove(),300)},2200)}triggerPlotInteraction(t){const e=this.gameData.farmPlots[t];if(e)if(e.status==="empty")this.activePlotIndex=t,this.openRadialSeedMenu();else if(e.status==="ready")this.harvestCrop(t);else{const n=e.seedId==="sunflower_seed"?30:60,i=Math.floor((Date.now()-e.plantTime)/1e3),s=Math.max(0,n-i),a=e.seedId==="sunflower_seed"?"向日葵":"草莓";this.showToast(`${a} 正在生长中，还需等待 ${s} 秒 ⏳`)}}initFarmUI(){this.refreshFarm()}refreshFarm(){const t=document.getElementById("farm-grid");t&&(t.innerHTML="",this.gameData.farmPlots.forEach((e,n)=>{const i=document.createElement("div");if(i.className="farm-plot",!e.unlocked)i.classList.add("locked"),i.innerHTML=`
          <div style="font-size: 1.5rem; opacity: 0.4;">🔒</div>
          <span style="font-size: 0.65rem; color: #ff8a80; margin-top: 4px;">未解锁</span>
        `;else if(e.status==="empty")i.innerHTML=`
          <div style="font-size: 1.8rem; color: #2ecc71;">➕</div>
          <span style="font-size: 0.72rem; color: var(--text-muted); margin-top: 4px;">空地</span>
        `,i.addEventListener("click",()=>{this.activePlotIndex=n,this.openRadialSeedMenu()});else{const s=e.status==="ready",a=e.seedId==="sunflower_seed"?"🌻":"🍓",r=e.seedId==="sunflower_seed"?"向日葵":"草莓";let c="";if(s)c='<span class="plot-crop-ready">🌾 可收割</span>';else{const l=e.seedId==="sunflower_seed"?30:60,h=Math.floor((Date.now()-e.plantTime)/1e3);c=`<span class="plot-crop-timer">⏳ ${Math.max(0,l-h)}s</span>`}i.innerHTML=`
          <span class="plot-crop-icon">${a}</span>
          <span class="plot-crop-name">${r}</span>
          ${c}
        `,s&&i.addEventListener("click",()=>{this.harvestCrop(n)})}t.appendChild(i)}))}buyAndPlant(t){const e=t==="sunflower_seed"?10:20;if(this.gameData.coins<e){alert("金币不足，无法购买种子！");return}this.gameData.coins-=e;const n=this.gameData.farmPlots[this.activePlotIndex];n.status="growing",n.seedId=t,n.plantTime=Date.now(),this.saveGameData(),document.getElementById("sub-modal-seed-shop").style.display="none",this.player&&(this.player.controlsLocked=!1),this.refreshFarm(),this.playCustomSound(330,.25,"sine",.1),this.recreateCrop3D(this.activePlotIndex);const i=t==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功播种了 ${i} 种子 🌱`)}harvestCrop(t){const e=this.gameData.farmPlots[t];if(!e||e.status!=="ready")return;const n=e.seedId==="sunflower_seed"?"sunflower_crop":"strawberry_crop",i=e.seedId==="sunflower_seed"?"新鲜向日葵":"多汁草莓",s=e.seedId,a=e.seedId==="sunflower_seed"?15:35;e.status="empty",e.seedId=null,e.plantTime=0;const r=this.gameData.backpack.find(l=>l.id===n);r?r.count++:this.gameData.backpack.push({id:n,name:i,type:"collect",count:1,quality:s==="sunflower_seed"?"green":"blue",desc:"在自家农田收获的优质作物，可直接在背包中出售以换取游戏币。"}),this.gameData.exp+=a,this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,this.playCustomSound(523.25,.4,"triangle",.1)),this.saveGameData(),this.refreshFarm(),this.updateTaskProgress("harvest",1),this.playCustomSound(440,.2,"sine",.1),this.recreateCrop3D(t);const c=s==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功收割了 ${c} 🌾！已存入背包`)}recreateCrop3D(t){if(!this.farmPlots3D)return;const e=this.farmPlots3D[t];if(!e)return;e.plantGroup.clear();const n=this.gameData.farmPlots[t];if(n.status==="empty"||!n.seedId)return;const i=new lt;if(n.seedId==="sunflower_seed"){const a=new J(.04,.04,.7,6),r=new H({color:3046706}),c=new x(a,r);c.position.y=.35,c.castShadow=!0,i.add(c);const l=new J(.2,.2,.06,8),h=new H({color:16771899}),d=new x(l,h);d.position.set(0,.7,.05),d.rotation.x=Math.PI/4,i.add(d);const u=new J(.1,.1,.08,8),f=new H({color:6111287}),g=new x(u,f);g.position.set(0,.72,.07),g.rotation.x=Math.PI/4,i.add(g)}else{const a=new O(.25,.04,.25),r=new H({color:2600544}),c=new x(a,r);c.position.y=.04,i.add(c);const l=new re(.18,.35,6),h=new H({color:16717636}),d=new x(l,h);d.rotation.x=Math.PI,d.position.y=.25,d.castShadow=!0,i.add(d)}e.plantGroup.add(i),n.status==="ready"?e.plantGroup.scale.set(1,1,1):e.plantGroup.scale.set(.15,.15,.15)}initPKUI(){const t=document.getElementById("btn-pk-match");t&&t.addEventListener("click",s=>{s.stopPropagation(),this.triggerPKMatching()});const e=document.getElementById("btn-cancel-match");e&&e.addEventListener("click",s=>{s.stopPropagation(),this.cancelPKMatching()});const n=document.getElementById("btn-create-room");n&&n.addEventListener("click",s=>{s.stopPropagation(),alert("正在努力创建房间中... 暂无其他联机对手，已为您指派了机器人。"),this.modalMgr.closeAllModals(),this.triggerPKMatching()});const i=document.getElementById("btn-pk-attack");i&&(i.addEventListener("touchstart",s=>{s.preventDefault(),s.stopPropagation(),this.playerPerformAttack()},{passive:!1}),i.addEventListener("click",s=>{s.stopPropagation(),this.playerPerformAttack()})),window.addEventListener("keydown",s=>{s.key.toLowerCase()==="j"&&this.playerPerformAttack()}),window.addEventListener("mousedown",s=>{if(s.button===0&&this.isPKActive){const a=s.target.tagName.toLowerCase();if(a==="button"||a==="a"||s.target.closest(".sidebar-container")||s.target.closest(".modal-card")||s.target.closest(".pk-hud")||s.target.closest(".action-buttons"))return;this.playerPerformAttack()}})}refreshPK(){const t=document.getElementById("pk-points-val"),e=document.getElementById("pk-rank-badge"),n=document.getElementById("pk-win-rate"),i=document.getElementById("pk-total-battles");t&&(t.textContent=this.gameData.pkPoints);const s=this.gameData.pkPoints;let a="🥉 皇家青铜";s>=1200&&s<1500&&(a="🥈 璀璨白银"),s>=1500&&s<1800&&(a="🥇 荣耀黄金"),s>=1800&&(a="👑 傲世战神"),e&&(e.textContent=a);const r=this.gameData.pkWins+this.gameData.pkLoses;if(i&&(i.textContent=r),n){const l=r>0?Math.floor(this.gameData.pkWins/r*100):0;n.textContent=`${l}%`}const c=document.getElementById("room-list");c&&(c.innerHTML=`
        <div class="room-card">
          <span>🎮 浮空挑战赛房 #102</span>
          <span style="color: #2ecc71;">在线匹配中...</span>
        </div>
        <div class="room-card">
          <span>🤖 人机搏击训练室 #001</span>
          <span style="color: var(--primary);">常驻训练</span>
        </div>
      `)}triggerPKMatching(){const t=document.getElementById("radar-overlay");if(!t)return;t.style.display="flex",this.modalMgr.closeAllModals(),this.radarTimerVal=0;const e=document.getElementById("radar-timer");e&&(e.textContent="0"),this.matchingInterval=setInterval(()=>{this.radarTimerVal++,e&&(e.textContent=this.radarTimerVal),this.radarTimerVal>=3&&(this.cancelPKMatching(),this.startPKMatch(!0))},1e3)}cancelPKMatching(){this.matchingInterval&&(clearInterval(this.matchingInterval),this.matchingInterval=null);const t=document.getElementById("radar-overlay");t&&(t.style.display="none")}startPKMatch(t=!0){if(this.currentMap!=="pk_arena"){this.switchMap("pk_arena");return}(this.isHomeBuildActive||document.getElementById("home-edit-hud")&&document.getElementById("home-edit-hud").style.display==="flex")&&this.exitHomeEditMode(!1),this.isPKActive=!0,this.pkOpponentType=t?"robot":"player",(!this.pkArenaColliders||this.pkArenaColliders.length===0)&&this.buildPKPlatform(),this.player&&(this.player.colliders=this.pkArenaColliders||[]),this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!1),this.interactMgr.generator={interactables:[]},document.getElementById("pk-hud").style.display="flex",this.playerHP=100,this.opponentHP=100,this.updatePKHPUI(),this.playerEquippedWeapon=null,this.playerWeapon3D&&(this.player.group.remove(this.playerWeapon3D),this.playerWeapon3D=null),this.activeBombs=[],this.activeExplosions=[],this.bombCooldownActive=!1;const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");e&&(e.style.display="none");const n=document.getElementById("pk-debug-info");if(n&&(n.style.display="block",n.textContent="准备战斗，请先走向擂台周边的武器架拾取武器..."),t){this.opponent3D&&(this.pkArenaGroup.remove(this.opponent3D),this.opponent3D=null);const i=new lt,s=new x(new O(.4,.4,.4),new H({color:15158332}));s.position.y=1.35,i.add(s);const a=new x(new O(.5,.7,.3),new H({color:2899536}));a.position.y=.8,i.add(a);const r=new J(.08,.08,.45,8),c=new x(r,new H({color:3426654}));c.position.set(-.16,.225,0),i.add(c);const l=c.clone();l.position.x=.16,i.add(l),i.position.set(5.5,.6,0),this.pkArenaGroup.add(i),this.opponent3D=i,this.opponentVelocity=new P(0,0,0),this.opponentIsGrounded=!0,this.opponentEquippedWeapon="sword";const h=this.createSword3D();h.position.set(.35,.8,.1),h.rotation.x=Math.PI/2,this.opponent3D.add(h),this.opponentWeapon3D=h}}updatePKHPUI(){const t=document.getElementById("pk-hud-p1-hp"),e=document.getElementById("pk-hud-p2-hp"),n=document.getElementById("pk-hud-p1-hp-text"),i=document.getElementById("pk-hud-p2-hp-text");t&&(t.style.width=`${this.playerHP}%`),e&&(e.style.width=`${this.opponentHP}%`),n&&(n.textContent=`${this.playerHP} / 100`),i&&(i.textContent=`${this.opponentHP} / 100`)}playDamageBubble(t,e,n=!1){const i=document.createElement("div");i.className="damage-bubble",n?(i.style.color="#ff1744",i.textContent=`-${e} HP`):(i.style.color="#ffeb3b",i.textContent=`-${e}`),document.body.appendChild(i),(()=>{if(!this.camera||!i.parentElement)return;const a=t.clone().add(new P(0,n?1:1.3,0));a.project(this.camera);const r=(a.x*.5+.5)*window.innerWidth,c=(-(a.y*.5)+.5)*window.innerHeight;i.style.left=`${r}px`,i.style.top=`${c}px`})(),setTimeout(()=>{i.classList.add("fade-up")},30),setTimeout(()=>{i.remove()},750)}showScreenFlash(){let t=document.getElementById("player-hurt-flash");t||(t=document.createElement("div"),t.id="player-hurt-flash",document.body.appendChild(t)),t.style.opacity="1",setTimeout(()=>{t.style.opacity="0"},120)}playerPerformAttack(){if(!(!this.isPKActive||this.playerHP<=0||!this.playerEquippedWeapon))if(this.playerEquippedWeapon==="bomb"){if(this.bombCooldownActive){if(this.playCustomSound(150,.1,"sine",.1),window.showMockToast){let t=document.querySelector(".mock-toast");t&&t.remove();const e=document.createElement("div");e.className="mock-toast",e.textContent="炸弹正在冷却中！💣",document.body.appendChild(e),setTimeout(()=>e.classList.add("show"),50),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>e.remove(),300)},1200)}return}this.triggerBombCooldown(),this.throwBomb()}else this.playerWeapon3D&&(this.playerWeapon3D.rotation.z=-Math.PI/2,setTimeout(()=>{this.playerWeapon3D&&(this.playerWeapon3D.rotation.z=0)},150)),this.playCustomSound(260,.1,"triangle",.15),this.performMeleeAttack()}performMeleeAttack(){const t=this.player.position,e=this.opponent3D.position,n=t.x-e.x,i=t.z-e.z,s=Math.sqrt(n*n+i*i);if(console.log(`[PK Damage Check] Player: (${t.x.toFixed(2)}, ${t.z.toFixed(2)}), Robot: (${e.x.toFixed(2)}, ${e.z.toFixed(2)}), Plane Distance: ${s.toFixed(2)}`),s<=4.5){let a=20,r=1.8;this.playerEquippedWeapon==="sword"?(a=20,r=2):this.playerEquippedWeapon==="hammer"&&(a=10,r=7.5),this.opponentHP=Math.max(0,this.opponentHP-a),this.updatePKHPUI(),this.playDamageBubble(e,a,!1),this.opponent3D&&(this.opponent3D.traverse(l=>{l.isMesh&&l.material&&(l.userData.origColor===void 0&&(l.userData.origColor=l.material.color.getHex()),l.material.color.setHex(16724787))}),setTimeout(()=>{this.opponent3D&&this.opponent3D.traverse(l=>{l.isMesh&&l.material&&l.userData.origColor!==void 0&&l.material.color.setHex(l.userData.origColor)})},150));const c=new P().subVectors(e,t).normalize();c.y=.4,this.opponentVelocity.addScaledVector(c,r*2.8),this.playCustomSound(120,.15,"sawtooth",.1),this.opponentHP<=0&&this.endPKBattle(!0)}else{console.log(`[PK Damage Check] MISS - Distance ${s.toFixed(2)}m is greater than 4.5m`);const a=document.getElementById("pk-debug-info");if(a){const r=document.createElement("span");r.style.color="#ff5722",r.style.fontWeight="bold",r.style.marginLeft="10px",r.textContent="[MISS - 距离过远]",a.appendChild(r),setTimeout(()=>r.remove(),1200)}}}triggerBombCooldown(){this.bombCooldownActive=!0;let t=5;const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack"),n=()=>{e&&(e.disabled=!0,e.style.opacity="0.5",e.innerHTML=`<span style="font-size: 1.1rem; font-weight: bold; color: #ffeb3b; font-family: system-ui; display: flex; align-items: center; justify-content: center;">💣 ${t}s</span>`)};n();const i=setInterval(()=>{if(this.playerEquippedWeapon!=="bomb"){clearInterval(i),this.bombCooldownActive=!1,e&&(e.disabled=!1,e.style.opacity="1");return}t--,t<=0?(clearInterval(i),this.bombCooldownActive=!1,this.playerEquippedWeapon==="bomb"&&this.playerWeapon3D&&(this.playerWeapon3D.visible=!0),e&&(e.disabled=!1,e.style.opacity="1",e.innerHTML=`
<svg style="display: flex;" class="lucide lucide-bomb" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="11" cy="13" r="9" />
  <path d="m19.5 4.5-3.5 3.5" />
  <path d="m21 3-2.5 2.5" />
  <path d="M19 8.5c.5-.5 1-1.5.5-2.5-.5-.5-1.5 0-2 .5" />
</svg>`)):n()},1e3)}throwBomb(){if(!this.player)return;this.playCustomSound(350,.1,"sine",.1),this.playerWeapon3D&&(this.playerWeapon3D.visible=!1);const t=new P(0,0,1).applyQuaternion(this.player.group.quaternion).normalize(),e=this.createBomb3D(),n=this.player.position.clone().add(t.clone().multiplyScalar(.5));n.y+=1,e.position.copy(n),this.scene.add(e);const s=t.clone().multiplyScalar(9);s.y=4;const a={mesh:e,velocity:s,position:n,timeElapsed:0,maxLifetime:1.5};this.activeBombs||(this.activeBombs=[]),this.activeBombs.push(a)}updateActiveBombs(t){if(!this.activeBombs||this.activeBombs.length===0)return;const e=9.8,n=.6;for(let i=this.activeBombs.length-1;i>=0;i--){const s=this.activeBombs[i];s.timeElapsed+=t,s.velocity.y-=e*t,s.position.addScaledVector(s.velocity,t),s.mesh.position.copy(s.position),s.mesh.rotation.x+=.05,s.mesh.rotation.y+=.05;let a=!1;if(s.position.y<=n&&Math.sqrt(s.position.x*s.position.x+s.position.z*s.position.z)<8&&(s.position.y=n,a=!0),this.opponent3D&&!a){const r=this.opponent3D.position;s.position.distanceTo(r)<.8&&(a=!0)}s.timeElapsed>=s.maxLifetime&&(a=!0),a&&(this.explodeBomb(s.position),this.scene.remove(s.mesh),this.activeBombs.splice(i,1))}}explodeBomb(t){if(this.playCustomSound(180,.35,"sawtooth",.25),setTimeout(()=>{this.playCustomSound(60,.2,"sine",.3)},50),this.createExplosionEffects(t),this.opponent3D&&this.isPKActive){const e=this.opponent3D.position;if(t.distanceTo(e)<=3.5){const a=e.clone().sub(t);a.y=0,a.normalize(),this.opponentVelocity.addScaledVector(a,6),this.opponentVelocity.y=3.5,this.opponentIsGrounded=!1,this.opponentHP=Math.max(0,this.opponentHP-50),this.updatePKHPUI(),this.playDamageBubble(e,50,!1),this.opponent3D.traverse(c=>{c.isMesh&&c.material&&(c.userData.origColor===void 0&&(c.userData.origColor=c.material.color.getHex()),c.material.color.setHex(16724787))}),setTimeout(()=>{this.opponent3D&&this.opponent3D.traverse(c=>{c.isMesh&&c.material&&c.userData.origColor!==void 0&&c.material.color.setHex(c.userData.origColor)})},150),this.opponentHP<=0&&this.endPKBattle(!0)}}}createExplosionEffects(t){const e=new Lt(.2,8,8),n=new Mt({color:16754470,transparent:!0,opacity:.9,depthWrite:!1}),i=new x(e,n);i.position.copy(t),this.scene.add(i);const s={mesh:i,type:"ball",scaleSpeed:9,opacitySpeed:2.2,scale:1,opacity:.9};this.activeExplosions||(this.activeExplosions=[]),this.activeExplosions.push(s);const a=12,r=new O(.08,.08,.08),c=[16727296,16761095,7697781];for(let l=0;l<a;l++){const h=c[Math.floor(Math.random()*c.length)],d=new H({color:h,transparent:!0,opacity:.9,flatShading:!0}),u=new x(r,d);u.position.copy(t);const f=Math.random()*Math.PI*2,g=1.5+Math.random()*3.5,y=new P(Math.cos(f)*g,2.5+Math.random()*3,Math.sin(f)*g);this.scene.add(u);const m={mesh:u,type:"particle",velocity:y,opacity:.9,rotationSpeed:new P(Math.random()*10,Math.random()*10,Math.random()*10)};this.activeExplosions.push(m)}}updateExplosionEffects(t){if(!this.activeExplosions||this.activeExplosions.length===0)return;const e=9.8;for(let n=this.activeExplosions.length-1;n>=0;n--){const i=this.activeExplosions[n];i.type==="ball"?(i.scale+=i.scaleSpeed*t,i.opacity-=i.opacitySpeed*t,i.mesh.scale.set(i.scale,i.scale,i.scale),i.mesh.material.opacity=Math.max(0,i.opacity),i.opacity<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.activeExplosions.splice(n,1))):i.type==="particle"&&(i.velocity.y-=e*t,i.mesh.position.addScaledVector(i.velocity,t),i.mesh.rotation.x+=i.rotationSpeed.x*t,i.mesh.rotation.y+=i.rotationSpeed.y*t,i.mesh.rotation.z+=i.rotationSpeed.z*t,i.opacity-=1.8*t,i.mesh.material.opacity=Math.max(0,i.opacity),i.opacity<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.activeExplosions.splice(n,1)))}}endPKBattle(t=!0){if(!this.isPKActive)return;this.isPKActive=!1,this.player&&(this.player.position.set(0,.6+.1,-6),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position)),this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!0);const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");e&&(e.style.display="none");let n=t?20:-10;this.gameData.pkPoints+n<0&&(n=-this.gameData.pkPoints),this.gameData.pkPoints+=n,t?this.gameData.pkWins++:this.gameData.pkLoses++,this.saveGameData();const i=t?"🎉 荣耀胜利！":"💀 惜败对手",s=t?"成功击败挑战者，天梯积分 +20！":"不幸败于挑战者，天梯积分 -10。",a=document.createElement("div");a.style.position="fixed",a.style.inset="0",a.style.zIndex="500",a.style.background="rgba(15,17,21,0.85)",a.style.backdropFilter="blur(20px)",a.style.webkitBackdropFilter="blur(20px)",a.style.display="flex",a.style.alignItems="center",a.style.justifyContent="center",a.style.color="white",a.innerHTML=`
      <div class="modal-card settle-card">
        <h2 class="settle-title" style="color: ${t?"#d97706":"#e74c3c"};">${i}</h2>
        <p class="settle-desc">${s}</p>
        <div class="settle-score-box">
          <span>当前天梯积分: <strong class="settle-score-val">${this.gameData.pkPoints}</strong></span>
        </div>
        <div class="settle-buttons">
          <button class="hud-btn settle-btn-action" id="btn-settle-retry">继续挑战 ⚔️</button>
          <button class="hud-btn settle-btn-secondary" id="btn-settle-close">返回群岛 🏝️</button>
        </div>
      </div>
    `,document.body.appendChild(a),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalOpened=="function"&&window.parent.appShell.onModalOpened("pk_settle");const r=a.querySelector("#btn-settle-close");r&&r.addEventListener("click",()=>{a.remove(),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed("pk_settle"),this.switchMap("island"),document.getElementById("pk-hud").style.display="none",document.getElementById("pk-debug-info")&&(document.getElementById("pk-debug-info").style.display="none")});const c=a.querySelector("#btn-settle-retry");c&&c.addEventListener("click",()=>{a.remove(),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed("pk_settle"),this.startPKMatch(!0)})}initMapUI(){document.querySelectorAll("#modal-map .map-node").forEach(e=>{e.addEventListener("click",()=>{const n=e.getAttribute("data-map");n&&(this.playCustomSound(440,.08,"sine",.15),setTimeout(()=>{this.playCustomSound(554.37,.08,"sine",.15)},80),this.modalMgr&&this.modalMgr.closeModal("map"),this.switchMap(n))})})}initBagUI(){const t=document.querySelectorAll("#modal-bag .bag-tabactive");t.forEach(e=>{e.addEventListener("click",n=>{t.forEach(i=>i.classList.remove("active")),e.classList.add("active"),this.refreshBag(e.getAttribute("data-tab"))})})}refreshBag(t="seed"){this.updateBaseUI();const e=document.getElementById("bag-grid"),n=document.getElementById("bag-item-detail");if(!e||!n)return;e.innerHTML="";const i=this.gameData.backpack.filter(s=>s.type===t);for(let s=0;s<20;s++){const a=document.createElement("div");a.className="bag-item-box";const r=i[s];if(r&&r.count>0){const c=`q-${r.quality||"white"}`;a.classList.add(c);let l="📦";r.id.includes("seed")?l="🌱":r.id==="sunflower_crop"?l="🌻":r.id==="strawberry_crop"?l="🍓":r.id.includes("painting")?l="🖼️":r.id.includes("tree")?l="🎄":r.id.includes("sofa")?l="🛋️":r.id.includes("swing")&&(l="🎪"),a.innerHTML=`
          <span style="font-size: 1.8rem;">${l}</span>
          <span class="bag-item-count">${r.count}</span>
        `,a.addEventListener("click",()=>{document.querySelectorAll(".bag-item-box.active").forEach(h=>h.classList.remove("active")),a.classList.add("active"),this.showBagItemDetail(r)})}else a.innerHTML="";e.appendChild(a)}n.querySelector(".item-detail-empty").style.display="flex",n.querySelector(".item-detail-content").style.display="none"}showBagItemDetail(t){const e=document.getElementById("bag-item-detail"),n=e.querySelector(".item-detail-empty"),i=e.querySelector(".item-detail-content");n.style.display="none",i.style.display="flex";let s="📦";t.id.includes("seed")?s="🌱":t.id==="sunflower_crop"?s="🌻":t.id==="strawberry_crop"?s="🍓":t.id.includes("painting")?s="🖼️":t.id.includes("tree")?s="🎄":t.id.includes("sofa")?s="🛋️":t.id.includes("swing")&&(s="🎪");const a={white:"普普通通",green:"翠绿新生",blue:"蔚蓝奇迹",purple:"秘境紫光",gold:"傲视至尊"},r=`bq-${t.quality||"white"}`,c=a[t.quality||"white"];let l="出售",h=!1,d=10;t.id==="sunflower_crop"?(d=20,h=!1):t.id==="strawberry_crop"?(d=45,h=!1):t.id.includes("seed")?(h=!0,l="去农田种植"):(h=!0,l="摆放家具");const f=t.count>1?`
      <div class="bag-sell-range-container" style="display: flex; flex-direction: column; gap: 4px; width: 100%; margin-bottom: 6px; padding: 0 10px; box-sizing: border-box;">
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.72rem; color: var(--text-muted);">
          <span>选择出售数量</span>
          <span class="range-val" style="font-weight: bold; color: var(--primary);"><strong id="sell-count-label">1</strong> / ${t.count}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; width: 100%;">
          <button class="bag-range-btn" id="btn-range-minus">-</button>
          <input type="range" id="sell-count-range" min="1" max="${t.count}" value="1" style="flex: 1; height: 6px; background: rgba(0,0,0,0.1); border-radius: 4px; outline: none; cursor: pointer; accent-color: var(--primary);" />
          <button class="bag-range-btn" id="btn-range-plus">+</button>
        </div>
      </div>
    `:"";i.innerHTML=`
      <div style="font-size: 3.5rem; margin-top: 20px;">${s}</div>
      <h3 style="font-size: 1.1rem; font-weight: bold; color: white; margin-top: 10px;">${t.name}</h3>
      <span class="bag-right-quality-badge ${r}">${c}</span>
      <p style="font-size: 0.75rem; color: var(--text-muted); line-height: 1.4; padding: 0 10px; margin-top: 12px; flex-grow: 1;">${t.desc}</p>
      
      <div style="width: 100%; display: flex; flex-direction: column; gap: 10px; margin-top: auto;">
        ${f}
        ${h?`<button class="hud-btn" id="btn-bag-use" style="width: 100%; padding: 8px 0; background: rgba(100, 255, 100, 0.15); border-color: rgba(100,255,100,0.3); color: #fff;">${l}</button>`:""}
        <button class="hud-btn" id="btn-bag-sell" style="width: 100%; padding: 8px 0; background: rgba(255, 140, 105, 0.1); border-color: rgba(255, 140, 105, 0.3); color: #fff;">出售 (获得 ${d}金币)</button>
      </div>
    `;const g=i.querySelector("#btn-bag-sell"),y=i.querySelector("#sell-count-range"),m=i.querySelector("#sell-count-label"),p=i.querySelector("#btn-range-minus"),_=i.querySelector("#btn-range-plus");let w=1;const v=T=>{w=Math.max(1,Math.min(t.count,T)),y&&(y.value=w),m&&(m.textContent=w),g&&(g.textContent=`出售 (获得 ${w*d}金币)`)};y&&y.addEventListener("input",T=>{v(parseInt(T.target.value)||1)}),p&&p.addEventListener("click",T=>{T.stopPropagation(),v(w-1)}),_&&_.addEventListener("click",T=>{T.stopPropagation(),v(w+1)}),g&&g.addEventListener("click",T=>{T.stopPropagation(),this.sellBagItem(t.id,d,w,T.clientX,T.clientY)});const R=i.querySelector("#btn-bag-use");R&&R.addEventListener("click",T=>{T.stopPropagation(),this.modalMgr.closeAllModals(),t.id.includes("seed")?this.switchMap("farm",new P(0,.7,-8)):this.switchMap("house",null,"home")})}sellBagItem(t,e,n,i,s){const a=this.gameData.backpack.find(c=>c.id===t);if(!a||a.count<n)return;a.count-=n;const r=e*n;this.gameData.coins+=r,this.saveGameData(),this.showCoinFloatText(r,i,s),this.refreshBag(document.querySelector("#modal-bag .bag-tabactive.active").getAttribute("data-tab"))}initHomeUI(){const t=document.getElementById("btn-enter-edit-mode");t&&t.addEventListener("click",s=>{s.stopPropagation(),this.modalMgr.closeAllModals(),this.enterHomeEditMode()});const e=document.getElementById("btn-edit-cancel");e&&e.addEventListener("click",s=>{s.stopPropagation(),this.exitHomeEditMode(!1)});const n=document.getElementById("btn-edit-save");n&&n.addEventListener("click",s=>{s.stopPropagation(),this.exitHomeEditMode(!0)});const i=document.getElementById("btn-edit-rotate");i&&i.addEventListener("click",s=>{s.stopPropagation(),this.rotateEditFurniture()}),window.addEventListener("keydown",s=>{s.key.toLowerCase()==="r"&&this.rotateEditFurniture()})}initExitChoicesUI(){document.querySelectorAll(".exit-choice-btn").forEach(e=>{e.addEventListener("click",n=>{n.stopPropagation();const i=e.getAttribute("data-target");this.modalMgr.closeModal("exit"),i==="island"?this.switchMap("island"):i==="farm"?this.switchMap("farm"):i==="pk"&&this.switchMap("pk_arena")})})}refreshHome(){const t=document.getElementById("furniture-shop-grid");if(!t)return;t.innerHTML="",[{id:"painting_1",type:"painting",name:"浮空岛日落挂画",price:50,emoji:"🖼️"},{id:"tree_1",type:"christmas_tree",name:"闪烁圣诞树",price:100,emoji:"🎄"},{id:"sofa_1",type:"rabbit_sofa",name:"粉嫩兔子沙发",price:150,emoji:"🛋️"},{id:"swing_1",type:"swing_chair",name:"室内网兜秋千",price:200,emoji:"🎪"}].forEach(n=>{const i=document.createElement("div");i.className="furniture-shop-card";const s=this.gameData.ownedFurnitures.includes(n.id);let a="";s?a=`<button class="hud-btn" data-action="place" data-id="${n.id}" style="width: 100%; font-size: 0.75rem; background: rgba(100, 255, 100, 0.15); border-color: rgba(100,255,100,0.3);">摆放家具</button>`:a=`<button class="hud-btn" data-action="buy" data-id="${n.id}" style="width: 100%; font-size: 0.75rem;">购买 (${n.price}金币)</button>`,i.innerHTML=`
        <div style="font-size: 2.2rem;">${n.emoji}</div>
        <div style="font-size: 0.8rem; font-weight: bold; color: #fff;">${n.name}</div>
        ${a}
      `;const r=i.querySelector('button[data-action="buy"]');r&&r.addEventListener("click",l=>{l.stopPropagation(),this.buyFurniture(n,l.clientX,l.clientY)});const c=i.querySelector('button[data-action="place"]');c&&c.addEventListener("click",l=>{l.stopPropagation(),this.modalMgr.closeAllModals(),this.startPlacingFurniture(n.type,n.id)}),t.appendChild(i)})}buyFurniture(t,e,n){if(this.gameData.coins<t.price){alert("金币不足，无法购买该家具！");return}this.gameData.coins-=t.price,this.gameData.ownedFurnitures.push(t.id),this.gameData.backpack.push({id:t.id,name:t.name,type:"decor",count:1,quality:"purple",desc:"购买于家园工坊的精美家具模型。进入家园编辑模式即可随意定位摆放它！"}),this.saveGameData(),this.refreshHome(),this.showCoinFloatText(-t.price,e,n)}enterHomeEditMode(){if(this.currentMap!=="house"){this.switchMap("house",null,null,"edit");return}this.isHomeBuildActive=!0,this.player.controlsLocked=!0,this.player.resetInputs(),this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV,position:this.camera.position.clone()},this.player.cameraDistance=8.5,this.player.cameraAngleV=Math.PI/2.1,this.player.cameraAngleH=Math.PI,this.editGrid=new qm(12,24,5227511,4473924),this.editGrid.position.set(0,.13,5),this.scene.add(this.editGrid),document.getElementById("home-edit-hud").style.display="flex"}startPlacingFurniture(t,e){this.enterHomeEditMode(),this.pendingFurnitureId=e,this.pendingFurnitureType=t,this.editPreviewGroup=this.createFurnitureModel(t),this.editPreviewGroup.position.set(0,.12,5),this.editPreviewGroup.traverse(n=>{n.isMesh&&(n.material=n.material.clone(),n.material.transparent=!0,n.material.opacity=.55,n.material.color.setHex(5227511))}),this.scene.add(this.editPreviewGroup),this.editFurnitureRotationY=0}rotateEditFurniture(){!this.isHomeBuildActive||!this.editPreviewGroup||(this.editFurnitureRotationY+=Math.PI/2,this.editPreviewGroup.rotation.y=this.editFurnitureRotationY,this.playCustomSound(400,.08,"sine",.05))}exitHomeEditMode(t=!0){if(this.isHomeBuildActive){if(this.isHomeBuildActive=!1,this.cameraSavedState&&(this.player.cameraDistance=this.cameraSavedState.distance,this.player.cameraAngleH=this.cameraSavedState.angleH,this.player.cameraAngleV=this.cameraSavedState.angleV,this.player.controlsLocked=!1),this.editGrid&&(this.scene.remove(this.editGrid),this.editGrid=null),t&&this.editPreviewGroup&&this.pendingFurnitureId){const e=this.editPreviewGroup.position;this.gameData.homeFurnitures.push({id:this.pendingFurnitureId+"_"+Date.now(),type:this.pendingFurnitureType,x:e.x,y:e.y,z:e.z,ry:this.editFurnitureRotationY});const n=this.gameData.backpack.find(i=>i.id===this.pendingFurnitureId);n&&(n.count--,n.count<=0&&(this.gameData.backpack=this.gameData.backpack.filter(i=>i.id!==this.pendingFurnitureId))),this.saveGameData(),this.renderHomeFurnitures(),this.playCustomSound(494,.2,"sine",.1)}this.editPreviewGroup&&(this.scene.remove(this.editPreviewGroup),this.editPreviewGroup=null),this.pendingFurnitureId=null,this.pendingFurnitureType=null,document.getElementById("home-edit-hud").style.display="none"}}renderHomeFurnitures(){this.houseGen&&(this.houseGen.furnituresGroup||(this.houseGen.furnituresGroup=new lt,this.houseGen.group.add(this.houseGen.furnituresGroup)),this.houseGen.furnituresGroup.clear(),this.gameData.homeFurnitures.forEach(t=>{const e=this.createFurnitureModel(t.type);e.position.set(t.x,t.y,t.z),e.rotation.y=t.ry,this.houseGen.furnituresGroup.add(e)}))}updateGameSystemsFrame(t,e){if(this.updateActivePlotForRadialMenu(),this.updateFarmPlotsFrame(),this.updatePKBattleFrame(t),this.updateHomeBuildFrame(),this.updatePKHallAnimations(t,e),this.currentMap==="farm"&&this.player&&this.player.position.y<-3.5&&(this.player.position.set(0,.6+.1,-8),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),window.showMockToast)){let n=document.querySelector(".mock-toast");n&&n.remove();const i=document.createElement("div");i.className="mock-toast",i.textContent="小心！不要掉入农场外的浮空深渊哦 ☁️",document.body.appendChild(i),setTimeout(()=>i.classList.add("show"),50),setTimeout(()=>{i.classList.remove("show"),setTimeout(()=>i.remove(),300)},2e3)}}updatePKHallAnimations(t,e){if(this.currentMap==="pk_arena"&&(this.pkCrystalMesh&&this.pkCrystalMesh.visible&&(this.pkCrystalMesh.rotation.y+=.015,this.pkCrystalMesh.position.y=1.35+Math.sin(e*.002)*.12),this.swordPreview&&(this.swordPreview.rotation.y+=.015,this.swordPreview.position.y=1.45+Math.sin(e*.0025)*.06),this.hammerPreview&&(this.hammerPreview.rotation.y+=.015,this.hammerPreview.position.y=1.45+Math.cos(e*.0025)*.06),this.bombPreview&&(this.bombPreview.rotation.y+=.015,this.bombPreview.position.y=1.45+Math.sin(e*.0025+1)*.06),!this.isPKActive&&(this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!0),this.player&&this.player.position.y<-3.5&&(this.player.position.set(0,.6+.1,-6),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),window.showMockToast)))){let n=document.querySelector(".mock-toast");n&&n.remove();const i=document.createElement("div");i.className="mock-toast",i.textContent="小心！不要跌落入云海深渊哦 ☁️",document.body.appendChild(i),setTimeout(()=>i.classList.add("show"),50),setTimeout(()=>{i.classList.remove("show"),setTimeout(()=>i.remove(),300)},2200)}}updateFarmPlotsFrame(){const t=document.getElementById("farm-bubbles-container");if(!t)return;const e=this.farmPlots3D;if(!e||!this.gameData||this.currentMap!=="farm"){t.innerHTML="";return}this.gameData.farmPlots.forEach((n,i)=>{const s=e[i];if(s){if(n.status!=="empty"&&s.plantGroup.children.length===0&&this.recreateCrop3D(i),n.status==="growing"){const a=n.seedId==="sunflower_seed"?30:60,r=Math.floor((Date.now()-n.plantTime)/1e3);if(r>=a)n.status="ready",this.saveGameData(),this.refreshFarm(),this.recreateCrop3D(i);else{const l=.15+r/a*.85;s.plantGroup.scale.set(l,l,l)}}if(n.status!=="empty"&&n.seedId){let a=document.getElementById(`crop-bubble-${i}`);a||(a=document.createElement("div"),a.id=`crop-bubble-${i}`,a.className="farm-crop-bubble",t.appendChild(a));const r=n.seedId==="sunflower_seed"?30:60,c=Math.floor((Date.now()-n.plantTime)/1e3),l=Math.max(0,r-c);if(n.status==="ready")a.innerHTML="🌾 可收割",a.style.background="linear-gradient(135deg, #27ae60, #1e824c)",a.style.borderColor="rgba(255,255,255,0.3)";else{const f=n.seedId==="sunflower_seed"?"🌻":"🍓";a.innerHTML=`${f} ⏳ ${l}s`,a.style.background="rgba(15,17,21,0.85)",a.style.borderColor="rgba(255,255,255,0.12)"}const h=new P(s.x,1.3,s.z);h.project(this.camera);const d=(h.x*.5+.5)*window.innerWidth,u=(-(h.y*.5)+.5)*window.innerHeight;a.style.left=`${d}px`,a.style.top=`${u}px`,a.style.opacity="1"}else{const a=document.getElementById(`crop-bubble-${i}`);a&&a.remove()}}})}updatePKBattleFrame(t){if(this.updateActiveBombs(t),this.updateExplosionEffects(t),!this.isPKActive||!this.opponent3D)return;if(this.player.position.y<-3.5){this.endPKBattle(!1);return}if(this.opponent3D.position.y<-3.5){this.endPKBattle(!0);return}const e=this.opponent3D,n=this.player.position;if(this.opponentIsGrounded||(this.opponentVelocity.y-=9.8*t),e.position.addScaledVector(this.opponentVelocity,t),this.opponentVelocity.x*=.88,this.opponentVelocity.z*=.88,e.position.y<=.6?Math.sqrt(e.position.x*e.position.x+e.position.z*e.position.z)<8?(e.position.y=.6,this.opponentVelocity.y=0,this.opponentIsGrounded=!0):this.opponentIsGrounded=!1:this.opponentIsGrounded=!1,this.opponentIsGrounded&&this.playerHP>0){const r=e.position.distanceTo(n),c=n.x-e.position.x,l=n.z-e.position.z,h=Math.atan2(c,l);e.rotation.y=h,r>1.8?e.translateZ(2.4*t):Math.random()<.018&&this.opponentPerformAttack()}const i=document.getElementById("pk-debug-info");i&&(this.playerEquippedWeapon?i.style.display="none":(i.style.display="block",i.innerHTML='<span style="font-weight: bold; color: #ffeb3b; animation: settleBlink 1.2s infinite;">⚠️ 尚未装备武器！请走向擂台周边的武器架拾取武器 ⚔️</span>'));const s=this.player.position;[{x:-7.5,z:0,weapon:"sword"},{x:7.5,z:0,weapon:"hammer"},{x:0,z:6.8,weapon:"bomb"}].forEach(r=>{if(s.distanceTo(new P(r.x,.6,r.z))<1.6&&this.playerEquippedWeapon!==r.weapon){const l=r.weapon;this.playerEquippedWeapon=l;const h=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");if(h){h.style.display="flex";const u={sword:`
<svg style="display: flex;" class="lucide lucide-swords" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5" />
  <line x1="13" x2="19" y1="19" y2="13" />
  <line x1="16" x2="20" y1="16" y2="20" />
  <line x1="19" x2="21" y1="21" y2="19" />
  <polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5" />
  <line x1="5" x2="9" y1="14" y2="18" />
  <line x1="7" x2="4" y1="17" y2="20" />
  <line x1="3" x2="5" y1="19" y2="21" />
</svg>`,hammer:`
<svg style="display: flex;" class="lucide lucide-hammer" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m15 5 4 4" />
  <path d="M21.5 12H16c-.5 0-1-.5-1-1V4.5L9 9.5c-.5.5-.5 1.5 0 2l11 11c.5.5 1.5.5 2 0z" />
  <path d="m2.1 21.9 10.3-10.3" />
</svg>`,bomb:`
<svg style="display: flex;" class="lucide lucide-bomb" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="11" cy="13" r="9" />
  <path d="m19.5 4.5-3.5 3.5" />
  <path d="m21 3-2.5 2.5" />
  <path d="M19 8.5c.5-.5 1-1.5.5-2.5-.5-.5-1.5 0-2 .5" />
</svg>`};h.innerHTML=u[l]||u.sword}this.playerWeapon3D&&this.player.group.remove(this.playerWeapon3D);let d;if(l==="sword"?d=this.createSword3D():l==="hammer"?d=this.createHammer3D():d=this.createBomb3D(),d.position.set(.32,.8,.1),d.rotation.x=Math.PI/2,this.player.group.add(d),this.playerWeapon3D=d,this.playCustomSound(600,.15,"sine",.1),window.showMockToast){let u=document.querySelector(".mock-toast");u&&u.remove();const f=document.createElement("div");f.className="mock-toast";const g={sword:"长剑 ⚔️",hammer:"大锤 🔨",bomb:"炸弹 💣"};f.textContent=`已装备武器：${g[l]}！`,document.body.appendChild(f),setTimeout(()=>f.classList.add("show"),50),setTimeout(()=>{f.classList.remove("show"),setTimeout(()=>f.remove(),300)},1800)}}})}opponentPerformAttack(){if(this.opponentHP<=0||this.playerHP<=0)return;if(this.opponentWeapon3D&&(this.opponentWeapon3D.rotation.z=-Math.PI/2,setTimeout(()=>{this.opponentWeapon3D&&(this.opponentWeapon3D.rotation.z=0)},150)),this.playCustomSound(220,.1,"sawtooth",.1),this.opponent3D.position.distanceTo(this.player.position)<=2.2){this.playerHP=Math.max(0,this.playerHP-15),this.updatePKHPUI(),this.showScreenFlash(),this.playDamageBubble(this.player.position,15,!0);const n=new P().subVectors(this.player.position,this.opponent3D.position).normalize();n.y=.35,this.player.velocity.addScaledVector(n,4.2),this.playCustomSound(100,.2,"sine",.15),this.playerHP<=0&&this.endPKBattle(!1)}}updateHomeBuildFrame(){if(!this.isHomeBuildActive||!this.editPreviewGroup)return;const t=new ut(0,0),e=new Xm;e.setFromCamera(t,this.camera);const n=e.intersectObjects(this.scene.children,!0);let i=null;for(let s=0;s<n.length;s++){const a=n[s];if(a.point&&Math.abs(a.point.y-.12)<.2){i=a.point;break}}if(i){let s=Math.round(i.x*2)/2,a=Math.round(i.z*2)/2;s=Math.max(-4,Math.min(4,s)),a=Math.max(1,Math.min(9,a)),this.editPreviewGroup.position.set(s,.12,a)}}buildFarmPlatform(){this.farmGroup.clear();const t=new J(12,12.5,1.2,32),e=new H({color:5025616,flatShading:!0}),n=new x(t,e);n.position.y=0,n.receiveShadow=!0,n.castShadow=!0,this.farmGroup.add(n);const i=new J(12.5,12,1.5,32),s=new H({color:6111287,flatShading:!0}),a=new x(i,s);a.position.y=-1.35,this.farmGroup.add(a),this.farmPlots3D=[];const r=new H({color:4073251,flatShading:!0}),c=new H({color:7951688,flatShading:!0}),l=[{x:-3.6,z:-2.2},{x:0,z:-2.2},{x:3.6,z:-2.2},{x:-3.6,z:2.2},{x:0,z:2.2},{x:3.6,z:2.2}];l.forEach((y,m)=>{const p=new lt;p.position.set(y.x,.6,y.z);const _=new x(new O(2.4,.02,2.4),r);_.receiveShadow=!0,p.add(_);const w=new x(new O(2.6,.1,.1),c);w.position.set(0,.05,1.25),w.castShadow=!0,p.add(w);const v=w.clone();v.position.z=-1.25,p.add(v);const R=new x(new O(.1,.1,2.4),c);R.position.set(1.25,.05,0),R.castShadow=!0,p.add(R);const T=R.clone();T.position.x=-1.25,p.add(T);const E=new lt;E.position.set(0,0,0),p.add(E),this.farmGroup.add(p),this.farmPlots3D.push({x:y.x,z:y.z,plantGroup:E})});const h=new J(.12,.16,1,6),d=new H({color:5125166}),u=new Gi(.6),f=new H({color:1793568,flatShading:!0});[{x:-8,z:-8},{x:8,z:-8},{x:-8,z:8},{x:8,z:8}].forEach(y=>{const m=new lt;m.position.set(y.x,.6,y.z);const p=new x(h,d);p.position.y=.5,p.castShadow=!0,m.add(p);const _=new x(u,f);_.position.y=1.1,_.castShadow=!0,m.add(_),this.farmGroup.add(m)}),this.farmColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:12}],this.farmInteractables=l.map((y,m)=>({id:`farm_plot_${m}`,name:"农田格子",x:y.x,y:.6,z:y.z,triggerRadius:1.8}))}buildPKPlatform(){this.pkArenaGroup.clear();const t=new J(8,8.2,.4,32),e=new H({color:1779781,flatShading:!0,emissive:461593}),n=new x(t,e);n.position.y=.4,n.receiveShadow=!0,n.castShadow=!0,this.pkArenaGroup.add(n);const i=new Sn(8.02,.05,8,48);i.rotateX(Math.PI/2);const s=new Mt({color:2733814}),a=new x(i,s);a.position.y=.58,this.pkArenaGroup.add(a);const r=new Sn(8.1,.03,8,48);r.rotateX(Math.PI/2);const c=new Mt({color:15684432}),l=new x(r,c);l.position.y=.55,this.pkArenaGroup.add(l);const h=new Mt({color:58879,transparent:!0,opacity:.65}),d=new O(3.6,.01,.16),u=new x(d,h);u.position.set(0,.605,0),this.pkArenaGroup.add(u);const f=new O(.16,.01,3.6),g=new x(f,h);g.position.set(0,.605,0),this.pkArenaGroup.add(g);const y=new Sn(.6,.04,4,24);y.rotateX(Math.PI/2);const m=new x(y,h);m.position.set(0,.605,0),this.pkArenaGroup.add(m);const p=new H({color:7901340,flatShading:!0});for(let M=0;M<6;M++){const S=M*Math.PI/3,L=10.5,F=Math.cos(S)*L,Z=Math.sin(S)*L,I=new lt;I.position.set(F,.4,Z);const B=new J(.5,.6,.4,8),k=new x(B,p);k.position.y=.2,k.castShadow=!0,k.receiveShadow=!0,I.add(k);const Y=new J(.35,.35,3.8,8),$=new x(Y,p);$.position.y=2.1,$.castShadow=!0,$.receiveShadow=!0,I.add($);const q=new J(.5,.4,.3,8),Q=new x(q,p);Q.position.y=4.15,Q.castShadow=!0,I.add(Q);const it=new Xs(.25),rt=new x(it,new Mt({color:M%2===0?2733814:15684432,transparent:!0,opacity:.95}));rt.position.y=4.65,I.add(rt),this.pkArenaGroup.add(I)}const _=new H({color:16777215,flatShading:!0,transparent:!0,opacity:.88});for(let M=0;M<8;M++){const S=M*Math.PI/4+Math.random()*.2,L=21+Math.random()*5,F=Math.cos(S)*L,Z=Math.sin(S)*L,I=-2.5-Math.random()*2,B=new lt;B.position.set(F,I,Z);const k=3+Math.floor(Math.random()*4);for(let Y=0;Y<k;Y++){const $=2.5+Math.random()*3.5,q=new Lt($,6,6),Q=new x(q,_);Q.position.set((Math.random()-.5)*$*1.6,(Math.random()-.5)*$*.6,(Math.random()-.5)*$*1.6),B.add(Q)}this.pkArenaGroup.add(B)}const w=new H({color:4545124,flatShading:!0});for(let M=0;M<10;M++){const S=Math.random()*Math.PI*2,L=9.5+Math.random()*4,F=Math.cos(S)*L,Z=Math.sin(S)*L,I=.2+Math.random()*2.2,B=new Gi(.25+Math.random()*.45),k=new x(B,w);k.position.set(F,I,Z),k.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),k.castShadow=!0,this.pkArenaGroup.add(k)}const v=new J(.3,.4,.4,8),R=new x(v,p);R.position.set(0,.8,-5),R.castShadow=!0,R.receiveShadow=!0,this.pkArenaGroup.add(R);const T=new Xs(.3),E=new Mt({color:58879,transparent:!0,opacity:.88});this.pkCrystalMesh=new x(T,E),this.pkCrystalMesh.scale.set(1,2,1),this.pkCrystalMesh.position.set(0,1.45,-5),this.pkArenaGroup.add(this.pkCrystalMesh);const U=[{x:-7.5,z:0,weapon:"sword"},{x:7.5,z:0,weapon:"hammer"},{x:0,z:6.8,weapon:"bomb"}];this.swordPreview=null,this.hammerPreview=null,this.bombPreview=null,U.forEach(M=>{const S=new lt;S.position.set(M.x,.6,M.z),M.z>0&&(S.rotation.y=Math.PI);const L=new J(.05,.05,1.3,8),F=new H({color:5125166,flatShading:!0}),Z=new x(L,F);Z.position.set(0,.65,-.4),Z.castShadow=!0,S.add(Z);const I=new x(L,F);I.position.set(0,.65,.4),I.castShadow=!0,S.add(I);const B=new O(.06,.06,1),k=new x(B,F);k.position.set(0,1.15,0),k.castShadow=!0,S.add(k);const Y=new O(.2,.08,1.1),$=new x(Y,new H({color:4073251,flatShading:!0}));$.position.set(0,.04,0),$.receiveShadow=!0,S.add($);let q;M.weapon==="sword"?(q=this.createSword3D(),this.swordPreview=q):M.weapon==="hammer"?(q=this.createHammer3D(),this.hammerPreview=q):(q=this.createBomb3D(),this.bombPreview=q),q.scale.set(.65,.65,.65),q.position.set(0,1.45,0),S.add(q),this.pkArenaGroup.add(S)}),this.pkArenaColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:8}],this.pkArenaInteractables=[{id:"pk_crystal",name:"决斗匹配",x:0,y:.6,z:-5,triggerRadius:1.8}]}createSword3D(){const t=new lt,e=new J(.02,.02,.18,6),n=new H({color:4073251,flatShading:!0}),i=new x(e,n);i.position.y=-.2,i.castShadow=!0,t.add(i);const s=new O(.14,.04,.04),a=new H({color:16757504,flatShading:!0}),r=new x(s,a);r.position.y=-.1,r.castShadow=!0,t.add(r);const c=new O(.06,.55,.018),l=new H({color:13621468,emissive:1118481,flatShading:!0}),h=new x(c,l);h.position.y=.22,h.castShadow=!0,t.add(h);const d=new re(.042,.08,4),u=new x(d,l);return u.position.y=.525,u.rotation.y=Math.PI/4,u.castShadow=!0,t.add(u),t}createHammer3D(){const t=new lt,e=new J(.02,.02,.8,6),n=new H({color:2171169,flatShading:!0}),i=new x(e,n);i.position.y=-.1,i.castShadow=!0,t.add(i);const s=new O(.24,.32,.24),a=new H({color:4545124,flatShading:!0}),r=new x(s,a);r.position.y=.38,r.castShadow=!0,t.add(r);const c=new O(.25,.06,.25),l=new H({color:16757504,flatShading:!0}),h=new x(c,l);return h.position.y=.38,t.add(h),t}createBomb3D(){const t=new lt,e=new Lt(.18,10,10),n=new H({color:2503224,flatShading:!0}),i=new x(e,n);i.position.y=.1,i.castShadow=!0,t.add(i);const s=new J(.04,.05,.06,8),a=new H({color:5533306,flatShading:!0}),r=new x(s,a);r.position.y=.28,r.castShadow=!0,t.add(r);const c=new J(.008,.008,.1,4),l=new H({color:16766287,flatShading:!0}),h=new x(c,l);h.position.set(.02,.35,0),h.rotation.z=-.3,t.add(h);const d=new Lt(.025,4,4),u=new Mt({color:16727296}),f=new x(d,u);return f.position.set(.05,.4,0),t.add(f),t}createFurnitureModel(t){const e=new lt;if(t==="painting"){const n=new O(1.2,.8,.06),i=new H({color:5125166,flatShading:!0}),s=new x(n,i);s.castShadow=!0,e.add(s);const a=new O(1.1,.7,.01),r=new H({color:16774112,flatShading:!0}),c=new x(a,r);c.position.z=.031,e.add(c);const l=new J(.18,.18,.01,12);l.rotateX(Math.PI/2);const h=new Mt({color:16740419}),d=new x(l,h);d.position.set(0,.1,.038),e.add(d);const u=new O(1.1,.25,.01),f=new H({color:2733814,flatShading:!0}),g=new x(u,f);g.position.set(0,-.2,.038),e.add(g)}else if(t==="christmas_tree"){const n=new J(.1,.12,.4,8),i=new H({color:6111287,flatShading:!0}),s=new x(n,i);s.position.y=.2,s.castShadow=!0,e.add(s);const a=new H({color:1793568,flatShading:!0}),r=new x(new re(.55,.65,8),a);r.position.y=.65,r.castShadow=!0,e.add(r);const c=new x(new re(.42,.52,8),a);c.position.y=1.05,c.castShadow=!0,e.add(c);const l=new x(new re(.28,.38,8),a);l.position.y=1.4,l.castShadow=!0,e.add(l);const h=[16717636,16771899,58998,2733814,14696699];for(let d=0;d<12;d++){const u=new Lt(.045,4,4),f=new Mt({color:h[d%h.length]}),g=new x(u,f),y=.4+Math.random()*1.1,m=.55*(1.5-y)/1.5,p=Math.random()*Math.PI*2;g.position.set(Math.cos(p)*m,y,Math.sin(p)*m),e.add(g)}}else if(t==="rabbit_sofa"){const n=new H({color:16744619,flatShading:!0}),i=new H({color:16777215,flatShading:!0}),s=new O(1.2,.3,.6),a=new x(s,n);a.position.y=.15,a.castShadow=!0,e.add(a);const r=new O(1.2,.55,.15),c=new x(r,n);c.position.set(0,.5,-.22),c.castShadow=!0,e.add(c);const l=new O(.14,.35,.08),h=new x(l,n);h.position.set(-.25,.9,-.22),h.rotation.z=.12,e.add(h);const d=new x(new O(.08,.25,.01),i);d.position.set(-.25,.9,-.179),d.rotation.z=.12,e.add(d);const u=new x(l,n);u.position.set(.25,.9,-.22),u.rotation.z=-.12,e.add(u);const f=new x(new O(.08,.25,.01),i);f.position.set(.25,.9,-.179),f.rotation.z=-.12,e.add(f);const g=new O(1.02,.1,.48),y=new x(g,i);y.position.set(0,.32,.03),e.add(y);const m=new O(.12,.38,.55),p=new x(m,n);p.position.set(-.54,.34,.02),p.castShadow=!0,e.add(p);const _=p.clone();_.position.x=.54,e.add(_)}else if(t==="swing_chair"){const n=new H({color:9479342,flatShading:!0}),i=new H({color:14737632,flatShading:!0}),s=new H({color:5227511,flatShading:!0}),a=new Sn(.35,.03,8,24);a.rotateX(Math.PI/2);const r=new x(a,n);r.position.y=.03,e.add(r);const c=new J(.03,.03,1.7,8),l=new x(c,n);l.position.set(0,.85,-.32),l.rotation.x=-.05,l.castShadow=!0,e.add(l);const h=new O(.06,.06,.38),d=new x(h,n);d.position.set(0,1.7,-.16),e.add(d);const u=new J(.008,.008,.1,4),f=new x(u,i);f.position.set(-.16,1.25,.02),f.rotation.z=.15,e.add(f);const g=new x(u,i);g.position.set(.16,1.25,.02),g.rotation.z=-.15,e.add(g);const y=new J(.24,.28,.12,12),m=new x(y,s);m.position.set(0,.82,.02),m.castShadow=!0,e.add(m);const p=new Lt(.28,8,8,0,Math.PI,0,Math.PI/2);p.rotateX(Math.PI/2);const _=new H({color:5227511,transparent:!0,opacity:.8,side:he,flatShading:!0}),w=new x(p,_);w.position.set(0,1.05,.02),w.rotation.y=Math.PI,e.add(w)}return e}initShopUI(){document.querySelectorAll("#modal-shop .shop-tabactive").forEach(r=>{r.addEventListener("click",c=>{const l=r.getAttribute("data-tab");this.switchShopTab(l)})}),this.switchShopTab("agriculture");const e=document.getElementById("btn-shop-count-minus"),n=document.getElementById("btn-shop-count-plus"),i=document.getElementById("btn-shop-count-plus10"),s=document.getElementById("shop-buy-count-slider"),a=document.getElementById("btn-shop-execute-buy");e&&s&&e.addEventListener("click",()=>{let r=parseInt(s.value)||1;r>1&&(s.value=r-1,this.updateShopBuyCountUI())}),n&&s&&n.addEventListener("click",()=>{let r=parseInt(s.value)||1;r<99&&(s.value=r+1,this.updateShopBuyCountUI())}),i&&s&&i.addEventListener("click",()=>{let r=parseInt(s.value)||1;s.value=Math.min(99,r+10),this.updateShopBuyCountUI()}),s&&s.addEventListener("input",()=>{this.updateShopBuyCountUI()}),a&&a.addEventListener("click",r=>{if(!this.selectedShopItem)return;const c=parseInt(s?s.value:1)||1;this.executeShopBuy(this.selectedShopItem,c,r.clientX,r.clientY)})}switchShopTab(t){const e=document.querySelectorAll("#modal-shop .shop-tabactive");e.forEach(n=>{n.getAttribute("data-tab")===t&&(e.forEach(i=>{i.classList.remove("active"),i.style.borderLeftColor="transparent",i.style.color="var(--text-muted)"}),n.classList.add("active"),n.style.borderLeftColor="#27ae60",n.style.color="#fff",this.renderShopItems(t))})}getActiveShopTab(){const t=document.querySelector("#modal-shop .shop-tabactive.active");return t?t.getAttribute("data-tab"):"agriculture"}getActiveBagTab(){const t=document.querySelector("#modal-bag .bag-tabactive.active");return t?t.getAttribute("data-tab"):"seed"}updateShopCoins(){const t=document.querySelector("#modal-shop .shop-coins-val");t&&(t.textContent=this.gameData.coins)}updateShopBuyCountUI(){const t=document.getElementById("shop-buy-count-slider"),e=document.getElementById("shop-buy-count-text"),n=document.querySelector("#shop-item-detail .shop-detail-total-price");if(!t||!this.selectedShopItem)return;const i=parseInt(t.value)||1;if(e&&(e.textContent=i),n)if(this.selectedShopItem.id.startsWith("coin_"))n.textContent="免费";else{const s=this.selectedShopItem.price*i;n.textContent=`🪙 ${s}`}}showShopItemDetail(t){this.selectedShopItem=t;const e=document.getElementById("shop-item-detail");if(!e)return;const n=e.querySelector(".shop-detail-empty"),i=e.querySelector(".shop-detail-content");n&&(n.style.display="none"),i&&(i.style.display="flex");const s=e.querySelector(".shop-detail-icon");if(s){const d=t.name.split(" ").pop()||"📦";s.textContent=d}const a=e.querySelector(".shop-detail-title");a&&(a.textContent=t.name.replace(/ 🌻| 🍓| 🖼️| 🎄| 🛋️| 🎪| 🪙| 🎁| 💎/,""));const r=e.querySelector(".shop-detail-owned");if(r)if(t.type==="seed"){const d=this.gameData.backpack.find(u=>u.id===t.id&&u.type==="seed");r.textContent=`已持有: ${d?d.count:0}`}else if(t.type==="decor"){const d=this.gameData.ownedFurnitures.includes(t.id);r.textContent=d?"✅ 已解锁":"🔒 未拥有"}else r.textContent="★ 免费福利";const c=e.querySelector(".shop-detail-desc");c&&(c.textContent=t.desc);const l=e.querySelector(".shop-detail-unit-price");l&&(t.id.startsWith("coin_")?l.textContent="￥0.00":l.textContent=`🪙 ${t.price}`);const h=document.getElementById("shop-buy-count-slider");h&&(h.value=1),this.updateShopBuyCountUI()}renderShopItems(t){const e=document.getElementById("shop-grid");if(!e)return;e.innerHTML="";let n=[];t==="agriculture"?n=[{id:"sunflower_seed",name:"向日葵种子 🌻",price:10,desc:"成熟需要 30 秒。收割可获得 20 金币 + 15 经验。",quality:"green",type:"seed"},{id:"strawberry_seed",name:"草莓种子 🍓",price:20,desc:"成熟需要 60 秒。收割可获得 45 金币 + 35 经验。",quality:"blue",type:"seed"}]:t==="decorations"?n=[{id:"painting_1",name:"浮空岛日落挂画 🖼️",price:50,desc:"悬挂在墙壁上的精美装饰，带来悠闲的落日余晖。",type:"decor",quality:"purple"},{id:"tree_1",name:"闪烁圣诞树 🎄",price:100,desc:"闪耀着七彩微光的圣诞树，散发节日温馨氛围。",type:"decor",quality:"purple"},{id:"sofa_1",name:"粉嫩兔子沙发 🛋️",price:150,desc:"兔耳设计的粉色单人沙发，触感松软，极度舒适。",type:"decor",quality:"purple"},{id:"swing_1",name:"室内网兜秋千 🎪",price:200,desc:"挂在天花板上的编织网秋千，轻轻摇曳，治愈满满。",type:"decor",quality:"purple"}]:t==="topup"&&(n=[{id:"coin_100",name:"免费金币充值包 🪙",amount:100,desc:"白嫖小包。免费充值 100 金币，附赠吃到金币声效！",type:"topup",quality:"gold",price:0},{id:"coin_500",name:"金币充值礼包 🎁",amount:500,desc:"免费大包。点击即刻免费充值 500 金币！",type:"topup",quality:"gold",price:0},{id:"coin_1000",name:"超级金币充值包 💎",amount:1e3,desc:"免费巨包！狂揽 1000 金币，金币爆屏！",type:"topup",quality:"gold",price:0}]);for(let s=0;s<12;s++){const a=document.createElement("div");a.className="shop-item-box";const r=n[s];if(r){const c=`q-${r.quality||"white"}`;a.classList.add(c),this.selectedShopItem&&this.selectedShopItem.id===r.id&&a.classList.add("active");const l=r.name.split(" ").pop()||"📦";a.innerHTML=`
          <span style="font-size: 1.8rem;">${l}</span>
          <span class="shop-item-box-price">${r.id.startsWith("coin_")?"免费":"🪙"+r.price}</span>
        `,a.addEventListener("click",()=>{document.querySelectorAll(".shop-item-box.active").forEach(h=>h.classList.remove("active")),a.classList.add("active"),this.showShopItemDetail(r)})}else a.innerHTML="";e.appendChild(a)}if(n.some(s=>this.selectedShopItem&&s.id===this.selectedShopItem.id))this.showShopItemDetail(this.selectedShopItem);else{this.selectedShopItem=null;const s=document.getElementById("shop-item-detail");if(s){const a=s.querySelector(".shop-detail-empty"),r=s.querySelector(".shop-detail-content");a&&(a.style.display="flex"),r&&(r.style.display="none")}}}executeShopBuy(t,e,n,i){if(t.id.startsWith("coin_")){const a=t.amount*e;this.gameData.coins+=a,this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(a,n,i),this.showShopItemDetail(t),setTimeout(()=>{this.refreshBag(this.getActiveBagTab())},50);return}const s=t.price*e;if(this.gameData.coins<s){alert("金币不足，无法购买！");return}if(this.gameData.coins-=s,t.type==="seed"){const a=this.gameData.backpack.find(r=>r.id===t.id&&r.type==="seed");a?a.count+=e:this.gameData.backpack.push({id:t.id,name:t.name.replace(/ 🌻| 🍓/,""),type:"seed",count:e,quality:t.quality,desc:t.desc}),this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(-s,n,i),this.showShopItemDetail(t),this.refreshFarm(),this.refreshBag("seed")}else if(t.type==="decor"){this.gameData.ownedFurnitures.includes(t.id)||this.gameData.ownedFurnitures.push(t.id);const a=this.gameData.backpack.find(r=>r.id===t.id&&r.type==="decor");a?a.count+=e:this.gameData.backpack.push({id:t.id,name:t.name.replace(/ 🖼️| 🎄| 🛋️| 🎪/,""),type:"decor",count:e,quality:"purple",desc:"购买于家园工坊的精美家具模型。进入家园编辑模式即可随意定位摆放它！"}),this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(-s,n,i),this.showShopItemDetail(t),this.refreshHome(),this.refreshBag("decor")}}initRadialSeedMenu(){const t=document.getElementById("btn-close-radial");t&&t.addEventListener("click",()=>{this.closeRadialSeedMenu()}),document.querySelectorAll("#radial-seed-menu .radial-item-btn").forEach(n=>{n.addEventListener("click",i=>{if(i.stopPropagation(),n.classList.contains("disabled")||n.style.opacity==="0.5"){this.showToast("请走近空农地后再种植！");return}const s=n.getAttribute("data-seed");this.plantCropFromRadialMenu(s)})}),window.addEventListener("keydown",n=>{if(this.isRadialMenuOpen)if(n.key==="1"){const i=document.getElementById("radial-seed-sunflower");i&&i.click()}else if(n.key==="2"){const i=document.getElementById("radial-seed-strawberry");i&&i.click()}else n.key==="Escape"&&this.closeRadialSeedMenu()})}openRadialSeedMenu(){const t=document.getElementById("radial-seed-menu");t&&(this.isRadialMenuOpen=!0,window.parent&&(window.parent.isRadialMenuOpen=!0),t.classList.add("open"),t.style.display="block",this.updateRadialCounts(),this.updateActivePlotForRadialMenu())}closeRadialSeedMenu(){const t=document.getElementById("radial-seed-menu");t&&(this.isRadialMenuOpen=!1,window.parent&&(window.parent.isRadialMenuOpen=!1),t.classList.remove("open"),setTimeout(()=>{this.isRadialMenuOpen||(t.style.display="none")},300))}updateRadialCounts(){const t=document.querySelector("#radial-seed-sunflower .radial-count"),e=document.querySelector("#radial-seed-strawberry .radial-count"),n=this.gameData.backpack.find(s=>s.id==="sunflower_seed"&&s.type==="seed"),i=this.gameData.backpack.find(s=>s.id==="strawberry_seed"&&s.type==="seed");t&&(t.textContent=n?n.count:0),e&&(e.textContent=i?i.count:0)}updateActivePlotForRadialMenu(){if(!this.isRadialMenuOpen||this.currentMap!=="farm"||!this.player||!this.farmPlots3D)return;let t=null,e=1/0;this.gameData.farmPlots.forEach((i,s)=>{if(i.unlocked&&i.status==="empty"){const a=this.farmPlots3D[s];if(a){const r=this.player.position.x-a.x,c=this.player.position.z-a.z,l=Math.sqrt(r*r+c*c);l<e&&(e=l,t=s)}}});const n=document.getElementById("radial-seed-menu");n&&(t!==null&&e<2.2?(this.activePlotIndex=t,n.querySelectorAll(".radial-item-btn").forEach(i=>{i.classList.remove("disabled"),i.style.opacity="1"})):(this.activePlotIndex=null,n.querySelectorAll(".radial-item-btn").forEach(i=>{i.classList.add("disabled"),i.style.opacity="0.5"})))}plantCropFromRadialMenu(t){if(this.activePlotIndex===null){this.showToast("请靠近空农地后再种植！");return}const e=this.gameData.backpack.find(s=>s.id===t&&s.type==="seed");if(!e||e.count<=0){this.showToast(`${t==="sunflower_seed"?"向日葵":"草莓"}种子数量不足！正为您打开市集商店...`),this.closeRadialSeedMenu(),this.modalMgr.openModal("shop"),this.switchShopTab("agriculture");return}e.count--;const n=this.gameData.farmPlots[this.activePlotIndex];n.status="growing",n.seedId=t,n.plantTime=Date.now(),this.saveGameData(),this.refreshFarm(),this.updateRadialCounts(),this.playCustomSound(330,.25,"sine",.1),this.recreateCrop3D(this.activePlotIndex);const i=t==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功播种了 1 颗 ${i} 种子 🌱`)}buildLakePlatform(){this.lakeGroup.clear(),this.lakeColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:12}],this.lakeInteractables=[],this.bowlsList=[],this.ripplesList=[],this.noteParticles=[],this.lastBowlSoundTime=0,this.lastWaterStepTime=0;const t=new J(12,12.5,1.2,32),e=new H({color:15724532,flatShading:!0}),n=new x(t,e);n.position.y=0,n.receiveShadow=!0,n.castShadow=!0,this.lakeGroup.add(n);const i=new J(12.5,11.8,1.8,32),s=new H({color:4545124,flatShading:!0}),a=new x(i,s);a.position.y=-1.5,this.lakeGroup.add(a);const r=new en(6,32);r.rotateX(-Math.PI/2);const c=new Mt({color:44225,side:he}),l=new x(r,c);l.position.y=.602,this.lakeGroup.add(l);const h=new en(6,32);h.rotateX(-Math.PI/2);const d=new Mt({color:5227511,transparent:!0,opacity:.55,side:he}),u=new x(h,d);u.position.y=.61,this.lakeGroup.add(u);const f=new H({color:14737632,flatShading:!0}),g=new O(1.6,.22,.4),y=24,m=6.1;for(let mt=0;mt<y;mt++){const A=mt*Math.PI*2/y,b=Math.cos(A)*m,z=Math.sin(A)*m,st=new x(g,f);st.position.set(b,.65,z),st.rotation.y=-A+Math.PI/2,st.castShadow=!0,st.receiveShadow=!0,this.lakeGroup.add(st)}const p=new J(.42,.28,.22,12,1,!0),_=new J(.28,.28,.02,12),w=new H({color:16777215,flatShading:!0,side:he,emissive:1118481});for(let mt=0;mt<6;mt++){const A=new lt,b=mt*Math.PI*2/6+(Math.random()-.5)*.5,z=2+Math.random()*2.8,st=Math.cos(b)*z,ot=Math.sin(b)*z;A.position.set(st,.61,ot);const nt=new x(p,w);nt.castShadow=!0,nt.receiveShadow=!0,A.add(nt);const At=new x(_,w);At.position.y=-.1,At.castShadow=!0,A.add(At),this.lakeGroup.add(A),this.bowlsList.push({group:A,position:A.position,rotation:A.rotation,velocity:new P((Math.random()-.5)*.35,0,(Math.random()-.5)*.35),phase:Math.random()*Math.PI*2})}const v=new lt;v.position.set(0,.6,-8);const R=new H({color:1710618,flatShading:!0}),T=new H({color:16448250,flatShading:!0}),E=new x(new O(1.6,.82,.65),R);E.position.y=.41,E.castShadow=!0,E.receiveShadow=!0,v.add(E);const U=new x(new O(1.6,.6,.2),R);U.position.set(0,1.12,-.225),U.castShadow=!0,v.add(U);const M=new x(new O(1.5,.05,.25),T);M.position.set(0,.81,.22),M.castShadow=!0,v.add(M);const S=new x(new O(.05,.12,.27),R);S.position.set(-.775,.85,.22),S.castShadow=!0,v.add(S);const L=S.clone();L.position.x=.775,v.add(L);const F=new x(new O(.65,.45,.3),R);F.position.set(0,.225,.65),F.castShadow=!0,F.receiveShadow=!0,v.add(F),this.lakeGroup.add(v),this.lakeInteractables.push({id:"piano",name:"弹奏钢琴",x:0,y:.6,z:-7,triggerRadius:1.6});const Z=new H({color:15658734,flatShading:!0}),I=new O(.8,.36,.45),B=new x(I,Z);B.position.set(7.5,.78,0),B.castShadow=!0,B.receiveShadow=!0,this.lakeGroup.add(B),this.lakeInteractables.push({id:"lake_seat_1",name:"坐下静赏",x:7.5,y:.6,z:0,triggerRadius:1.5});const k=new x(I,Z);k.position.set(-7.5,.78,0),k.castShadow=!0,k.receiveShadow=!0,this.lakeGroup.add(k),this.lakeInteractables.push({id:"lake_seat_2",name:"坐下静赏",x:-7.5,y:.6,z:0,triggerRadius:1.5});const Y=new lt;Y.position.set(0,.6,9.5);const $=f,q=new x(new J(.8,.9,.22,12),$);q.position.y=.11,q.castShadow=!0,q.receiveShadow=!0,Y.add(q);const Q=new x(new J(.68,.58,.35,12),$);Q.position.y=.38,Q.castShadow=!0,Q.receiveShadow=!0,Y.add(Q);const it=new Mt({color:45311,transparent:!0,opacity:.65,side:he}),rt=new x(new en(.64,12),it);rt.rotateX(-Math.PI/2),rt.position.y=.54,Y.add(rt);const V=new J(.07,.14,.8,8),et=new Mt({color:14743546,transparent:!0,opacity:.82}),ft=new x(V,et);ft.position.y=.9,Y.add(ft);const Et=new Mt({color:16777215}),_t=new x(new O(.07,.07,.07),Et);_t.position.set(.1,1.25,.07),Y.add(_t);const Nt=_t.clone();Nt.position.set(-.12,1.3,-.09),Y.add(Nt);const zt=_t.clone();zt.position.set(.04,1.15,-.13),Y.add(zt);const Tt=new x(new J(.03,.03,.8,8),new H({color:5125166}));Tt.position.set(.9,.4,.4),Tt.rotation.z=-.15,Tt.castShadow=!0,Y.add(Tt);const Ft=new x(new O(.55,.16,.03),new H({color:9268835}));Ft.position.set(.85,.72,.4),Ft.rotation.z=-.15,Ft.rotation.y=-.2,Ft.castShadow=!0,Y.add(Ft);const D=new x(new O(.38,.06,.04),new Mt({color:58879}));D.position.set(.86,.72,.42),D.rotation.z=-.15,D.rotation.y=-.2,Y.add(D),this.lakeGroup.add(Y),this.lakeInteractables.push({id:"exit_house",name:"返回海岛大厅",x:0,y:.6,z:8.5,triggerRadius:1.5});const pt=new J(.1,.14,.8,6),K=new H({color:5125166}),ct=new Gi(.55),tt=new H({color:3046706,flatShading:!0});[{x:-9.5,z:-9.5},{x:9.5,z:-9.5},{x:-9.5,z:9.5},{x:9.5,z:9.5}].forEach(mt=>{const A=new lt;A.position.set(mt.x,.6,mt.z);const b=new x(pt,K);b.position.y=.4,b.castShadow=!0,A.add(b);const z=new x(ct,tt);z.position.y=.95,z.castShadow=!0,A.add(z),this.lakeGroup.add(A)}),this.initPianoKeysEvents()}initPianoKeysEvents(){const t=document.querySelectorAll("#modal-piano .piano-key"),e={C4:261.63,D4:293.66,E4:329.63,F4:349.23,G4:392,A4:440,B4:493.88,C5:523.25};t.forEach(a=>{const r=c=>{c.preventDefault();const l=a.getAttribute("data-note"),h=e[l];h&&(this.playCustomSound(h,.8,"sine",.1),window.dispatchEvent(new CustomEvent("piano-note-played",{detail:{note:l}})),a.classList.add("active"),setTimeout(()=>a.classList.remove("active"),120))};a.addEventListener("mousedown",r),a.addEventListener("touchstart",r,{passive:!1})});const n={a:"C4",s:"D4",d:"E4",f:"F4",g:"G4",h:"A4",j:"B4",k:"C5"},i=a=>{const r=this.modalMgr?this.modalMgr.modals.piano:null;if(r&&r.classList.contains("open")){const c=a.key.toLowerCase(),l=n[c];if(l){const h=document.querySelector(`#modal-piano .piano-key[data-note="${l}"]`);if(h){const d=e[l];this.playCustomSound(d,.8,"sine",.1),window.dispatchEvent(new CustomEvent("piano-note-played",{detail:{note:l}})),h.classList.add("active"),setTimeout(()=>h.classList.remove("active"),120)}}}};window._pianoKeydownHandler&&window.removeEventListener("keydown",window._pianoKeydownHandler),window._pianoKeydownHandler=i,window.addEventListener("keydown",i);const s=document.getElementById("btn-exit-sitting");s&&s.addEventListener("click",a=>{a.preventDefault(),this.player&&(this.player.isSitting||this.player.isLyingDown)&&this.player.standUp()})}spawnNoteParticle(t){const e=document.createElement("canvas");e.width=64,e.height=64;const n=e.getContext("2d");n.fillStyle="#ffd700",n.font='bold 44px Outfit, "Noto Sans SC", sans-serif',n.textAlign="center",n.textBaseline="middle";const i=["🎵","🎶","楽","✨","♩","♩"],s=i[Math.floor(Math.random()*i.length)];n.fillText(s,32,32);const a=new zc(e),r=new Nc({map:a,transparent:!0,opacity:.95,blending:Ns}),c=new sm(r),l=(Math.random()-.5)*.9,h=-7.5+(Math.random()-.5)*.3;c.position.set(l,1.45,h);const d=.32+Math.random()*.16;c.scale.set(d,d,d),this.lakeGroup.add(c),this.noteParticles.push({sprite:c,texture:a,material:r,velocity:new P((Math.random()-.5)*.7,1.1+Math.random()*.7,(Math.random()-.5)*.5),age:0,maxAge:1.6+Math.random()*.8})}playBowlCollisionSound(t,e){const n=Date.now();if(n-this.lastBowlSoundTime<80)return;this.lastBowlSoundTime=n;const i=[523.25,587.33,659.25,783.99,880,1046.5,1174.66,1318.51],s=i[Math.floor(Math.random()*i.length)];try{window.audioCtx||(window.audioCtx=new(window.AudioContext||window.webkitAudioContext)),window.audioCtx.state==="suspended"&&window.audioCtx.resume();const a=window.audioCtx.currentTime,r=.75*Math.min(e,1.2),c=.05*Math.min(e,1.2),l=window.audioCtx.createOscillator(),h=window.audioCtx.createGain();l.type="sine",l.frequency.setValueAtTime(s,a),h.gain.setValueAtTime(c,a),h.gain.exponentialRampToValueAtTime(1e-4,a+r),l.connect(h),h.connect(window.audioCtx.destination),l.start(),l.stop(a+r);const d=window.audioCtx.createOscillator(),u=window.audioCtx.createGain();d.type="sine",d.frequency.setValueAtTime(s*1.5,a),u.gain.setValueAtTime(c*.28,a),u.gain.exponentialRampToValueAtTime(1e-4,a+.25),d.connect(u),u.connect(window.audioCtx.destination),d.start(),d.stop(a+.25);const f=window.audioCtx.createOscillator(),g=window.audioCtx.createGain();f.type="sine",f.frequency.setValueAtTime(s*2,a),g.gain.setValueAtTime(c*.15,a),g.gain.exponentialRampToValueAtTime(1e-4,a+.18),f.connect(g),g.connect(window.audioCtx.destination),f.start(),f.stop(a+.18)}catch(a){console.warn("[音效] 白瓷碗磬钟音效合成失败:",a)}}createRipple(t,e,n){const i=new ji(.06,.09,32);i.rotateX(-Math.PI/2);const s=new Mt({color:8445674,transparent:!0,opacity:.48,side:he}),a=new x(i,s);a.position.set(t,e,n),this.lakeGroup.add(a),this.ripplesList.push({mesh:a,geometry:i,material:s,size:.08,maxSize:1.4+Math.random()*.6,speed:1.1,maxOpacity:.5})}updateLakeFrame(t,e){if(!this.player)return;const n=this.player.position.x,i=this.player.position.z,s=Math.sqrt(n*n+i*i);if(s<6&&!this.player.isSitting){if(this.player.position.y=.52,this.player.velocity.y=0,this.player.isGrounded=!0,this.player.keys.w||this.player.keys.s||this.player.keys.a||this.player.keys.d||window.joystickDir&&(window.joystickDir.x!==0||window.joystickDir.y!==0)){const r=Date.now();r-this.lastWaterStepTime>320&&(this.createRipple(n,.612,i),this.lastWaterStepTime=r,this.playCustomSound(120,.18,"sine",.03))}this.bowlsList.forEach(r=>{const c=r.position.x-n,l=r.position.z-i,h=Math.sqrt(c*c+l*l);if(h<.82){const u=h>0?c/h:1,f=h>0?l/h:0,g=1.35;r.velocity.x+=u*g,r.velocity.z+=f*g,r.velocity.length()>2.2&&r.velocity.normalize().multiplyScalar(2.2),r.position.x=n+u*.83,r.position.z=i+f*.83,this.playBowlCollisionSound(r.position,1.1),this.createRipple(r.position.x,.612,r.position.z)}})}if(s>11.8){const a=n/s,r=i/s;this.player.position.x=a*11.8,this.player.position.z=r*11.8,this.player.group.position.copy(this.player.position),this.player.velocity.set(0,0,0)}this.bowlsList.forEach(a=>{a.position.x+=a.velocity.x*t,a.position.z+=a.velocity.z*t,a.velocity.multiplyScalar(.982),a.velocity.x+=(Math.random()-.5)*.08*t,a.velocity.z+=(Math.random()-.5)*.08*t,a.position.y=.61+Math.sin(e*.0022+a.phase)*.018,a.rotation.x=Math.sin(e*.0018+a.phase)*.038,a.rotation.z=Math.cos(e*.0024+a.phase)*.038;const r=Math.sqrt(a.position.x*a.position.x+a.position.z*a.position.z);if(r>5.58){const c=a.position.x/r,l=a.position.z/r,h=a.velocity.x*c+a.velocity.z*l;a.velocity.x-=2*h*c,a.velocity.z-=2*h*l,a.position.x=c*5.56,a.position.z=l*5.56,this.playBowlCollisionSound(a.position,.45),this.createRipple(a.position.x,.612,a.position.z)}});for(let a=0;a<this.bowlsList.length;a++)for(let r=a+1;r<this.bowlsList.length;r++){const c=this.bowlsList[a],l=this.bowlsList[r],h=l.position.x-c.position.x,d=l.position.z-c.position.z,u=Math.sqrt(h*h+d*d),f=.84;if(u<f){const g=h/u,y=d/u,m=l.velocity.x-c.velocity.x,p=l.velocity.z-c.velocity.z,_=m*g+p*y;if(_<0){const T=-1.05*_;c.velocity.x-=T*g*.5,c.velocity.z-=T*y*.5,l.velocity.x+=T*g*.5,l.velocity.z+=T*y*.5}const w=f-u;c.position.x-=g*w*.5,c.position.z-=y*w*.5,l.position.x+=g*w*.5,l.position.z+=y*w*.5;const v=(c.position.x+l.position.x)/2,R=(c.position.z+l.position.z)/2;this.playBowlCollisionSound(new P(v,.61,R),1),this.createRipple(v,.612,R)}}for(let a=this.ripplesList.length-1;a>=0;a--){const r=this.ripplesList[a];r.size+=r.speed*t,r.mesh.scale.set(r.size*10,1,r.size*10),r.material.opacity=r.maxOpacity*(1-r.size/r.maxSize),r.size>=r.maxSize&&(this.lakeGroup.remove(r.mesh),r.geometry.dispose(),r.material.dispose(),this.ripplesList.splice(a,1))}for(let a=this.noteParticles.length-1;a>=0;a--){const r=this.noteParticles[a];r.age+=t,r.sprite.position.addScaledVector(r.velocity,t),r.sprite.position.x+=Math.sin(r.age*6)*.012;const c=r.age/r.maxAge;r.material.opacity=.95*(1-c);const l=(.32+Math.sin(r.age*2)*.05)*(1-c*.4);r.sprite.scale.set(l,l,l),r.age>=r.maxAge&&(this.lakeGroup.remove(r.sprite),r.texture.dispose(),r.material.dispose(),this.noteParticles.splice(a,1))}}buildCastlePlatform(){this.castleGroup.clear(),this.castleColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:24}],this.castleInteractables=[],this.sakuraList=[],this.castleRipples=[],this.lastCastleWaterStepTime=0;const t=2,e=new pa;e.moveTo(0,-6*t),e.bezierCurveTo(-5*t,-3*t,-8*t,2*t,-5*t,6*t),e.bezierCurveTo(-2*t,9*t,0,5*t,0,4*t),e.bezierCurveTo(0,5*t,2*t,9*t,5*t,6*t),e.bezierCurveTo(8*t,2*t,5*t,-3*t,0,-6*t);const n={depth:1.2,bevelEnabled:!0,bevelSegments:2,steps:1,bevelSize:.1,bevelThickness:.1},i=new $i(e,n);i.rotateX(-Math.PI/2);const s=new H({color:16770540,flatShading:!0}),a=new x(i,s);a.position.y=-.6,a.receiveShadow=!0,a.castShadow=!0,this.castleGroup.add(a);const r=new $i(e,{depth:2.2,bevelEnabled:!0,bevelSegments:2,steps:1,bevelSize:.05,bevelThickness:.1});r.rotateX(-Math.PI/2);const c=new H({color:10233776,flatShading:!0}),l=new x(r,c);l.position.y=-2.8,this.castleGroup.add(l);const h=new H({color:16757702,flatShading:!0}),d=new H({color:16777215,flatShading:!0}),u=new O(1.9,.02,1.9),f=(ht,dt)=>{const Pt=Math.sqrt((ht+4.5)*(ht+4.5)+(dt+6)*(dt+6)),Dt=Math.sqrt((ht-4.5)*(ht-4.5)+(dt+6)*(dt+6));if(Pt<6.5||Dt<6.5)return!0;if(dt>=-6&&dt<=14){const Rt=11*(1-(dt+6)/20);if(Math.abs(ht)<=Rt)return!0}return!1};let g=!1;for(let ht=-16;ht<=16;ht+=2)for(let dt=-12;dt<=18;dt+=2){const Pt=Math.sqrt((ht- -9)*(ht- -9)+(dt-2)*(dt-2))<3.2,Dt=ht>=-6.5&&ht<=6.5&&dt>=-12.5&&dt<=-2.5;if(f(ht,dt)&&!Pt&&!Dt){const Rt=new x(u,g?h:d);Rt.position.set(ht,.605,dt),Rt.receiveShadow=!0,Rt.castShadow=!0,this.castleGroup.add(Rt),g=!g}}const y=new H({color:16777215,flatShading:!0}),m=new J(.12,.12,.8,8),p=y,_=new Mt({color:16728193});e.getPoints(42).forEach((ht,dt)=>{const Pt=ht.x,Dt=-ht.y;if(Dt>13.5||Math.abs(Pt)<3&&Dt>11)return;const Rt=new x(m,y);if(Rt.position.set(Pt,.6+.4,Dt),Rt.castShadow=!0,Rt.receiveShadow=!0,this.castleGroup.add(Rt),dt%6===0){const se=new lt;se.position.set(Pt,.6,Dt);const pe=new x(new J(.06,.08,2.5,8),p);pe.position.y=1.25,pe.castShadow=!0,se.add(pe);const de=new lt;de.position.set(0,2.6,0);const ke=new x(new Lt(.18,6,6),_);ke.position.set(-.1,.1,0),de.add(ke);const ce=ke.clone();ce.position.x=.1,de.add(ce);const $t=new x(new re(.24,.32,6),_);$t.rotation.x=Math.PI,$t.position.set(0,-.1,0),de.add($t),se.add(de);const Yn=new Ne(16738740,1.2,5);Yn.position.set(0,2.6,0),se.add(Yn),this.castleGroup.add(se)}});const v=-7.5,R=14,T=10,E=4.2,U=16745889,M=new H({color:U,flatShading:!0}),S=new H({color:16777215,flatShading:!0}),L=new x(new O(R,.12,T),d);L.position.set(0,.6+.06,v),L.receiveShadow=!0,L.castShadow=!0,this.castleGroup.add(L),this.castleColliders.push({type:"floor",worldX:0,worldZ:v,worldY:.72,radius:8});const F=new x(new O(.3,E,T),M);F.position.set(-R/2+.15,.6+E/2,v),F.castShadow=!0,F.receiveShadow=!0,this.castleGroup.add(F);const Z=F.clone();Z.position.x=R/2-.15,this.castleGroup.add(Z);const I=new x(new O(R,E,.3),M);I.position.set(0,.6+E/2,v-T/2+.15),I.castShadow=!0,I.receiveShadow=!0,this.castleGroup.add(I);const B=E,k=new J(.32,.38,B,12);for(let ht=0;ht<4;ht++){const dt=-5+ht*3.33;if(Math.abs(dt)<1)continue;const Pt=new x(k,S);Pt.position.set(dt,.6+B/2,v+T/2-.3),Pt.castShadow=!0,Pt.receiveShadow=!0,this.castleGroup.add(Pt)}const Y=new lt;Y.position.set(0,.72,v-1.5);const $=new x(new O(4.2,.42,1.2),h);$.position.y=.21,$.castShadow=!0,Y.add($);const q=new O(.5,.72,1.2),Q=new x(q,h);Q.position.set(-2.1+.25,.36,0),Q.castShadow=!0,Y.add(Q);const it=Q.clone();it.position.x=2.1-.25,Y.add(it);const rt=new O(4.2,.72,.4),V=new x(rt,h);V.position.set(0,.52,-.4),V.castShadow=!0,Y.add(V),this.castleGroup.add(Y),this.castleInteractables.push({id:"sit_sofa",name:"坐下大沙发",x:0,y:.72,z:v-1.5+.8,triggerRadius:1.5});const et=new lt;et.position.set(-4,.72,v-3);const ft=new x(new O(1.6,.75,.7),S);ft.position.y=.375,ft.castShadow=!0,et.add(ft);const Et=new x(new J(.55,.55,.05,16),new H({color:16766720}));Et.rotateX(Math.PI/2),Et.position.set(0,1.35,-.3),Et.castShadow=!0,et.add(Et);const _t=new x(new J(.48,.48,.06,16),new Mt({color:8445674,transparent:!0,opacity:.8}));_t.rotateX(Math.PI/2),_t.position.set(0,1.35,-.28),et.add(_t);const Nt=new x(new J(.32,.32,.45,12),h);Nt.position.set(0,.225,.6),Nt.castShadow=!0,et.add(Nt),this.castleGroup.add(et),this.castleInteractables.push({id:"wardrobe",name:"整理仪容 (试衣间)",x:-4,y:.72,z:v-3+.6,triggerRadius:1.5});const zt=.6+E,Tt=new x(new O(R,.15,T),S);Tt.position.set(0,zt+.075,v),Tt.receiveShadow=!0,Tt.castShadow=!0,this.castleGroup.add(Tt),this.castleColliders.push({type:"floor",worldX:0,worldZ:v,worldY:zt+.15,radius:8.5});const Ft=new J(.08,.08,.72,8),D=new O(R,.08,.08),pt=new O(.08,.08,T),K=new lt;K.position.set(0,zt+.15,v);const ct=new x(D,S);ct.position.set(0,.72,T/2-.1),ct.castShadow=!0,K.add(ct);for(let ht=-R/2+.4;ht<=R/2-.4;ht+=.8){const dt=new x(Ft,S);dt.position.set(ht,.36,T/2-.1),dt.castShadow=!0,K.add(dt)}const tt=new x(pt,S);tt.position.set(-R/2+.1,.72,0),tt.castShadow=!0,K.add(tt);const It=tt.clone();It.position.x=R/2-.1,K.add(It);for(let ht=-T/2+.4;ht<=T/2-.4;ht+=.8){const dt=new x(Ft,S);dt.position.set(-R/2+.1,.36,ht),dt.castShadow=!0,K.add(dt);const Pt=dt.clone();Pt.position.x=R/2-.1,K.add(Pt)}this.castleGroup.add(K);const mt=18,A=Math.PI/11,b=E/mt,z=2.8,st=R/2-.5,ot=v+T/2-1.2;for(let ht=0;ht<mt;ht++){const dt=Math.PI+ht*A,Pt=st+Math.cos(dt)*z,Dt=ot+Math.sin(dt)*z,Rt=.6+ht*b,se=new O(1.6,.15,.65),pe=new x(se,S);pe.position.set(Pt,Rt+.075,Dt),pe.rotation.y=-dt+Math.PI/2,pe.castShadow=!0,pe.receiveShadow=!0,this.castleGroup.add(pe),this.castleColliders.push({type:"floor",worldX:Pt,worldZ:Dt,worldY:Rt+.15,radius:.95})}const nt=new lt;nt.position.set(0,zt+.15,v-2.5);const At=new H({color:16766720,flatShading:!0}),wt=new x(new O(2.8,.35,2.4),At);wt.position.y=.175,wt.castShadow=!0,nt.add(wt);const St=new x(new O(2.6,.3,2.2),d);St.position.set(0,.35,0),St.castShadow=!0,St.receiveShadow=!0,nt.add(St);const kt=new O(.8,.12,.45),Ht=new x(kt,h);Ht.position.set(-.6,.54,-.8),Ht.rotation.x=.15,Ht.castShadow=!0,nt.add(Ht);const at=Ht.clone();at.position.x=.6,nt.add(at);const Qt=new J(.04,.04,2.2,8),Yt=new x(Qt,At);Yt.position.set(-1.3,1.1,-1.1),Yt.castShadow=!0,nt.add(Yt);const Vt=Yt.clone();Vt.position.x=1.3,nt.add(Vt);const Bt=new H({color:16761553,transparent:!0,opacity:.55,side:he}),Ct=new x(new J(1.4,1.6,.4,12,1,!0),Bt);Ct.position.set(0,2.2,-.6),Ct.castShadow=!0,nt.add(Ct),this.castleGroup.add(nt),this.castleInteractables.push({id:"lie_bed",name:"小憩睡下",x:0,y:zt+.15,z:v-2.5,triggerRadius:1.8});const Wt=-9,Kt=2,ne=3.2,qt=new x(new en(ne,16),new Mt({color:16731501,side:he}));qt.rotateX(-Math.PI/2),qt.position.set(Wt,.602,Kt),qt.receiveShadow=!0,this.castleGroup.add(qt);const gt=new en(ne,16);gt.rotateX(-Math.PI/2);const N=new Mt({color:16761553,transparent:!0,opacity:.6,side:he}),xt=new x(gt,N);xt.position.set(Wt,.61,Kt),this.castleGroup.add(xt);const vt=S,Gt=new O(.85,.15,.3),Ot=16;for(let ht=0;ht<Ot;ht++){const dt=ht*Math.PI*2/Ot,Pt=Wt+Math.cos(dt)*(ne+.12),Dt=Kt+Math.sin(dt)*(ne+.12),Rt=new x(Gt,vt);Rt.position.set(Pt,.65,Dt),Rt.rotation.y=-dt+Math.PI/2,Rt.castShadow=!0,Rt.receiveShadow=!0,this.castleGroup.add(Rt)}const te=new lt,ie=new H({color:16745889,flatShading:!0}),we=Wt+ne+.9,be=Kt-.8;te.position.set(we,.6,be),te.rotation.y=-Math.PI/2;const ee=new x(new O(1.6,.08,.65),ie);ee.position.y=.04,ee.castShadow=!0,ee.receiveShadow=!0,te.add(ee);const xe=new x(new O(.68,.08,.65),ie);xe.position.set(-.62,.22,0),xe.rotation.z=.45,xe.castShadow=!0,te.add(xe),this.castleGroup.add(te),this.castleInteractables.push({id:"lie_lounger_1",name:"日光浴 (躺椅)",x:we,y:.6,z:be,triggerRadius:1.3});const ze=te.clone(),Ci=Wt+ne+.9,ts=Kt+.8;ze.position.set(Ci,.6,ts),this.castleGroup.add(ze),this.castleInteractables.push({id:"lie_lounger_2",name:"日光浴 (躺椅)",x:Ci,y:.6,z:ts,triggerRadius:1.3});const Ae=new lt;Ae.position.set(0,.6,7);const Rn=new x(new J(.8,.9,.22,12),S);Rn.position.y=.11,Rn.castShadow=!0,Rn.receiveShadow=!0,Ae.add(Rn);const on=new x(new J(.68,.58,.35,12),S);on.position.y=.38,on.castShadow=!0,on.receiveShadow=!0,Ae.add(on);const qn=new x(new en(.64,12),N);qn.rotateX(-Math.PI/2),qn.position.y=.54,Ae.add(qn);const es=new J(.07,.14,.8,8),Qs=new Mt({color:16773363,transparent:!0,opacity:.85}),ns=new x(es,Qs);ns.position.y=.9,Ae.add(ns);const to=new Mt({color:16777215}),C=new x(new O(.07,.07,.07),to);C.position.set(.1,1.25,.07),Ae.add(C);const G=C.clone();G.position.set(-.12,1.3,-.09),Ae.add(G);const X=new x(new J(.03,.03,.8,8),new H({color:6111287}));X.position.set(.9,.4,.4),X.rotation.z=-.15,X.castShadow=!0,Ae.add(X);const j=new x(new O(.55,.16,.03),new H({color:16747937}));j.position.set(.85,.72,.4),j.rotation.z=-.15,j.rotation.y=-.2,j.castShadow=!0,Ae.add(j);const W=new x(new O(.38,.06,.04),_);W.position.set(.86,.72,.42),W.rotation.z=-.15,W.rotation.y=-.2,Ae.add(W),this.castleGroup.add(Ae),this.castleInteractables.push({id:"exit_house",name:"返回海岛大厅",x:0,y:.6,z:6,triggerRadius:1.5});const bt=new Mt({color:16758725,transparent:!0,opacity:.8}),Ut=new O(.08,.08,.02);for(let ht=0;ht<20;ht++){const dt=new x(Ut,bt),Pt=(Math.random()-.5)*22,Dt=(Math.random()-.5)*22-2,Rt=1+Math.random()*11;dt.position.set(Pt,Rt,Dt),dt.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),this.castleGroup.add(dt),this.sakuraList.push({mesh:dt,velocity:new P((Math.random()-.5)*.4,-.6-Math.random()*.6,(Math.random()-.5)*.4),rotSpeed:new P(Math.random()*1.5,Math.random()*1.5,0),phase:Math.random()*Math.PI*2})}}updateCastleFrame(t,e){if(this.sakuraList){if(this.sakuraList.forEach(n=>{n.mesh.position.addScaledVector(n.velocity,t),n.mesh.rotation.x+=n.rotSpeed.x*t,n.mesh.rotation.y+=n.rotSpeed.y*t,n.mesh.position.x+=Math.sin(e*1.5+n.phase)*.005,n.mesh.position.y<=.6&&(n.mesh.position.y=11+Math.random()*3,n.mesh.position.x=(Math.random()-.5)*22,n.mesh.position.z=(Math.random()-.5)*22-2)}),this.player){const n=this.player.position.x,i=this.player.position.z;if(Math.sqrt((n- -9)*(n- -9)+(i-2)*(i-2))<3&&(this.player.position.y>=.58&&(this.player.position.y=.52,this.player.velocity.y=0,this.player.isGrounded=!0),Math.sqrt(this.player.velocity.x*this.player.velocity.x+this.player.velocity.z*this.player.velocity.z)>.05&&e-this.lastCastleWaterStepTime>.32)){this.lastCastleWaterStepTime=e;const r=new ji(.01,.28,12),c=new Mt({color:16745889,transparent:!0,opacity:.6,side:he}),l=new x(r,c);l.rotateX(-Math.PI/2),l.position.set(n,.612,i),this.castleGroup.add(l),this.castleRipples.push({mesh:l,geometry:r,material:c,size:.01,maxSize:.65,speed:1.4,maxOpacity:.6})}}for(let n=this.castleRipples.length-1;n>=0;n--){const i=this.castleRipples[n];i.size+=i.speed*t,i.mesh.scale.set(i.size*5,i.size*5,1),i.material.opacity=i.maxOpacity*(1-i.size/i.maxSize),i.size>=i.maxSize&&(this.castleGroup.remove(i.mesh),i.geometry.dispose(),i.material.dispose(),this.castleRipples.splice(n,1))}}}}window.gameApp=new Jm;
