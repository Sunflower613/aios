import{siteConfig as Hn}from"./site-config-CqbHk6xq.js";import{_ as Zc}from"./preload-helper-BFKGaBgn.js";/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Yo="160",Kc=0,ma=1,Jc=2,$o=1,Jr=2,cn=3,bn=0,Ue=1,ye=2,wn=0,ui=1,Es=2,ga=3,ya=4,Qc=5,Un=100,tl=101,el=102,va=103,_a=104,nl=200,il=201,sl=202,ol=203,Do=204,Uo=205,al=206,rl=207,cl=208,ll=209,hl=210,dl=211,ul=212,fl=213,pl=214,ml=0,gl=1,yl=2,Ts=3,vl=4,_l=5,xl=6,wl=7,jo=0,Ml=1,Sl=2,Mn=0,Qr=1,bl=2,El=3,Tl=4,Al=5,Cl=6,tc=300,pi=301,mi=302,No=303,Bo=304,Bs=306,Fo=1e3,Ze=1001,Oo=1002,Ie=1003,xa=1004,$s=1005,He=1006,Rl=1007,Bi=1008,Sn=1009,Ll=1010,Pl=1011,Zo=1012,ec=1013,vn=1014,_n=1015,Fi=1016,nc=1017,ic=1018,Bn=1020,Il=1021,Ke=1023,Dl=1024,Ul=1025,Fn=1026,gi=1027,Nl=1028,sc=1029,Bl=1030,oc=1031,ac=1033,js=33776,Zs=33777,Ks=33778,Js=33779,wa=35840,Ma=35841,Sa=35842,ba=35843,rc=36196,Ea=37492,Ta=37496,Aa=37808,Ca=37809,Ra=37810,La=37811,Pa=37812,Ia=37813,Da=37814,Ua=37815,Na=37816,Ba=37817,Fa=37818,Oa=37819,ka=37820,za=37821,Qs=36492,Ga=36494,Ha=36495,Fl=36283,Va=36284,Wa=36285,Xa=36286,cc=3e3,On=3001,Ol=3200,kl=3201,lc=0,zl=1,We="",Se="srgb",un="srgb-linear",Ko="display-p3",Fs="display-p3-linear",As="linear",ae="srgb",Cs="rec709",Rs="p3",Vn=7680,qa=519,Gl=512,Hl=513,Vl=514,hc=515,Wl=516,Xl=517,ql=518,Yl=519,ko=35044,Ya="300 es",zo=1035,hn=2e3,Ls=2001;class vi{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;const n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;const i=this._listeners[t];if(i!==void 0){const s=i.indexOf(e);s!==-1&&i.splice(s,1)}}dispatchEvent(t){if(this._listeners===void 0)return;const n=this._listeners[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let s=0,a=i.length;s<a;s++)i[s].call(this,t);t.target=null}}}const Ee=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],to=Math.PI/180,Ps=180/Math.PI;function dn(){const o=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ee[o&255]+Ee[o>>8&255]+Ee[o>>16&255]+Ee[o>>24&255]+"-"+Ee[t&255]+Ee[t>>8&255]+"-"+Ee[t>>16&15|64]+Ee[t>>24&255]+"-"+Ee[e&63|128]+Ee[e>>8&255]+"-"+Ee[e>>16&255]+Ee[e>>24&255]+Ee[n&255]+Ee[n>>8&255]+Ee[n>>16&255]+Ee[n>>24&255]).toLowerCase()}function Ae(o,t,e){return Math.max(t,Math.min(e,o))}function $l(o,t){return(o%t+t)%t}function eo(o,t,e){return(1-e)*o+e*t}function $a(o){return(o&o-1)===0&&o!==0}function Go(o){return Math.pow(2,Math.floor(Math.log(o)/Math.LN2))}function ln(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function ee(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}class ct{constructor(t=0,e=0){ct.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Ae(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),s=this.x-t.x,a=this.y-t.y;return this.x=s*n-a*i+t.x,this.y=s*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class jt{constructor(t,e,n,i,s,a,r,c,l){jt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,r,c,l)}set(t,e,n,i,s,a,r,c,l){const h=this.elements;return h[0]=t,h[1]=i,h[2]=r,h[3]=e,h[4]=s,h[5]=c,h[6]=n,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],r=n[3],c=n[6],l=n[1],h=n[4],d=n[7],u=n[2],f=n[5],g=n[8],y=i[0],m=i[3],p=i[6],x=i[1],v=i[4],M=i[7],R=i[2],T=i[5],E=i[8];return s[0]=a*y+r*x+c*R,s[3]=a*m+r*v+c*T,s[6]=a*p+r*M+c*E,s[1]=l*y+h*x+d*R,s[4]=l*m+h*v+d*T,s[7]=l*p+h*M+d*E,s[2]=u*y+f*x+g*R,s[5]=u*m+f*v+g*T,s[8]=u*p+f*M+g*E,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8];return e*a*h-e*r*l-n*s*h+n*r*c+i*s*l-i*a*c}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8],d=h*a-r*l,u=r*c-h*s,f=l*s-a*c,g=e*d+n*u+i*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const y=1/g;return t[0]=d*y,t[1]=(i*l-h*n)*y,t[2]=(r*n-i*a)*y,t[3]=u*y,t[4]=(h*e-i*c)*y,t[5]=(i*s-r*e)*y,t[6]=f*y,t[7]=(n*c-l*e)*y,t[8]=(a*e-n*s)*y,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,s,a,r){const c=Math.cos(s),l=Math.sin(s);return this.set(n*c,n*l,-n*(c*a+l*r)+a+t,-i*l,i*c,-i*(-l*a+c*r)+r+e,0,0,1),this}scale(t,e){return this.premultiply(no.makeScale(t,e)),this}rotate(t){return this.premultiply(no.makeRotation(-t)),this}translate(t,e){return this.premultiply(no.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const no=new jt;function dc(o){for(let t=o.length-1;t>=0;--t)if(o[t]>=65535)return!0;return!1}function Is(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function jl(){const o=Is("canvas");return o.style.display="block",o}const ja={};function Pi(o){o in ja||(ja[o]=!0,console.warn(o))}const Za=new jt().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Ka=new jt().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Yi={[un]:{transfer:As,primaries:Cs,toReference:o=>o,fromReference:o=>o},[Se]:{transfer:ae,primaries:Cs,toReference:o=>o.convertSRGBToLinear(),fromReference:o=>o.convertLinearToSRGB()},[Fs]:{transfer:As,primaries:Rs,toReference:o=>o.applyMatrix3(Ka),fromReference:o=>o.applyMatrix3(Za)},[Ko]:{transfer:ae,primaries:Rs,toReference:o=>o.convertSRGBToLinear().applyMatrix3(Ka),fromReference:o=>o.applyMatrix3(Za).convertLinearToSRGB()}},Zl=new Set([un,Fs]),te={enabled:!0,_workingColorSpace:un,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(o){if(!Zl.has(o))throw new Error(`Unsupported working color space, "${o}".`);this._workingColorSpace=o},convert:function(o,t,e){if(this.enabled===!1||t===e||!t||!e)return o;const n=Yi[t].toReference,i=Yi[e].fromReference;return i(n(o))},fromWorkingColorSpace:function(o,t){return this.convert(o,this._workingColorSpace,t)},toWorkingColorSpace:function(o,t){return this.convert(o,t,this._workingColorSpace)},getPrimaries:function(o){return Yi[o].primaries},getTransfer:function(o){return o===We?As:Yi[o].transfer}};function fi(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function io(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Wn;class uc{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Wn===void 0&&(Wn=Is("canvas")),Wn.width=t.width,Wn.height=t.height;const n=Wn.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Wn}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Is("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),s=i.data;for(let a=0;a<s.length;a++)s[a]=fi(s[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(fi(e[n]/255)*255):e[n]=fi(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Kl=0;class fc{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Kl++}),this.uuid=dn(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let a=0,r=i.length;a<r;a++)i[a].isDataTexture?s.push(so(i[a].image)):s.push(so(i[a]))}else s=so(i);n.url=s}return e||(t.images[this.uuid]=n),n}}function so(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?uc.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Jl=0;class Ne extends vi{constructor(t=Ne.DEFAULT_IMAGE,e=Ne.DEFAULT_MAPPING,n=Ze,i=Ze,s=He,a=Bi,r=Ke,c=Sn,l=Ne.DEFAULT_ANISOTROPY,h=We){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Jl++}),this.uuid=dn(),this.name="",this.source=new fc(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=a,this.anisotropy=l,this.format=r,this.internalFormat=null,this.type=c,this.offset=new ct(0,0),this.repeat=new ct(1,1),this.center=new ct(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new jt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(Pi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===On?Se:We),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==tc)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Fo:t.x=t.x-Math.floor(t.x);break;case Ze:t.x=t.x<0?0:1;break;case Oo:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Fo:t.y=t.y-Math.floor(t.y);break;case Ze:t.y=t.y<0?0:1;break;case Oo:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Pi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Se?On:cc}set encoding(t){Pi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===On?Se:We}}Ne.DEFAULT_IMAGE=null;Ne.DEFAULT_MAPPING=tc;Ne.DEFAULT_ANISOTROPY=1;class re{constructor(t=0,e=0,n=0,i=1){re.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*s,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*s,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*s,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*s,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,s;const c=t.elements,l=c[0],h=c[4],d=c[8],u=c[1],f=c[5],g=c[9],y=c[2],m=c[6],p=c[10];if(Math.abs(h-u)<.01&&Math.abs(d-y)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+y)<.1&&Math.abs(g+m)<.1&&Math.abs(l+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const v=(l+1)/2,M=(f+1)/2,R=(p+1)/2,T=(h+u)/4,E=(d+y)/4,U=(g+m)/4;return v>M&&v>R?v<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(v),i=T/n,s=E/n):M>R?M<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(M),n=T/i,s=U/i):R<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(R),n=E/s,i=U/s),this.set(n,i,s,e),this}let x=Math.sqrt((m-g)*(m-g)+(d-y)*(d-y)+(u-h)*(u-h));return Math.abs(x)<.001&&(x=1),this.x=(m-g)/x,this.y=(d-y)/x,this.z=(u-h)/x,this.w=Math.acos((l+f+p-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Ql extends vi{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new re(0,0,t,e),this.scissorTest=!1,this.viewport=new re(0,0,t,e);const i={width:t,height:e,depth:1};n.encoding!==void 0&&(Pi("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===On?Se:We),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:He,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new Ne(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;const e=Object.assign({},t.texture.image);return this.texture.source=new fc(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class kn extends Ql{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class pc extends Ne{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ie,this.minFilter=Ie,this.wrapR=Ze,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class th extends Ne{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ie,this.minFilter=Ie,this.wrapR=Ze,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Gi{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,s,a,r){let c=n[i+0],l=n[i+1],h=n[i+2],d=n[i+3];const u=s[a+0],f=s[a+1],g=s[a+2],y=s[a+3];if(r===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d;return}if(r===1){t[e+0]=u,t[e+1]=f,t[e+2]=g,t[e+3]=y;return}if(d!==y||c!==u||l!==f||h!==g){let m=1-r;const p=c*u+l*f+h*g+d*y,x=p>=0?1:-1,v=1-p*p;if(v>Number.EPSILON){const R=Math.sqrt(v),T=Math.atan2(R,p*x);m=Math.sin(m*T)/R,r=Math.sin(r*T)/R}const M=r*x;if(c=c*m+u*M,l=l*m+f*M,h=h*m+g*M,d=d*m+y*M,m===1-r){const R=1/Math.sqrt(c*c+l*l+h*h+d*d);c*=R,l*=R,h*=R,d*=R}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d}static multiplyQuaternionsFlat(t,e,n,i,s,a){const r=n[i],c=n[i+1],l=n[i+2],h=n[i+3],d=s[a],u=s[a+1],f=s[a+2],g=s[a+3];return t[e]=r*g+h*d+c*f-l*u,t[e+1]=c*g+h*u+l*d-r*f,t[e+2]=l*g+h*f+r*u-c*d,t[e+3]=h*g-r*d-c*u-l*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,s=t._z,a=t._order,r=Math.cos,c=Math.sin,l=r(n/2),h=r(i/2),d=r(s/2),u=c(n/2),f=c(i/2),g=c(s/2);switch(a){case"XYZ":this._x=u*h*d+l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d-u*f*g;break;case"YXZ":this._x=u*h*d+l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d+u*f*g;break;case"ZXY":this._x=u*h*d-l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d-u*f*g;break;case"ZYX":this._x=u*h*d-l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d+u*f*g;break;case"YZX":this._x=u*h*d+l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d-u*f*g;break;case"XZY":this._x=u*h*d-l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d+u*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],s=e[8],a=e[1],r=e[5],c=e[9],l=e[2],h=e[6],d=e[10],u=n+r+d;if(u>0){const f=.5/Math.sqrt(u+1);this._w=.25/f,this._x=(h-c)*f,this._y=(s-l)*f,this._z=(a-i)*f}else if(n>r&&n>d){const f=2*Math.sqrt(1+n-r-d);this._w=(h-c)/f,this._x=.25*f,this._y=(i+a)/f,this._z=(s+l)/f}else if(r>d){const f=2*Math.sqrt(1+r-n-d);this._w=(s-l)/f,this._x=(i+a)/f,this._y=.25*f,this._z=(c+h)/f}else{const f=2*Math.sqrt(1+d-n-r);this._w=(a-i)/f,this._x=(s+l)/f,this._y=(c+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ae(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,s=t._z,a=t._w,r=e._x,c=e._y,l=e._z,h=e._w;return this._x=n*h+a*r+i*l-s*c,this._y=i*h+a*c+s*r-n*l,this._z=s*h+a*l+n*c-i*r,this._w=a*h-n*r-i*c-s*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,i=this._y,s=this._z,a=this._w;let r=a*t._w+n*t._x+i*t._y+s*t._z;if(r<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,r=-r):this.copy(t),r>=1)return this._w=a,this._x=n,this._y=i,this._z=s,this;const c=1-r*r;if(c<=Number.EPSILON){const f=1-e;return this._w=f*a+e*this._w,this._x=f*n+e*this._x,this._y=f*i+e*this._y,this._z=f*s+e*this._z,this.normalize(),this}const l=Math.sqrt(c),h=Math.atan2(l,r),d=Math.sin((1-e)*h)/l,u=Math.sin(e*h)/l;return this._w=a*d+this._w*u,this._x=n*d+this._x*u,this._y=i*d+this._y*u,this._z=s*d+this._z*u,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),i=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(e*Math.cos(i),n*Math.sin(s),n*Math.cos(s),e*Math.sin(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class L{constructor(t=0,e=0,n=0){L.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Ja.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Ja.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6]*i,this.y=s[1]*e+s[4]*n+s[7]*i,this.z=s[2]*e+s[5]*n+s[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=t.elements,a=1/(s[3]*e+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*e+s[4]*n+s[8]*i+s[12])*a,this.y=(s[1]*e+s[5]*n+s[9]*i+s[13])*a,this.z=(s[2]*e+s[6]*n+s[10]*i+s[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,s=t.x,a=t.y,r=t.z,c=t.w,l=2*(a*i-r*n),h=2*(r*e-s*i),d=2*(s*n-a*e);return this.x=e+c*l+a*d-r*h,this.y=n+c*h+r*l-s*d,this.z=i+c*d+s*h-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[4]*n+s[8]*i,this.y=s[1]*e+s[5]*n+s[9]*i,this.z=s[2]*e+s[6]*n+s[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,s=t.z,a=e.x,r=e.y,c=e.z;return this.x=i*c-s*r,this.y=s*a-n*c,this.z=n*r-i*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return oo.copy(this).projectOnVector(t),this.sub(oo)}reflect(t){return this.sub(oo.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Ae(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const oo=new L,Ja=new Gi;class Hi{constructor(t=new L(1/0,1/0,1/0),e=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Ye.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Ye.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=Ye.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const s=n.getAttribute("position");if(e===!0&&s!==void 0&&t.isInstancedMesh!==!0)for(let a=0,r=s.count;a<r;a++)t.isMesh===!0?t.getVertexPosition(a,Ye):Ye.fromBufferAttribute(s,a),Ye.applyMatrix4(t.matrixWorld),this.expandByPoint(Ye);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),$i.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),$i.copy(n.boundingBox)),$i.applyMatrix4(t.matrixWorld),this.union($i)}const i=t.children;for(let s=0,a=i.length;s<a;s++)this.expandByObject(i[s],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,Ye),Ye.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(wi),ji.subVectors(this.max,wi),Xn.subVectors(t.a,wi),qn.subVectors(t.b,wi),Yn.subVectors(t.c,wi),fn.subVectors(qn,Xn),pn.subVectors(Yn,qn),Cn.subVectors(Xn,Yn);let e=[0,-fn.z,fn.y,0,-pn.z,pn.y,0,-Cn.z,Cn.y,fn.z,0,-fn.x,pn.z,0,-pn.x,Cn.z,0,-Cn.x,-fn.y,fn.x,0,-pn.y,pn.x,0,-Cn.y,Cn.x,0];return!ao(e,Xn,qn,Yn,ji)||(e=[1,0,0,0,1,0,0,0,1],!ao(e,Xn,qn,Yn,ji))?!1:(Zi.crossVectors(fn,pn),e=[Zi.x,Zi.y,Zi.z],ao(e,Xn,qn,Yn,ji))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Ye).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Ye).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(nn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),nn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),nn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),nn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),nn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),nn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),nn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),nn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(nn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}}const nn=[new L,new L,new L,new L,new L,new L,new L,new L],Ye=new L,$i=new Hi,Xn=new L,qn=new L,Yn=new L,fn=new L,pn=new L,Cn=new L,wi=new L,ji=new L,Zi=new L,Rn=new L;function ao(o,t,e,n,i){for(let s=0,a=o.length-3;s<=a;s+=3){Rn.fromArray(o,s);const r=i.x*Math.abs(Rn.x)+i.y*Math.abs(Rn.y)+i.z*Math.abs(Rn.z),c=t.dot(Rn),l=e.dot(Rn),h=n.dot(Rn);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>r)return!1}return!0}const eh=new Hi,Mi=new L,ro=new L;class Vi{constructor(t=new L,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):eh.setFromPoints(t).getCenter(n);let i=0;for(let s=0,a=t.length;s<a;s++)i=Math.max(i,n.distanceToSquared(t[s]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Mi.subVectors(t,this.center);const e=Mi.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(Mi,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(ro.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Mi.copy(t.center).add(ro)),this.expandByPoint(Mi.copy(t.center).sub(ro))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}}const sn=new L,co=new L,Ki=new L,mn=new L,lo=new L,Ji=new L,ho=new L;class Os{constructor(t=new L,e=new L(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,sn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=sn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(sn.copy(this.origin).addScaledVector(this.direction,e),sn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){co.copy(t).add(e).multiplyScalar(.5),Ki.copy(e).sub(t).normalize(),mn.copy(this.origin).sub(co);const s=t.distanceTo(e)*.5,a=-this.direction.dot(Ki),r=mn.dot(this.direction),c=-mn.dot(Ki),l=mn.lengthSq(),h=Math.abs(1-a*a);let d,u,f,g;if(h>0)if(d=a*c-r,u=a*r-c,g=s*h,d>=0)if(u>=-g)if(u<=g){const y=1/h;d*=y,u*=y,f=d*(d+a*u+2*r)+u*(a*d+u+2*c)+l}else u=s,d=Math.max(0,-(a*u+r)),f=-d*d+u*(u+2*c)+l;else u=-s,d=Math.max(0,-(a*u+r)),f=-d*d+u*(u+2*c)+l;else u<=-g?(d=Math.max(0,-(-a*s+r)),u=d>0?-s:Math.min(Math.max(-s,-c),s),f=-d*d+u*(u+2*c)+l):u<=g?(d=0,u=Math.min(Math.max(-s,-c),s),f=u*(u+2*c)+l):(d=Math.max(0,-(a*s+r)),u=d>0?s:Math.min(Math.max(-s,-c),s),f=-d*d+u*(u+2*c)+l);else u=a>0?-s:s,d=Math.max(0,-(a*u+r)),f=-d*d+u*(u+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,d),i&&i.copy(co).addScaledVector(Ki,u),f}intersectSphere(t,e){sn.subVectors(t.center,this.origin);const n=sn.dot(this.direction),i=sn.dot(sn)-n*n,s=t.radius*t.radius;if(i>s)return null;const a=Math.sqrt(s-i),r=n-a,c=n+a;return c<0?null:r<0?this.at(c,e):this.at(r,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,s,a,r,c;const l=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return l>=0?(n=(t.min.x-u.x)*l,i=(t.max.x-u.x)*l):(n=(t.max.x-u.x)*l,i=(t.min.x-u.x)*l),h>=0?(s=(t.min.y-u.y)*h,a=(t.max.y-u.y)*h):(s=(t.max.y-u.y)*h,a=(t.min.y-u.y)*h),n>a||s>i||((s>n||isNaN(n))&&(n=s),(a<i||isNaN(i))&&(i=a),d>=0?(r=(t.min.z-u.z)*d,c=(t.max.z-u.z)*d):(r=(t.max.z-u.z)*d,c=(t.min.z-u.z)*d),n>c||r>i)||((r>n||n!==n)&&(n=r),(c<i||i!==i)&&(i=c),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,sn)!==null}intersectTriangle(t,e,n,i,s){lo.subVectors(e,t),Ji.subVectors(n,t),ho.crossVectors(lo,Ji);let a=this.direction.dot(ho),r;if(a>0){if(i)return null;r=1}else if(a<0)r=-1,a=-a;else return null;mn.subVectors(this.origin,t);const c=r*this.direction.dot(Ji.crossVectors(mn,Ji));if(c<0)return null;const l=r*this.direction.dot(lo.cross(mn));if(l<0||c+l>a)return null;const h=-r*mn.dot(ho);return h<0?null:this.at(h/a,s)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class ce{constructor(t,e,n,i,s,a,r,c,l,h,d,u,f,g,y,m){ce.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,r,c,l,h,d,u,f,g,y,m)}set(t,e,n,i,s,a,r,c,l,h,d,u,f,g,y,m){const p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=i,p[1]=s,p[5]=a,p[9]=r,p[13]=c,p[2]=l,p[6]=h,p[10]=d,p[14]=u,p[3]=f,p[7]=g,p[11]=y,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new ce().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,i=1/$n.setFromMatrixColumn(t,0).length(),s=1/$n.setFromMatrixColumn(t,1).length(),a=1/$n.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*s,e[5]=n[5]*s,e[6]=n[6]*s,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,s=t.z,a=Math.cos(n),r=Math.sin(n),c=Math.cos(i),l=Math.sin(i),h=Math.cos(s),d=Math.sin(s);if(t.order==="XYZ"){const u=a*h,f=a*d,g=r*h,y=r*d;e[0]=c*h,e[4]=-c*d,e[8]=l,e[1]=f+g*l,e[5]=u-y*l,e[9]=-r*c,e[2]=y-u*l,e[6]=g+f*l,e[10]=a*c}else if(t.order==="YXZ"){const u=c*h,f=c*d,g=l*h,y=l*d;e[0]=u+y*r,e[4]=g*r-f,e[8]=a*l,e[1]=a*d,e[5]=a*h,e[9]=-r,e[2]=f*r-g,e[6]=y+u*r,e[10]=a*c}else if(t.order==="ZXY"){const u=c*h,f=c*d,g=l*h,y=l*d;e[0]=u-y*r,e[4]=-a*d,e[8]=g+f*r,e[1]=f+g*r,e[5]=a*h,e[9]=y-u*r,e[2]=-a*l,e[6]=r,e[10]=a*c}else if(t.order==="ZYX"){const u=a*h,f=a*d,g=r*h,y=r*d;e[0]=c*h,e[4]=g*l-f,e[8]=u*l+y,e[1]=c*d,e[5]=y*l+u,e[9]=f*l-g,e[2]=-l,e[6]=r*c,e[10]=a*c}else if(t.order==="YZX"){const u=a*c,f=a*l,g=r*c,y=r*l;e[0]=c*h,e[4]=y-u*d,e[8]=g*d+f,e[1]=d,e[5]=a*h,e[9]=-r*h,e[2]=-l*h,e[6]=f*d+g,e[10]=u-y*d}else if(t.order==="XZY"){const u=a*c,f=a*l,g=r*c,y=r*l;e[0]=c*h,e[4]=-d,e[8]=l*h,e[1]=u*d+y,e[5]=a*h,e[9]=f*d-g,e[2]=g*d-f,e[6]=r*h,e[10]=y*d+u}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(nh,t,ih)}lookAt(t,e,n){const i=this.elements;return Fe.subVectors(t,e),Fe.lengthSq()===0&&(Fe.z=1),Fe.normalize(),gn.crossVectors(n,Fe),gn.lengthSq()===0&&(Math.abs(n.z)===1?Fe.x+=1e-4:Fe.z+=1e-4,Fe.normalize(),gn.crossVectors(n,Fe)),gn.normalize(),Qi.crossVectors(Fe,gn),i[0]=gn.x,i[4]=Qi.x,i[8]=Fe.x,i[1]=gn.y,i[5]=Qi.y,i[9]=Fe.y,i[2]=gn.z,i[6]=Qi.z,i[10]=Fe.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],r=n[4],c=n[8],l=n[12],h=n[1],d=n[5],u=n[9],f=n[13],g=n[2],y=n[6],m=n[10],p=n[14],x=n[3],v=n[7],M=n[11],R=n[15],T=i[0],E=i[4],U=i[8],w=i[12],S=i[1],P=i[5],F=i[9],j=i[13],I=i[2],B=i[6],O=i[10],Z=i[14],X=i[3],q=i[7],J=i[11],et=i[15];return s[0]=a*T+r*S+c*I+l*X,s[4]=a*E+r*P+c*B+l*q,s[8]=a*U+r*F+c*O+l*J,s[12]=a*w+r*j+c*Z+l*et,s[1]=h*T+d*S+u*I+f*X,s[5]=h*E+d*P+u*B+f*q,s[9]=h*U+d*F+u*O+f*J,s[13]=h*w+d*j+u*Z+f*et,s[2]=g*T+y*S+m*I+p*X,s[6]=g*E+y*P+m*B+p*q,s[10]=g*U+y*F+m*O+p*J,s[14]=g*w+y*j+m*Z+p*et,s[3]=x*T+v*S+M*I+R*X,s[7]=x*E+v*P+M*B+R*q,s[11]=x*U+v*F+M*O+R*J,s[15]=x*w+v*j+M*Z+R*et,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],s=t[12],a=t[1],r=t[5],c=t[9],l=t[13],h=t[2],d=t[6],u=t[10],f=t[14],g=t[3],y=t[7],m=t[11],p=t[15];return g*(+s*c*d-i*l*d-s*r*u+n*l*u+i*r*f-n*c*f)+y*(+e*c*f-e*l*u+s*a*u-i*a*f+i*l*h-s*c*h)+m*(+e*l*d-e*r*f-s*a*d+n*a*f+s*r*h-n*l*h)+p*(-i*r*h-e*c*d+e*r*u+i*a*d-n*a*u+n*c*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8],d=t[9],u=t[10],f=t[11],g=t[12],y=t[13],m=t[14],p=t[15],x=d*m*l-y*u*l+y*c*f-r*m*f-d*c*p+r*u*p,v=g*u*l-h*m*l-g*c*f+a*m*f+h*c*p-a*u*p,M=h*y*l-g*d*l+g*r*f-a*y*f-h*r*p+a*d*p,R=g*d*c-h*y*c-g*r*u+a*y*u+h*r*m-a*d*m,T=e*x+n*v+i*M+s*R;if(T===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const E=1/T;return t[0]=x*E,t[1]=(y*u*s-d*m*s-y*i*f+n*m*f+d*i*p-n*u*p)*E,t[2]=(r*m*s-y*c*s+y*i*l-n*m*l-r*i*p+n*c*p)*E,t[3]=(d*c*s-r*u*s-d*i*l+n*u*l+r*i*f-n*c*f)*E,t[4]=v*E,t[5]=(h*m*s-g*u*s+g*i*f-e*m*f-h*i*p+e*u*p)*E,t[6]=(g*c*s-a*m*s-g*i*l+e*m*l+a*i*p-e*c*p)*E,t[7]=(a*u*s-h*c*s+h*i*l-e*u*l-a*i*f+e*c*f)*E,t[8]=M*E,t[9]=(g*d*s-h*y*s-g*n*f+e*y*f+h*n*p-e*d*p)*E,t[10]=(a*y*s-g*r*s+g*n*l-e*y*l-a*n*p+e*r*p)*E,t[11]=(h*r*s-a*d*s-h*n*l+e*d*l+a*n*f-e*r*f)*E,t[12]=R*E,t[13]=(h*y*i-g*d*i+g*n*u-e*y*u-h*n*m+e*d*m)*E,t[14]=(g*r*i-a*y*i-g*n*c+e*y*c+a*n*m-e*r*m)*E,t[15]=(a*d*i-h*r*i+h*n*c-e*d*c-a*n*u+e*r*u)*E,this}scale(t){const e=this.elements,n=t.x,i=t.y,s=t.z;return e[0]*=n,e[4]*=i,e[8]*=s,e[1]*=n,e[5]*=i,e[9]*=s,e[2]*=n,e[6]*=i,e[10]*=s,e[3]*=n,e[7]*=i,e[11]*=s,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),s=1-n,a=t.x,r=t.y,c=t.z,l=s*a,h=s*r;return this.set(l*a+n,l*r-i*c,l*c+i*r,0,l*r+i*c,h*r+n,h*c-i*a,0,l*c-i*r,h*c+i*a,s*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,s,a){return this.set(1,n,s,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,s=e._x,a=e._y,r=e._z,c=e._w,l=s+s,h=a+a,d=r+r,u=s*l,f=s*h,g=s*d,y=a*h,m=a*d,p=r*d,x=c*l,v=c*h,M=c*d,R=n.x,T=n.y,E=n.z;return i[0]=(1-(y+p))*R,i[1]=(f+M)*R,i[2]=(g-v)*R,i[3]=0,i[4]=(f-M)*T,i[5]=(1-(u+p))*T,i[6]=(m+x)*T,i[7]=0,i[8]=(g+v)*E,i[9]=(m-x)*E,i[10]=(1-(u+y))*E,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;let s=$n.set(i[0],i[1],i[2]).length();const a=$n.set(i[4],i[5],i[6]).length(),r=$n.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),t.x=i[12],t.y=i[13],t.z=i[14],$e.copy(this);const l=1/s,h=1/a,d=1/r;return $e.elements[0]*=l,$e.elements[1]*=l,$e.elements[2]*=l,$e.elements[4]*=h,$e.elements[5]*=h,$e.elements[6]*=h,$e.elements[8]*=d,$e.elements[9]*=d,$e.elements[10]*=d,e.setFromRotationMatrix($e),n.x=s,n.y=a,n.z=r,this}makePerspective(t,e,n,i,s,a,r=hn){const c=this.elements,l=2*s/(e-t),h=2*s/(n-i),d=(e+t)/(e-t),u=(n+i)/(n-i);let f,g;if(r===hn)f=-(a+s)/(a-s),g=-2*a*s/(a-s);else if(r===Ls)f=-a/(a-s),g=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+r);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=h,c[9]=u,c[13]=0,c[2]=0,c[6]=0,c[10]=f,c[14]=g,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,i,s,a,r=hn){const c=this.elements,l=1/(e-t),h=1/(n-i),d=1/(a-s),u=(e+t)*l,f=(n+i)*h;let g,y;if(r===hn)g=(a+s)*d,y=-2*d;else if(r===Ls)g=s*d,y=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+r);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-u,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-f,c[2]=0,c[6]=0,c[10]=y,c[14]=-g,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const $n=new L,$e=new ce,nh=new L(0,0,0),ih=new L(1,1,1),gn=new L,Qi=new L,Fe=new L,Qa=new ce,tr=new Gi;class ks{constructor(t=0,e=0,n=0,i=ks.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,s=i[0],a=i[4],r=i[8],c=i[1],l=i[5],h=i[9],d=i[2],u=i[6],f=i[10];switch(e){case"XYZ":this._y=Math.asin(Ae(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Ae(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(r,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,s),this._z=0);break;case"ZXY":this._x=Math.asin(Ae(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,f),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-Ae(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,f),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Ae(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-d,s)):(this._x=0,this._y=Math.atan2(r,f));break;case"XZY":this._z=Math.asin(-Ae(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(r,s)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Qa.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Qa,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return tr.setFromEuler(this),this.setFromQuaternion(tr,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}ks.DEFAULT_ORDER="XYZ";class Jo{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let sh=0;const er=new L,jn=new Gi,on=new ce,ts=new L,Si=new L,oh=new L,ah=new Gi,nr=new L(1,0,0),ir=new L(0,1,0),sr=new L(0,0,1),rh={type:"added"},ch={type:"removed"};class fe extends vi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:sh++}),this.uuid=dn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=fe.DEFAULT_UP.clone();const t=new L,e=new ks,n=new Gi,i=new L(1,1,1);function s(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new ce},normalMatrix:{value:new jt}}),this.matrix=new ce,this.matrixWorld=new ce,this.matrixAutoUpdate=fe.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=fe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Jo,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return jn.setFromAxisAngle(t,e),this.quaternion.multiply(jn),this}rotateOnWorldAxis(t,e){return jn.setFromAxisAngle(t,e),this.quaternion.premultiply(jn),this}rotateX(t){return this.rotateOnAxis(nr,t)}rotateY(t){return this.rotateOnAxis(ir,t)}rotateZ(t){return this.rotateOnAxis(sr,t)}translateOnAxis(t,e){return er.copy(t).applyQuaternion(this.quaternion),this.position.add(er.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(nr,t)}translateY(t){return this.translateOnAxis(ir,t)}translateZ(t){return this.translateOnAxis(sr,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(on.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?ts.copy(t):ts.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),Si.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?on.lookAt(Si,ts,this.up):on.lookAt(ts,Si,this.up),this.quaternion.setFromRotationMatrix(on),i&&(on.extractRotation(i.matrixWorld),jn.setFromRotationMatrix(on),this.quaternion.premultiply(jn.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(rh)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(ch)),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),on.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),on.multiply(t.parent.matrixWorld)),t.applyMatrix4(on),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let s=0,a=i.length;s<a;s++)i[s].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Si,t,oh),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Si,ah,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++){const s=e[n];(s.matrixWorldAutoUpdate===!0||t===!0)&&s.updateMatrixWorld(t)}}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){const i=this.children;for(let s=0,a=i.length;s<a;s++){const r=i[s];r.matrixWorldAutoUpdate===!0&&r.updateWorldMatrix(!1,!0)}}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(r=>({boxInitialized:r.boxInitialized,boxMin:r.box.min.toArray(),boxMax:r.box.max.toArray(),sphereInitialized:r.sphereInitialized,sphereRadius:r.sphere.radius,sphereCenter:r.sphere.center.toArray()})),i.maxGeometryCount=this._maxGeometryCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function s(r,c){return r[c.uuid]===void 0&&(r[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(t.geometries,this.geometry);const r=this.geometry.parameters;if(r!==void 0&&r.shapes!==void 0){const c=r.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const d=c[l];s(t.shapes,d)}else s(t.shapes,c)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const r=[];for(let c=0,l=this.material.length;c<l;c++)r.push(s(t.materials,this.material[c]));i.material=r}else i.material=s(t.materials,this.material);if(this.children.length>0){i.children=[];for(let r=0;r<this.children.length;r++)i.children.push(this.children[r].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let r=0;r<this.animations.length;r++){const c=this.animations[r];i.animations.push(s(t.animations,c))}}if(e){const r=a(t.geometries),c=a(t.materials),l=a(t.textures),h=a(t.images),d=a(t.shapes),u=a(t.skeletons),f=a(t.animations),g=a(t.nodes);r.length>0&&(n.geometries=r),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),d.length>0&&(n.shapes=d),u.length>0&&(n.skeletons=u),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=i,n;function a(r){const c=[];for(const l in r){const h=r[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}}fe.DEFAULT_UP=new L(0,1,0);fe.DEFAULT_MATRIX_AUTO_UPDATE=!0;fe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const je=new L,an=new L,uo=new L,rn=new L,Zn=new L,Kn=new L,or=new L,fo=new L,po=new L,mo=new L;let es=!1;class Ve{constructor(t=new L,e=new L,n=new L){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),je.subVectors(t,e),i.cross(je);const s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(t,e,n,i,s){je.subVectors(i,e),an.subVectors(n,e),uo.subVectors(t,e);const a=je.dot(je),r=je.dot(an),c=je.dot(uo),l=an.dot(an),h=an.dot(uo),d=a*l-r*r;if(d===0)return s.set(0,0,0),null;const u=1/d,f=(l*c-r*h)*u,g=(a*h-r*c)*u;return s.set(1-f-g,g,f)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,rn)===null?!1:rn.x>=0&&rn.y>=0&&rn.x+rn.y<=1}static getUV(t,e,n,i,s,a,r,c){return es===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),es=!0),this.getInterpolation(t,e,n,i,s,a,r,c)}static getInterpolation(t,e,n,i,s,a,r,c){return this.getBarycoord(t,e,n,i,rn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,rn.x),c.addScaledVector(a,rn.y),c.addScaledVector(r,rn.z),c)}static isFrontFacing(t,e,n,i){return je.subVectors(n,e),an.subVectors(t,e),je.cross(an).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return je.subVectors(this.c,this.b),an.subVectors(this.a,this.b),je.cross(an).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Ve.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return Ve.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,i,s){return es===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),es=!0),Ve.getInterpolation(t,this.a,this.b,this.c,e,n,i,s)}getInterpolation(t,e,n,i,s){return Ve.getInterpolation(t,this.a,this.b,this.c,e,n,i,s)}containsPoint(t){return Ve.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Ve.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,s=this.c;let a,r;Zn.subVectors(i,n),Kn.subVectors(s,n),fo.subVectors(t,n);const c=Zn.dot(fo),l=Kn.dot(fo);if(c<=0&&l<=0)return e.copy(n);po.subVectors(t,i);const h=Zn.dot(po),d=Kn.dot(po);if(h>=0&&d<=h)return e.copy(i);const u=c*d-h*l;if(u<=0&&c>=0&&h<=0)return a=c/(c-h),e.copy(n).addScaledVector(Zn,a);mo.subVectors(t,s);const f=Zn.dot(mo),g=Kn.dot(mo);if(g>=0&&f<=g)return e.copy(s);const y=f*l-c*g;if(y<=0&&l>=0&&g<=0)return r=l/(l-g),e.copy(n).addScaledVector(Kn,r);const m=h*g-f*d;if(m<=0&&d-h>=0&&f-g>=0)return or.subVectors(s,i),r=(d-h)/(d-h+(f-g)),e.copy(i).addScaledVector(or,r);const p=1/(m+y+u);return a=y*p,r=u*p,e.copy(n).addScaledVector(Zn,a).addScaledVector(Kn,r)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const mc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},yn={h:0,s:0,l:0},ns={h:0,s:0,l:0};function go(o,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?o+(t-o)*6*e:e<1/2?t:e<2/3?o+(t-o)*6*(2/3-e):o}class kt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Se){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,te.toWorkingColorSpace(this,e),this}setRGB(t,e,n,i=te.workingColorSpace){return this.r=t,this.g=e,this.b=n,te.toWorkingColorSpace(this,i),this}setHSL(t,e,n,i=te.workingColorSpace){if(t=$l(t,1),e=Ae(e,0,1),n=Ae(n,0,1),e===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+e):n+e-n*e,a=2*n-s;this.r=go(a,s,t+1/3),this.g=go(a,s,t),this.b=go(a,s,t-1/3)}return te.toWorkingColorSpace(this,i),this}setStyle(t,e=Se){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let s;const a=i[1],r=i[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,e);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,e);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const s=i[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(s,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Se){const n=mc[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=fi(t.r),this.g=fi(t.g),this.b=fi(t.b),this}copyLinearToSRGB(t){return this.r=io(t.r),this.g=io(t.g),this.b=io(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Se){return te.fromWorkingColorSpace(Te.copy(this),t),Math.round(Ae(Te.r*255,0,255))*65536+Math.round(Ae(Te.g*255,0,255))*256+Math.round(Ae(Te.b*255,0,255))}getHexString(t=Se){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=te.workingColorSpace){te.fromWorkingColorSpace(Te.copy(this),e);const n=Te.r,i=Te.g,s=Te.b,a=Math.max(n,i,s),r=Math.min(n,i,s);let c,l;const h=(r+a)/2;if(r===a)c=0,l=0;else{const d=a-r;switch(l=h<=.5?d/(a+r):d/(2-a-r),a){case n:c=(i-s)/d+(i<s?6:0);break;case i:c=(s-n)/d+2;break;case s:c=(n-i)/d+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=te.workingColorSpace){return te.fromWorkingColorSpace(Te.copy(this),e),t.r=Te.r,t.g=Te.g,t.b=Te.b,t}getStyle(t=Se){te.fromWorkingColorSpace(Te.copy(this),t);const e=Te.r,n=Te.g,i=Te.b;return t!==Se?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(yn),this.setHSL(yn.h+t,yn.s+e,yn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(yn),t.getHSL(ns);const n=eo(yn.h,ns.h,e),i=eo(yn.s,ns.s,e),s=eo(yn.l,ns.l,e);return this.setHSL(n,i,s),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,s=t.elements;return this.r=s[0]*e+s[3]*n+s[6]*i,this.g=s[1]*e+s[4]*n+s[7]*i,this.b=s[2]*e+s[5]*n+s[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Te=new kt;kt.NAMES=mc;let lh=0;class En extends vi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:lh++}),this.uuid=dn(),this.name="",this.type="Material",this.blending=ui,this.side=bn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Do,this.blendDst=Uo,this.blendEquation=Un,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new kt(0,0,0),this.blendAlpha=0,this.depthFunc=Ts,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=qa,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Vn,this.stencilZFail=Vn,this.stencilZPass=Vn,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==ui&&(n.blending=this.blending),this.side!==bn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Do&&(n.blendSrc=this.blendSrc),this.blendDst!==Uo&&(n.blendDst=this.blendDst),this.blendEquation!==Un&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Ts&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==qa&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Vn&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Vn&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Vn&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(s){const a=[];for(const r in s){const c=s[r];delete c.metadata,a.push(c)}return a}if(e){const s=i(t.textures),a=i(t.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=e[s].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class Lt extends En{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new kt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=jo,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const me=new L,is=new ct;class qe{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=ko,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=_n,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)is.fromBufferAttribute(this,e),is.applyMatrix3(t),this.setXY(e,is.x,is.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)me.fromBufferAttribute(this,e),me.applyMatrix3(t),this.setXYZ(e,me.x,me.y,me.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)me.fromBufferAttribute(this,e),me.applyMatrix4(t),this.setXYZ(e,me.x,me.y,me.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)me.fromBufferAttribute(this,e),me.applyNormalMatrix(t),this.setXYZ(e,me.x,me.y,me.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)me.fromBufferAttribute(this,e),me.transformDirection(t),this.setXYZ(e,me.x,me.y,me.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=ln(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ee(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=ln(e,this.array)),e}setX(t,e){return this.normalized&&(e=ee(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=ln(e,this.array)),e}setY(t,e){return this.normalized&&(e=ee(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=ln(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ee(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=ln(e,this.array)),e}setW(t,e){return this.normalized&&(e=ee(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=ee(e,this.array),n=ee(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=ee(e,this.array),n=ee(n,this.array),i=ee(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,s){return t*=this.itemSize,this.normalized&&(e=ee(e,this.array),n=ee(n,this.array),i=ee(i,this.array),s=ee(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=s,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==ko&&(t.usage=this.usage),t}}class gc extends qe{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class yc extends qe{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class Kt extends qe{constructor(t,e,n){super(new Float32Array(t),e,n)}}let hh=0;const Ge=new ce,yo=new fe,Jn=new L,Oe=new Hi,bi=new Hi,Me=new L;class ge extends vi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:hh++}),this.uuid=dn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(dc(t)?yc:gc)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new jt().getNormalMatrix(t);n.applyNormalMatrix(s),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Ge.makeRotationFromQuaternion(t),this.applyMatrix4(Ge),this}rotateX(t){return Ge.makeRotationX(t),this.applyMatrix4(Ge),this}rotateY(t){return Ge.makeRotationY(t),this.applyMatrix4(Ge),this}rotateZ(t){return Ge.makeRotationZ(t),this.applyMatrix4(Ge),this}translate(t,e,n){return Ge.makeTranslation(t,e,n),this.applyMatrix4(Ge),this}scale(t,e,n){return Ge.makeScale(t,e,n),this.applyMatrix4(Ge),this}lookAt(t){return yo.lookAt(t),yo.updateMatrix(),this.applyMatrix4(yo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Jn).negate(),this.translate(Jn.x,Jn.y,Jn.z),this}setFromPoints(t){const e=[];for(let n=0,i=t.length;n<i;n++){const s=t[n];e.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Kt(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Hi);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const s=e[n];Oe.setFromBufferAttribute(s),this.morphTargetsRelative?(Me.addVectors(this.boundingBox.min,Oe.min),this.boundingBox.expandByPoint(Me),Me.addVectors(this.boundingBox.max,Oe.max),this.boundingBox.expandByPoint(Me)):(this.boundingBox.expandByPoint(Oe.min),this.boundingBox.expandByPoint(Oe.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Vi);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new L,1/0);return}if(t){const n=this.boundingSphere.center;if(Oe.setFromBufferAttribute(t),e)for(let s=0,a=e.length;s<a;s++){const r=e[s];bi.setFromBufferAttribute(r),this.morphTargetsRelative?(Me.addVectors(Oe.min,bi.min),Oe.expandByPoint(Me),Me.addVectors(Oe.max,bi.max),Oe.expandByPoint(Me)):(Oe.expandByPoint(bi.min),Oe.expandByPoint(bi.max))}Oe.getCenter(n);let i=0;for(let s=0,a=t.count;s<a;s++)Me.fromBufferAttribute(t,s),i=Math.max(i,n.distanceToSquared(Me));if(e)for(let s=0,a=e.length;s<a;s++){const r=e[s],c=this.morphTargetsRelative;for(let l=0,h=r.count;l<h;l++)Me.fromBufferAttribute(r,l),c&&(Jn.fromBufferAttribute(t,l),Me.add(Jn)),i=Math.max(i,n.distanceToSquared(Me))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.array,i=e.position.array,s=e.normal.array,a=e.uv.array,r=i.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new qe(new Float32Array(4*r),4));const c=this.getAttribute("tangent").array,l=[],h=[];for(let S=0;S<r;S++)l[S]=new L,h[S]=new L;const d=new L,u=new L,f=new L,g=new ct,y=new ct,m=new ct,p=new L,x=new L;function v(S,P,F){d.fromArray(i,S*3),u.fromArray(i,P*3),f.fromArray(i,F*3),g.fromArray(a,S*2),y.fromArray(a,P*2),m.fromArray(a,F*2),u.sub(d),f.sub(d),y.sub(g),m.sub(g);const j=1/(y.x*m.y-m.x*y.y);isFinite(j)&&(p.copy(u).multiplyScalar(m.y).addScaledVector(f,-y.y).multiplyScalar(j),x.copy(f).multiplyScalar(y.x).addScaledVector(u,-m.x).multiplyScalar(j),l[S].add(p),l[P].add(p),l[F].add(p),h[S].add(x),h[P].add(x),h[F].add(x))}let M=this.groups;M.length===0&&(M=[{start:0,count:n.length}]);for(let S=0,P=M.length;S<P;++S){const F=M[S],j=F.start,I=F.count;for(let B=j,O=j+I;B<O;B+=3)v(n[B+0],n[B+1],n[B+2])}const R=new L,T=new L,E=new L,U=new L;function w(S){E.fromArray(s,S*3),U.copy(E);const P=l[S];R.copy(P),R.sub(E.multiplyScalar(E.dot(P))).normalize(),T.crossVectors(U,P);const j=T.dot(h[S])<0?-1:1;c[S*4]=R.x,c[S*4+1]=R.y,c[S*4+2]=R.z,c[S*4+3]=j}for(let S=0,P=M.length;S<P;++S){const F=M[S],j=F.start,I=F.count;for(let B=j,O=j+I;B<O;B+=3)w(n[B+0]),w(n[B+1]),w(n[B+2])}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new qe(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let u=0,f=n.count;u<f;u++)n.setXYZ(u,0,0,0);const i=new L,s=new L,a=new L,r=new L,c=new L,l=new L,h=new L,d=new L;if(t)for(let u=0,f=t.count;u<f;u+=3){const g=t.getX(u+0),y=t.getX(u+1),m=t.getX(u+2);i.fromBufferAttribute(e,g),s.fromBufferAttribute(e,y),a.fromBufferAttribute(e,m),h.subVectors(a,s),d.subVectors(i,s),h.cross(d),r.fromBufferAttribute(n,g),c.fromBufferAttribute(n,y),l.fromBufferAttribute(n,m),r.add(h),c.add(h),l.add(h),n.setXYZ(g,r.x,r.y,r.z),n.setXYZ(y,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let u=0,f=e.count;u<f;u+=3)i.fromBufferAttribute(e,u+0),s.fromBufferAttribute(e,u+1),a.fromBufferAttribute(e,u+2),h.subVectors(a,s),d.subVectors(i,s),h.cross(d),n.setXYZ(u+0,h.x,h.y,h.z),n.setXYZ(u+1,h.x,h.y,h.z),n.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Me.fromBufferAttribute(t,e),Me.normalize(),t.setXYZ(e,Me.x,Me.y,Me.z)}toNonIndexed(){function t(r,c){const l=r.array,h=r.itemSize,d=r.normalized,u=new l.constructor(c.length*h);let f=0,g=0;for(let y=0,m=c.length;y<m;y++){r.isInterleavedBufferAttribute?f=c[y]*r.data.stride+r.offset:f=c[y]*h;for(let p=0;p<h;p++)u[g++]=l[f++]}return new qe(u,h,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new ge,n=this.index.array,i=this.attributes;for(const r in i){const c=i[r],l=t(c,n);e.setAttribute(r,l)}const s=this.morphAttributes;for(const r in s){const c=[],l=s[r];for(let h=0,d=l.length;h<d;h++){const u=l[h],f=t(u,n);c.push(f)}e.morphAttributes[r]=c}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let r=0,c=a.length;r<c;r++){const l=a[r];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const i={};let s=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let d=0,u=l.length;d<u;d++){const f=l[d];h.push(f.toJSON(t.data))}h.length>0&&(i[c]=h,s=!0)}s&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const r=this.boundingSphere;return r!==null&&(t.data.boundingSphere={center:r.center.toArray(),radius:r.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone(e));const i=t.attributes;for(const l in i){const h=i[l];this.setAttribute(l,h.clone(e))}const s=t.morphAttributes;for(const l in s){const h=[],d=s[l];for(let u=0,f=d.length;u<f;u++)h.push(d[u].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let l=0,h=a.length;l<h;l++){const d=a[l];this.addGroup(d.start,d.count,d.materialIndex)}const r=t.boundingBox;r!==null&&(this.boundingBox=r.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const ar=new ce,Ln=new Os,ss=new Vi,rr=new L,Qn=new L,ti=new L,ei=new L,vo=new L,os=new L,as=new ct,rs=new ct,cs=new ct,cr=new L,lr=new L,hr=new L,ls=new L,hs=new L;class _ extends fe{constructor(t=new ge,e=new Lt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const r=this.morphTargetInfluences;if(s&&r){os.set(0,0,0);for(let c=0,l=s.length;c<l;c++){const h=r[c],d=s[c];h!==0&&(vo.fromBufferAttribute(d,t),a?os.addScaledVector(vo,h):os.addScaledVector(vo.sub(e),h))}e.add(os)}return e}raycast(t,e){const n=this.geometry,i=this.material,s=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ss.copy(n.boundingSphere),ss.applyMatrix4(s),Ln.copy(t.ray).recast(t.near),!(ss.containsPoint(Ln.origin)===!1&&(Ln.intersectSphere(ss,rr)===null||Ln.origin.distanceToSquared(rr)>(t.far-t.near)**2))&&(ar.copy(s).invert(),Ln.copy(t.ray).applyMatrix4(ar),!(n.boundingBox!==null&&Ln.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Ln)))}_computeIntersections(t,e,n){let i;const s=this.geometry,a=this.material,r=s.index,c=s.attributes.position,l=s.attributes.uv,h=s.attributes.uv1,d=s.attributes.normal,u=s.groups,f=s.drawRange;if(r!==null)if(Array.isArray(a))for(let g=0,y=u.length;g<y;g++){const m=u[g],p=a[m.materialIndex],x=Math.max(m.start,f.start),v=Math.min(r.count,Math.min(m.start+m.count,f.start+f.count));for(let M=x,R=v;M<R;M+=3){const T=r.getX(M),E=r.getX(M+1),U=r.getX(M+2);i=ds(this,p,t,n,l,h,d,T,E,U),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,f.start),y=Math.min(r.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){const x=r.getX(m),v=r.getX(m+1),M=r.getX(m+2);i=ds(this,a,t,n,l,h,d,x,v,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(c!==void 0)if(Array.isArray(a))for(let g=0,y=u.length;g<y;g++){const m=u[g],p=a[m.materialIndex],x=Math.max(m.start,f.start),v=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let M=x,R=v;M<R;M+=3){const T=M,E=M+1,U=M+2;i=ds(this,p,t,n,l,h,d,T,E,U),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,f.start),y=Math.min(c.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){const x=m,v=m+1,M=m+2;i=ds(this,a,t,n,l,h,d,x,v,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}}function dh(o,t,e,n,i,s,a,r){let c;if(t.side===Ue?c=n.intersectTriangle(a,s,i,!0,r):c=n.intersectTriangle(i,s,a,t.side===bn,r),c===null)return null;hs.copy(r),hs.applyMatrix4(o.matrixWorld);const l=e.ray.origin.distanceTo(hs);return l<e.near||l>e.far?null:{distance:l,point:hs.clone(),object:o}}function ds(o,t,e,n,i,s,a,r,c,l){o.getVertexPosition(r,Qn),o.getVertexPosition(c,ti),o.getVertexPosition(l,ei);const h=dh(o,t,e,n,Qn,ti,ei,ls);if(h){i&&(as.fromBufferAttribute(i,r),rs.fromBufferAttribute(i,c),cs.fromBufferAttribute(i,l),h.uv=Ve.getInterpolation(ls,Qn,ti,ei,as,rs,cs,new ct)),s&&(as.fromBufferAttribute(s,r),rs.fromBufferAttribute(s,c),cs.fromBufferAttribute(s,l),h.uv1=Ve.getInterpolation(ls,Qn,ti,ei,as,rs,cs,new ct),h.uv2=h.uv1),a&&(cr.fromBufferAttribute(a,r),lr.fromBufferAttribute(a,c),hr.fromBufferAttribute(a,l),h.normal=Ve.getInterpolation(ls,Qn,ti,ei,cr,lr,hr,new L),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a:r,b:c,c:l,normal:new L,materialIndex:0};Ve.getNormal(Qn,ti,ei,d.normal),h.face=d}return h}class G extends ge{constructor(t=1,e=1,n=1,i=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:s,depthSegments:a};const r=this;i=Math.floor(i),s=Math.floor(s),a=Math.floor(a);const c=[],l=[],h=[],d=[];let u=0,f=0;g("z","y","x",-1,-1,n,e,t,a,s,0),g("z","y","x",1,-1,n,e,-t,a,s,1),g("x","z","y",1,1,t,n,e,i,a,2),g("x","z","y",1,-1,t,n,-e,i,a,3),g("x","y","z",1,-1,t,e,n,i,s,4),g("x","y","z",-1,-1,t,e,-n,i,s,5),this.setIndex(c),this.setAttribute("position",new Kt(l,3)),this.setAttribute("normal",new Kt(h,3)),this.setAttribute("uv",new Kt(d,2));function g(y,m,p,x,v,M,R,T,E,U,w){const S=M/E,P=R/U,F=M/2,j=R/2,I=T/2,B=E+1,O=U+1;let Z=0,X=0;const q=new L;for(let J=0;J<O;J++){const et=J*P-j;for(let rt=0;rt<B;rt++){const H=rt*S-F;q[y]=H*x,q[m]=et*v,q[p]=I,l.push(q.x,q.y,q.z),q[y]=0,q[m]=0,q[p]=T>0?1:-1,h.push(q.x,q.y,q.z),d.push(rt/E),d.push(1-J/U),Z+=1}}for(let J=0;J<U;J++)for(let et=0;et<E;et++){const rt=u+et+B*J,H=u+et+B*(J+1),tt=u+(et+1)+B*(J+1),ut=u+(et+1)+B*J;c.push(rt,H,ut),c.push(H,tt,ut),X+=6}r.addGroup(f,X,w),f+=X,u+=Z}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new G(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function yi(o){const t={};for(const e in o){t[e]={};for(const n in o[e]){const i=o[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function Pe(o){const t={};for(let e=0;e<o.length;e++){const n=yi(o[e]);for(const i in n)t[i]=n[i]}return t}function uh(o){const t=[];for(let e=0;e<o.length;e++)t.push(o[e].clone());return t}function vc(o){return o.getRenderTarget()===null?o.outputColorSpace:te.workingColorSpace}const fh={clone:yi,merge:Pe};var ph=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,mh=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class zn extends En{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=ph,this.fragmentShader=mh,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=yi(t.uniforms),this.uniformsGroups=uh(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class _c extends fe{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ce,this.projectionMatrix=new ce,this.projectionMatrixInverse=new ce,this.coordinateSystem=hn}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class De extends _c{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Ps*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(to*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Ps*2*Math.atan(Math.tan(to*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,i,s,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(to*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,s=-.5*i;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;s+=a.offsetX*i/c,e-=a.offsetY*n/l,i*=a.width/c,n*=a.height/l}const r=this.filmOffset;r!==0&&(s+=t*r/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const ni=-90,ii=1;class gh extends fe{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new De(ni,ii,t,e);i.layers=this.layers,this.add(i);const s=new De(ni,ii,t,e);s.layers=this.layers,this.add(s);const a=new De(ni,ii,t,e);a.layers=this.layers,this.add(a);const r=new De(ni,ii,t,e);r.layers=this.layers,this.add(r);const c=new De(ni,ii,t,e);c.layers=this.layers,this.add(c);const l=new De(ni,ii,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,s,a,r,c]=e;for(const l of e)this.remove(l);if(t===hn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),r.up.set(0,1,0),r.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===Ls)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),r.up.set(0,-1,0),r.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[s,a,r,c,l,h]=this.children,d=t.getRenderTarget(),u=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const y=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,s),t.setRenderTarget(n,1,i),t.render(e,a),t.setRenderTarget(n,2,i),t.render(e,r),t.setRenderTarget(n,3,i),t.render(e,c),t.setRenderTarget(n,4,i),t.render(e,l),n.texture.generateMipmaps=y,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(d,u,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class xc extends Ne{constructor(t,e,n,i,s,a,r,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:pi,super(t,e,n,i,s,a,r,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class yh extends kn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];e.encoding!==void 0&&(Pi("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===On?Se:We),this.texture=new xc(i,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:He}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new G(5,5,5),s=new zn({name:"CubemapFromEquirect",uniforms:yi(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ue,blending:wn});s.uniforms.tEquirect.value=e;const a=new _(i,s),r=e.minFilter;return e.minFilter===Bi&&(e.minFilter=He),new gh(1,10,this).update(t,a),e.minFilter=r,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,i){const s=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(s)}}const _o=new L,vh=new L,_h=new jt;class In{constructor(t=new L(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=_o.subVectors(n,e).cross(vh.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(_o),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const s=-(t.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:e.copy(t.start).addScaledVector(n,s)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||_h.getNormalMatrix(t),i=this.coplanarPoint(_o).applyMatrix4(t),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Pn=new Vi,us=new L;class Qo{constructor(t=new In,e=new In,n=new In,i=new In,s=new In,a=new In){this.planes=[t,e,n,i,s,a]}set(t,e,n,i,s,a){const r=this.planes;return r[0].copy(t),r[1].copy(e),r[2].copy(n),r[3].copy(i),r[4].copy(s),r[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=hn){const n=this.planes,i=t.elements,s=i[0],a=i[1],r=i[2],c=i[3],l=i[4],h=i[5],d=i[6],u=i[7],f=i[8],g=i[9],y=i[10],m=i[11],p=i[12],x=i[13],v=i[14],M=i[15];if(n[0].setComponents(c-s,u-l,m-f,M-p).normalize(),n[1].setComponents(c+s,u+l,m+f,M+p).normalize(),n[2].setComponents(c+a,u+h,m+g,M+x).normalize(),n[3].setComponents(c-a,u-h,m-g,M-x).normalize(),n[4].setComponents(c-r,u-d,m-y,M-v).normalize(),e===hn)n[5].setComponents(c+r,u+d,m+y,M+v).normalize();else if(e===Ls)n[5].setComponents(r,d,y,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Pn.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Pn.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Pn)}intersectsSprite(t){return Pn.center.set(0,0,0),Pn.radius=.7071067811865476,Pn.applyMatrix4(t.matrixWorld),this.intersectsSphere(Pn)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let s=0;s<6;s++)if(e[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(us.x=i.normal.x>0?t.max.x:t.min.x,us.y=i.normal.y>0?t.max.y:t.min.y,us.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(us)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function wc(){let o=null,t=!1,e=null,n=null;function i(s,a){e(s,a),n=o.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=o.requestAnimationFrame(i),t=!0)},stop:function(){o.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(s){e=s},setContext:function(s){o=s}}}function xh(o,t){const e=t.isWebGL2,n=new WeakMap;function i(l,h){const d=l.array,u=l.usage,f=d.byteLength,g=o.createBuffer();o.bindBuffer(h,g),o.bufferData(h,d,u),l.onUploadCallback();let y;if(d instanceof Float32Array)y=o.FLOAT;else if(d instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(e)y=o.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else y=o.UNSIGNED_SHORT;else if(d instanceof Int16Array)y=o.SHORT;else if(d instanceof Uint32Array)y=o.UNSIGNED_INT;else if(d instanceof Int32Array)y=o.INT;else if(d instanceof Int8Array)y=o.BYTE;else if(d instanceof Uint8Array)y=o.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)y=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:g,type:y,bytesPerElement:d.BYTES_PER_ELEMENT,version:l.version,size:f}}function s(l,h,d){const u=h.array,f=h._updateRange,g=h.updateRanges;if(o.bindBuffer(d,l),f.count===-1&&g.length===0&&o.bufferSubData(d,0,u),g.length!==0){for(let y=0,m=g.length;y<m;y++){const p=g[y];e?o.bufferSubData(d,p.start*u.BYTES_PER_ELEMENT,u,p.start,p.count):o.bufferSubData(d,p.start*u.BYTES_PER_ELEMENT,u.subarray(p.start,p.start+p.count))}h.clearUpdateRanges()}f.count!==-1&&(e?o.bufferSubData(d,f.offset*u.BYTES_PER_ELEMENT,u,f.offset,f.count):o.bufferSubData(d,f.offset*u.BYTES_PER_ELEMENT,u.subarray(f.offset,f.offset+f.count)),f.count=-1),h.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),n.get(l)}function r(l){l.isInterleavedBufferAttribute&&(l=l.data);const h=n.get(l);h&&(o.deleteBuffer(h.buffer),n.delete(l))}function c(l,h){if(l.isGLBufferAttribute){const u=n.get(l);(!u||u.version<l.version)&&n.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);const d=n.get(l);if(d===void 0)n.set(l,i(l,h));else if(d.version<l.version){if(d.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(d.buffer,l,h),d.version=l.version}}return{get:a,remove:r,update:c}}class Xe extends ge{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const s=t/2,a=e/2,r=Math.floor(n),c=Math.floor(i),l=r+1,h=c+1,d=t/r,u=e/c,f=[],g=[],y=[],m=[];for(let p=0;p<h;p++){const x=p*u-a;for(let v=0;v<l;v++){const M=v*d-s;g.push(M,-x,0),y.push(0,0,1),m.push(v/r),m.push(1-p/c)}}for(let p=0;p<c;p++)for(let x=0;x<r;x++){const v=x+l*p,M=x+l*(p+1),R=x+1+l*(p+1),T=x+1+l*p;f.push(v,M,T),f.push(M,R,T)}this.setIndex(f),this.setAttribute("position",new Kt(g,3)),this.setAttribute("normal",new Kt(y,3)),this.setAttribute("uv",new Kt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Xe(t.width,t.height,t.widthSegments,t.heightSegments)}}var wh=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Mh=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Sh=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,bh=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Eh=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Th=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ah=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Ch=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Rh=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Lh=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,Ph=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Ih=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Dh=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Uh=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Nh=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Bh=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Fh=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Oh=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,kh=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,zh=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Gh=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Hh=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Vh=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Wh=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Xh=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,qh=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Yh=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,$h=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,jh=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Zh=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Kh="gl_FragColor = linearToOutputTexel( gl_FragColor );",Jh=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Qh=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,td=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,ed=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,nd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,id=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,sd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,od=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,ad=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,rd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,cd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,ld=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,hd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,dd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,ud=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,fd=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,pd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,md=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,gd=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,yd=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,vd=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,_d=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,xd=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,wd=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Md=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Sd=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,bd=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Ed=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Td=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,Ad=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,Cd=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Rd=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Ld=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Pd=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Id=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Dd=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ud=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Nd=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Bd=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Fd=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Od=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,kd=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,zd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Gd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Hd=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Vd=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Wd=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Xd=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,qd=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Yd=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,$d=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,jd=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Zd=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Kd=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Jd=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Qd=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,tu=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,eu=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,nu=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,iu=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,su=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,ou=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,au=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,ru=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,cu=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,lu=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,hu=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,du=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,uu=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,fu=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,pu=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,mu=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,gu=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,yu=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,vu=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,_u=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const xu=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,wu=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Mu=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Su=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,bu=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Eu=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Tu=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Au=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,Cu=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Ru=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Lu=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Pu=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Iu=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Du=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Uu=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Nu=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Bu=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Fu=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ou=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,ku=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zu=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Gu=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Hu=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Vu=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Wu=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Xu=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,qu=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Yu=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$u=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,ju=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Zu=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ku=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ju=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Qu=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Xt={alphahash_fragment:wh,alphahash_pars_fragment:Mh,alphamap_fragment:Sh,alphamap_pars_fragment:bh,alphatest_fragment:Eh,alphatest_pars_fragment:Th,aomap_fragment:Ah,aomap_pars_fragment:Ch,batching_pars_vertex:Rh,batching_vertex:Lh,begin_vertex:Ph,beginnormal_vertex:Ih,bsdfs:Dh,iridescence_fragment:Uh,bumpmap_pars_fragment:Nh,clipping_planes_fragment:Bh,clipping_planes_pars_fragment:Fh,clipping_planes_pars_vertex:Oh,clipping_planes_vertex:kh,color_fragment:zh,color_pars_fragment:Gh,color_pars_vertex:Hh,color_vertex:Vh,common:Wh,cube_uv_reflection_fragment:Xh,defaultnormal_vertex:qh,displacementmap_pars_vertex:Yh,displacementmap_vertex:$h,emissivemap_fragment:jh,emissivemap_pars_fragment:Zh,colorspace_fragment:Kh,colorspace_pars_fragment:Jh,envmap_fragment:Qh,envmap_common_pars_fragment:td,envmap_pars_fragment:ed,envmap_pars_vertex:nd,envmap_physical_pars_fragment:pd,envmap_vertex:id,fog_vertex:sd,fog_pars_vertex:od,fog_fragment:ad,fog_pars_fragment:rd,gradientmap_pars_fragment:cd,lightmap_fragment:ld,lightmap_pars_fragment:hd,lights_lambert_fragment:dd,lights_lambert_pars_fragment:ud,lights_pars_begin:fd,lights_toon_fragment:md,lights_toon_pars_fragment:gd,lights_phong_fragment:yd,lights_phong_pars_fragment:vd,lights_physical_fragment:_d,lights_physical_pars_fragment:xd,lights_fragment_begin:wd,lights_fragment_maps:Md,lights_fragment_end:Sd,logdepthbuf_fragment:bd,logdepthbuf_pars_fragment:Ed,logdepthbuf_pars_vertex:Td,logdepthbuf_vertex:Ad,map_fragment:Cd,map_pars_fragment:Rd,map_particle_fragment:Ld,map_particle_pars_fragment:Pd,metalnessmap_fragment:Id,metalnessmap_pars_fragment:Dd,morphcolor_vertex:Ud,morphnormal_vertex:Nd,morphtarget_pars_vertex:Bd,morphtarget_vertex:Fd,normal_fragment_begin:Od,normal_fragment_maps:kd,normal_pars_fragment:zd,normal_pars_vertex:Gd,normal_vertex:Hd,normalmap_pars_fragment:Vd,clearcoat_normal_fragment_begin:Wd,clearcoat_normal_fragment_maps:Xd,clearcoat_pars_fragment:qd,iridescence_pars_fragment:Yd,opaque_fragment:$d,packing:jd,premultiplied_alpha_fragment:Zd,project_vertex:Kd,dithering_fragment:Jd,dithering_pars_fragment:Qd,roughnessmap_fragment:tu,roughnessmap_pars_fragment:eu,shadowmap_pars_fragment:nu,shadowmap_pars_vertex:iu,shadowmap_vertex:su,shadowmask_pars_fragment:ou,skinbase_vertex:au,skinning_pars_vertex:ru,skinning_vertex:cu,skinnormal_vertex:lu,specularmap_fragment:hu,specularmap_pars_fragment:du,tonemapping_fragment:uu,tonemapping_pars_fragment:fu,transmission_fragment:pu,transmission_pars_fragment:mu,uv_pars_fragment:gu,uv_pars_vertex:yu,uv_vertex:vu,worldpos_vertex:_u,background_vert:xu,background_frag:wu,backgroundCube_vert:Mu,backgroundCube_frag:Su,cube_vert:bu,cube_frag:Eu,depth_vert:Tu,depth_frag:Au,distanceRGBA_vert:Cu,distanceRGBA_frag:Ru,equirect_vert:Lu,equirect_frag:Pu,linedashed_vert:Iu,linedashed_frag:Du,meshbasic_vert:Uu,meshbasic_frag:Nu,meshlambert_vert:Bu,meshlambert_frag:Fu,meshmatcap_vert:Ou,meshmatcap_frag:ku,meshnormal_vert:zu,meshnormal_frag:Gu,meshphong_vert:Hu,meshphong_frag:Vu,meshphysical_vert:Wu,meshphysical_frag:Xu,meshtoon_vert:qu,meshtoon_frag:Yu,points_vert:$u,points_frag:ju,shadow_vert:Zu,shadow_frag:Ku,sprite_vert:Ju,sprite_frag:Qu},pt={common:{diffuse:{value:new kt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new jt},alphaMap:{value:null},alphaMapTransform:{value:new jt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new jt}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new jt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new jt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new jt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new jt},normalScale:{value:new ct(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new jt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new jt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new jt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new jt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new kt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new kt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new jt},alphaTest:{value:0},uvTransform:{value:new jt}},sprite:{diffuse:{value:new kt(16777215)},opacity:{value:1},center:{value:new ct(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new jt},alphaMap:{value:null},alphaMapTransform:{value:new jt},alphaTest:{value:0}}},Qe={basic:{uniforms:Pe([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.fog]),vertexShader:Xt.meshbasic_vert,fragmentShader:Xt.meshbasic_frag},lambert:{uniforms:Pe([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new kt(0)}}]),vertexShader:Xt.meshlambert_vert,fragmentShader:Xt.meshlambert_frag},phong:{uniforms:Pe([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new kt(0)},specular:{value:new kt(1118481)},shininess:{value:30}}]),vertexShader:Xt.meshphong_vert,fragmentShader:Xt.meshphong_frag},standard:{uniforms:Pe([pt.common,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.roughnessmap,pt.metalnessmap,pt.fog,pt.lights,{emissive:{value:new kt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Xt.meshphysical_vert,fragmentShader:Xt.meshphysical_frag},toon:{uniforms:Pe([pt.common,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.gradientmap,pt.fog,pt.lights,{emissive:{value:new kt(0)}}]),vertexShader:Xt.meshtoon_vert,fragmentShader:Xt.meshtoon_frag},matcap:{uniforms:Pe([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,{matcap:{value:null}}]),vertexShader:Xt.meshmatcap_vert,fragmentShader:Xt.meshmatcap_frag},points:{uniforms:Pe([pt.points,pt.fog]),vertexShader:Xt.points_vert,fragmentShader:Xt.points_frag},dashed:{uniforms:Pe([pt.common,pt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Xt.linedashed_vert,fragmentShader:Xt.linedashed_frag},depth:{uniforms:Pe([pt.common,pt.displacementmap]),vertexShader:Xt.depth_vert,fragmentShader:Xt.depth_frag},normal:{uniforms:Pe([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,{opacity:{value:1}}]),vertexShader:Xt.meshnormal_vert,fragmentShader:Xt.meshnormal_frag},sprite:{uniforms:Pe([pt.sprite,pt.fog]),vertexShader:Xt.sprite_vert,fragmentShader:Xt.sprite_frag},background:{uniforms:{uvTransform:{value:new jt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Xt.background_vert,fragmentShader:Xt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Xt.backgroundCube_vert,fragmentShader:Xt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Xt.cube_vert,fragmentShader:Xt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Xt.equirect_vert,fragmentShader:Xt.equirect_frag},distanceRGBA:{uniforms:Pe([pt.common,pt.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Xt.distanceRGBA_vert,fragmentShader:Xt.distanceRGBA_frag},shadow:{uniforms:Pe([pt.lights,pt.fog,{color:{value:new kt(0)},opacity:{value:1}}]),vertexShader:Xt.shadow_vert,fragmentShader:Xt.shadow_frag}};Qe.physical={uniforms:Pe([Qe.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new jt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new jt},clearcoatNormalScale:{value:new ct(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new jt},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new jt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new jt},sheen:{value:0},sheenColor:{value:new kt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new jt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new jt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new jt},transmissionSamplerSize:{value:new ct},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new jt},attenuationDistance:{value:0},attenuationColor:{value:new kt(0)},specularColor:{value:new kt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new jt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new jt},anisotropyVector:{value:new ct},anisotropyMap:{value:null},anisotropyMapTransform:{value:new jt}}]),vertexShader:Xt.meshphysical_vert,fragmentShader:Xt.meshphysical_frag};const fs={r:0,b:0,g:0};function tf(o,t,e,n,i,s,a){const r=new kt(0);let c=s===!0?0:1,l,h,d=null,u=0,f=null;function g(m,p){let x=!1,v=p.isScene===!0?p.background:null;v&&v.isTexture&&(v=(p.backgroundBlurriness>0?e:t).get(v)),v===null?y(r,c):v&&v.isColor&&(y(v,1),x=!0);const M=o.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,a):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(o.autoClear||x)&&o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil),v&&(v.isCubeTexture||v.mapping===Bs)?(h===void 0&&(h=new _(new G(1,1,1),new zn({name:"BackgroundCubeMaterial",uniforms:yi(Qe.backgroundCube.uniforms),vertexShader:Qe.backgroundCube.vertexShader,fragmentShader:Qe.backgroundCube.fragmentShader,side:Ue,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(R,T,E){this.matrixWorld.copyPosition(E.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),h.material.uniforms.envMap.value=v,h.material.uniforms.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=p.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,h.material.toneMapped=te.getTransfer(v.colorSpace)!==ae,(d!==v||u!==v.version||f!==o.toneMapping)&&(h.material.needsUpdate=!0,d=v,u=v.version,f=o.toneMapping),h.layers.enableAll(),m.unshift(h,h.geometry,h.material,0,0,null)):v&&v.isTexture&&(l===void 0&&(l=new _(new Xe(2,2),new zn({name:"BackgroundMaterial",uniforms:yi(Qe.background.uniforms),vertexShader:Qe.background.vertexShader,fragmentShader:Qe.background.fragmentShader,side:bn,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=v,l.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,l.material.toneMapped=te.getTransfer(v.colorSpace)!==ae,v.matrixAutoUpdate===!0&&v.updateMatrix(),l.material.uniforms.uvTransform.value.copy(v.matrix),(d!==v||u!==v.version||f!==o.toneMapping)&&(l.material.needsUpdate=!0,d=v,u=v.version,f=o.toneMapping),l.layers.enableAll(),m.unshift(l,l.geometry,l.material,0,0,null))}function y(m,p){m.getRGB(fs,vc(o)),n.buffers.color.setClear(fs.r,fs.g,fs.b,p,a)}return{getClearColor:function(){return r},setClearColor:function(m,p=1){r.set(m),c=p,y(r,c)},getClearAlpha:function(){return c},setClearAlpha:function(m){c=m,y(r,c)},render:g}}function ef(o,t,e,n){const i=o.getParameter(o.MAX_VERTEX_ATTRIBS),s=n.isWebGL2?null:t.get("OES_vertex_array_object"),a=n.isWebGL2||s!==null,r={},c=m(null);let l=c,h=!1;function d(I,B,O,Z,X){let q=!1;if(a){const J=y(Z,O,B);l!==J&&(l=J,f(l.object)),q=p(I,Z,O,X),q&&x(I,Z,O,X)}else{const J=B.wireframe===!0;(l.geometry!==Z.id||l.program!==O.id||l.wireframe!==J)&&(l.geometry=Z.id,l.program=O.id,l.wireframe=J,q=!0)}X!==null&&e.update(X,o.ELEMENT_ARRAY_BUFFER),(q||h)&&(h=!1,U(I,B,O,Z),X!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,e.get(X).buffer))}function u(){return n.isWebGL2?o.createVertexArray():s.createVertexArrayOES()}function f(I){return n.isWebGL2?o.bindVertexArray(I):s.bindVertexArrayOES(I)}function g(I){return n.isWebGL2?o.deleteVertexArray(I):s.deleteVertexArrayOES(I)}function y(I,B,O){const Z=O.wireframe===!0;let X=r[I.id];X===void 0&&(X={},r[I.id]=X);let q=X[B.id];q===void 0&&(q={},X[B.id]=q);let J=q[Z];return J===void 0&&(J=m(u()),q[Z]=J),J}function m(I){const B=[],O=[],Z=[];for(let X=0;X<i;X++)B[X]=0,O[X]=0,Z[X]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:B,enabledAttributes:O,attributeDivisors:Z,object:I,attributes:{},index:null}}function p(I,B,O,Z){const X=l.attributes,q=B.attributes;let J=0;const et=O.getAttributes();for(const rt in et)if(et[rt].location>=0){const tt=X[rt];let ut=q[rt];if(ut===void 0&&(rt==="instanceMatrix"&&I.instanceMatrix&&(ut=I.instanceMatrix),rt==="instanceColor"&&I.instanceColor&&(ut=I.instanceColor)),tt===void 0||tt.attribute!==ut||ut&&tt.data!==ut.data)return!0;J++}return l.attributesNum!==J||l.index!==Z}function x(I,B,O,Z){const X={},q=B.attributes;let J=0;const et=O.getAttributes();for(const rt in et)if(et[rt].location>=0){let tt=q[rt];tt===void 0&&(rt==="instanceMatrix"&&I.instanceMatrix&&(tt=I.instanceMatrix),rt==="instanceColor"&&I.instanceColor&&(tt=I.instanceColor));const ut={};ut.attribute=tt,tt&&tt.data&&(ut.data=tt.data),X[rt]=ut,J++}l.attributes=X,l.attributesNum=J,l.index=Z}function v(){const I=l.newAttributes;for(let B=0,O=I.length;B<O;B++)I[B]=0}function M(I){R(I,0)}function R(I,B){const O=l.newAttributes,Z=l.enabledAttributes,X=l.attributeDivisors;O[I]=1,Z[I]===0&&(o.enableVertexAttribArray(I),Z[I]=1),X[I]!==B&&((n.isWebGL2?o:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](I,B),X[I]=B)}function T(){const I=l.newAttributes,B=l.enabledAttributes;for(let O=0,Z=B.length;O<Z;O++)B[O]!==I[O]&&(o.disableVertexAttribArray(O),B[O]=0)}function E(I,B,O,Z,X,q,J){J===!0?o.vertexAttribIPointer(I,B,O,X,q):o.vertexAttribPointer(I,B,O,Z,X,q)}function U(I,B,O,Z){if(n.isWebGL2===!1&&(I.isInstancedMesh||Z.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;v();const X=Z.attributes,q=O.getAttributes(),J=B.defaultAttributeValues;for(const et in q){const rt=q[et];if(rt.location>=0){let H=X[et];if(H===void 0&&(et==="instanceMatrix"&&I.instanceMatrix&&(H=I.instanceMatrix),et==="instanceColor"&&I.instanceColor&&(H=I.instanceColor)),H!==void 0){const tt=H.normalized,ut=H.itemSize,Et=e.get(H);if(Et===void 0)continue;const mt=Et.buffer,St=Et.type,Pt=Et.bytesPerElement,wt=n.isWebGL2===!0&&(St===o.INT||St===o.UNSIGNED_INT||H.gpuType===ec);if(H.isInterleavedBufferAttribute){const It=H.data,D=It.stride,ht=H.offset;if(It.isInstancedInterleavedBuffer){for(let K=0;K<rt.locationSize;K++)R(rt.location+K,It.meshPerAttribute);I.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=It.meshPerAttribute*It.count)}else for(let K=0;K<rt.locationSize;K++)M(rt.location+K);o.bindBuffer(o.ARRAY_BUFFER,mt);for(let K=0;K<rt.locationSize;K++)E(rt.location+K,ut/rt.locationSize,St,tt,D*Pt,(ht+ut/rt.locationSize*K)*Pt,wt)}else{if(H.isInstancedBufferAttribute){for(let It=0;It<rt.locationSize;It++)R(rt.location+It,H.meshPerAttribute);I.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=H.meshPerAttribute*H.count)}else for(let It=0;It<rt.locationSize;It++)M(rt.location+It);o.bindBuffer(o.ARRAY_BUFFER,mt);for(let It=0;It<rt.locationSize;It++)E(rt.location+It,ut/rt.locationSize,St,tt,ut*Pt,ut/rt.locationSize*It*Pt,wt)}}else if(J!==void 0){const tt=J[et];if(tt!==void 0)switch(tt.length){case 2:o.vertexAttrib2fv(rt.location,tt);break;case 3:o.vertexAttrib3fv(rt.location,tt);break;case 4:o.vertexAttrib4fv(rt.location,tt);break;default:o.vertexAttrib1fv(rt.location,tt)}}}}T()}function w(){F();for(const I in r){const B=r[I];for(const O in B){const Z=B[O];for(const X in Z)g(Z[X].object),delete Z[X];delete B[O]}delete r[I]}}function S(I){if(r[I.id]===void 0)return;const B=r[I.id];for(const O in B){const Z=B[O];for(const X in Z)g(Z[X].object),delete Z[X];delete B[O]}delete r[I.id]}function P(I){for(const B in r){const O=r[B];if(O[I.id]===void 0)continue;const Z=O[I.id];for(const X in Z)g(Z[X].object),delete Z[X];delete O[I.id]}}function F(){j(),h=!0,l!==c&&(l=c,f(l.object))}function j(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:d,reset:F,resetDefaultState:j,dispose:w,releaseStatesOfGeometry:S,releaseStatesOfProgram:P,initAttributes:v,enableAttribute:M,disableUnusedAttributes:T}}function nf(o,t,e,n){const i=n.isWebGL2;let s;function a(h){s=h}function r(h,d){o.drawArrays(s,h,d),e.update(d,s,1)}function c(h,d,u){if(u===0)return;let f,g;if(i)f=o,g="drawArraysInstanced";else if(f=t.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",f===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}f[g](s,h,d,u),e.update(d,s,u)}function l(h,d,u){if(u===0)return;const f=t.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<u;g++)this.render(h[g],d[g]);else{f.multiDrawArraysWEBGL(s,h,0,d,0,u);let g=0;for(let y=0;y<u;y++)g+=d[y];e.update(g,s,1)}}this.setMode=a,this.render=r,this.renderInstances=c,this.renderMultiDraw=l}function sf(o,t,e){let n;function i(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){const E=t.get("EXT_texture_filter_anisotropic");n=o.getParameter(E.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function s(E){if(E==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";E="mediump"}return E==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&o.constructor.name==="WebGL2RenderingContext";let r=e.precision!==void 0?e.precision:"highp";const c=s(r);c!==r&&(console.warn("THREE.WebGLRenderer:",r,"not supported, using",c,"instead."),r=c);const l=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,d=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),u=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),f=o.getParameter(o.MAX_TEXTURE_SIZE),g=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),y=o.getParameter(o.MAX_VERTEX_ATTRIBS),m=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),p=o.getParameter(o.MAX_VARYING_VECTORS),x=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),v=u>0,M=a||t.has("OES_texture_float"),R=v&&M,T=a?o.getParameter(o.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:i,getMaxPrecision:s,precision:r,logarithmicDepthBuffer:h,maxTextures:d,maxVertexTextures:u,maxTextureSize:f,maxCubemapSize:g,maxAttributes:y,maxVertexUniforms:m,maxVaryings:p,maxFragmentUniforms:x,vertexTextures:v,floatFragmentTextures:M,floatVertexTextures:R,maxSamples:T}}function of(o){const t=this;let e=null,n=0,i=!1,s=!1;const a=new In,r=new jt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,u){const f=d.length!==0||u||n!==0||i;return i=u,n=d.length,f},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(d,u){e=h(d,u,0)},this.setState=function(d,u,f){const g=d.clippingPlanes,y=d.clipIntersection,m=d.clipShadows,p=o.get(d);if(!i||g===null||g.length===0||s&&!m)s?h(null):l();else{const x=s?0:n,v=x*4;let M=p.clippingState||null;c.value=M,M=h(g,u,v,f);for(let R=0;R!==v;++R)M[R]=e[R];p.clippingState=M,this.numIntersection=y?this.numPlanes:0,this.numPlanes+=x}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(d,u,f,g){const y=d!==null?d.length:0;let m=null;if(y!==0){if(m=c.value,g!==!0||m===null){const p=f+y*4,x=u.matrixWorldInverse;r.getNormalMatrix(x),(m===null||m.length<p)&&(m=new Float32Array(p));for(let v=0,M=f;v!==y;++v,M+=4)a.copy(d[v]).applyMatrix4(x,r),a.normal.toArray(m,M),m[M+3]=a.constant}c.value=m,c.needsUpdate=!0}return t.numPlanes=y,t.numIntersection=0,m}}function af(o){let t=new WeakMap;function e(a,r){return r===No?a.mapping=pi:r===Bo&&(a.mapping=mi),a}function n(a){if(a&&a.isTexture){const r=a.mapping;if(r===No||r===Bo)if(t.has(a)){const c=t.get(a).texture;return e(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new yh(c.height/2);return l.fromEquirectangularTexture(o,a),t.set(a,l),a.addEventListener("dispose",i),e(l.texture,a.mapping)}else return null}}return a}function i(a){const r=a.target;r.removeEventListener("dispose",i);const c=t.get(r);c!==void 0&&(t.delete(r),c.dispose())}function s(){t=new WeakMap}return{get:n,dispose:s}}class Mc extends _c{constructor(t=-1,e=1,n=1,i=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let s=n-t,a=n+t,r=i+e,c=i-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,a=s+l*this.view.width,r-=h*this.view.offsetY,c=r-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,r,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}const li=4,dr=[.125,.215,.35,.446,.526,.582],Nn=20,xo=new Mc,ur=new kt;let wo=null,Mo=0,So=0;const Dn=(1+Math.sqrt(5))/2,si=1/Dn,fr=[new L(1,1,1),new L(-1,1,1),new L(1,1,-1),new L(-1,1,-1),new L(0,Dn,si),new L(0,Dn,-si),new L(si,0,Dn),new L(-si,0,Dn),new L(Dn,si,0),new L(-Dn,si,0)];class pr{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100){wo=this._renderer.getRenderTarget(),Mo=this._renderer.getActiveCubeFace(),So=this._renderer.getActiveMipmapLevel(),this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(t,n,i,s),e>0&&this._blur(s,0,0,e),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=yr(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=gr(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(wo,Mo,So),t.scissorTest=!1,ps(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===pi||t.mapping===mi?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),wo=this._renderer.getRenderTarget(),Mo=this._renderer.getActiveCubeFace(),So=this._renderer.getActiveMipmapLevel();const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:He,minFilter:He,generateMipmaps:!1,type:Fi,format:Ke,colorSpace:un,depthBuffer:!1},i=mr(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=mr(t,e,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=rf(s)),this._blurMaterial=cf(s,t,e)}return i}_compileMaterial(t){const e=new _(this._lodPlanes[0],t);this._renderer.compile(e,xo)}_sceneToCubeUV(t,e,n,i){const r=new De(90,1,e,n),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,d=h.autoClear,u=h.toneMapping;h.getClearColor(ur),h.toneMapping=Mn,h.autoClear=!1;const f=new Lt({name:"PMREM.Background",side:Ue,depthWrite:!1,depthTest:!1}),g=new _(new G,f);let y=!1;const m=t.background;m?m.isColor&&(f.color.copy(m),t.background=null,y=!0):(f.color.copy(ur),y=!0);for(let p=0;p<6;p++){const x=p%3;x===0?(r.up.set(0,c[p],0),r.lookAt(l[p],0,0)):x===1?(r.up.set(0,0,c[p]),r.lookAt(0,l[p],0)):(r.up.set(0,c[p],0),r.lookAt(0,0,l[p]));const v=this._cubeSize;ps(i,x*v,p>2?v:0,v,v),h.setRenderTarget(i),y&&h.render(g,r),h.render(t,r)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=u,h.autoClear=d,t.background=m}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===pi||t.mapping===mi;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=yr()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=gr());const s=i?this._cubemapMaterial:this._equirectMaterial,a=new _(this._lodPlanes[0],s),r=s.uniforms;r.envMap.value=t;const c=this._cubeSize;ps(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(a,xo)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let i=1;i<this._lodPlanes.length;i++){const s=Math.sqrt(this._sigmas[i]*this._sigmas[i]-this._sigmas[i-1]*this._sigmas[i-1]),a=fr[(i-1)%fr.length];this._blur(t,i-1,i,s,a)}e.autoClear=n}_blur(t,e,n,i,s){const a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,i,"latitudinal",s),this._halfBlur(a,t,n,n,i,"longitudinal",s)}_halfBlur(t,e,n,i,s,a,r){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,d=new _(this._lodPlanes[i],l),u=l.uniforms,f=this._sizeLods[n]-1,g=isFinite(s)?Math.PI/(2*f):2*Math.PI/(2*Nn-1),y=s/g,m=isFinite(s)?1+Math.floor(h*y):Nn;m>Nn&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Nn}`);const p=[];let x=0;for(let E=0;E<Nn;++E){const U=E/y,w=Math.exp(-U*U/2);p.push(w),E===0?x+=w:E<m&&(x+=2*w)}for(let E=0;E<p.length;E++)p[E]=p[E]/x;u.envMap.value=t.texture,u.samples.value=m,u.weights.value=p,u.latitudinal.value=a==="latitudinal",r&&(u.poleAxis.value=r);const{_lodMax:v}=this;u.dTheta.value=g,u.mipInt.value=v-n;const M=this._sizeLods[i],R=3*M*(i>v-li?i-v+li:0),T=4*(this._cubeSize-M);ps(e,R,T,3*M,2*M),c.setRenderTarget(e),c.render(d,xo)}}function rf(o){const t=[],e=[],n=[];let i=o;const s=o-li+1+dr.length;for(let a=0;a<s;a++){const r=Math.pow(2,i);e.push(r);let c=1/r;a>o-li?c=dr[a-o+li-1]:a===0&&(c=0),n.push(c);const l=1/(r-2),h=-l,d=1+l,u=[h,h,d,h,d,d,h,h,d,d,h,d],f=6,g=6,y=3,m=2,p=1,x=new Float32Array(y*g*f),v=new Float32Array(m*g*f),M=new Float32Array(p*g*f);for(let T=0;T<f;T++){const E=T%3*2/3-1,U=T>2?0:-1,w=[E,U,0,E+2/3,U,0,E+2/3,U+1,0,E,U,0,E+2/3,U+1,0,E,U+1,0];x.set(w,y*g*T),v.set(u,m*g*T);const S=[T,T,T,T,T,T];M.set(S,p*g*T)}const R=new ge;R.setAttribute("position",new qe(x,y)),R.setAttribute("uv",new qe(v,m)),R.setAttribute("faceIndex",new qe(M,p)),t.push(R),i>li&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function mr(o,t,e){const n=new kn(o,t,e);return n.texture.mapping=Bs,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ps(o,t,e,n,i){o.viewport.set(t,e,n,i),o.scissor.set(t,e,n,i)}function cf(o,t,e){const n=new Float32Array(Nn),i=new L(0,1,0);return new zn({name:"SphericalGaussianBlur",defines:{n:Nn,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:ta(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:wn,depthTest:!1,depthWrite:!1})}function gr(){return new zn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:ta(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:wn,depthTest:!1,depthWrite:!1})}function yr(){return new zn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:ta(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:wn,depthTest:!1,depthWrite:!1})}function ta(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function lf(o){let t=new WeakMap,e=null;function n(r){if(r&&r.isTexture){const c=r.mapping,l=c===No||c===Bo,h=c===pi||c===mi;if(l||h)if(r.isRenderTargetTexture&&r.needsPMREMUpdate===!0){r.needsPMREMUpdate=!1;let d=t.get(r);return e===null&&(e=new pr(o)),d=l?e.fromEquirectangular(r,d):e.fromCubemap(r,d),t.set(r,d),d.texture}else{if(t.has(r))return t.get(r).texture;{const d=r.image;if(l&&d&&d.height>0||h&&d&&i(d)){e===null&&(e=new pr(o));const u=l?e.fromEquirectangular(r):e.fromCubemap(r);return t.set(r,u),r.addEventListener("dispose",s),u.texture}else return null}}}return r}function i(r){let c=0;const l=6;for(let h=0;h<l;h++)r[h]!==void 0&&c++;return c===l}function s(r){const c=r.target;c.removeEventListener("dispose",s);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function hf(o){const t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=o.getExtension("WEBGL_depth_texture")||o.getExtension("MOZ_WEBGL_depth_texture")||o.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=o.getExtension("EXT_texture_filter_anisotropic")||o.getExtension("MOZ_EXT_texture_filter_anisotropic")||o.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=o.getExtension("WEBGL_compressed_texture_s3tc")||o.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=o.getExtension("WEBGL_compressed_texture_pvrtc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=o.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){const i=e(n);return i===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function df(o,t,e,n){const i={},s=new WeakMap;function a(d){const u=d.target;u.index!==null&&t.remove(u.index);for(const g in u.attributes)t.remove(u.attributes[g]);for(const g in u.morphAttributes){const y=u.morphAttributes[g];for(let m=0,p=y.length;m<p;m++)t.remove(y[m])}u.removeEventListener("dispose",a),delete i[u.id];const f=s.get(u);f&&(t.remove(f),s.delete(u)),n.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,e.memory.geometries--}function r(d,u){return i[u.id]===!0||(u.addEventListener("dispose",a),i[u.id]=!0,e.memory.geometries++),u}function c(d){const u=d.attributes;for(const g in u)t.update(u[g],o.ARRAY_BUFFER);const f=d.morphAttributes;for(const g in f){const y=f[g];for(let m=0,p=y.length;m<p;m++)t.update(y[m],o.ARRAY_BUFFER)}}function l(d){const u=[],f=d.index,g=d.attributes.position;let y=0;if(f!==null){const x=f.array;y=f.version;for(let v=0,M=x.length;v<M;v+=3){const R=x[v+0],T=x[v+1],E=x[v+2];u.push(R,T,T,E,E,R)}}else if(g!==void 0){const x=g.array;y=g.version;for(let v=0,M=x.length/3-1;v<M;v+=3){const R=v+0,T=v+1,E=v+2;u.push(R,T,T,E,E,R)}}else return;const m=new(dc(u)?yc:gc)(u,1);m.version=y;const p=s.get(d);p&&t.remove(p),s.set(d,m)}function h(d){const u=s.get(d);if(u){const f=d.index;f!==null&&u.version<f.version&&l(d)}else l(d);return s.get(d)}return{get:r,update:c,getWireframeAttribute:h}}function uf(o,t,e,n){const i=n.isWebGL2;let s;function a(f){s=f}let r,c;function l(f){r=f.type,c=f.bytesPerElement}function h(f,g){o.drawElements(s,g,r,f*c),e.update(g,s,1)}function d(f,g,y){if(y===0)return;let m,p;if(i)m=o,p="drawElementsInstanced";else if(m=t.get("ANGLE_instanced_arrays"),p="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[p](s,g,r,f*c,y),e.update(g,s,y)}function u(f,g,y){if(y===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<y;p++)this.render(f[p]/c,g[p]);else{m.multiDrawElementsWEBGL(s,g,0,r,f,0,y);let p=0;for(let x=0;x<y;x++)p+=g[x];e.update(p,s,1)}}this.setMode=a,this.setIndex=l,this.render=h,this.renderInstances=d,this.renderMultiDraw=u}function ff(o){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,r){switch(e.calls++,a){case o.TRIANGLES:e.triangles+=r*(s/3);break;case o.LINES:e.lines+=r*(s/2);break;case o.LINE_STRIP:e.lines+=r*(s-1);break;case o.LINE_LOOP:e.lines+=r*s;break;case o.POINTS:e.points+=r*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function pf(o,t){return o[0]-t[0]}function mf(o,t){return Math.abs(t[1])-Math.abs(o[1])}function gf(o,t,e){const n={},i=new Float32Array(8),s=new WeakMap,a=new re,r=[];for(let l=0;l<8;l++)r[l]=[l,0];function c(l,h,d){const u=l.morphTargetInfluences;if(t.isWebGL2===!0){const f=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,g=f!==void 0?f.length:0;let y=s.get(h);if(y===void 0||y.count!==g){let I=function(){F.dispose(),s.delete(h),h.removeEventListener("dispose",I)};y!==void 0&&y.texture.dispose();const x=h.morphAttributes.position!==void 0,v=h.morphAttributes.normal!==void 0,M=h.morphAttributes.color!==void 0,R=h.morphAttributes.position||[],T=h.morphAttributes.normal||[],E=h.morphAttributes.color||[];let U=0;x===!0&&(U=1),v===!0&&(U=2),M===!0&&(U=3);let w=h.attributes.position.count*U,S=1;w>t.maxTextureSize&&(S=Math.ceil(w/t.maxTextureSize),w=t.maxTextureSize);const P=new Float32Array(w*S*4*g),F=new pc(P,w,S,g);F.type=_n,F.needsUpdate=!0;const j=U*4;for(let B=0;B<g;B++){const O=R[B],Z=T[B],X=E[B],q=w*S*4*B;for(let J=0;J<O.count;J++){const et=J*j;x===!0&&(a.fromBufferAttribute(O,J),P[q+et+0]=a.x,P[q+et+1]=a.y,P[q+et+2]=a.z,P[q+et+3]=0),v===!0&&(a.fromBufferAttribute(Z,J),P[q+et+4]=a.x,P[q+et+5]=a.y,P[q+et+6]=a.z,P[q+et+7]=0),M===!0&&(a.fromBufferAttribute(X,J),P[q+et+8]=a.x,P[q+et+9]=a.y,P[q+et+10]=a.z,P[q+et+11]=X.itemSize===4?a.w:1)}}y={count:g,texture:F,size:new ct(w,S)},s.set(h,y),h.addEventListener("dispose",I)}let m=0;for(let x=0;x<u.length;x++)m+=u[x];const p=h.morphTargetsRelative?1:1-m;d.getUniforms().setValue(o,"morphTargetBaseInfluence",p),d.getUniforms().setValue(o,"morphTargetInfluences",u),d.getUniforms().setValue(o,"morphTargetsTexture",y.texture,e),d.getUniforms().setValue(o,"morphTargetsTextureSize",y.size)}else{const f=u===void 0?0:u.length;let g=n[h.id];if(g===void 0||g.length!==f){g=[];for(let v=0;v<f;v++)g[v]=[v,0];n[h.id]=g}for(let v=0;v<f;v++){const M=g[v];M[0]=v,M[1]=u[v]}g.sort(mf);for(let v=0;v<8;v++)v<f&&g[v][1]?(r[v][0]=g[v][0],r[v][1]=g[v][1]):(r[v][0]=Number.MAX_SAFE_INTEGER,r[v][1]=0);r.sort(pf);const y=h.morphAttributes.position,m=h.morphAttributes.normal;let p=0;for(let v=0;v<8;v++){const M=r[v],R=M[0],T=M[1];R!==Number.MAX_SAFE_INTEGER&&T?(y&&h.getAttribute("morphTarget"+v)!==y[R]&&h.setAttribute("morphTarget"+v,y[R]),m&&h.getAttribute("morphNormal"+v)!==m[R]&&h.setAttribute("morphNormal"+v,m[R]),i[v]=T,p+=T):(y&&h.hasAttribute("morphTarget"+v)===!0&&h.deleteAttribute("morphTarget"+v),m&&h.hasAttribute("morphNormal"+v)===!0&&h.deleteAttribute("morphNormal"+v),i[v]=0)}const x=h.morphTargetsRelative?1:1-p;d.getUniforms().setValue(o,"morphTargetBaseInfluence",x),d.getUniforms().setValue(o,"morphTargetInfluences",i)}}return{update:c}}function yf(o,t,e,n){let i=new WeakMap;function s(c){const l=n.render.frame,h=c.geometry,d=t.get(c,h);if(i.get(d)!==l&&(t.update(d),i.set(d,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",r)===!1&&c.addEventListener("dispose",r),i.get(c)!==l&&(e.update(c.instanceMatrix,o.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,o.ARRAY_BUFFER),i.set(c,l))),c.isSkinnedMesh){const u=c.skeleton;i.get(u)!==l&&(u.update(),i.set(u,l))}return d}function a(){i=new WeakMap}function r(c){const l=c.target;l.removeEventListener("dispose",r),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:s,dispose:a}}class Sc extends Ne{constructor(t,e,n,i,s,a,r,c,l,h){if(h=h!==void 0?h:Fn,h!==Fn&&h!==gi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===Fn&&(n=vn),n===void 0&&h===gi&&(n=Bn),super(null,i,s,a,r,c,h,n,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=r!==void 0?r:Ie,this.minFilter=c!==void 0?c:Ie,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}const bc=new Ne,Ec=new Sc(1,1);Ec.compareFunction=hc;const Tc=new pc,Ac=new th,Cc=new xc,vr=[],_r=[],xr=new Float32Array(16),wr=new Float32Array(9),Mr=new Float32Array(4);function _i(o,t,e){const n=o[0];if(n<=0||n>0)return o;const i=t*e;let s=vr[i];if(s===void 0&&(s=new Float32Array(i),vr[i]=s),t!==0){n.toArray(s,0);for(let a=1,r=0;a!==t;++a)r+=e,o[a].toArray(s,r)}return s}function ve(o,t){if(o.length!==t.length)return!1;for(let e=0,n=o.length;e<n;e++)if(o[e]!==t[e])return!1;return!0}function _e(o,t){for(let e=0,n=t.length;e<n;e++)o[e]=t[e]}function zs(o,t){let e=_r[t];e===void 0&&(e=new Int32Array(t),_r[t]=e);for(let n=0;n!==t;++n)e[n]=o.allocateTextureUnit();return e}function vf(o,t){const e=this.cache;e[0]!==t&&(o.uniform1f(this.addr,t),e[0]=t)}function _f(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ve(e,t))return;o.uniform2fv(this.addr,t),_e(e,t)}}function xf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(o.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(ve(e,t))return;o.uniform3fv(this.addr,t),_e(e,t)}}function wf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ve(e,t))return;o.uniform4fv(this.addr,t),_e(e,t)}}function Mf(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(ve(e,t))return;o.uniformMatrix2fv(this.addr,!1,t),_e(e,t)}else{if(ve(e,n))return;Mr.set(n),o.uniformMatrix2fv(this.addr,!1,Mr),_e(e,n)}}function Sf(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(ve(e,t))return;o.uniformMatrix3fv(this.addr,!1,t),_e(e,t)}else{if(ve(e,n))return;wr.set(n),o.uniformMatrix3fv(this.addr,!1,wr),_e(e,n)}}function bf(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(ve(e,t))return;o.uniformMatrix4fv(this.addr,!1,t),_e(e,t)}else{if(ve(e,n))return;xr.set(n),o.uniformMatrix4fv(this.addr,!1,xr),_e(e,n)}}function Ef(o,t){const e=this.cache;e[0]!==t&&(o.uniform1i(this.addr,t),e[0]=t)}function Tf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ve(e,t))return;o.uniform2iv(this.addr,t),_e(e,t)}}function Af(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ve(e,t))return;o.uniform3iv(this.addr,t),_e(e,t)}}function Cf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ve(e,t))return;o.uniform4iv(this.addr,t),_e(e,t)}}function Rf(o,t){const e=this.cache;e[0]!==t&&(o.uniform1ui(this.addr,t),e[0]=t)}function Lf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ve(e,t))return;o.uniform2uiv(this.addr,t),_e(e,t)}}function Pf(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ve(e,t))return;o.uniform3uiv(this.addr,t),_e(e,t)}}function If(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ve(e,t))return;o.uniform4uiv(this.addr,t),_e(e,t)}}function Df(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i);const s=this.type===o.SAMPLER_2D_SHADOW?Ec:bc;e.setTexture2D(t||s,i)}function Uf(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Ac,i)}function Nf(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||Cc,i)}function Bf(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||Tc,i)}function Ff(o){switch(o){case 5126:return vf;case 35664:return _f;case 35665:return xf;case 35666:return wf;case 35674:return Mf;case 35675:return Sf;case 35676:return bf;case 5124:case 35670:return Ef;case 35667:case 35671:return Tf;case 35668:case 35672:return Af;case 35669:case 35673:return Cf;case 5125:return Rf;case 36294:return Lf;case 36295:return Pf;case 36296:return If;case 35678:case 36198:case 36298:case 36306:case 35682:return Df;case 35679:case 36299:case 36307:return Uf;case 35680:case 36300:case 36308:case 36293:return Nf;case 36289:case 36303:case 36311:case 36292:return Bf}}function Of(o,t){o.uniform1fv(this.addr,t)}function kf(o,t){const e=_i(t,this.size,2);o.uniform2fv(this.addr,e)}function zf(o,t){const e=_i(t,this.size,3);o.uniform3fv(this.addr,e)}function Gf(o,t){const e=_i(t,this.size,4);o.uniform4fv(this.addr,e)}function Hf(o,t){const e=_i(t,this.size,4);o.uniformMatrix2fv(this.addr,!1,e)}function Vf(o,t){const e=_i(t,this.size,9);o.uniformMatrix3fv(this.addr,!1,e)}function Wf(o,t){const e=_i(t,this.size,16);o.uniformMatrix4fv(this.addr,!1,e)}function Xf(o,t){o.uniform1iv(this.addr,t)}function qf(o,t){o.uniform2iv(this.addr,t)}function Yf(o,t){o.uniform3iv(this.addr,t)}function $f(o,t){o.uniform4iv(this.addr,t)}function jf(o,t){o.uniform1uiv(this.addr,t)}function Zf(o,t){o.uniform2uiv(this.addr,t)}function Kf(o,t){o.uniform3uiv(this.addr,t)}function Jf(o,t){o.uniform4uiv(this.addr,t)}function Qf(o,t,e){const n=this.cache,i=t.length,s=zs(e,i);ve(n,s)||(o.uniform1iv(this.addr,s),_e(n,s));for(let a=0;a!==i;++a)e.setTexture2D(t[a]||bc,s[a])}function tp(o,t,e){const n=this.cache,i=t.length,s=zs(e,i);ve(n,s)||(o.uniform1iv(this.addr,s),_e(n,s));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||Ac,s[a])}function ep(o,t,e){const n=this.cache,i=t.length,s=zs(e,i);ve(n,s)||(o.uniform1iv(this.addr,s),_e(n,s));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||Cc,s[a])}function np(o,t,e){const n=this.cache,i=t.length,s=zs(e,i);ve(n,s)||(o.uniform1iv(this.addr,s),_e(n,s));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||Tc,s[a])}function ip(o){switch(o){case 5126:return Of;case 35664:return kf;case 35665:return zf;case 35666:return Gf;case 35674:return Hf;case 35675:return Vf;case 35676:return Wf;case 5124:case 35670:return Xf;case 35667:case 35671:return qf;case 35668:case 35672:return Yf;case 35669:case 35673:return $f;case 5125:return jf;case 36294:return Zf;case 36295:return Kf;case 36296:return Jf;case 35678:case 36198:case 36298:case 36306:case 35682:return Qf;case 35679:case 36299:case 36307:return tp;case 35680:case 36300:case 36308:case 36293:return ep;case 36289:case 36303:case 36311:case 36292:return np}}class sp{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Ff(e.type)}}class op{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=ip(e.type)}}class ap{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let s=0,a=i.length;s!==a;++s){const r=i[s];r.setValue(t,e[r.id],n)}}}const bo=/(\w+)(\])?(\[|\.)?/g;function Sr(o,t){o.seq.push(t),o.map[t.id]=t}function rp(o,t,e){const n=o.name,i=n.length;for(bo.lastIndex=0;;){const s=bo.exec(n),a=bo.lastIndex;let r=s[1];const c=s[2]==="]",l=s[3];if(c&&(r=r|0),l===void 0||l==="["&&a+2===i){Sr(e,l===void 0?new sp(r,o,t):new op(r,o,t));break}else{let d=e.map[r];d===void 0&&(d=new ap(r),Sr(e,d)),e=d}}}class bs{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const s=t.getActiveUniform(e,i),a=t.getUniformLocation(e,s.name);rp(s,a,this)}}setValue(t,e,n,i){const s=this.map[e];s!==void 0&&s.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let s=0,a=e.length;s!==a;++s){const r=e[s],c=n[r.id];c.needsUpdate!==!1&&r.setValue(t,c.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,s=t.length;i!==s;++i){const a=t[i];a.id in e&&n.push(a)}return n}}function br(o,t,e){const n=o.createShader(t);return o.shaderSource(n,e),o.compileShader(n),n}const cp=37297;let lp=0;function hp(o,t){const e=o.split(`
`),n=[],i=Math.max(t-6,0),s=Math.min(t+6,e.length);for(let a=i;a<s;a++){const r=a+1;n.push(`${r===t?">":" "} ${r}: ${e[a]}`)}return n.join(`
`)}function dp(o){const t=te.getPrimaries(te.workingColorSpace),e=te.getPrimaries(o);let n;switch(t===e?n="":t===Rs&&e===Cs?n="LinearDisplayP3ToLinearSRGB":t===Cs&&e===Rs&&(n="LinearSRGBToLinearDisplayP3"),o){case un:case Fs:return[n,"LinearTransferOETF"];case Se:case Ko:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",o),[n,"LinearTransferOETF"]}}function Er(o,t,e){const n=o.getShaderParameter(t,o.COMPILE_STATUS),i=o.getShaderInfoLog(t).trim();if(n&&i==="")return"";const s=/ERROR: 0:(\d+)/.exec(i);if(s){const a=parseInt(s[1]);return e.toUpperCase()+`

`+i+`

`+hp(o.getShaderSource(t),a)}else return i}function up(o,t){const e=dp(t);return`vec4 ${o}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function fp(o,t){let e;switch(t){case Qr:e="Linear";break;case bl:e="Reinhard";break;case El:e="OptimizedCineon";break;case Tl:e="ACESFilmic";break;case Cl:e="AgX";break;case Al:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+o+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function pp(o){return[o.extensionDerivatives||o.envMapCubeUVHeight||o.bumpMap||o.normalMapTangentSpace||o.clearcoatNormalMap||o.flatShading||o.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(o.extensionFragDepth||o.logarithmicDepthBuffer)&&o.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",o.extensionDrawBuffers&&o.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(o.extensionShaderTextureLOD||o.envMap||o.transmission)&&o.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(hi).join(`
`)}function mp(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(hi).join(`
`)}function gp(o){const t=[];for(const e in o){const n=o[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function yp(o,t){const e={},n=o.getProgramParameter(t,o.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const s=o.getActiveAttrib(t,i),a=s.name;let r=1;s.type===o.FLOAT_MAT2&&(r=2),s.type===o.FLOAT_MAT3&&(r=3),s.type===o.FLOAT_MAT4&&(r=4),e[a]={type:s.type,location:o.getAttribLocation(t,a),locationSize:r}}return e}function hi(o){return o!==""}function Tr(o,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Ar(o,t){return o.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const vp=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ho(o){return o.replace(vp,xp)}const _p=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function xp(o,t){let e=Xt[t];if(e===void 0){const n=_p.get(t);if(n!==void 0)e=Xt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Ho(e)}const wp=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Cr(o){return o.replace(wp,Mp)}function Mp(o,t,e,n){let i="";for(let s=parseInt(t);s<parseInt(e);s++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return i}function Rr(o){let t="precision "+o.precision+` float;
precision `+o.precision+" int;";return o.precision==="highp"?t+=`
#define HIGH_PRECISION`:o.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Sp(o){let t="SHADOWMAP_TYPE_BASIC";return o.shadowMapType===$o?t="SHADOWMAP_TYPE_PCF":o.shadowMapType===Jr?t="SHADOWMAP_TYPE_PCF_SOFT":o.shadowMapType===cn&&(t="SHADOWMAP_TYPE_VSM"),t}function bp(o){let t="ENVMAP_TYPE_CUBE";if(o.envMap)switch(o.envMapMode){case pi:case mi:t="ENVMAP_TYPE_CUBE";break;case Bs:t="ENVMAP_TYPE_CUBE_UV";break}return t}function Ep(o){let t="ENVMAP_MODE_REFLECTION";if(o.envMap)switch(o.envMapMode){case mi:t="ENVMAP_MODE_REFRACTION";break}return t}function Tp(o){let t="ENVMAP_BLENDING_NONE";if(o.envMap)switch(o.combine){case jo:t="ENVMAP_BLENDING_MULTIPLY";break;case Ml:t="ENVMAP_BLENDING_MIX";break;case Sl:t="ENVMAP_BLENDING_ADD";break}return t}function Ap(o){const t=o.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function Cp(o,t,e,n){const i=o.getContext(),s=e.defines;let a=e.vertexShader,r=e.fragmentShader;const c=Sp(e),l=bp(e),h=Ep(e),d=Tp(e),u=Ap(e),f=e.isWebGL2?"":pp(e),g=mp(e),y=gp(s),m=i.createProgram();let p,x,v=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(hi).join(`
`),p.length>0&&(p+=`
`),x=[f,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(hi).join(`
`),x.length>0&&(x+=`
`)):(p=[Rr(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(hi).join(`
`),x=[f,Rr(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+d:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Mn?"#define TONE_MAPPING":"",e.toneMapping!==Mn?Xt.tonemapping_pars_fragment:"",e.toneMapping!==Mn?fp("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Xt.colorspace_pars_fragment,up("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(hi).join(`
`)),a=Ho(a),a=Tr(a,e),a=Ar(a,e),r=Ho(r),r=Tr(r,e),r=Ar(r,e),a=Cr(a),r=Cr(r),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,p=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,x=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===Ya?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Ya?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);const M=v+p+a,R=v+x+r,T=br(i,i.VERTEX_SHADER,M),E=br(i,i.FRAGMENT_SHADER,R);i.attachShader(m,T),i.attachShader(m,E),e.index0AttributeName!==void 0?i.bindAttribLocation(m,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(m,0,"position"),i.linkProgram(m);function U(F){if(o.debug.checkShaderErrors){const j=i.getProgramInfoLog(m).trim(),I=i.getShaderInfoLog(T).trim(),B=i.getShaderInfoLog(E).trim();let O=!0,Z=!0;if(i.getProgramParameter(m,i.LINK_STATUS)===!1)if(O=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(i,m,T,E);else{const X=Er(i,T,"vertex"),q=Er(i,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(m,i.VALIDATE_STATUS)+`

Program Info Log: `+j+`
`+X+`
`+q)}else j!==""?console.warn("THREE.WebGLProgram: Program Info Log:",j):(I===""||B==="")&&(Z=!1);Z&&(F.diagnostics={runnable:O,programLog:j,vertexShader:{log:I,prefix:p},fragmentShader:{log:B,prefix:x}})}i.deleteShader(T),i.deleteShader(E),w=new bs(i,m),S=yp(i,m)}let w;this.getUniforms=function(){return w===void 0&&U(this),w};let S;this.getAttributes=function(){return S===void 0&&U(this),S};let P=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return P===!1&&(P=i.getProgramParameter(m,cp)),P},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(m),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=lp++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=T,this.fragmentShader=E,this}let Rp=0;class Lp{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),s=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new Pp(t),e.set(t,n)),n}}class Pp{constructor(t){this.id=Rp++,this.code=t,this.usedTimes=0}}function Ip(o,t,e,n,i,s,a){const r=new Jo,c=new Lp,l=[],h=i.isWebGL2,d=i.logarithmicDepthBuffer,u=i.vertexTextures;let f=i.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(w){return w===0?"uv":`uv${w}`}function m(w,S,P,F,j){const I=F.fog,B=j.geometry,O=w.isMeshStandardMaterial?F.environment:null,Z=(w.isMeshStandardMaterial?e:t).get(w.envMap||O),X=Z&&Z.mapping===Bs?Z.image.height:null,q=g[w.type];w.precision!==null&&(f=i.getMaxPrecision(w.precision),f!==w.precision&&console.warn("THREE.WebGLProgram.getParameters:",w.precision,"not supported, using",f,"instead."));const J=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,et=J!==void 0?J.length:0;let rt=0;B.morphAttributes.position!==void 0&&(rt=1),B.morphAttributes.normal!==void 0&&(rt=2),B.morphAttributes.color!==void 0&&(rt=3);let H,tt,ut,Et;if(q){const Ce=Qe[q];H=Ce.vertexShader,tt=Ce.fragmentShader}else H=w.vertexShader,tt=w.fragmentShader,c.update(w),ut=c.getVertexShaderID(w),Et=c.getFragmentShaderID(w);const mt=o.getRenderTarget(),St=j.isInstancedMesh===!0,Pt=j.isBatchedMesh===!0,wt=!!w.map,It=!!w.matcap,D=!!Z,ht=!!w.aoMap,K=!!w.lightMap,lt=!!w.bumpMap,Q=!!w.normalMap,Rt=!!w.displacementMap,_t=!!w.emissiveMap,A=!!w.metalnessMap,b=!!w.roughnessMap,z=w.anisotropy>0,at=w.clearcoat>0,st=w.iridescence>0,it=w.sheen>0,At=w.transmission>0,gt=z&&!!w.anisotropyMap,Mt=at&&!!w.clearcoatMap,Ut=at&&!!w.clearcoatNormalMap,Ht=at&&!!w.clearcoatRoughnessMap,ot=st&&!!w.iridescenceMap,Jt=st&&!!w.iridescenceThicknessMap,Zt=it&&!!w.sheenColorMap,zt=it&&!!w.sheenRoughnessMap,Dt=!!w.specularMap,bt=!!w.specularColorMap,Wt=!!w.specularIntensityMap,Qt=At&&!!w.transmissionMap,de=At&&!!w.thicknessMap,Yt=!!w.gradientMap,ft=!!w.alphaMap,N=w.alphaTest>0,yt=!!w.alphaHash,vt=!!w.extensions,Ft=!!B.attributes.uv1,Nt=!!B.attributes.uv2,ne=!!B.attributes.uv3;let ie=Mn;return w.toneMapped&&(mt===null||mt.isXRRenderTarget===!0)&&(ie=o.toneMapping),{isWebGL2:h,shaderID:q,shaderType:w.type,shaderName:w.name,vertexShader:H,fragmentShader:tt,defines:w.defines,customVertexShaderID:ut,customFragmentShaderID:Et,isRawShaderMaterial:w.isRawShaderMaterial===!0,glslVersion:w.glslVersion,precision:f,batching:Pt,instancing:St,instancingColor:St&&j.instanceColor!==null,supportsVertexTextures:u,outputColorSpace:mt===null?o.outputColorSpace:mt.isXRRenderTarget===!0?mt.texture.colorSpace:un,map:wt,matcap:It,envMap:D,envMapMode:D&&Z.mapping,envMapCubeUVHeight:X,aoMap:ht,lightMap:K,bumpMap:lt,normalMap:Q,displacementMap:u&&Rt,emissiveMap:_t,normalMapObjectSpace:Q&&w.normalMapType===zl,normalMapTangentSpace:Q&&w.normalMapType===lc,metalnessMap:A,roughnessMap:b,anisotropy:z,anisotropyMap:gt,clearcoat:at,clearcoatMap:Mt,clearcoatNormalMap:Ut,clearcoatRoughnessMap:Ht,iridescence:st,iridescenceMap:ot,iridescenceThicknessMap:Jt,sheen:it,sheenColorMap:Zt,sheenRoughnessMap:zt,specularMap:Dt,specularColorMap:bt,specularIntensityMap:Wt,transmission:At,transmissionMap:Qt,thicknessMap:de,gradientMap:Yt,opaque:w.transparent===!1&&w.blending===ui,alphaMap:ft,alphaTest:N,alphaHash:yt,combine:w.combine,mapUv:wt&&y(w.map.channel),aoMapUv:ht&&y(w.aoMap.channel),lightMapUv:K&&y(w.lightMap.channel),bumpMapUv:lt&&y(w.bumpMap.channel),normalMapUv:Q&&y(w.normalMap.channel),displacementMapUv:Rt&&y(w.displacementMap.channel),emissiveMapUv:_t&&y(w.emissiveMap.channel),metalnessMapUv:A&&y(w.metalnessMap.channel),roughnessMapUv:b&&y(w.roughnessMap.channel),anisotropyMapUv:gt&&y(w.anisotropyMap.channel),clearcoatMapUv:Mt&&y(w.clearcoatMap.channel),clearcoatNormalMapUv:Ut&&y(w.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ht&&y(w.clearcoatRoughnessMap.channel),iridescenceMapUv:ot&&y(w.iridescenceMap.channel),iridescenceThicknessMapUv:Jt&&y(w.iridescenceThicknessMap.channel),sheenColorMapUv:Zt&&y(w.sheenColorMap.channel),sheenRoughnessMapUv:zt&&y(w.sheenRoughnessMap.channel),specularMapUv:Dt&&y(w.specularMap.channel),specularColorMapUv:bt&&y(w.specularColorMap.channel),specularIntensityMapUv:Wt&&y(w.specularIntensityMap.channel),transmissionMapUv:Qt&&y(w.transmissionMap.channel),thicknessMapUv:de&&y(w.thicknessMap.channel),alphaMapUv:ft&&y(w.alphaMap.channel),vertexTangents:!!B.attributes.tangent&&(Q||z),vertexColors:w.vertexColors,vertexAlphas:w.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,vertexUv1s:Ft,vertexUv2s:Nt,vertexUv3s:ne,pointsUvs:j.isPoints===!0&&!!B.attributes.uv&&(wt||ft),fog:!!I,useFog:w.fog===!0,fogExp2:I&&I.isFogExp2,flatShading:w.flatShading===!0,sizeAttenuation:w.sizeAttenuation===!0,logarithmicDepthBuffer:d,skinning:j.isSkinnedMesh===!0,morphTargets:B.morphAttributes.position!==void 0,morphNormals:B.morphAttributes.normal!==void 0,morphColors:B.morphAttributes.color!==void 0,morphTargetsCount:et,morphTextureStride:rt,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:w.dithering,shadowMapEnabled:o.shadowMap.enabled&&P.length>0,shadowMapType:o.shadowMap.type,toneMapping:ie,useLegacyLights:o._useLegacyLights,decodeVideoTexture:wt&&w.map.isVideoTexture===!0&&te.getTransfer(w.map.colorSpace)===ae,premultipliedAlpha:w.premultipliedAlpha,doubleSided:w.side===ye,flipSided:w.side===Ue,useDepthPacking:w.depthPacking>=0,depthPacking:w.depthPacking||0,index0AttributeName:w.index0AttributeName,extensionDerivatives:vt&&w.extensions.derivatives===!0,extensionFragDepth:vt&&w.extensions.fragDepth===!0,extensionDrawBuffers:vt&&w.extensions.drawBuffers===!0,extensionShaderTextureLOD:vt&&w.extensions.shaderTextureLOD===!0,extensionClipCullDistance:vt&&w.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:w.customProgramCacheKey()}}function p(w){const S=[];if(w.shaderID?S.push(w.shaderID):(S.push(w.customVertexShaderID),S.push(w.customFragmentShaderID)),w.defines!==void 0)for(const P in w.defines)S.push(P),S.push(w.defines[P]);return w.isRawShaderMaterial===!1&&(x(S,w),v(S,w),S.push(o.outputColorSpace)),S.push(w.customProgramCacheKey),S.join()}function x(w,S){w.push(S.precision),w.push(S.outputColorSpace),w.push(S.envMapMode),w.push(S.envMapCubeUVHeight),w.push(S.mapUv),w.push(S.alphaMapUv),w.push(S.lightMapUv),w.push(S.aoMapUv),w.push(S.bumpMapUv),w.push(S.normalMapUv),w.push(S.displacementMapUv),w.push(S.emissiveMapUv),w.push(S.metalnessMapUv),w.push(S.roughnessMapUv),w.push(S.anisotropyMapUv),w.push(S.clearcoatMapUv),w.push(S.clearcoatNormalMapUv),w.push(S.clearcoatRoughnessMapUv),w.push(S.iridescenceMapUv),w.push(S.iridescenceThicknessMapUv),w.push(S.sheenColorMapUv),w.push(S.sheenRoughnessMapUv),w.push(S.specularMapUv),w.push(S.specularColorMapUv),w.push(S.specularIntensityMapUv),w.push(S.transmissionMapUv),w.push(S.thicknessMapUv),w.push(S.combine),w.push(S.fogExp2),w.push(S.sizeAttenuation),w.push(S.morphTargetsCount),w.push(S.morphAttributeCount),w.push(S.numDirLights),w.push(S.numPointLights),w.push(S.numSpotLights),w.push(S.numSpotLightMaps),w.push(S.numHemiLights),w.push(S.numRectAreaLights),w.push(S.numDirLightShadows),w.push(S.numPointLightShadows),w.push(S.numSpotLightShadows),w.push(S.numSpotLightShadowsWithMaps),w.push(S.numLightProbes),w.push(S.shadowMapType),w.push(S.toneMapping),w.push(S.numClippingPlanes),w.push(S.numClipIntersection),w.push(S.depthPacking)}function v(w,S){r.disableAll(),S.isWebGL2&&r.enable(0),S.supportsVertexTextures&&r.enable(1),S.instancing&&r.enable(2),S.instancingColor&&r.enable(3),S.matcap&&r.enable(4),S.envMap&&r.enable(5),S.normalMapObjectSpace&&r.enable(6),S.normalMapTangentSpace&&r.enable(7),S.clearcoat&&r.enable(8),S.iridescence&&r.enable(9),S.alphaTest&&r.enable(10),S.vertexColors&&r.enable(11),S.vertexAlphas&&r.enable(12),S.vertexUv1s&&r.enable(13),S.vertexUv2s&&r.enable(14),S.vertexUv3s&&r.enable(15),S.vertexTangents&&r.enable(16),S.anisotropy&&r.enable(17),S.alphaHash&&r.enable(18),S.batching&&r.enable(19),w.push(r.mask),r.disableAll(),S.fog&&r.enable(0),S.useFog&&r.enable(1),S.flatShading&&r.enable(2),S.logarithmicDepthBuffer&&r.enable(3),S.skinning&&r.enable(4),S.morphTargets&&r.enable(5),S.morphNormals&&r.enable(6),S.morphColors&&r.enable(7),S.premultipliedAlpha&&r.enable(8),S.shadowMapEnabled&&r.enable(9),S.useLegacyLights&&r.enable(10),S.doubleSided&&r.enable(11),S.flipSided&&r.enable(12),S.useDepthPacking&&r.enable(13),S.dithering&&r.enable(14),S.transmission&&r.enable(15),S.sheen&&r.enable(16),S.opaque&&r.enable(17),S.pointsUvs&&r.enable(18),S.decodeVideoTexture&&r.enable(19),w.push(r.mask)}function M(w){const S=g[w.type];let P;if(S){const F=Qe[S];P=fh.clone(F.uniforms)}else P=w.uniforms;return P}function R(w,S){let P;for(let F=0,j=l.length;F<j;F++){const I=l[F];if(I.cacheKey===S){P=I,++P.usedTimes;break}}return P===void 0&&(P=new Cp(o,S,w,s),l.push(P)),P}function T(w){if(--w.usedTimes===0){const S=l.indexOf(w);l[S]=l[l.length-1],l.pop(),w.destroy()}}function E(w){c.remove(w)}function U(){c.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:M,acquireProgram:R,releaseProgram:T,releaseShaderCache:E,programs:l,dispose:U}}function Dp(){let o=new WeakMap;function t(s){let a=o.get(s);return a===void 0&&(a={},o.set(s,a)),a}function e(s){o.delete(s)}function n(s,a,r){o.get(s)[a]=r}function i(){o=new WeakMap}return{get:t,remove:e,update:n,dispose:i}}function Up(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.material.id!==t.material.id?o.material.id-t.material.id:o.z!==t.z?o.z-t.z:o.id-t.id}function Lr(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.z!==t.z?t.z-o.z:o.id-t.id}function Pr(){const o=[];let t=0;const e=[],n=[],i=[];function s(){t=0,e.length=0,n.length=0,i.length=0}function a(d,u,f,g,y,m){let p=o[t];return p===void 0?(p={id:d.id,object:d,geometry:u,material:f,groupOrder:g,renderOrder:d.renderOrder,z:y,group:m},o[t]=p):(p.id=d.id,p.object=d,p.geometry=u,p.material=f,p.groupOrder=g,p.renderOrder=d.renderOrder,p.z=y,p.group=m),t++,p}function r(d,u,f,g,y,m){const p=a(d,u,f,g,y,m);f.transmission>0?n.push(p):f.transparent===!0?i.push(p):e.push(p)}function c(d,u,f,g,y,m){const p=a(d,u,f,g,y,m);f.transmission>0?n.unshift(p):f.transparent===!0?i.unshift(p):e.unshift(p)}function l(d,u){e.length>1&&e.sort(d||Up),n.length>1&&n.sort(u||Lr),i.length>1&&i.sort(u||Lr)}function h(){for(let d=t,u=o.length;d<u;d++){const f=o[d];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:i,init:s,push:r,unshift:c,finish:h,sort:l}}function Np(){let o=new WeakMap;function t(n,i){const s=o.get(n);let a;return s===void 0?(a=new Pr,o.set(n,[a])):i>=s.length?(a=new Pr,s.push(a)):a=s[i],a}function e(){o=new WeakMap}return{get:t,dispose:e}}function Bp(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new L,color:new kt};break;case"SpotLight":e={position:new L,direction:new L,color:new kt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new L,color:new kt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new L,skyColor:new kt,groundColor:new kt};break;case"RectAreaLight":e={color:new kt,position:new L,halfWidth:new L,halfHeight:new L};break}return o[t.id]=e,e}}}function Fp(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ct};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ct};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ct,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[t.id]=e,e}}}let Op=0;function kp(o,t){return(t.castShadow?2:0)-(o.castShadow?2:0)+(t.map?1:0)-(o.map?1:0)}function zp(o,t){const e=new Bp,n=Fp(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)i.probe.push(new L);const s=new L,a=new ce,r=new ce;function c(h,d){let u=0,f=0,g=0;for(let F=0;F<9;F++)i.probe[F].set(0,0,0);let y=0,m=0,p=0,x=0,v=0,M=0,R=0,T=0,E=0,U=0,w=0;h.sort(kp);const S=d===!0?Math.PI:1;for(let F=0,j=h.length;F<j;F++){const I=h[F],B=I.color,O=I.intensity,Z=I.distance,X=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)u+=B.r*O*S,f+=B.g*O*S,g+=B.b*O*S;else if(I.isLightProbe){for(let q=0;q<9;q++)i.probe[q].addScaledVector(I.sh.coefficients[q],O);w++}else if(I.isDirectionalLight){const q=e.get(I);if(q.color.copy(I.color).multiplyScalar(I.intensity*S),I.castShadow){const J=I.shadow,et=n.get(I);et.shadowBias=J.bias,et.shadowNormalBias=J.normalBias,et.shadowRadius=J.radius,et.shadowMapSize=J.mapSize,i.directionalShadow[y]=et,i.directionalShadowMap[y]=X,i.directionalShadowMatrix[y]=I.shadow.matrix,M++}i.directional[y]=q,y++}else if(I.isSpotLight){const q=e.get(I);q.position.setFromMatrixPosition(I.matrixWorld),q.color.copy(B).multiplyScalar(O*S),q.distance=Z,q.coneCos=Math.cos(I.angle),q.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),q.decay=I.decay,i.spot[p]=q;const J=I.shadow;if(I.map&&(i.spotLightMap[E]=I.map,E++,J.updateMatrices(I),I.castShadow&&U++),i.spotLightMatrix[p]=J.matrix,I.castShadow){const et=n.get(I);et.shadowBias=J.bias,et.shadowNormalBias=J.normalBias,et.shadowRadius=J.radius,et.shadowMapSize=J.mapSize,i.spotShadow[p]=et,i.spotShadowMap[p]=X,T++}p++}else if(I.isRectAreaLight){const q=e.get(I);q.color.copy(B).multiplyScalar(O),q.halfWidth.set(I.width*.5,0,0),q.halfHeight.set(0,I.height*.5,0),i.rectArea[x]=q,x++}else if(I.isPointLight){const q=e.get(I);if(q.color.copy(I.color).multiplyScalar(I.intensity*S),q.distance=I.distance,q.decay=I.decay,I.castShadow){const J=I.shadow,et=n.get(I);et.shadowBias=J.bias,et.shadowNormalBias=J.normalBias,et.shadowRadius=J.radius,et.shadowMapSize=J.mapSize,et.shadowCameraNear=J.camera.near,et.shadowCameraFar=J.camera.far,i.pointShadow[m]=et,i.pointShadowMap[m]=X,i.pointShadowMatrix[m]=I.shadow.matrix,R++}i.point[m]=q,m++}else if(I.isHemisphereLight){const q=e.get(I);q.skyColor.copy(I.color).multiplyScalar(O*S),q.groundColor.copy(I.groundColor).multiplyScalar(O*S),i.hemi[v]=q,v++}}x>0&&(t.isWebGL2?o.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=pt.LTC_FLOAT_1,i.rectAreaLTC2=pt.LTC_FLOAT_2):(i.rectAreaLTC1=pt.LTC_HALF_1,i.rectAreaLTC2=pt.LTC_HALF_2):o.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=pt.LTC_FLOAT_1,i.rectAreaLTC2=pt.LTC_FLOAT_2):o.has("OES_texture_half_float_linear")===!0?(i.rectAreaLTC1=pt.LTC_HALF_1,i.rectAreaLTC2=pt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),i.ambient[0]=u,i.ambient[1]=f,i.ambient[2]=g;const P=i.hash;(P.directionalLength!==y||P.pointLength!==m||P.spotLength!==p||P.rectAreaLength!==x||P.hemiLength!==v||P.numDirectionalShadows!==M||P.numPointShadows!==R||P.numSpotShadows!==T||P.numSpotMaps!==E||P.numLightProbes!==w)&&(i.directional.length=y,i.spot.length=p,i.rectArea.length=x,i.point.length=m,i.hemi.length=v,i.directionalShadow.length=M,i.directionalShadowMap.length=M,i.pointShadow.length=R,i.pointShadowMap.length=R,i.spotShadow.length=T,i.spotShadowMap.length=T,i.directionalShadowMatrix.length=M,i.pointShadowMatrix.length=R,i.spotLightMatrix.length=T+E-U,i.spotLightMap.length=E,i.numSpotLightShadowsWithMaps=U,i.numLightProbes=w,P.directionalLength=y,P.pointLength=m,P.spotLength=p,P.rectAreaLength=x,P.hemiLength=v,P.numDirectionalShadows=M,P.numPointShadows=R,P.numSpotShadows=T,P.numSpotMaps=E,P.numLightProbes=w,i.version=Op++)}function l(h,d){let u=0,f=0,g=0,y=0,m=0;const p=d.matrixWorldInverse;for(let x=0,v=h.length;x<v;x++){const M=h[x];if(M.isDirectionalLight){const R=i.directional[u];R.direction.setFromMatrixPosition(M.matrixWorld),s.setFromMatrixPosition(M.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(p),u++}else if(M.isSpotLight){const R=i.spot[g];R.position.setFromMatrixPosition(M.matrixWorld),R.position.applyMatrix4(p),R.direction.setFromMatrixPosition(M.matrixWorld),s.setFromMatrixPosition(M.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(p),g++}else if(M.isRectAreaLight){const R=i.rectArea[y];R.position.setFromMatrixPosition(M.matrixWorld),R.position.applyMatrix4(p),r.identity(),a.copy(M.matrixWorld),a.premultiply(p),r.extractRotation(a),R.halfWidth.set(M.width*.5,0,0),R.halfHeight.set(0,M.height*.5,0),R.halfWidth.applyMatrix4(r),R.halfHeight.applyMatrix4(r),y++}else if(M.isPointLight){const R=i.point[f];R.position.setFromMatrixPosition(M.matrixWorld),R.position.applyMatrix4(p),f++}else if(M.isHemisphereLight){const R=i.hemi[m];R.direction.setFromMatrixPosition(M.matrixWorld),R.direction.transformDirection(p),m++}}}return{setup:c,setupView:l,state:i}}function Ir(o,t){const e=new zp(o,t),n=[],i=[];function s(){n.length=0,i.length=0}function a(d){n.push(d)}function r(d){i.push(d)}function c(d){e.setup(n,d)}function l(d){e.setupView(n,d)}return{init:s,state:{lightsArray:n,shadowsArray:i,lights:e},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:r}}function Gp(o,t){let e=new WeakMap;function n(s,a=0){const r=e.get(s);let c;return r===void 0?(c=new Ir(o,t),e.set(s,[c])):a>=r.length?(c=new Ir(o,t),r.push(c)):c=r[a],c}function i(){e=new WeakMap}return{get:n,dispose:i}}class Hp extends En{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Ol,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class Vp extends En{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const Wp=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Xp=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function qp(o,t,e){let n=new Qo;const i=new ct,s=new ct,a=new re,r=new Hp({depthPacking:kl}),c=new Vp,l={},h=e.maxTextureSize,d={[bn]:Ue,[Ue]:bn,[ye]:ye},u=new zn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ct},radius:{value:4}},vertexShader:Wp,fragmentShader:Xp}),f=u.clone();f.defines.HORIZONTAL_PASS=1;const g=new ge;g.setAttribute("position",new qe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const y=new _(g,u),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=$o;let p=this.type;this.render=function(T,E,U){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||T.length===0)return;const w=o.getRenderTarget(),S=o.getActiveCubeFace(),P=o.getActiveMipmapLevel(),F=o.state;F.setBlending(wn),F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const j=p!==cn&&this.type===cn,I=p===cn&&this.type!==cn;for(let B=0,O=T.length;B<O;B++){const Z=T[B],X=Z.shadow;if(X===void 0){console.warn("THREE.WebGLShadowMap:",Z,"has no shadow.");continue}if(X.autoUpdate===!1&&X.needsUpdate===!1)continue;i.copy(X.mapSize);const q=X.getFrameExtents();if(i.multiply(q),s.copy(X.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(s.x=Math.floor(h/q.x),i.x=s.x*q.x,X.mapSize.x=s.x),i.y>h&&(s.y=Math.floor(h/q.y),i.y=s.y*q.y,X.mapSize.y=s.y)),X.map===null||j===!0||I===!0){const et=this.type!==cn?{minFilter:Ie,magFilter:Ie}:{};X.map!==null&&X.map.dispose(),X.map=new kn(i.x,i.y,et),X.map.texture.name=Z.name+".shadowMap",X.camera.updateProjectionMatrix()}o.setRenderTarget(X.map),o.clear();const J=X.getViewportCount();for(let et=0;et<J;et++){const rt=X.getViewport(et);a.set(s.x*rt.x,s.y*rt.y,s.x*rt.z,s.y*rt.w),F.viewport(a),X.updateMatrices(Z,et),n=X.getFrustum(),M(E,U,X.camera,Z,this.type)}X.isPointLightShadow!==!0&&this.type===cn&&x(X,U),X.needsUpdate=!1}p=this.type,m.needsUpdate=!1,o.setRenderTarget(w,S,P)};function x(T,E){const U=t.update(y);u.defines.VSM_SAMPLES!==T.blurSamples&&(u.defines.VSM_SAMPLES=T.blurSamples,f.defines.VSM_SAMPLES=T.blurSamples,u.needsUpdate=!0,f.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new kn(i.x,i.y)),u.uniforms.shadow_pass.value=T.map.texture,u.uniforms.resolution.value=T.mapSize,u.uniforms.radius.value=T.radius,o.setRenderTarget(T.mapPass),o.clear(),o.renderBufferDirect(E,null,U,u,y,null),f.uniforms.shadow_pass.value=T.mapPass.texture,f.uniforms.resolution.value=T.mapSize,f.uniforms.radius.value=T.radius,o.setRenderTarget(T.map),o.clear(),o.renderBufferDirect(E,null,U,f,y,null)}function v(T,E,U,w){let S=null;const P=U.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(P!==void 0)S=P;else if(S=U.isPointLight===!0?c:r,o.localClippingEnabled&&E.clipShadows===!0&&Array.isArray(E.clippingPlanes)&&E.clippingPlanes.length!==0||E.displacementMap&&E.displacementScale!==0||E.alphaMap&&E.alphaTest>0||E.map&&E.alphaTest>0){const F=S.uuid,j=E.uuid;let I=l[F];I===void 0&&(I={},l[F]=I);let B=I[j];B===void 0&&(B=S.clone(),I[j]=B,E.addEventListener("dispose",R)),S=B}if(S.visible=E.visible,S.wireframe=E.wireframe,w===cn?S.side=E.shadowSide!==null?E.shadowSide:E.side:S.side=E.shadowSide!==null?E.shadowSide:d[E.side],S.alphaMap=E.alphaMap,S.alphaTest=E.alphaTest,S.map=E.map,S.clipShadows=E.clipShadows,S.clippingPlanes=E.clippingPlanes,S.clipIntersection=E.clipIntersection,S.displacementMap=E.displacementMap,S.displacementScale=E.displacementScale,S.displacementBias=E.displacementBias,S.wireframeLinewidth=E.wireframeLinewidth,S.linewidth=E.linewidth,U.isPointLight===!0&&S.isMeshDistanceMaterial===!0){const F=o.properties.get(S);F.light=U}return S}function M(T,E,U,w,S){if(T.visible===!1)return;if(T.layers.test(E.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&S===cn)&&(!T.frustumCulled||n.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,T.matrixWorld);const j=t.update(T),I=T.material;if(Array.isArray(I)){const B=j.groups;for(let O=0,Z=B.length;O<Z;O++){const X=B[O],q=I[X.materialIndex];if(q&&q.visible){const J=v(T,q,w,S);T.onBeforeShadow(o,T,E,U,j,J,X),o.renderBufferDirect(U,null,j,J,T,X),T.onAfterShadow(o,T,E,U,j,J,X)}}}else if(I.visible){const B=v(T,I,w,S);T.onBeforeShadow(o,T,E,U,j,B,null),o.renderBufferDirect(U,null,j,B,T,null),T.onAfterShadow(o,T,E,U,j,B,null)}}const F=T.children;for(let j=0,I=F.length;j<I;j++)M(F[j],E,U,w,S)}function R(T){T.target.removeEventListener("dispose",R);for(const U in l){const w=l[U],S=T.target.uuid;S in w&&(w[S].dispose(),delete w[S])}}}function Yp(o,t,e){const n=e.isWebGL2;function i(){let N=!1;const yt=new re;let vt=null;const Ft=new re(0,0,0,0);return{setMask:function(Nt){vt!==Nt&&!N&&(o.colorMask(Nt,Nt,Nt,Nt),vt=Nt)},setLocked:function(Nt){N=Nt},setClear:function(Nt,ne,ie,xe,Ce){Ce===!0&&(Nt*=xe,ne*=xe,ie*=xe),yt.set(Nt,ne,ie,xe),Ft.equals(yt)===!1&&(o.clearColor(Nt,ne,ie,xe),Ft.copy(yt))},reset:function(){N=!1,vt=null,Ft.set(-1,0,0,0)}}}function s(){let N=!1,yt=null,vt=null,Ft=null;return{setTest:function(Nt){Nt?Pt(o.DEPTH_TEST):wt(o.DEPTH_TEST)},setMask:function(Nt){yt!==Nt&&!N&&(o.depthMask(Nt),yt=Nt)},setFunc:function(Nt){if(vt!==Nt){switch(Nt){case ml:o.depthFunc(o.NEVER);break;case gl:o.depthFunc(o.ALWAYS);break;case yl:o.depthFunc(o.LESS);break;case Ts:o.depthFunc(o.LEQUAL);break;case vl:o.depthFunc(o.EQUAL);break;case _l:o.depthFunc(o.GEQUAL);break;case xl:o.depthFunc(o.GREATER);break;case wl:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}vt=Nt}},setLocked:function(Nt){N=Nt},setClear:function(Nt){Ft!==Nt&&(o.clearDepth(Nt),Ft=Nt)},reset:function(){N=!1,yt=null,vt=null,Ft=null}}}function a(){let N=!1,yt=null,vt=null,Ft=null,Nt=null,ne=null,ie=null,xe=null,Ce=null;return{setTest:function(se){N||(se?Pt(o.STENCIL_TEST):wt(o.STENCIL_TEST))},setMask:function(se){yt!==se&&!N&&(o.stencilMask(se),yt=se)},setFunc:function(se,Re,Je){(vt!==se||Ft!==Re||Nt!==Je)&&(o.stencilFunc(se,Re,Je),vt=se,Ft=Re,Nt=Je)},setOp:function(se,Re,Je){(ne!==se||ie!==Re||xe!==Je)&&(o.stencilOp(se,Re,Je),ne=se,ie=Re,xe=Je)},setLocked:function(se){N=se},setClear:function(se){Ce!==se&&(o.clearStencil(se),Ce=se)},reset:function(){N=!1,yt=null,vt=null,Ft=null,Nt=null,ne=null,ie=null,xe=null,Ce=null}}}const r=new i,c=new s,l=new a,h=new WeakMap,d=new WeakMap;let u={},f={},g=new WeakMap,y=[],m=null,p=!1,x=null,v=null,M=null,R=null,T=null,E=null,U=null,w=new kt(0,0,0),S=0,P=!1,F=null,j=null,I=null,B=null,O=null;const Z=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let X=!1,q=0;const J=o.getParameter(o.VERSION);J.indexOf("WebGL")!==-1?(q=parseFloat(/^WebGL (\d)/.exec(J)[1]),X=q>=1):J.indexOf("OpenGL ES")!==-1&&(q=parseFloat(/^OpenGL ES (\d)/.exec(J)[1]),X=q>=2);let et=null,rt={};const H=o.getParameter(o.SCISSOR_BOX),tt=o.getParameter(o.VIEWPORT),ut=new re().fromArray(H),Et=new re().fromArray(tt);function mt(N,yt,vt,Ft){const Nt=new Uint8Array(4),ne=o.createTexture();o.bindTexture(N,ne),o.texParameteri(N,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(N,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let ie=0;ie<vt;ie++)n&&(N===o.TEXTURE_3D||N===o.TEXTURE_2D_ARRAY)?o.texImage3D(yt,0,o.RGBA,1,1,Ft,0,o.RGBA,o.UNSIGNED_BYTE,Nt):o.texImage2D(yt+ie,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,Nt);return ne}const St={};St[o.TEXTURE_2D]=mt(o.TEXTURE_2D,o.TEXTURE_2D,1),St[o.TEXTURE_CUBE_MAP]=mt(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(St[o.TEXTURE_2D_ARRAY]=mt(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),St[o.TEXTURE_3D]=mt(o.TEXTURE_3D,o.TEXTURE_3D,1,1)),r.setClear(0,0,0,1),c.setClear(1),l.setClear(0),Pt(o.DEPTH_TEST),c.setFunc(Ts),_t(!1),A(ma),Pt(o.CULL_FACE),Q(wn);function Pt(N){u[N]!==!0&&(o.enable(N),u[N]=!0)}function wt(N){u[N]!==!1&&(o.disable(N),u[N]=!1)}function It(N,yt){return f[N]!==yt?(o.bindFramebuffer(N,yt),f[N]=yt,n&&(N===o.DRAW_FRAMEBUFFER&&(f[o.FRAMEBUFFER]=yt),N===o.FRAMEBUFFER&&(f[o.DRAW_FRAMEBUFFER]=yt)),!0):!1}function D(N,yt){let vt=y,Ft=!1;if(N)if(vt=g.get(yt),vt===void 0&&(vt=[],g.set(yt,vt)),N.isWebGLMultipleRenderTargets){const Nt=N.texture;if(vt.length!==Nt.length||vt[0]!==o.COLOR_ATTACHMENT0){for(let ne=0,ie=Nt.length;ne<ie;ne++)vt[ne]=o.COLOR_ATTACHMENT0+ne;vt.length=Nt.length,Ft=!0}}else vt[0]!==o.COLOR_ATTACHMENT0&&(vt[0]=o.COLOR_ATTACHMENT0,Ft=!0);else vt[0]!==o.BACK&&(vt[0]=o.BACK,Ft=!0);Ft&&(e.isWebGL2?o.drawBuffers(vt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(vt))}function ht(N){return m!==N?(o.useProgram(N),m=N,!0):!1}const K={[Un]:o.FUNC_ADD,[tl]:o.FUNC_SUBTRACT,[el]:o.FUNC_REVERSE_SUBTRACT};if(n)K[va]=o.MIN,K[_a]=o.MAX;else{const N=t.get("EXT_blend_minmax");N!==null&&(K[va]=N.MIN_EXT,K[_a]=N.MAX_EXT)}const lt={[nl]:o.ZERO,[il]:o.ONE,[sl]:o.SRC_COLOR,[Do]:o.SRC_ALPHA,[hl]:o.SRC_ALPHA_SATURATE,[cl]:o.DST_COLOR,[al]:o.DST_ALPHA,[ol]:o.ONE_MINUS_SRC_COLOR,[Uo]:o.ONE_MINUS_SRC_ALPHA,[ll]:o.ONE_MINUS_DST_COLOR,[rl]:o.ONE_MINUS_DST_ALPHA,[dl]:o.CONSTANT_COLOR,[ul]:o.ONE_MINUS_CONSTANT_COLOR,[fl]:o.CONSTANT_ALPHA,[pl]:o.ONE_MINUS_CONSTANT_ALPHA};function Q(N,yt,vt,Ft,Nt,ne,ie,xe,Ce,se){if(N===wn){p===!0&&(wt(o.BLEND),p=!1);return}if(p===!1&&(Pt(o.BLEND),p=!0),N!==Qc){if(N!==x||se!==P){if((v!==Un||T!==Un)&&(o.blendEquation(o.FUNC_ADD),v=Un,T=Un),se)switch(N){case ui:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case Es:o.blendFunc(o.ONE,o.ONE);break;case ga:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case ya:o.blendFuncSeparate(o.ZERO,o.SRC_COLOR,o.ZERO,o.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}else switch(N){case ui:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case Es:o.blendFunc(o.SRC_ALPHA,o.ONE);break;case ga:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case ya:o.blendFunc(o.ZERO,o.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}M=null,R=null,E=null,U=null,w.set(0,0,0),S=0,x=N,P=se}return}Nt=Nt||yt,ne=ne||vt,ie=ie||Ft,(yt!==v||Nt!==T)&&(o.blendEquationSeparate(K[yt],K[Nt]),v=yt,T=Nt),(vt!==M||Ft!==R||ne!==E||ie!==U)&&(o.blendFuncSeparate(lt[vt],lt[Ft],lt[ne],lt[ie]),M=vt,R=Ft,E=ne,U=ie),(xe.equals(w)===!1||Ce!==S)&&(o.blendColor(xe.r,xe.g,xe.b,Ce),w.copy(xe),S=Ce),x=N,P=!1}function Rt(N,yt){N.side===ye?wt(o.CULL_FACE):Pt(o.CULL_FACE);let vt=N.side===Ue;yt&&(vt=!vt),_t(vt),N.blending===ui&&N.transparent===!1?Q(wn):Q(N.blending,N.blendEquation,N.blendSrc,N.blendDst,N.blendEquationAlpha,N.blendSrcAlpha,N.blendDstAlpha,N.blendColor,N.blendAlpha,N.premultipliedAlpha),c.setFunc(N.depthFunc),c.setTest(N.depthTest),c.setMask(N.depthWrite),r.setMask(N.colorWrite);const Ft=N.stencilWrite;l.setTest(Ft),Ft&&(l.setMask(N.stencilWriteMask),l.setFunc(N.stencilFunc,N.stencilRef,N.stencilFuncMask),l.setOp(N.stencilFail,N.stencilZFail,N.stencilZPass)),z(N.polygonOffset,N.polygonOffsetFactor,N.polygonOffsetUnits),N.alphaToCoverage===!0?Pt(o.SAMPLE_ALPHA_TO_COVERAGE):wt(o.SAMPLE_ALPHA_TO_COVERAGE)}function _t(N){F!==N&&(N?o.frontFace(o.CW):o.frontFace(o.CCW),F=N)}function A(N){N!==Kc?(Pt(o.CULL_FACE),N!==j&&(N===ma?o.cullFace(o.BACK):N===Jc?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):wt(o.CULL_FACE),j=N}function b(N){N!==I&&(X&&o.lineWidth(N),I=N)}function z(N,yt,vt){N?(Pt(o.POLYGON_OFFSET_FILL),(B!==yt||O!==vt)&&(o.polygonOffset(yt,vt),B=yt,O=vt)):wt(o.POLYGON_OFFSET_FILL)}function at(N){N?Pt(o.SCISSOR_TEST):wt(o.SCISSOR_TEST)}function st(N){N===void 0&&(N=o.TEXTURE0+Z-1),et!==N&&(o.activeTexture(N),et=N)}function it(N,yt,vt){vt===void 0&&(et===null?vt=o.TEXTURE0+Z-1:vt=et);let Ft=rt[vt];Ft===void 0&&(Ft={type:void 0,texture:void 0},rt[vt]=Ft),(Ft.type!==N||Ft.texture!==yt)&&(et!==vt&&(o.activeTexture(vt),et=vt),o.bindTexture(N,yt||St[N]),Ft.type=N,Ft.texture=yt)}function At(){const N=rt[et];N!==void 0&&N.type!==void 0&&(o.bindTexture(N.type,null),N.type=void 0,N.texture=void 0)}function gt(){try{o.compressedTexImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Mt(){try{o.compressedTexImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ut(){try{o.texSubImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ht(){try{o.texSubImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function ot(){try{o.compressedTexSubImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Jt(){try{o.compressedTexSubImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Zt(){try{o.texStorage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function zt(){try{o.texStorage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Dt(){try{o.texImage2D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function bt(){try{o.texImage3D.apply(o,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Wt(N){ut.equals(N)===!1&&(o.scissor(N.x,N.y,N.z,N.w),ut.copy(N))}function Qt(N){Et.equals(N)===!1&&(o.viewport(N.x,N.y,N.z,N.w),Et.copy(N))}function de(N,yt){let vt=d.get(yt);vt===void 0&&(vt=new WeakMap,d.set(yt,vt));let Ft=vt.get(N);Ft===void 0&&(Ft=o.getUniformBlockIndex(yt,N.name),vt.set(N,Ft))}function Yt(N,yt){const Ft=d.get(yt).get(N);h.get(yt)!==Ft&&(o.uniformBlockBinding(yt,Ft,N.__bindingPointIndex),h.set(yt,Ft))}function ft(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),n===!0&&(o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null)),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),u={},et=null,rt={},f={},g=new WeakMap,y=[],m=null,p=!1,x=null,v=null,M=null,R=null,T=null,E=null,U=null,w=new kt(0,0,0),S=0,P=!1,F=null,j=null,I=null,B=null,O=null,ut.set(0,0,o.canvas.width,o.canvas.height),Et.set(0,0,o.canvas.width,o.canvas.height),r.reset(),c.reset(),l.reset()}return{buffers:{color:r,depth:c,stencil:l},enable:Pt,disable:wt,bindFramebuffer:It,drawBuffers:D,useProgram:ht,setBlending:Q,setMaterial:Rt,setFlipSided:_t,setCullFace:A,setLineWidth:b,setPolygonOffset:z,setScissorTest:at,activeTexture:st,bindTexture:it,unbindTexture:At,compressedTexImage2D:gt,compressedTexImage3D:Mt,texImage2D:Dt,texImage3D:bt,updateUBOMapping:de,uniformBlockBinding:Yt,texStorage2D:Zt,texStorage3D:zt,texSubImage2D:Ut,texSubImage3D:Ht,compressedTexSubImage2D:ot,compressedTexSubImage3D:Jt,scissor:Wt,viewport:Qt,reset:ft}}function $p(o,t,e,n,i,s,a){const r=i.isWebGL2,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap;let d;const u=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(A,b){return f?new OffscreenCanvas(A,b):Is("canvas")}function y(A,b,z,at){let st=1;if((A.width>at||A.height>at)&&(st=at/Math.max(A.width,A.height)),st<1||b===!0)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){const it=b?Go:Math.floor,At=it(st*A.width),gt=it(st*A.height);d===void 0&&(d=g(At,gt));const Mt=z?g(At,gt):d;return Mt.width=At,Mt.height=gt,Mt.getContext("2d").drawImage(A,0,0,At,gt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+At+"x"+gt+")."),Mt}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A;return A}function m(A){return $a(A.width)&&$a(A.height)}function p(A){return r?!1:A.wrapS!==Ze||A.wrapT!==Ze||A.minFilter!==Ie&&A.minFilter!==He}function x(A,b){return A.generateMipmaps&&b&&A.minFilter!==Ie&&A.minFilter!==He}function v(A){o.generateMipmap(A)}function M(A,b,z,at,st=!1){if(r===!1)return b;if(A!==null){if(o[A]!==void 0)return o[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let it=b;if(b===o.RED&&(z===o.FLOAT&&(it=o.R32F),z===o.HALF_FLOAT&&(it=o.R16F),z===o.UNSIGNED_BYTE&&(it=o.R8)),b===o.RED_INTEGER&&(z===o.UNSIGNED_BYTE&&(it=o.R8UI),z===o.UNSIGNED_SHORT&&(it=o.R16UI),z===o.UNSIGNED_INT&&(it=o.R32UI),z===o.BYTE&&(it=o.R8I),z===o.SHORT&&(it=o.R16I),z===o.INT&&(it=o.R32I)),b===o.RG&&(z===o.FLOAT&&(it=o.RG32F),z===o.HALF_FLOAT&&(it=o.RG16F),z===o.UNSIGNED_BYTE&&(it=o.RG8)),b===o.RGBA){const At=st?As:te.getTransfer(at);z===o.FLOAT&&(it=o.RGBA32F),z===o.HALF_FLOAT&&(it=o.RGBA16F),z===o.UNSIGNED_BYTE&&(it=At===ae?o.SRGB8_ALPHA8:o.RGBA8),z===o.UNSIGNED_SHORT_4_4_4_4&&(it=o.RGBA4),z===o.UNSIGNED_SHORT_5_5_5_1&&(it=o.RGB5_A1)}return(it===o.R16F||it===o.R32F||it===o.RG16F||it===o.RG32F||it===o.RGBA16F||it===o.RGBA32F)&&t.get("EXT_color_buffer_float"),it}function R(A,b,z){return x(A,z)===!0||A.isFramebufferTexture&&A.minFilter!==Ie&&A.minFilter!==He?Math.log2(Math.max(b.width,b.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?b.mipmaps.length:1}function T(A){return A===Ie||A===xa||A===$s?o.NEAREST:o.LINEAR}function E(A){const b=A.target;b.removeEventListener("dispose",E),w(b),b.isVideoTexture&&h.delete(b)}function U(A){const b=A.target;b.removeEventListener("dispose",U),P(b)}function w(A){const b=n.get(A);if(b.__webglInit===void 0)return;const z=A.source,at=u.get(z);if(at){const st=at[b.__cacheKey];st.usedTimes--,st.usedTimes===0&&S(A),Object.keys(at).length===0&&u.delete(z)}n.remove(A)}function S(A){const b=n.get(A);o.deleteTexture(b.__webglTexture);const z=A.source,at=u.get(z);delete at[b.__cacheKey],a.memory.textures--}function P(A){const b=A.texture,z=n.get(A),at=n.get(b);if(at.__webglTexture!==void 0&&(o.deleteTexture(at.__webglTexture),a.memory.textures--),A.depthTexture&&A.depthTexture.dispose(),A.isWebGLCubeRenderTarget)for(let st=0;st<6;st++){if(Array.isArray(z.__webglFramebuffer[st]))for(let it=0;it<z.__webglFramebuffer[st].length;it++)o.deleteFramebuffer(z.__webglFramebuffer[st][it]);else o.deleteFramebuffer(z.__webglFramebuffer[st]);z.__webglDepthbuffer&&o.deleteRenderbuffer(z.__webglDepthbuffer[st])}else{if(Array.isArray(z.__webglFramebuffer))for(let st=0;st<z.__webglFramebuffer.length;st++)o.deleteFramebuffer(z.__webglFramebuffer[st]);else o.deleteFramebuffer(z.__webglFramebuffer);if(z.__webglDepthbuffer&&o.deleteRenderbuffer(z.__webglDepthbuffer),z.__webglMultisampledFramebuffer&&o.deleteFramebuffer(z.__webglMultisampledFramebuffer),z.__webglColorRenderbuffer)for(let st=0;st<z.__webglColorRenderbuffer.length;st++)z.__webglColorRenderbuffer[st]&&o.deleteRenderbuffer(z.__webglColorRenderbuffer[st]);z.__webglDepthRenderbuffer&&o.deleteRenderbuffer(z.__webglDepthRenderbuffer)}if(A.isWebGLMultipleRenderTargets)for(let st=0,it=b.length;st<it;st++){const At=n.get(b[st]);At.__webglTexture&&(o.deleteTexture(At.__webglTexture),a.memory.textures--),n.remove(b[st])}n.remove(b),n.remove(A)}let F=0;function j(){F=0}function I(){const A=F;return A>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+i.maxTextures),F+=1,A}function B(A){const b=[];return b.push(A.wrapS),b.push(A.wrapT),b.push(A.wrapR||0),b.push(A.magFilter),b.push(A.minFilter),b.push(A.anisotropy),b.push(A.internalFormat),b.push(A.format),b.push(A.type),b.push(A.generateMipmaps),b.push(A.premultiplyAlpha),b.push(A.flipY),b.push(A.unpackAlignment),b.push(A.colorSpace),b.join()}function O(A,b){const z=n.get(A);if(A.isVideoTexture&&Rt(A),A.isRenderTargetTexture===!1&&A.version>0&&z.__version!==A.version){const at=A.image;if(at===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(at.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ut(z,A,b);return}}e.bindTexture(o.TEXTURE_2D,z.__webglTexture,o.TEXTURE0+b)}function Z(A,b){const z=n.get(A);if(A.version>0&&z.__version!==A.version){ut(z,A,b);return}e.bindTexture(o.TEXTURE_2D_ARRAY,z.__webglTexture,o.TEXTURE0+b)}function X(A,b){const z=n.get(A);if(A.version>0&&z.__version!==A.version){ut(z,A,b);return}e.bindTexture(o.TEXTURE_3D,z.__webglTexture,o.TEXTURE0+b)}function q(A,b){const z=n.get(A);if(A.version>0&&z.__version!==A.version){Et(z,A,b);return}e.bindTexture(o.TEXTURE_CUBE_MAP,z.__webglTexture,o.TEXTURE0+b)}const J={[Fo]:o.REPEAT,[Ze]:o.CLAMP_TO_EDGE,[Oo]:o.MIRRORED_REPEAT},et={[Ie]:o.NEAREST,[xa]:o.NEAREST_MIPMAP_NEAREST,[$s]:o.NEAREST_MIPMAP_LINEAR,[He]:o.LINEAR,[Rl]:o.LINEAR_MIPMAP_NEAREST,[Bi]:o.LINEAR_MIPMAP_LINEAR},rt={[Gl]:o.NEVER,[Yl]:o.ALWAYS,[Hl]:o.LESS,[hc]:o.LEQUAL,[Vl]:o.EQUAL,[ql]:o.GEQUAL,[Wl]:o.GREATER,[Xl]:o.NOTEQUAL};function H(A,b,z){if(z?(o.texParameteri(A,o.TEXTURE_WRAP_S,J[b.wrapS]),o.texParameteri(A,o.TEXTURE_WRAP_T,J[b.wrapT]),(A===o.TEXTURE_3D||A===o.TEXTURE_2D_ARRAY)&&o.texParameteri(A,o.TEXTURE_WRAP_R,J[b.wrapR]),o.texParameteri(A,o.TEXTURE_MAG_FILTER,et[b.magFilter]),o.texParameteri(A,o.TEXTURE_MIN_FILTER,et[b.minFilter])):(o.texParameteri(A,o.TEXTURE_WRAP_S,o.CLAMP_TO_EDGE),o.texParameteri(A,o.TEXTURE_WRAP_T,o.CLAMP_TO_EDGE),(A===o.TEXTURE_3D||A===o.TEXTURE_2D_ARRAY)&&o.texParameteri(A,o.TEXTURE_WRAP_R,o.CLAMP_TO_EDGE),(b.wrapS!==Ze||b.wrapT!==Ze)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),o.texParameteri(A,o.TEXTURE_MAG_FILTER,T(b.magFilter)),o.texParameteri(A,o.TEXTURE_MIN_FILTER,T(b.minFilter)),b.minFilter!==Ie&&b.minFilter!==He&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),b.compareFunction&&(o.texParameteri(A,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(A,o.TEXTURE_COMPARE_FUNC,rt[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){const at=t.get("EXT_texture_filter_anisotropic");if(b.magFilter===Ie||b.minFilter!==$s&&b.minFilter!==Bi||b.type===_n&&t.has("OES_texture_float_linear")===!1||r===!1&&b.type===Fi&&t.has("OES_texture_half_float_linear")===!1)return;(b.anisotropy>1||n.get(b).__currentAnisotropy)&&(o.texParameterf(A,at.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,i.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy)}}function tt(A,b){let z=!1;A.__webglInit===void 0&&(A.__webglInit=!0,b.addEventListener("dispose",E));const at=b.source;let st=u.get(at);st===void 0&&(st={},u.set(at,st));const it=B(b);if(it!==A.__cacheKey){st[it]===void 0&&(st[it]={texture:o.createTexture(),usedTimes:0},a.memory.textures++,z=!0),st[it].usedTimes++;const At=st[A.__cacheKey];At!==void 0&&(st[A.__cacheKey].usedTimes--,At.usedTimes===0&&S(b)),A.__cacheKey=it,A.__webglTexture=st[it].texture}return z}function ut(A,b,z){let at=o.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(at=o.TEXTURE_2D_ARRAY),b.isData3DTexture&&(at=o.TEXTURE_3D);const st=tt(A,b),it=b.source;e.bindTexture(at,A.__webglTexture,o.TEXTURE0+z);const At=n.get(it);if(it.version!==At.__version||st===!0){e.activeTexture(o.TEXTURE0+z);const gt=te.getPrimaries(te.workingColorSpace),Mt=b.colorSpace===We?null:te.getPrimaries(b.colorSpace),Ut=b.colorSpace===We||gt===Mt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,b.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,b.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ut);const Ht=p(b)&&m(b.image)===!1;let ot=y(b.image,Ht,!1,i.maxTextureSize);ot=_t(b,ot);const Jt=m(ot)||r,Zt=s.convert(b.format,b.colorSpace);let zt=s.convert(b.type),Dt=M(b.internalFormat,Zt,zt,b.colorSpace,b.isVideoTexture);H(at,b,Jt);let bt;const Wt=b.mipmaps,Qt=r&&b.isVideoTexture!==!0&&Dt!==rc,de=At.__version===void 0||st===!0,Yt=R(b,ot,Jt);if(b.isDepthTexture)Dt=o.DEPTH_COMPONENT,r?b.type===_n?Dt=o.DEPTH_COMPONENT32F:b.type===vn?Dt=o.DEPTH_COMPONENT24:b.type===Bn?Dt=o.DEPTH24_STENCIL8:Dt=o.DEPTH_COMPONENT16:b.type===_n&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),b.format===Fn&&Dt===o.DEPTH_COMPONENT&&b.type!==Zo&&b.type!==vn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),b.type=vn,zt=s.convert(b.type)),b.format===gi&&Dt===o.DEPTH_COMPONENT&&(Dt=o.DEPTH_STENCIL,b.type!==Bn&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),b.type=Bn,zt=s.convert(b.type))),de&&(Qt?e.texStorage2D(o.TEXTURE_2D,1,Dt,ot.width,ot.height):e.texImage2D(o.TEXTURE_2D,0,Dt,ot.width,ot.height,0,Zt,zt,null));else if(b.isDataTexture)if(Wt.length>0&&Jt){Qt&&de&&e.texStorage2D(o.TEXTURE_2D,Yt,Dt,Wt[0].width,Wt[0].height);for(let ft=0,N=Wt.length;ft<N;ft++)bt=Wt[ft],Qt?e.texSubImage2D(o.TEXTURE_2D,ft,0,0,bt.width,bt.height,Zt,zt,bt.data):e.texImage2D(o.TEXTURE_2D,ft,Dt,bt.width,bt.height,0,Zt,zt,bt.data);b.generateMipmaps=!1}else Qt?(de&&e.texStorage2D(o.TEXTURE_2D,Yt,Dt,ot.width,ot.height),e.texSubImage2D(o.TEXTURE_2D,0,0,0,ot.width,ot.height,Zt,zt,ot.data)):e.texImage2D(o.TEXTURE_2D,0,Dt,ot.width,ot.height,0,Zt,zt,ot.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){Qt&&de&&e.texStorage3D(o.TEXTURE_2D_ARRAY,Yt,Dt,Wt[0].width,Wt[0].height,ot.depth);for(let ft=0,N=Wt.length;ft<N;ft++)bt=Wt[ft],b.format!==Ke?Zt!==null?Qt?e.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,ft,0,0,0,bt.width,bt.height,ot.depth,Zt,bt.data,0,0):e.compressedTexImage3D(o.TEXTURE_2D_ARRAY,ft,Dt,bt.width,bt.height,ot.depth,0,bt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Qt?e.texSubImage3D(o.TEXTURE_2D_ARRAY,ft,0,0,0,bt.width,bt.height,ot.depth,Zt,zt,bt.data):e.texImage3D(o.TEXTURE_2D_ARRAY,ft,Dt,bt.width,bt.height,ot.depth,0,Zt,zt,bt.data)}else{Qt&&de&&e.texStorage2D(o.TEXTURE_2D,Yt,Dt,Wt[0].width,Wt[0].height);for(let ft=0,N=Wt.length;ft<N;ft++)bt=Wt[ft],b.format!==Ke?Zt!==null?Qt?e.compressedTexSubImage2D(o.TEXTURE_2D,ft,0,0,bt.width,bt.height,Zt,bt.data):e.compressedTexImage2D(o.TEXTURE_2D,ft,Dt,bt.width,bt.height,0,bt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Qt?e.texSubImage2D(o.TEXTURE_2D,ft,0,0,bt.width,bt.height,Zt,zt,bt.data):e.texImage2D(o.TEXTURE_2D,ft,Dt,bt.width,bt.height,0,Zt,zt,bt.data)}else if(b.isDataArrayTexture)Qt?(de&&e.texStorage3D(o.TEXTURE_2D_ARRAY,Yt,Dt,ot.width,ot.height,ot.depth),e.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,ot.width,ot.height,ot.depth,Zt,zt,ot.data)):e.texImage3D(o.TEXTURE_2D_ARRAY,0,Dt,ot.width,ot.height,ot.depth,0,Zt,zt,ot.data);else if(b.isData3DTexture)Qt?(de&&e.texStorage3D(o.TEXTURE_3D,Yt,Dt,ot.width,ot.height,ot.depth),e.texSubImage3D(o.TEXTURE_3D,0,0,0,0,ot.width,ot.height,ot.depth,Zt,zt,ot.data)):e.texImage3D(o.TEXTURE_3D,0,Dt,ot.width,ot.height,ot.depth,0,Zt,zt,ot.data);else if(b.isFramebufferTexture){if(de)if(Qt)e.texStorage2D(o.TEXTURE_2D,Yt,Dt,ot.width,ot.height);else{let ft=ot.width,N=ot.height;for(let yt=0;yt<Yt;yt++)e.texImage2D(o.TEXTURE_2D,yt,Dt,ft,N,0,Zt,zt,null),ft>>=1,N>>=1}}else if(Wt.length>0&&Jt){Qt&&de&&e.texStorage2D(o.TEXTURE_2D,Yt,Dt,Wt[0].width,Wt[0].height);for(let ft=0,N=Wt.length;ft<N;ft++)bt=Wt[ft],Qt?e.texSubImage2D(o.TEXTURE_2D,ft,0,0,Zt,zt,bt):e.texImage2D(o.TEXTURE_2D,ft,Dt,Zt,zt,bt);b.generateMipmaps=!1}else Qt?(de&&e.texStorage2D(o.TEXTURE_2D,Yt,Dt,ot.width,ot.height),e.texSubImage2D(o.TEXTURE_2D,0,0,0,Zt,zt,ot)):e.texImage2D(o.TEXTURE_2D,0,Dt,Zt,zt,ot);x(b,Jt)&&v(at),At.__version=it.version,b.onUpdate&&b.onUpdate(b)}A.__version=b.version}function Et(A,b,z){if(b.image.length!==6)return;const at=tt(A,b),st=b.source;e.bindTexture(o.TEXTURE_CUBE_MAP,A.__webglTexture,o.TEXTURE0+z);const it=n.get(st);if(st.version!==it.__version||at===!0){e.activeTexture(o.TEXTURE0+z);const At=te.getPrimaries(te.workingColorSpace),gt=b.colorSpace===We?null:te.getPrimaries(b.colorSpace),Mt=b.colorSpace===We||At===gt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,b.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,b.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Mt);const Ut=b.isCompressedTexture||b.image[0].isCompressedTexture,Ht=b.image[0]&&b.image[0].isDataTexture,ot=[];for(let ft=0;ft<6;ft++)!Ut&&!Ht?ot[ft]=y(b.image[ft],!1,!0,i.maxCubemapSize):ot[ft]=Ht?b.image[ft].image:b.image[ft],ot[ft]=_t(b,ot[ft]);const Jt=ot[0],Zt=m(Jt)||r,zt=s.convert(b.format,b.colorSpace),Dt=s.convert(b.type),bt=M(b.internalFormat,zt,Dt,b.colorSpace),Wt=r&&b.isVideoTexture!==!0,Qt=it.__version===void 0||at===!0;let de=R(b,Jt,Zt);H(o.TEXTURE_CUBE_MAP,b,Zt);let Yt;if(Ut){Wt&&Qt&&e.texStorage2D(o.TEXTURE_CUBE_MAP,de,bt,Jt.width,Jt.height);for(let ft=0;ft<6;ft++){Yt=ot[ft].mipmaps;for(let N=0;N<Yt.length;N++){const yt=Yt[N];b.format!==Ke?zt!==null?Wt?e.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N,0,0,yt.width,yt.height,zt,yt.data):e.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N,bt,yt.width,yt.height,0,yt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N,0,0,yt.width,yt.height,zt,Dt,yt.data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N,bt,yt.width,yt.height,0,zt,Dt,yt.data)}}}else{Yt=b.mipmaps,Wt&&Qt&&(Yt.length>0&&de++,e.texStorage2D(o.TEXTURE_CUBE_MAP,de,bt,ot[0].width,ot[0].height));for(let ft=0;ft<6;ft++)if(Ht){Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,ot[ft].width,ot[ft].height,zt,Dt,ot[ft].data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,bt,ot[ft].width,ot[ft].height,0,zt,Dt,ot[ft].data);for(let N=0;N<Yt.length;N++){const vt=Yt[N].image[ft].image;Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N+1,0,0,vt.width,vt.height,zt,Dt,vt.data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N+1,bt,vt.width,vt.height,0,zt,Dt,vt.data)}}else{Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,zt,Dt,ot[ft]):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,bt,zt,Dt,ot[ft]);for(let N=0;N<Yt.length;N++){const yt=Yt[N];Wt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N+1,0,0,zt,Dt,yt.image[ft]):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ft,N+1,bt,zt,Dt,yt.image[ft])}}}x(b,Zt)&&v(o.TEXTURE_CUBE_MAP),it.__version=st.version,b.onUpdate&&b.onUpdate(b)}A.__version=b.version}function mt(A,b,z,at,st,it){const At=s.convert(z.format,z.colorSpace),gt=s.convert(z.type),Mt=M(z.internalFormat,At,gt,z.colorSpace);if(!n.get(b).__hasExternalTextures){const Ht=Math.max(1,b.width>>it),ot=Math.max(1,b.height>>it);st===o.TEXTURE_3D||st===o.TEXTURE_2D_ARRAY?e.texImage3D(st,it,Mt,Ht,ot,b.depth,0,At,gt,null):e.texImage2D(st,it,Mt,Ht,ot,0,At,gt,null)}e.bindFramebuffer(o.FRAMEBUFFER,A),Q(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,at,st,n.get(z).__webglTexture,0,lt(b)):(st===o.TEXTURE_2D||st>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&st<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,at,st,n.get(z).__webglTexture,it),e.bindFramebuffer(o.FRAMEBUFFER,null)}function St(A,b,z){if(o.bindRenderbuffer(o.RENDERBUFFER,A),b.depthBuffer&&!b.stencilBuffer){let at=r===!0?o.DEPTH_COMPONENT24:o.DEPTH_COMPONENT16;if(z||Q(b)){const st=b.depthTexture;st&&st.isDepthTexture&&(st.type===_n?at=o.DEPTH_COMPONENT32F:st.type===vn&&(at=o.DEPTH_COMPONENT24));const it=lt(b);Q(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,it,at,b.width,b.height):o.renderbufferStorageMultisample(o.RENDERBUFFER,it,at,b.width,b.height)}else o.renderbufferStorage(o.RENDERBUFFER,at,b.width,b.height);o.framebufferRenderbuffer(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.RENDERBUFFER,A)}else if(b.depthBuffer&&b.stencilBuffer){const at=lt(b);z&&Q(b)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,at,o.DEPTH24_STENCIL8,b.width,b.height):Q(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,at,o.DEPTH24_STENCIL8,b.width,b.height):o.renderbufferStorage(o.RENDERBUFFER,o.DEPTH_STENCIL,b.width,b.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.RENDERBUFFER,A)}else{const at=b.isWebGLMultipleRenderTargets===!0?b.texture:[b.texture];for(let st=0;st<at.length;st++){const it=at[st],At=s.convert(it.format,it.colorSpace),gt=s.convert(it.type),Mt=M(it.internalFormat,At,gt,it.colorSpace),Ut=lt(b);z&&Q(b)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,Ut,Mt,b.width,b.height):Q(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,Ut,Mt,b.width,b.height):o.renderbufferStorage(o.RENDERBUFFER,Mt,b.width,b.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function Pt(A,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(o.FRAMEBUFFER,A),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(b.depthTexture).__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),O(b.depthTexture,0);const at=n.get(b.depthTexture).__webglTexture,st=lt(b);if(b.depthTexture.format===Fn)Q(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,at,0,st):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,at,0);else if(b.depthTexture.format===gi)Q(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,at,0,st):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,at,0);else throw new Error("Unknown depthTexture format")}function wt(A){const b=n.get(A),z=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!b.__autoAllocateDepthBuffer){if(z)throw new Error("target.depthTexture not supported in Cube render targets");Pt(b.__webglFramebuffer,A)}else if(z){b.__webglDepthbuffer=[];for(let at=0;at<6;at++)e.bindFramebuffer(o.FRAMEBUFFER,b.__webglFramebuffer[at]),b.__webglDepthbuffer[at]=o.createRenderbuffer(),St(b.__webglDepthbuffer[at],A,!1)}else e.bindFramebuffer(o.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer=o.createRenderbuffer(),St(b.__webglDepthbuffer,A,!1);e.bindFramebuffer(o.FRAMEBUFFER,null)}function It(A,b,z){const at=n.get(A);b!==void 0&&mt(at.__webglFramebuffer,A,A.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),z!==void 0&&wt(A)}function D(A){const b=A.texture,z=n.get(A),at=n.get(b);A.addEventListener("dispose",U),A.isWebGLMultipleRenderTargets!==!0&&(at.__webglTexture===void 0&&(at.__webglTexture=o.createTexture()),at.__version=b.version,a.memory.textures++);const st=A.isWebGLCubeRenderTarget===!0,it=A.isWebGLMultipleRenderTargets===!0,At=m(A)||r;if(st){z.__webglFramebuffer=[];for(let gt=0;gt<6;gt++)if(r&&b.mipmaps&&b.mipmaps.length>0){z.__webglFramebuffer[gt]=[];for(let Mt=0;Mt<b.mipmaps.length;Mt++)z.__webglFramebuffer[gt][Mt]=o.createFramebuffer()}else z.__webglFramebuffer[gt]=o.createFramebuffer()}else{if(r&&b.mipmaps&&b.mipmaps.length>0){z.__webglFramebuffer=[];for(let gt=0;gt<b.mipmaps.length;gt++)z.__webglFramebuffer[gt]=o.createFramebuffer()}else z.__webglFramebuffer=o.createFramebuffer();if(it)if(i.drawBuffers){const gt=A.texture;for(let Mt=0,Ut=gt.length;Mt<Ut;Mt++){const Ht=n.get(gt[Mt]);Ht.__webglTexture===void 0&&(Ht.__webglTexture=o.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(r&&A.samples>0&&Q(A)===!1){const gt=it?b:[b];z.__webglMultisampledFramebuffer=o.createFramebuffer(),z.__webglColorRenderbuffer=[],e.bindFramebuffer(o.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let Mt=0;Mt<gt.length;Mt++){const Ut=gt[Mt];z.__webglColorRenderbuffer[Mt]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,z.__webglColorRenderbuffer[Mt]);const Ht=s.convert(Ut.format,Ut.colorSpace),ot=s.convert(Ut.type),Jt=M(Ut.internalFormat,Ht,ot,Ut.colorSpace,A.isXRRenderTarget===!0),Zt=lt(A);o.renderbufferStorageMultisample(o.RENDERBUFFER,Zt,Jt,A.width,A.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Mt,o.RENDERBUFFER,z.__webglColorRenderbuffer[Mt])}o.bindRenderbuffer(o.RENDERBUFFER,null),A.depthBuffer&&(z.__webglDepthRenderbuffer=o.createRenderbuffer(),St(z.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(o.FRAMEBUFFER,null)}}if(st){e.bindTexture(o.TEXTURE_CUBE_MAP,at.__webglTexture),H(o.TEXTURE_CUBE_MAP,b,At);for(let gt=0;gt<6;gt++)if(r&&b.mipmaps&&b.mipmaps.length>0)for(let Mt=0;Mt<b.mipmaps.length;Mt++)mt(z.__webglFramebuffer[gt][Mt],A,b,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,Mt);else mt(z.__webglFramebuffer[gt],A,b,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0);x(b,At)&&v(o.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(it){const gt=A.texture;for(let Mt=0,Ut=gt.length;Mt<Ut;Mt++){const Ht=gt[Mt],ot=n.get(Ht);e.bindTexture(o.TEXTURE_2D,ot.__webglTexture),H(o.TEXTURE_2D,Ht,At),mt(z.__webglFramebuffer,A,Ht,o.COLOR_ATTACHMENT0+Mt,o.TEXTURE_2D,0),x(Ht,At)&&v(o.TEXTURE_2D)}e.unbindTexture()}else{let gt=o.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(r?gt=A.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(gt,at.__webglTexture),H(gt,b,At),r&&b.mipmaps&&b.mipmaps.length>0)for(let Mt=0;Mt<b.mipmaps.length;Mt++)mt(z.__webglFramebuffer[Mt],A,b,o.COLOR_ATTACHMENT0,gt,Mt);else mt(z.__webglFramebuffer,A,b,o.COLOR_ATTACHMENT0,gt,0);x(b,At)&&v(gt),e.unbindTexture()}A.depthBuffer&&wt(A)}function ht(A){const b=m(A)||r,z=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let at=0,st=z.length;at<st;at++){const it=z[at];if(x(it,b)){const At=A.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:o.TEXTURE_2D,gt=n.get(it).__webglTexture;e.bindTexture(At,gt),v(At),e.unbindTexture()}}}function K(A){if(r&&A.samples>0&&Q(A)===!1){const b=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],z=A.width,at=A.height;let st=o.COLOR_BUFFER_BIT;const it=[],At=A.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,gt=n.get(A),Mt=A.isWebGLMultipleRenderTargets===!0;if(Mt)for(let Ut=0;Ut<b.length;Ut++)e.bindFramebuffer(o.FRAMEBUFFER,gt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ut,o.RENDERBUFFER,null),e.bindFramebuffer(o.FRAMEBUFFER,gt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ut,o.TEXTURE_2D,null,0);e.bindFramebuffer(o.READ_FRAMEBUFFER,gt.__webglMultisampledFramebuffer),e.bindFramebuffer(o.DRAW_FRAMEBUFFER,gt.__webglFramebuffer);for(let Ut=0;Ut<b.length;Ut++){it.push(o.COLOR_ATTACHMENT0+Ut),A.depthBuffer&&it.push(At);const Ht=gt.__ignoreDepthValues!==void 0?gt.__ignoreDepthValues:!1;if(Ht===!1&&(A.depthBuffer&&(st|=o.DEPTH_BUFFER_BIT),A.stencilBuffer&&(st|=o.STENCIL_BUFFER_BIT)),Mt&&o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,gt.__webglColorRenderbuffer[Ut]),Ht===!0&&(o.invalidateFramebuffer(o.READ_FRAMEBUFFER,[At]),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[At])),Mt){const ot=n.get(b[Ut]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,ot,0)}o.blitFramebuffer(0,0,z,at,0,0,z,at,st,o.NEAREST),l&&o.invalidateFramebuffer(o.READ_FRAMEBUFFER,it)}if(e.bindFramebuffer(o.READ_FRAMEBUFFER,null),e.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),Mt)for(let Ut=0;Ut<b.length;Ut++){e.bindFramebuffer(o.FRAMEBUFFER,gt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ut,o.RENDERBUFFER,gt.__webglColorRenderbuffer[Ut]);const Ht=n.get(b[Ut]).__webglTexture;e.bindFramebuffer(o.FRAMEBUFFER,gt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ut,o.TEXTURE_2D,Ht,0)}e.bindFramebuffer(o.DRAW_FRAMEBUFFER,gt.__webglMultisampledFramebuffer)}}function lt(A){return Math.min(i.maxSamples,A.samples)}function Q(A){const b=n.get(A);return r&&A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function Rt(A){const b=a.render.frame;h.get(A)!==b&&(h.set(A,b),A.update())}function _t(A,b){const z=A.colorSpace,at=A.format,st=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===zo||z!==un&&z!==We&&(te.getTransfer(z)===ae?r===!1?t.has("EXT_sRGB")===!0&&at===Ke?(A.format=zo,A.minFilter=He,A.generateMipmaps=!1):b=uc.sRGBToLinear(b):(at!==Ke||st!==Sn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",z)),b}this.allocateTextureUnit=I,this.resetTextureUnits=j,this.setTexture2D=O,this.setTexture2DArray=Z,this.setTexture3D=X,this.setTextureCube=q,this.rebindTextures=It,this.setupRenderTarget=D,this.updateRenderTargetMipmap=ht,this.updateMultisampleRenderTarget=K,this.setupDepthRenderbuffer=wt,this.setupFrameBufferTexture=mt,this.useMultisampledRTT=Q}function jp(o,t,e){const n=e.isWebGL2;function i(s,a=We){let r;const c=te.getTransfer(a);if(s===Sn)return o.UNSIGNED_BYTE;if(s===nc)return o.UNSIGNED_SHORT_4_4_4_4;if(s===ic)return o.UNSIGNED_SHORT_5_5_5_1;if(s===Ll)return o.BYTE;if(s===Pl)return o.SHORT;if(s===Zo)return o.UNSIGNED_SHORT;if(s===ec)return o.INT;if(s===vn)return o.UNSIGNED_INT;if(s===_n)return o.FLOAT;if(s===Fi)return n?o.HALF_FLOAT:(r=t.get("OES_texture_half_float"),r!==null?r.HALF_FLOAT_OES:null);if(s===Il)return o.ALPHA;if(s===Ke)return o.RGBA;if(s===Dl)return o.LUMINANCE;if(s===Ul)return o.LUMINANCE_ALPHA;if(s===Fn)return o.DEPTH_COMPONENT;if(s===gi)return o.DEPTH_STENCIL;if(s===zo)return r=t.get("EXT_sRGB"),r!==null?r.SRGB_ALPHA_EXT:null;if(s===Nl)return o.RED;if(s===sc)return o.RED_INTEGER;if(s===Bl)return o.RG;if(s===oc)return o.RG_INTEGER;if(s===ac)return o.RGBA_INTEGER;if(s===js||s===Zs||s===Ks||s===Js)if(c===ae)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(s===js)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Zs)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===Ks)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Js)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(s===js)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Zs)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===Ks)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Js)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===wa||s===Ma||s===Sa||s===ba)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(s===wa)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===Ma)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Sa)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===ba)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===rc)return r=t.get("WEBGL_compressed_texture_etc1"),r!==null?r.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===Ea||s===Ta)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(s===Ea)return c===ae?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(s===Ta)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===Aa||s===Ca||s===Ra||s===La||s===Pa||s===Ia||s===Da||s===Ua||s===Na||s===Ba||s===Fa||s===Oa||s===ka||s===za)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(s===Aa)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Ca)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Ra)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===La)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Pa)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Ia)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Da)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Ua)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===Na)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Ba)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Fa)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Oa)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===ka)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===za)return c===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Qs||s===Ga||s===Ha)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(s===Qs)return c===ae?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===Ga)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Ha)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===Fl||s===Va||s===Wa||s===Xa)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(s===Qs)return r.COMPRESSED_RED_RGTC1_EXT;if(s===Va)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===Wa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Xa)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===Bn?n?o.UNSIGNED_INT_24_8:(r=t.get("WEBGL_depth_texture"),r!==null?r.UNSIGNED_INT_24_8_WEBGL:null):o[s]!==void 0?o[s]:null}return{convert:i}}class Zp extends De{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}}class dt extends fe{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Kp={type:"move"};class Eo{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new dt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new dt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new dt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,s=null,a=null;const r=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(const y of t.hand.values()){const m=e.getJointPose(y,n),p=this._getHandJoint(l,y);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const h=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],u=h.position.distanceTo(d.position),f=.02,g=.005;l.inputState.pinching&&u>f+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&u<=f-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(s=e.getPose(t.gripSpace,n),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));r!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&s!==null&&(i=s),i!==null&&(r.matrix.fromArray(i.transform.matrix),r.matrix.decompose(r.position,r.rotation,r.scale),r.matrixWorldNeedsUpdate=!0,i.linearVelocity?(r.hasLinearVelocity=!0,r.linearVelocity.copy(i.linearVelocity)):r.hasLinearVelocity=!1,i.angularVelocity?(r.hasAngularVelocity=!0,r.angularVelocity.copy(i.angularVelocity)):r.hasAngularVelocity=!1,this.dispatchEvent(Kp)))}return r!==null&&(r.visible=i!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new dt;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}class Jp extends vi{constructor(t,e){super();const n=this;let i=null,s=1,a=null,r="local-floor",c=1,l=null,h=null,d=null,u=null,f=null,g=null;const y=e.getContextAttributes();let m=null,p=null;const x=[],v=[],M=new ct;let R=null;const T=new De;T.layers.enable(1),T.viewport=new re;const E=new De;E.layers.enable(2),E.viewport=new re;const U=[T,E],w=new Zp;w.layers.enable(1),w.layers.enable(2);let S=null,P=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(H){let tt=x[H];return tt===void 0&&(tt=new Eo,x[H]=tt),tt.getTargetRaySpace()},this.getControllerGrip=function(H){let tt=x[H];return tt===void 0&&(tt=new Eo,x[H]=tt),tt.getGripSpace()},this.getHand=function(H){let tt=x[H];return tt===void 0&&(tt=new Eo,x[H]=tt),tt.getHandSpace()};function F(H){const tt=v.indexOf(H.inputSource);if(tt===-1)return;const ut=x[tt];ut!==void 0&&(ut.update(H.inputSource,H.frame,l||a),ut.dispatchEvent({type:H.type,data:H.inputSource}))}function j(){i.removeEventListener("select",F),i.removeEventListener("selectstart",F),i.removeEventListener("selectend",F),i.removeEventListener("squeeze",F),i.removeEventListener("squeezestart",F),i.removeEventListener("squeezeend",F),i.removeEventListener("end",j),i.removeEventListener("inputsourceschange",I);for(let H=0;H<x.length;H++){const tt=v[H];tt!==null&&(v[H]=null,x[H].disconnect(tt))}S=null,P=null,t.setRenderTarget(m),f=null,u=null,d=null,i=null,p=null,rt.stop(),n.isPresenting=!1,t.setPixelRatio(R),t.setSize(M.width,M.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(H){s=H,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(H){r=H,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(H){l=H},this.getBaseLayer=function(){return u!==null?u:f},this.getBinding=function(){return d},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(H){if(i=H,i!==null){if(m=t.getRenderTarget(),i.addEventListener("select",F),i.addEventListener("selectstart",F),i.addEventListener("selectend",F),i.addEventListener("squeeze",F),i.addEventListener("squeezestart",F),i.addEventListener("squeezeend",F),i.addEventListener("end",j),i.addEventListener("inputsourceschange",I),y.xrCompatible!==!0&&await e.makeXRCompatible(),R=t.getPixelRatio(),t.getSize(M),i.renderState.layers===void 0||t.capabilities.isWebGL2===!1){const tt={antialias:i.renderState.layers===void 0?y.antialias:!0,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(i,e,tt),i.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),p=new kn(f.framebufferWidth,f.framebufferHeight,{format:Ke,type:Sn,colorSpace:t.outputColorSpace,stencilBuffer:y.stencil})}else{let tt=null,ut=null,Et=null;y.depth&&(Et=y.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,tt=y.stencil?gi:Fn,ut=y.stencil?Bn:vn);const mt={colorFormat:e.RGBA8,depthFormat:Et,scaleFactor:s};d=new XRWebGLBinding(i,e),u=d.createProjectionLayer(mt),i.updateRenderState({layers:[u]}),t.setPixelRatio(1),t.setSize(u.textureWidth,u.textureHeight,!1),p=new kn(u.textureWidth,u.textureHeight,{format:Ke,type:Sn,depthTexture:new Sc(u.textureWidth,u.textureHeight,ut,void 0,void 0,void 0,void 0,void 0,void 0,tt),stencilBuffer:y.stencil,colorSpace:t.outputColorSpace,samples:y.antialias?4:0});const St=t.properties.get(p);St.__ignoreDepthValues=u.ignoreDepthValues}p.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await i.requestReferenceSpace(r),rt.setContext(i),rt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode};function I(H){for(let tt=0;tt<H.removed.length;tt++){const ut=H.removed[tt],Et=v.indexOf(ut);Et>=0&&(v[Et]=null,x[Et].disconnect(ut))}for(let tt=0;tt<H.added.length;tt++){const ut=H.added[tt];let Et=v.indexOf(ut);if(Et===-1){for(let St=0;St<x.length;St++)if(St>=v.length){v.push(ut),Et=St;break}else if(v[St]===null){v[St]=ut,Et=St;break}if(Et===-1)break}const mt=x[Et];mt&&mt.connect(ut)}}const B=new L,O=new L;function Z(H,tt,ut){B.setFromMatrixPosition(tt.matrixWorld),O.setFromMatrixPosition(ut.matrixWorld);const Et=B.distanceTo(O),mt=tt.projectionMatrix.elements,St=ut.projectionMatrix.elements,Pt=mt[14]/(mt[10]-1),wt=mt[14]/(mt[10]+1),It=(mt[9]+1)/mt[5],D=(mt[9]-1)/mt[5],ht=(mt[8]-1)/mt[0],K=(St[8]+1)/St[0],lt=Pt*ht,Q=Pt*K,Rt=Et/(-ht+K),_t=Rt*-ht;tt.matrixWorld.decompose(H.position,H.quaternion,H.scale),H.translateX(_t),H.translateZ(Rt),H.matrixWorld.compose(H.position,H.quaternion,H.scale),H.matrixWorldInverse.copy(H.matrixWorld).invert();const A=Pt+Rt,b=wt+Rt,z=lt-_t,at=Q+(Et-_t),st=It*wt/b*A,it=D*wt/b*A;H.projectionMatrix.makePerspective(z,at,st,it,A,b),H.projectionMatrixInverse.copy(H.projectionMatrix).invert()}function X(H,tt){tt===null?H.matrixWorld.copy(H.matrix):H.matrixWorld.multiplyMatrices(tt.matrixWorld,H.matrix),H.matrixWorldInverse.copy(H.matrixWorld).invert()}this.updateCamera=function(H){if(i===null)return;w.near=E.near=T.near=H.near,w.far=E.far=T.far=H.far,(S!==w.near||P!==w.far)&&(i.updateRenderState({depthNear:w.near,depthFar:w.far}),S=w.near,P=w.far);const tt=H.parent,ut=w.cameras;X(w,tt);for(let Et=0;Et<ut.length;Et++)X(ut[Et],tt);ut.length===2?Z(w,T,E):w.projectionMatrix.copy(T.projectionMatrix),q(H,w,tt)};function q(H,tt,ut){ut===null?H.matrix.copy(tt.matrixWorld):(H.matrix.copy(ut.matrixWorld),H.matrix.invert(),H.matrix.multiply(tt.matrixWorld)),H.matrix.decompose(H.position,H.quaternion,H.scale),H.updateMatrixWorld(!0),H.projectionMatrix.copy(tt.projectionMatrix),H.projectionMatrixInverse.copy(tt.projectionMatrixInverse),H.isPerspectiveCamera&&(H.fov=Ps*2*Math.atan(1/H.projectionMatrix.elements[5]),H.zoom=1)}this.getCamera=function(){return w},this.getFoveation=function(){if(!(u===null&&f===null))return c},this.setFoveation=function(H){c=H,u!==null&&(u.fixedFoveation=H),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=H)};let J=null;function et(H,tt){if(h=tt.getViewerPose(l||a),g=tt,h!==null){const ut=h.views;f!==null&&(t.setRenderTargetFramebuffer(p,f.framebuffer),t.setRenderTarget(p));let Et=!1;ut.length!==w.cameras.length&&(w.cameras.length=0,Et=!0);for(let mt=0;mt<ut.length;mt++){const St=ut[mt];let Pt=null;if(f!==null)Pt=f.getViewport(St);else{const It=d.getViewSubImage(u,St);Pt=It.viewport,mt===0&&(t.setRenderTargetTextures(p,It.colorTexture,u.ignoreDepthValues?void 0:It.depthStencilTexture),t.setRenderTarget(p))}let wt=U[mt];wt===void 0&&(wt=new De,wt.layers.enable(mt),wt.viewport=new re,U[mt]=wt),wt.matrix.fromArray(St.transform.matrix),wt.matrix.decompose(wt.position,wt.quaternion,wt.scale),wt.projectionMatrix.fromArray(St.projectionMatrix),wt.projectionMatrixInverse.copy(wt.projectionMatrix).invert(),wt.viewport.set(Pt.x,Pt.y,Pt.width,Pt.height),mt===0&&(w.matrix.copy(wt.matrix),w.matrix.decompose(w.position,w.quaternion,w.scale)),Et===!0&&w.cameras.push(wt)}}for(let ut=0;ut<x.length;ut++){const Et=v[ut],mt=x[ut];Et!==null&&mt!==void 0&&mt.update(Et,tt,l||a)}J&&J(H,tt),tt.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:tt}),g=null}const rt=new wc;rt.setAnimationLoop(et),this.setAnimationLoop=function(H){J=H},this.dispose=function(){}}}function Qp(o,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,vc(o)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function i(m,p,x,v,M){p.isMeshBasicMaterial||p.isMeshLambertMaterial?s(m,p):p.isMeshToonMaterial?(s(m,p),d(m,p)):p.isMeshPhongMaterial?(s(m,p),h(m,p)):p.isMeshStandardMaterial?(s(m,p),u(m,p),p.isMeshPhysicalMaterial&&f(m,p,M)):p.isMeshMatcapMaterial?(s(m,p),g(m,p)):p.isMeshDepthMaterial?s(m,p):p.isMeshDistanceMaterial?(s(m,p),y(m,p)):p.isMeshNormalMaterial?s(m,p):p.isLineBasicMaterial?(a(m,p),p.isLineDashedMaterial&&r(m,p)):p.isPointsMaterial?c(m,p,x,v):p.isSpriteMaterial?l(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Ue&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Ue&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const x=t.get(p).envMap;if(x&&(m.envMap.value=x,m.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap){m.lightMap.value=p.lightMap;const v=o._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=p.lightMapIntensity*v,e(p.lightMap,m.lightMapTransform)}p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function a(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function r(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function c(m,p,x,v){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*x,m.scale.value=v*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function l(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function d(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function u(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),t.get(p).envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,x){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Ue&&m.clearcoatNormalScale.value.negate())),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=x.texture,m.transmissionSamplerSize.value.set(x.width,x.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function y(m,p){const x=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(x.matrixWorld),m.nearDistance.value=x.shadow.camera.near,m.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function tm(o,t,e,n){let i={},s={},a=[];const r=e.isWebGL2?o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(x,v){const M=v.program;n.uniformBlockBinding(x,M)}function l(x,v){let M=i[x.id];M===void 0&&(g(x),M=h(x),i[x.id]=M,x.addEventListener("dispose",m));const R=v.program;n.updateUBOMapping(x,R);const T=t.render.frame;s[x.id]!==T&&(u(x),s[x.id]=T)}function h(x){const v=d();x.__bindingPointIndex=v;const M=o.createBuffer(),R=x.__size,T=x.usage;return o.bindBuffer(o.UNIFORM_BUFFER,M),o.bufferData(o.UNIFORM_BUFFER,R,T),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,v,M),M}function d(){for(let x=0;x<r;x++)if(a.indexOf(x)===-1)return a.push(x),x;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(x){const v=i[x.id],M=x.uniforms,R=x.__cache;o.bindBuffer(o.UNIFORM_BUFFER,v);for(let T=0,E=M.length;T<E;T++){const U=Array.isArray(M[T])?M[T]:[M[T]];for(let w=0,S=U.length;w<S;w++){const P=U[w];if(f(P,T,w,R)===!0){const F=P.__offset,j=Array.isArray(P.value)?P.value:[P.value];let I=0;for(let B=0;B<j.length;B++){const O=j[B],Z=y(O);typeof O=="number"||typeof O=="boolean"?(P.__data[0]=O,o.bufferSubData(o.UNIFORM_BUFFER,F+I,P.__data)):O.isMatrix3?(P.__data[0]=O.elements[0],P.__data[1]=O.elements[1],P.__data[2]=O.elements[2],P.__data[3]=0,P.__data[4]=O.elements[3],P.__data[5]=O.elements[4],P.__data[6]=O.elements[5],P.__data[7]=0,P.__data[8]=O.elements[6],P.__data[9]=O.elements[7],P.__data[10]=O.elements[8],P.__data[11]=0):(O.toArray(P.__data,I),I+=Z.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,F,P.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function f(x,v,M,R){const T=x.value,E=v+"_"+M;if(R[E]===void 0)return typeof T=="number"||typeof T=="boolean"?R[E]=T:R[E]=T.clone(),!0;{const U=R[E];if(typeof T=="number"||typeof T=="boolean"){if(U!==T)return R[E]=T,!0}else if(U.equals(T)===!1)return U.copy(T),!0}return!1}function g(x){const v=x.uniforms;let M=0;const R=16;for(let E=0,U=v.length;E<U;E++){const w=Array.isArray(v[E])?v[E]:[v[E]];for(let S=0,P=w.length;S<P;S++){const F=w[S],j=Array.isArray(F.value)?F.value:[F.value];for(let I=0,B=j.length;I<B;I++){const O=j[I],Z=y(O),X=M%R;X!==0&&R-X<Z.boundary&&(M+=R-X),F.__data=new Float32Array(Z.storage/Float32Array.BYTES_PER_ELEMENT),F.__offset=M,M+=Z.storage}}}const T=M%R;return T>0&&(M+=R-T),x.__size=M,x.__cache={},this}function y(x){const v={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(v.boundary=4,v.storage=4):x.isVector2?(v.boundary=8,v.storage=8):x.isVector3||x.isColor?(v.boundary=16,v.storage=12):x.isVector4?(v.boundary=16,v.storage=16):x.isMatrix3?(v.boundary=48,v.storage=48):x.isMatrix4?(v.boundary=64,v.storage=64):x.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",x),v}function m(x){const v=x.target;v.removeEventListener("dispose",m);const M=a.indexOf(v.__bindingPointIndex);a.splice(M,1),o.deleteBuffer(i[v.id]),delete i[v.id],delete s[v.id]}function p(){for(const x in i)o.deleteBuffer(i[x]);a=[],i={},s={}}return{bind:c,update:l,dispose:p}}class Rc{constructor(t={}){const{canvas:e=jl(),context:n=null,depth:i=!0,stencil:s=!0,alpha:a=!1,antialias:r=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1}=t;this.isWebGLRenderer=!0;let u;n!==null?u=n.getContextAttributes().alpha:u=a;const f=new Uint32Array(4),g=new Int32Array(4);let y=null,m=null;const p=[],x=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Se,this._useLegacyLights=!1,this.toneMapping=Mn,this.toneMappingExposure=1;const v=this;let M=!1,R=0,T=0,E=null,U=-1,w=null;const S=new re,P=new re;let F=null;const j=new kt(0);let I=0,B=e.width,O=e.height,Z=1,X=null,q=null;const J=new re(0,0,B,O),et=new re(0,0,B,O);let rt=!1;const H=new Qo;let tt=!1,ut=!1,Et=null;const mt=new ce,St=new ct,Pt=new L,wt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function It(){return E===null?Z:1}let D=n;function ht(C,k){for(let W=0;W<C.length;W++){const $=C[W],V=e.getContext($,k);if(V!==null)return V}return null}try{const C={alpha:!0,depth:i,stencil:s,antialias:r,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Yo}`),e.addEventListener("webglcontextlost",ft,!1),e.addEventListener("webglcontextrestored",N,!1),e.addEventListener("webglcontextcreationerror",yt,!1),D===null){const k=["webgl2","webgl","experimental-webgl"];if(v.isWebGL1Renderer===!0&&k.shift(),D=ht(k,C),D===null)throw ht(k)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&D instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),D.getShaderPrecisionFormat===void 0&&(D.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let K,lt,Q,Rt,_t,A,b,z,at,st,it,At,gt,Mt,Ut,Ht,ot,Jt,Zt,zt,Dt,bt,Wt,Qt;function de(){K=new hf(D),lt=new sf(D,K,t),K.init(lt),bt=new jp(D,K,lt),Q=new Yp(D,K,lt),Rt=new ff(D),_t=new Dp,A=new $p(D,K,Q,_t,lt,bt,Rt),b=new af(v),z=new lf(v),at=new xh(D,lt),Wt=new ef(D,K,at,lt),st=new df(D,at,Rt,Wt),it=new yf(D,st,at,Rt),Zt=new gf(D,lt,A),Ht=new of(_t),At=new Ip(v,b,z,K,lt,Wt,Ht),gt=new Qp(v,_t),Mt=new Np,Ut=new Gp(K,lt),Jt=new tf(v,b,z,Q,it,u,c),ot=new qp(v,it,lt),Qt=new tm(D,Rt,lt,Q),zt=new nf(D,K,Rt,lt),Dt=new uf(D,K,Rt,lt),Rt.programs=At.programs,v.capabilities=lt,v.extensions=K,v.properties=_t,v.renderLists=Mt,v.shadowMap=ot,v.state=Q,v.info=Rt}de();const Yt=new Jp(v,D);this.xr=Yt,this.getContext=function(){return D},this.getContextAttributes=function(){return D.getContextAttributes()},this.forceContextLoss=function(){const C=K.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=K.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return Z},this.setPixelRatio=function(C){C!==void 0&&(Z=C,this.setSize(B,O,!1))},this.getSize=function(C){return C.set(B,O)},this.setSize=function(C,k,W=!0){if(Yt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}B=C,O=k,e.width=Math.floor(C*Z),e.height=Math.floor(k*Z),W===!0&&(e.style.width=C+"px",e.style.height=k+"px"),this.setViewport(0,0,C,k)},this.getDrawingBufferSize=function(C){return C.set(B*Z,O*Z).floor()},this.setDrawingBufferSize=function(C,k,W){B=C,O=k,Z=W,e.width=Math.floor(C*W),e.height=Math.floor(k*W),this.setViewport(0,0,C,k)},this.getCurrentViewport=function(C){return C.copy(S)},this.getViewport=function(C){return C.copy(J)},this.setViewport=function(C,k,W,$){C.isVector4?J.set(C.x,C.y,C.z,C.w):J.set(C,k,W,$),Q.viewport(S.copy(J).multiplyScalar(Z).floor())},this.getScissor=function(C){return C.copy(et)},this.setScissor=function(C,k,W,$){C.isVector4?et.set(C.x,C.y,C.z,C.w):et.set(C,k,W,$),Q.scissor(P.copy(et).multiplyScalar(Z).floor())},this.getScissorTest=function(){return rt},this.setScissorTest=function(C){Q.setScissorTest(rt=C)},this.setOpaqueSort=function(C){X=C},this.setTransparentSort=function(C){q=C},this.getClearColor=function(C){return C.copy(Jt.getClearColor())},this.setClearColor=function(){Jt.setClearColor.apply(Jt,arguments)},this.getClearAlpha=function(){return Jt.getClearAlpha()},this.setClearAlpha=function(){Jt.setClearAlpha.apply(Jt,arguments)},this.clear=function(C=!0,k=!0,W=!0){let $=0;if(C){let V=!1;if(E!==null){const xt=E.texture.format;V=xt===ac||xt===oc||xt===sc}if(V){const xt=E.texture.type,Ct=xt===Sn||xt===vn||xt===Zo||xt===Bn||xt===nc||xt===ic,Bt=Jt.getClearColor(),Ot=Jt.getClearAlpha(),qt=Bt.r,Gt=Bt.g,Vt=Bt.b;Ct?(f[0]=qt,f[1]=Gt,f[2]=Vt,f[3]=Ot,D.clearBufferuiv(D.COLOR,0,f)):(g[0]=qt,g[1]=Gt,g[2]=Vt,g[3]=Ot,D.clearBufferiv(D.COLOR,0,g))}else $|=D.COLOR_BUFFER_BIT}k&&($|=D.DEPTH_BUFFER_BIT),W&&($|=D.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),D.clear($)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",ft,!1),e.removeEventListener("webglcontextrestored",N,!1),e.removeEventListener("webglcontextcreationerror",yt,!1),Mt.dispose(),Ut.dispose(),_t.dispose(),b.dispose(),z.dispose(),it.dispose(),Wt.dispose(),Qt.dispose(),At.dispose(),Yt.dispose(),Yt.removeEventListener("sessionstart",Ce),Yt.removeEventListener("sessionend",se),Et&&(Et.dispose(),Et=null),Re.stop()};function ft(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),M=!0}function N(){console.log("THREE.WebGLRenderer: Context Restored."),M=!1;const C=Rt.autoReset,k=ot.enabled,W=ot.autoUpdate,$=ot.needsUpdate,V=ot.type;de(),Rt.autoReset=C,ot.enabled=k,ot.autoUpdate=W,ot.needsUpdate=$,ot.type=V}function yt(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function vt(C){const k=C.target;k.removeEventListener("dispose",vt),Ft(k)}function Ft(C){Nt(C),_t.remove(C)}function Nt(C){const k=_t.get(C).programs;k!==void 0&&(k.forEach(function(W){At.releaseProgram(W)}),C.isShaderMaterial&&At.releaseShaderCache(C))}this.renderBufferDirect=function(C,k,W,$,V,xt){k===null&&(k=wt);const Ct=V.isMesh&&V.matrixWorld.determinant()<0,Bt=qc(C,k,W,$,V);Q.setMaterial($,Ct);let Ot=W.index,qt=1;if($.wireframe===!0){if(Ot=st.getWireframeAttribute(W),Ot===void 0)return;qt=2}const Gt=W.drawRange,Vt=W.attributes.position;let pe=Gt.start*qt,Be=(Gt.start+Gt.count)*qt;xt!==null&&(pe=Math.max(pe,xt.start*qt),Be=Math.min(Be,(xt.start+xt.count)*qt)),Ot!==null?(pe=Math.max(pe,0),Be=Math.min(Be,Ot.count)):Vt!=null&&(pe=Math.max(pe,0),Be=Math.min(Be,Vt.count));const we=Be-pe;if(we<0||we===1/0)return;Wt.setup(V,$,Bt,W,Ot);let en,le=zt;if(Ot!==null&&(en=at.get(Ot),le=Dt,le.setIndex(en)),V.isMesh)$.wireframe===!0?(Q.setLineWidth($.wireframeLinewidth*It()),le.setMode(D.LINES)):le.setMode(D.TRIANGLES);else if(V.isLine){let $t=$.linewidth;$t===void 0&&($t=1),Q.setLineWidth($t*It()),V.isLineSegments?le.setMode(D.LINES):V.isLineLoop?le.setMode(D.LINE_LOOP):le.setMode(D.LINE_STRIP)}else V.isPoints?le.setMode(D.POINTS):V.isSprite&&le.setMode(D.TRIANGLES);if(V.isBatchedMesh)le.renderMultiDraw(V._multiDrawStarts,V._multiDrawCounts,V._multiDrawCount);else if(V.isInstancedMesh)le.renderInstances(pe,we,V.count);else if(W.isInstancedBufferGeometry){const $t=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,Ws=Math.min(W.instanceCount,$t);le.renderInstances(pe,we,Ws)}else le.render(pe,we)};function ne(C,k,W){C.transparent===!0&&C.side===ye&&C.forceSinglePass===!1?(C.side=Ue,C.needsUpdate=!0,qi(C,k,W),C.side=bn,C.needsUpdate=!0,qi(C,k,W),C.side=ye):qi(C,k,W)}this.compile=function(C,k,W=null){W===null&&(W=C),m=Ut.get(W),m.init(),x.push(m),W.traverseVisible(function(V){V.isLight&&V.layers.test(k.layers)&&(m.pushLight(V),V.castShadow&&m.pushShadow(V))}),C!==W&&C.traverseVisible(function(V){V.isLight&&V.layers.test(k.layers)&&(m.pushLight(V),V.castShadow&&m.pushShadow(V))}),m.setupLights(v._useLegacyLights);const $=new Set;return C.traverse(function(V){const xt=V.material;if(xt)if(Array.isArray(xt))for(let Ct=0;Ct<xt.length;Ct++){const Bt=xt[Ct];ne(Bt,W,V),$.add(Bt)}else ne(xt,W,V),$.add(xt)}),x.pop(),m=null,$},this.compileAsync=function(C,k,W=null){const $=this.compile(C,k,W);return new Promise(V=>{function xt(){if($.forEach(function(Ct){_t.get(Ct).currentProgram.isReady()&&$.delete(Ct)}),$.size===0){V(C);return}setTimeout(xt,10)}K.get("KHR_parallel_shader_compile")!==null?xt():setTimeout(xt,10)})};let ie=null;function xe(C){ie&&ie(C)}function Ce(){Re.stop()}function se(){Re.start()}const Re=new wc;Re.setAnimationLoop(xe),typeof self<"u"&&Re.setContext(self),this.setAnimationLoop=function(C){ie=C,Yt.setAnimationLoop(C),C===null?Re.stop():Re.start()},Yt.addEventListener("sessionstart",Ce),Yt.addEventListener("sessionend",se),this.render=function(C,k){if(k!==void 0&&k.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(M===!0)return;C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),k.parent===null&&k.matrixWorldAutoUpdate===!0&&k.updateMatrixWorld(),Yt.enabled===!0&&Yt.isPresenting===!0&&(Yt.cameraAutoUpdate===!0&&Yt.updateCamera(k),k=Yt.getCamera()),C.isScene===!0&&C.onBeforeRender(v,C,k,E),m=Ut.get(C,x.length),m.init(),x.push(m),mt.multiplyMatrices(k.projectionMatrix,k.matrixWorldInverse),H.setFromProjectionMatrix(mt),ut=this.localClippingEnabled,tt=Ht.init(this.clippingPlanes,ut),y=Mt.get(C,p.length),y.init(),p.push(y),Je(C,k,0,v.sortObjects),y.finish(),v.sortObjects===!0&&y.sort(X,q),this.info.render.frame++,tt===!0&&Ht.beginShadows();const W=m.state.shadowsArray;if(ot.render(W,C,k),tt===!0&&Ht.endShadows(),this.info.autoReset===!0&&this.info.reset(),Jt.render(y,C),m.setupLights(v._useLegacyLights),k.isArrayCamera){const $=k.cameras;for(let V=0,xt=$.length;V<xt;V++){const Ct=$[V];la(y,C,Ct,Ct.viewport)}}else la(y,C,k);E!==null&&(A.updateMultisampleRenderTarget(E),A.updateRenderTargetMipmap(E)),C.isScene===!0&&C.onAfterRender(v,C,k),Wt.resetDefaultState(),U=-1,w=null,x.pop(),x.length>0?m=x[x.length-1]:m=null,p.pop(),p.length>0?y=p[p.length-1]:y=null};function Je(C,k,W,$){if(C.visible===!1)return;if(C.layers.test(k.layers)){if(C.isGroup)W=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(k);else if(C.isLight)m.pushLight(C),C.castShadow&&m.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||H.intersectsSprite(C)){$&&Pt.setFromMatrixPosition(C.matrixWorld).applyMatrix4(mt);const Ct=it.update(C),Bt=C.material;Bt.visible&&y.push(C,Ct,Bt,W,Pt.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||H.intersectsObject(C))){const Ct=it.update(C),Bt=C.material;if($&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),Pt.copy(C.boundingSphere.center)):(Ct.boundingSphere===null&&Ct.computeBoundingSphere(),Pt.copy(Ct.boundingSphere.center)),Pt.applyMatrix4(C.matrixWorld).applyMatrix4(mt)),Array.isArray(Bt)){const Ot=Ct.groups;for(let qt=0,Gt=Ot.length;qt<Gt;qt++){const Vt=Ot[qt],pe=Bt[Vt.materialIndex];pe&&pe.visible&&y.push(C,Ct,pe,W,Pt.z,Vt)}}else Bt.visible&&y.push(C,Ct,Bt,W,Pt.z,null)}}const xt=C.children;for(let Ct=0,Bt=xt.length;Ct<Bt;Ct++)Je(xt[Ct],k,W,$)}function la(C,k,W,$){const V=C.opaque,xt=C.transmissive,Ct=C.transparent;m.setupLightsView(W),tt===!0&&Ht.setGlobalState(v.clippingPlanes,W),xt.length>0&&Xc(V,xt,k,W),$&&Q.viewport(S.copy($)),V.length>0&&Xi(V,k,W),xt.length>0&&Xi(xt,k,W),Ct.length>0&&Xi(Ct,k,W),Q.buffers.depth.setTest(!0),Q.buffers.depth.setMask(!0),Q.buffers.color.setMask(!0),Q.setPolygonOffset(!1)}function Xc(C,k,W,$){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;const xt=lt.isWebGL2;Et===null&&(Et=new kn(1,1,{generateMipmaps:!0,type:K.has("EXT_color_buffer_half_float")?Fi:Sn,minFilter:Bi,samples:xt?4:0})),v.getDrawingBufferSize(St),xt?Et.setSize(St.x,St.y):Et.setSize(Go(St.x),Go(St.y));const Ct=v.getRenderTarget();v.setRenderTarget(Et),v.getClearColor(j),I=v.getClearAlpha(),I<1&&v.setClearColor(16777215,.5),v.clear();const Bt=v.toneMapping;v.toneMapping=Mn,Xi(C,W,$),A.updateMultisampleRenderTarget(Et),A.updateRenderTargetMipmap(Et);let Ot=!1;for(let qt=0,Gt=k.length;qt<Gt;qt++){const Vt=k[qt],pe=Vt.object,Be=Vt.geometry,we=Vt.material,en=Vt.group;if(we.side===ye&&pe.layers.test($.layers)){const le=we.side;we.side=Ue,we.needsUpdate=!0,ha(pe,W,$,Be,we,en),we.side=le,we.needsUpdate=!0,Ot=!0}}Ot===!0&&(A.updateMultisampleRenderTarget(Et),A.updateRenderTargetMipmap(Et)),v.setRenderTarget(Ct),v.setClearColor(j,I),v.toneMapping=Bt}function Xi(C,k,W){const $=k.isScene===!0?k.overrideMaterial:null;for(let V=0,xt=C.length;V<xt;V++){const Ct=C[V],Bt=Ct.object,Ot=Ct.geometry,qt=$===null?Ct.material:$,Gt=Ct.group;Bt.layers.test(W.layers)&&ha(Bt,k,W,Ot,qt,Gt)}}function ha(C,k,W,$,V,xt){C.onBeforeRender(v,k,W,$,V,xt),C.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),V.onBeforeRender(v,k,W,$,C,xt),V.transparent===!0&&V.side===ye&&V.forceSinglePass===!1?(V.side=Ue,V.needsUpdate=!0,v.renderBufferDirect(W,k,$,V,C,xt),V.side=bn,V.needsUpdate=!0,v.renderBufferDirect(W,k,$,V,C,xt),V.side=ye):v.renderBufferDirect(W,k,$,V,C,xt),C.onAfterRender(v,k,W,$,V,xt)}function qi(C,k,W){k.isScene!==!0&&(k=wt);const $=_t.get(C),V=m.state.lights,xt=m.state.shadowsArray,Ct=V.state.version,Bt=At.getParameters(C,V.state,xt,k,W),Ot=At.getProgramCacheKey(Bt);let qt=$.programs;$.environment=C.isMeshStandardMaterial?k.environment:null,$.fog=k.fog,$.envMap=(C.isMeshStandardMaterial?z:b).get(C.envMap||$.environment),qt===void 0&&(C.addEventListener("dispose",vt),qt=new Map,$.programs=qt);let Gt=qt.get(Ot);if(Gt!==void 0){if($.currentProgram===Gt&&$.lightsStateVersion===Ct)return ua(C,Bt),Gt}else Bt.uniforms=At.getUniforms(C),C.onBuild(W,Bt,v),C.onBeforeCompile(Bt,v),Gt=At.acquireProgram(Bt,Ot),qt.set(Ot,Gt),$.uniforms=Bt.uniforms;const Vt=$.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(Vt.clippingPlanes=Ht.uniform),ua(C,Bt),$.needsLights=$c(C),$.lightsStateVersion=Ct,$.needsLights&&(Vt.ambientLightColor.value=V.state.ambient,Vt.lightProbe.value=V.state.probe,Vt.directionalLights.value=V.state.directional,Vt.directionalLightShadows.value=V.state.directionalShadow,Vt.spotLights.value=V.state.spot,Vt.spotLightShadows.value=V.state.spotShadow,Vt.rectAreaLights.value=V.state.rectArea,Vt.ltc_1.value=V.state.rectAreaLTC1,Vt.ltc_2.value=V.state.rectAreaLTC2,Vt.pointLights.value=V.state.point,Vt.pointLightShadows.value=V.state.pointShadow,Vt.hemisphereLights.value=V.state.hemi,Vt.directionalShadowMap.value=V.state.directionalShadowMap,Vt.directionalShadowMatrix.value=V.state.directionalShadowMatrix,Vt.spotShadowMap.value=V.state.spotShadowMap,Vt.spotLightMatrix.value=V.state.spotLightMatrix,Vt.spotLightMap.value=V.state.spotLightMap,Vt.pointShadowMap.value=V.state.pointShadowMap,Vt.pointShadowMatrix.value=V.state.pointShadowMatrix),$.currentProgram=Gt,$.uniformsList=null,Gt}function da(C){if(C.uniformsList===null){const k=C.currentProgram.getUniforms();C.uniformsList=bs.seqWithValue(k.seq,C.uniforms)}return C.uniformsList}function ua(C,k){const W=_t.get(C);W.outputColorSpace=k.outputColorSpace,W.batching=k.batching,W.instancing=k.instancing,W.instancingColor=k.instancingColor,W.skinning=k.skinning,W.morphTargets=k.morphTargets,W.morphNormals=k.morphNormals,W.morphColors=k.morphColors,W.morphTargetsCount=k.morphTargetsCount,W.numClippingPlanes=k.numClippingPlanes,W.numIntersection=k.numClipIntersection,W.vertexAlphas=k.vertexAlphas,W.vertexTangents=k.vertexTangents,W.toneMapping=k.toneMapping}function qc(C,k,W,$,V){k.isScene!==!0&&(k=wt),A.resetTextureUnits();const xt=k.fog,Ct=$.isMeshStandardMaterial?k.environment:null,Bt=E===null?v.outputColorSpace:E.isXRRenderTarget===!0?E.texture.colorSpace:un,Ot=($.isMeshStandardMaterial?z:b).get($.envMap||Ct),qt=$.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,Gt=!!W.attributes.tangent&&(!!$.normalMap||$.anisotropy>0),Vt=!!W.morphAttributes.position,pe=!!W.morphAttributes.normal,Be=!!W.morphAttributes.color;let we=Mn;$.toneMapped&&(E===null||E.isXRRenderTarget===!0)&&(we=v.toneMapping);const en=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,le=en!==void 0?en.length:0,$t=_t.get($),Ws=m.state.lights;if(tt===!0&&(ut===!0||C!==w)){const ze=C===w&&$.id===U;Ht.setState($,C,ze)}let ue=!1;$.version===$t.__version?($t.needsLights&&$t.lightsStateVersion!==Ws.state.version||$t.outputColorSpace!==Bt||V.isBatchedMesh&&$t.batching===!1||!V.isBatchedMesh&&$t.batching===!0||V.isInstancedMesh&&$t.instancing===!1||!V.isInstancedMesh&&$t.instancing===!0||V.isSkinnedMesh&&$t.skinning===!1||!V.isSkinnedMesh&&$t.skinning===!0||V.isInstancedMesh&&$t.instancingColor===!0&&V.instanceColor===null||V.isInstancedMesh&&$t.instancingColor===!1&&V.instanceColor!==null||$t.envMap!==Ot||$.fog===!0&&$t.fog!==xt||$t.numClippingPlanes!==void 0&&($t.numClippingPlanes!==Ht.numPlanes||$t.numIntersection!==Ht.numIntersection)||$t.vertexAlphas!==qt||$t.vertexTangents!==Gt||$t.morphTargets!==Vt||$t.morphNormals!==pe||$t.morphColors!==Be||$t.toneMapping!==we||lt.isWebGL2===!0&&$t.morphTargetsCount!==le)&&(ue=!0):(ue=!0,$t.__version=$.version);let Tn=$t.currentProgram;ue===!0&&(Tn=qi($,k,V));let fa=!1,xi=!1,Xs=!1;const be=Tn.getUniforms(),An=$t.uniforms;if(Q.useProgram(Tn.program)&&(fa=!0,xi=!0,Xs=!0),$.id!==U&&(U=$.id,xi=!0),fa||w!==C){be.setValue(D,"projectionMatrix",C.projectionMatrix),be.setValue(D,"viewMatrix",C.matrixWorldInverse);const ze=be.map.cameraPosition;ze!==void 0&&ze.setValue(D,Pt.setFromMatrixPosition(C.matrixWorld)),lt.logarithmicDepthBuffer&&be.setValue(D,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),($.isMeshPhongMaterial||$.isMeshToonMaterial||$.isMeshLambertMaterial||$.isMeshBasicMaterial||$.isMeshStandardMaterial||$.isShaderMaterial)&&be.setValue(D,"isOrthographic",C.isOrthographicCamera===!0),w!==C&&(w=C,xi=!0,Xs=!0)}if(V.isSkinnedMesh){be.setOptional(D,V,"bindMatrix"),be.setOptional(D,V,"bindMatrixInverse");const ze=V.skeleton;ze&&(lt.floatVertexTextures?(ze.boneTexture===null&&ze.computeBoneTexture(),be.setValue(D,"boneTexture",ze.boneTexture,A)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}V.isBatchedMesh&&(be.setOptional(D,V,"batchingTexture"),be.setValue(D,"batchingTexture",V._matricesTexture,A));const qs=W.morphAttributes;if((qs.position!==void 0||qs.normal!==void 0||qs.color!==void 0&&lt.isWebGL2===!0)&&Zt.update(V,W,Tn),(xi||$t.receiveShadow!==V.receiveShadow)&&($t.receiveShadow=V.receiveShadow,be.setValue(D,"receiveShadow",V.receiveShadow)),$.isMeshGouraudMaterial&&$.envMap!==null&&(An.envMap.value=Ot,An.flipEnvMap.value=Ot.isCubeTexture&&Ot.isRenderTargetTexture===!1?-1:1),xi&&(be.setValue(D,"toneMappingExposure",v.toneMappingExposure),$t.needsLights&&Yc(An,Xs),xt&&$.fog===!0&&gt.refreshFogUniforms(An,xt),gt.refreshMaterialUniforms(An,$,Z,O,Et),bs.upload(D,da($t),An,A)),$.isShaderMaterial&&$.uniformsNeedUpdate===!0&&(bs.upload(D,da($t),An,A),$.uniformsNeedUpdate=!1),$.isSpriteMaterial&&be.setValue(D,"center",V.center),be.setValue(D,"modelViewMatrix",V.modelViewMatrix),be.setValue(D,"normalMatrix",V.normalMatrix),be.setValue(D,"modelMatrix",V.matrixWorld),$.isShaderMaterial||$.isRawShaderMaterial){const ze=$.uniformsGroups;for(let Ys=0,jc=ze.length;Ys<jc;Ys++)if(lt.isWebGL2){const pa=ze[Ys];Qt.update(pa,Tn),Qt.bind(pa,Tn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Tn}function Yc(C,k){C.ambientLightColor.needsUpdate=k,C.lightProbe.needsUpdate=k,C.directionalLights.needsUpdate=k,C.directionalLightShadows.needsUpdate=k,C.pointLights.needsUpdate=k,C.pointLightShadows.needsUpdate=k,C.spotLights.needsUpdate=k,C.spotLightShadows.needsUpdate=k,C.rectAreaLights.needsUpdate=k,C.hemisphereLights.needsUpdate=k}function $c(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return E},this.setRenderTargetTextures=function(C,k,W){_t.get(C.texture).__webglTexture=k,_t.get(C.depthTexture).__webglTexture=W;const $=_t.get(C);$.__hasExternalTextures=!0,$.__hasExternalTextures&&($.__autoAllocateDepthBuffer=W===void 0,$.__autoAllocateDepthBuffer||K.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),$.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(C,k){const W=_t.get(C);W.__webglFramebuffer=k,W.__useDefaultFramebuffer=k===void 0},this.setRenderTarget=function(C,k=0,W=0){E=C,R=k,T=W;let $=!0,V=null,xt=!1,Ct=!1;if(C){const Ot=_t.get(C);Ot.__useDefaultFramebuffer!==void 0?(Q.bindFramebuffer(D.FRAMEBUFFER,null),$=!1):Ot.__webglFramebuffer===void 0?A.setupRenderTarget(C):Ot.__hasExternalTextures&&A.rebindTextures(C,_t.get(C.texture).__webglTexture,_t.get(C.depthTexture).__webglTexture);const qt=C.texture;(qt.isData3DTexture||qt.isDataArrayTexture||qt.isCompressedArrayTexture)&&(Ct=!0);const Gt=_t.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(Gt[k])?V=Gt[k][W]:V=Gt[k],xt=!0):lt.isWebGL2&&C.samples>0&&A.useMultisampledRTT(C)===!1?V=_t.get(C).__webglMultisampledFramebuffer:Array.isArray(Gt)?V=Gt[W]:V=Gt,S.copy(C.viewport),P.copy(C.scissor),F=C.scissorTest}else S.copy(J).multiplyScalar(Z).floor(),P.copy(et).multiplyScalar(Z).floor(),F=rt;if(Q.bindFramebuffer(D.FRAMEBUFFER,V)&&lt.drawBuffers&&$&&Q.drawBuffers(C,V),Q.viewport(S),Q.scissor(P),Q.setScissorTest(F),xt){const Ot=_t.get(C.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_CUBE_MAP_POSITIVE_X+k,Ot.__webglTexture,W)}else if(Ct){const Ot=_t.get(C.texture),qt=k||0;D.framebufferTextureLayer(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,Ot.__webglTexture,W||0,qt)}U=-1},this.readRenderTargetPixels=function(C,k,W,$,V,xt,Ct){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Bt=_t.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ct!==void 0&&(Bt=Bt[Ct]),Bt){Q.bindFramebuffer(D.FRAMEBUFFER,Bt);try{const Ot=C.texture,qt=Ot.format,Gt=Ot.type;if(qt!==Ke&&bt.convert(qt)!==D.getParameter(D.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const Vt=Gt===Fi&&(K.has("EXT_color_buffer_half_float")||lt.isWebGL2&&K.has("EXT_color_buffer_float"));if(Gt!==Sn&&bt.convert(Gt)!==D.getParameter(D.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Gt===_n&&(lt.isWebGL2||K.has("OES_texture_float")||K.has("WEBGL_color_buffer_float")))&&!Vt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}k>=0&&k<=C.width-$&&W>=0&&W<=C.height-V&&D.readPixels(k,W,$,V,bt.convert(qt),bt.convert(Gt),xt)}finally{const Ot=E!==null?_t.get(E).__webglFramebuffer:null;Q.bindFramebuffer(D.FRAMEBUFFER,Ot)}}},this.copyFramebufferToTexture=function(C,k,W=0){const $=Math.pow(2,-W),V=Math.floor(k.image.width*$),xt=Math.floor(k.image.height*$);A.setTexture2D(k,0),D.copyTexSubImage2D(D.TEXTURE_2D,W,0,0,C.x,C.y,V,xt),Q.unbindTexture()},this.copyTextureToTexture=function(C,k,W,$=0){const V=k.image.width,xt=k.image.height,Ct=bt.convert(W.format),Bt=bt.convert(W.type);A.setTexture2D(W,0),D.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,W.flipY),D.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),D.pixelStorei(D.UNPACK_ALIGNMENT,W.unpackAlignment),k.isDataTexture?D.texSubImage2D(D.TEXTURE_2D,$,C.x,C.y,V,xt,Ct,Bt,k.image.data):k.isCompressedTexture?D.compressedTexSubImage2D(D.TEXTURE_2D,$,C.x,C.y,k.mipmaps[0].width,k.mipmaps[0].height,Ct,k.mipmaps[0].data):D.texSubImage2D(D.TEXTURE_2D,$,C.x,C.y,Ct,Bt,k.image),$===0&&W.generateMipmaps&&D.generateMipmap(D.TEXTURE_2D),Q.unbindTexture()},this.copyTextureToTexture3D=function(C,k,W,$,V=0){if(v.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const xt=C.max.x-C.min.x+1,Ct=C.max.y-C.min.y+1,Bt=C.max.z-C.min.z+1,Ot=bt.convert($.format),qt=bt.convert($.type);let Gt;if($.isData3DTexture)A.setTexture3D($,0),Gt=D.TEXTURE_3D;else if($.isDataArrayTexture||$.isCompressedArrayTexture)A.setTexture2DArray($,0),Gt=D.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}D.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,$.flipY),D.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),D.pixelStorei(D.UNPACK_ALIGNMENT,$.unpackAlignment);const Vt=D.getParameter(D.UNPACK_ROW_LENGTH),pe=D.getParameter(D.UNPACK_IMAGE_HEIGHT),Be=D.getParameter(D.UNPACK_SKIP_PIXELS),we=D.getParameter(D.UNPACK_SKIP_ROWS),en=D.getParameter(D.UNPACK_SKIP_IMAGES),le=W.isCompressedTexture?W.mipmaps[V]:W.image;D.pixelStorei(D.UNPACK_ROW_LENGTH,le.width),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,le.height),D.pixelStorei(D.UNPACK_SKIP_PIXELS,C.min.x),D.pixelStorei(D.UNPACK_SKIP_ROWS,C.min.y),D.pixelStorei(D.UNPACK_SKIP_IMAGES,C.min.z),W.isDataTexture||W.isData3DTexture?D.texSubImage3D(Gt,V,k.x,k.y,k.z,xt,Ct,Bt,Ot,qt,le.data):W.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),D.compressedTexSubImage3D(Gt,V,k.x,k.y,k.z,xt,Ct,Bt,Ot,le.data)):D.texSubImage3D(Gt,V,k.x,k.y,k.z,xt,Ct,Bt,Ot,qt,le),D.pixelStorei(D.UNPACK_ROW_LENGTH,Vt),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,pe),D.pixelStorei(D.UNPACK_SKIP_PIXELS,Be),D.pixelStorei(D.UNPACK_SKIP_ROWS,we),D.pixelStorei(D.UNPACK_SKIP_IMAGES,en),V===0&&$.generateMipmaps&&D.generateMipmap(Gt),Q.unbindTexture()},this.initTexture=function(C){C.isCubeTexture?A.setTextureCube(C,0):C.isData3DTexture?A.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?A.setTexture2DArray(C,0):A.setTexture2D(C,0),Q.unbindTexture()},this.resetState=function(){R=0,T=0,E=null,Q.reset(),Wt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return hn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=t===Ko?"display-p3":"srgb",e.unpackColorSpace=te.workingColorSpace===Fs?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Se?On:cc}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===On?Se:un}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}}class em extends Rc{}em.prototype.isWebGL1Renderer=!0;class ea{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new kt(t),this.density=e}clone(){return new ea(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class nm extends fe{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}}class im{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=ko,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=dn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let i=0,s=this.stride;i<s;i++)this.array[t+i]=e.array[n+i];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=dn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=dn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Le=new L;class Ds{constructor(t,e,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)Le.fromBufferAttribute(this,e),Le.applyMatrix4(t),this.setXYZ(e,Le.x,Le.y,Le.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Le.fromBufferAttribute(this,e),Le.applyNormalMatrix(t),this.setXYZ(e,Le.x,Le.y,Le.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Le.fromBufferAttribute(this,e),Le.transformDirection(t),this.setXYZ(e,Le.x,Le.y,Le.z);return this}setX(t,e){return this.normalized&&(e=ee(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=ee(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=ee(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=ee(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=ln(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=ln(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=ln(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=ln(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=ee(e,this.array),n=ee(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=ee(e,this.array),n=ee(n,this.array),i=ee(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this}setXYZW(t,e,n,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=ee(e,this.array),n=ee(n,this.array),i=ee(i,this.array),s=ee(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this.data.array[t+3]=s,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[i+s])}return new qe(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new Ds(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Lc extends En{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new kt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let oi;const Ei=new L,ai=new L,ri=new L,ci=new ct,Ti=new ct,Pc=new ce,ms=new L,Ai=new L,gs=new L,Dr=new ct,To=new ct,Ur=new ct;class sm extends fe{constructor(t=new Lc){if(super(),this.isSprite=!0,this.type="Sprite",oi===void 0){oi=new ge;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new im(e,5);oi.setIndex([0,1,2,0,2,3]),oi.setAttribute("position",new Ds(n,3,0,!1)),oi.setAttribute("uv",new Ds(n,2,3,!1))}this.geometry=oi,this.material=t,this.center=new ct(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),ai.setFromMatrixScale(this.matrixWorld),Pc.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),ri.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&ai.multiplyScalar(-ri.z);const n=this.material.rotation;let i,s;n!==0&&(s=Math.cos(n),i=Math.sin(n));const a=this.center;ys(ms.set(-.5,-.5,0),ri,a,ai,i,s),ys(Ai.set(.5,-.5,0),ri,a,ai,i,s),ys(gs.set(.5,.5,0),ri,a,ai,i,s),Dr.set(0,0),To.set(1,0),Ur.set(1,1);let r=t.ray.intersectTriangle(ms,Ai,gs,!1,Ei);if(r===null&&(ys(Ai.set(-.5,.5,0),ri,a,ai,i,s),To.set(0,1),r=t.ray.intersectTriangle(ms,gs,Ai,!1,Ei),r===null))return;const c=t.ray.origin.distanceTo(Ei);c<t.near||c>t.far||e.push({distance:c,point:Ei.clone(),uv:Ve.getInterpolation(Ei,ms,Ai,gs,Dr,To,Ur,new ct),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}}function ys(o,t,e,n,i,s){ci.subVectors(o,e).addScalar(.5).multiply(n),i!==void 0?(Ti.x=s*ci.x-i*ci.y,Ti.y=i*ci.x+s*ci.y):Ti.copy(ci),o.copy(t),o.x+=Ti.x,o.y+=Ti.y,o.applyMatrix4(Pc)}class Ic extends En{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new kt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Nr=new L,Br=new L,Fr=new ce,Ao=new Os,vs=new Vi;class om extends fe{constructor(t=new ge,e=new Ic){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let i=1,s=e.count;i<s;i++)Nr.fromBufferAttribute(e,i-1),Br.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=Nr.distanceTo(Br);t.setAttribute("lineDistance",new Kt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),vs.copy(n.boundingSphere),vs.applyMatrix4(i),vs.radius+=s,t.ray.intersectsSphere(vs)===!1)return;Fr.copy(i).invert(),Ao.copy(t.ray).applyMatrix4(Fr);const r=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=r*r,l=new L,h=new L,d=new L,u=new L,f=this.isLineSegments?2:1,g=n.index,m=n.attributes.position;if(g!==null){const p=Math.max(0,a.start),x=Math.min(g.count,a.start+a.count);for(let v=p,M=x-1;v<M;v+=f){const R=g.getX(v),T=g.getX(v+1);if(l.fromBufferAttribute(m,R),h.fromBufferAttribute(m,T),Ao.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);const U=t.ray.origin.distanceTo(u);U<t.near||U>t.far||e.push({distance:U,point:d.clone().applyMatrix4(this.matrixWorld),index:v,face:null,faceIndex:null,object:this})}}else{const p=Math.max(0,a.start),x=Math.min(m.count,a.start+a.count);for(let v=p,M=x-1;v<M;v+=f){if(l.fromBufferAttribute(m,v),h.fromBufferAttribute(m,v+1),Ao.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);const T=t.ray.origin.distanceTo(u);T<t.near||T>t.far||e.push({distance:T,point:d.clone().applyMatrix4(this.matrixWorld),index:v,face:null,faceIndex:null,object:this})}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}}const Or=new L,kr=new L;class am extends om{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let i=0,s=e.count;i<s;i+=2)Or.fromBufferAttribute(e,i),kr.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+Or.distanceTo(kr);t.setAttribute("lineDistance",new Kt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Dc extends En{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new kt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const zr=new ce,Vo=new Os,_s=new Vi,xs=new L;class rm extends fe{constructor(t=new ge,e=new Dc){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),_s.copy(n.boundingSphere),_s.applyMatrix4(i),_s.radius+=s,t.ray.intersectsSphere(_s)===!1)return;zr.copy(i).invert(),Vo.copy(t.ray).applyMatrix4(zr);const r=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=r*r,l=n.index,d=n.attributes.position;if(l!==null){const u=Math.max(0,a.start),f=Math.min(l.count,a.start+a.count);for(let g=u,y=f;g<y;g++){const m=l.getX(g);xs.fromBufferAttribute(d,m),Gr(xs,m,c,i,t,e,this)}}else{const u=Math.max(0,a.start),f=Math.min(d.count,a.start+a.count);for(let g=u,y=f;g<y;g++)xs.fromBufferAttribute(d,g),Gr(xs,g,c,i,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}}function Gr(o,t,e,n,i,s,a){const r=Vo.distanceSqToPoint(o);if(r<e){const c=new L;Vo.closestPointToPoint(o,c),c.applyMatrix4(n);const l=i.ray.origin.distanceTo(c);if(l<i.near||l>i.far)return;s.push({distance:l,distanceToRay:Math.sqrt(r),point:c,index:t,face:null,object:a})}}class Uc extends Ne{constructor(t,e,n,i,s,a,r,c,l){super(t,e,n,i,s,a,r,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class tn{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){const n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const e=[];let n,i=this.getPoint(0),s=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),s+=n.distanceTo(i),e.push(s),i=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){const n=this.getLengths();let i=0;const s=n.length;let a;e?a=e:a=t*n[s-1];let r=0,c=s-1,l;for(;r<=c;)if(i=Math.floor(r+(c-r)/2),l=n[i]-a,l<0)r=i+1;else if(l>0)c=i-1;else{c=i;break}if(i=c,n[i]===a)return i/(s-1);const h=n[i],u=n[i+1]-h,f=(a-h)/u;return(i+f)/(s-1)}getTangent(t,e){let i=t-1e-4,s=t+1e-4;i<0&&(i=0),s>1&&(s=1);const a=this.getPoint(i),r=this.getPoint(s),c=e||(a.isVector2?new ct:new L);return c.copy(r).sub(a).normalize(),c}getTangentAt(t,e){const n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){const n=new L,i=[],s=[],a=[],r=new L,c=new ce;for(let f=0;f<=t;f++){const g=f/t;i[f]=this.getTangentAt(g,new L)}s[0]=new L,a[0]=new L;let l=Number.MAX_VALUE;const h=Math.abs(i[0].x),d=Math.abs(i[0].y),u=Math.abs(i[0].z);h<=l&&(l=h,n.set(1,0,0)),d<=l&&(l=d,n.set(0,1,0)),u<=l&&n.set(0,0,1),r.crossVectors(i[0],n).normalize(),s[0].crossVectors(i[0],r),a[0].crossVectors(i[0],s[0]);for(let f=1;f<=t;f++){if(s[f]=s[f-1].clone(),a[f]=a[f-1].clone(),r.crossVectors(i[f-1],i[f]),r.length()>Number.EPSILON){r.normalize();const g=Math.acos(Ae(i[f-1].dot(i[f]),-1,1));s[f].applyMatrix4(c.makeRotationAxis(r,g))}a[f].crossVectors(i[f],s[f])}if(e===!0){let f=Math.acos(Ae(s[0].dot(s[t]),-1,1));f/=t,i[0].dot(r.crossVectors(s[0],s[t]))>0&&(f=-f);for(let g=1;g<=t;g++)s[g].applyMatrix4(c.makeRotationAxis(i[g],f*g)),a[g].crossVectors(i[g],s[g])}return{tangents:i,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){const t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}}class na extends tn{constructor(t=0,e=0,n=1,i=1,s=0,a=Math.PI*2,r=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=i,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=r,this.aRotation=c}getPoint(t,e){const n=e||new ct,i=Math.PI*2;let s=this.aEndAngle-this.aStartAngle;const a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=i;for(;s>i;)s-=i;s<Number.EPSILON&&(a?s=0:s=i),this.aClockwise===!0&&!a&&(s===i?s=-i:s=s-i);const r=this.aStartAngle+t*s;let c=this.aX+this.xRadius*Math.cos(r),l=this.aY+this.yRadius*Math.sin(r);if(this.aRotation!==0){const h=Math.cos(this.aRotation),d=Math.sin(this.aRotation),u=c-this.aX,f=l-this.aY;c=u*h-f*d+this.aX,l=u*d+f*h+this.aY}return n.set(c,l)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){const t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}}class cm extends na{constructor(t,e,n,i,s,a){super(t,e,n,n,i,s,a),this.isArcCurve=!0,this.type="ArcCurve"}}function ia(){let o=0,t=0,e=0,n=0;function i(s,a,r,c){o=s,t=r,e=-3*s+3*a-2*r-c,n=2*s-2*a+r+c}return{initCatmullRom:function(s,a,r,c,l){i(a,r,l*(r-s),l*(c-a))},initNonuniformCatmullRom:function(s,a,r,c,l,h,d){let u=(a-s)/l-(r-s)/(l+h)+(r-a)/h,f=(r-a)/h-(c-a)/(h+d)+(c-r)/d;u*=h,f*=h,i(a,r,u,f)},calc:function(s){const a=s*s,r=a*s;return o+t*s+e*a+n*r}}}const ws=new L,Co=new ia,Ro=new ia,Lo=new ia;class Nc extends tn{constructor(t=[],e=!1,n="centripetal",i=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=i}getPoint(t,e=new L){const n=e,i=this.points,s=i.length,a=(s-(this.closed?0:1))*t;let r=Math.floor(a),c=a-r;this.closed?r+=r>0?0:(Math.floor(Math.abs(r)/s)+1)*s:c===0&&r===s-1&&(r=s-2,c=1);let l,h;this.closed||r>0?l=i[(r-1)%s]:(ws.subVectors(i[0],i[1]).add(i[0]),l=ws);const d=i[r%s],u=i[(r+1)%s];if(this.closed||r+2<s?h=i[(r+2)%s]:(ws.subVectors(i[s-1],i[s-2]).add(i[s-1]),h=ws),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let g=Math.pow(l.distanceToSquared(d),f),y=Math.pow(d.distanceToSquared(u),f),m=Math.pow(u.distanceToSquared(h),f);y<1e-4&&(y=1),g<1e-4&&(g=y),m<1e-4&&(m=y),Co.initNonuniformCatmullRom(l.x,d.x,u.x,h.x,g,y,m),Ro.initNonuniformCatmullRom(l.y,d.y,u.y,h.y,g,y,m),Lo.initNonuniformCatmullRom(l.z,d.z,u.z,h.z,g,y,m)}else this.curveType==="catmullrom"&&(Co.initCatmullRom(l.x,d.x,u.x,h.x,this.tension),Ro.initCatmullRom(l.y,d.y,u.y,h.y,this.tension),Lo.initCatmullRom(l.z,d.z,u.z,h.z,this.tension));return n.set(Co.calc(c),Ro.calc(c),Lo.calc(c)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(i.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const i=this.points[e];t.points.push(i.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(new L().fromArray(i))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}function Hr(o,t,e,n,i){const s=(n-t)*.5,a=(i-e)*.5,r=o*o,c=o*r;return(2*e-2*n+s+a)*c+(-3*e+3*n-2*s-a)*r+s*o+e}function lm(o,t){const e=1-o;return e*e*t}function hm(o,t){return 2*(1-o)*o*t}function dm(o,t){return o*o*t}function Ii(o,t,e,n){return lm(o,t)+hm(o,e)+dm(o,n)}function um(o,t){const e=1-o;return e*e*e*t}function fm(o,t){const e=1-o;return 3*e*e*o*t}function pm(o,t){return 3*(1-o)*o*o*t}function mm(o,t){return o*o*o*t}function Di(o,t,e,n,i){return um(o,t)+fm(o,e)+pm(o,n)+mm(o,i)}class Bc extends tn{constructor(t=new ct,e=new ct,n=new ct,i=new ct){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new ct){const n=e,i=this.v0,s=this.v1,a=this.v2,r=this.v3;return n.set(Di(t,i.x,s.x,a.x,r.x),Di(t,i.y,s.y,a.y,r.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class gm extends tn{constructor(t=new L,e=new L,n=new L,i=new L){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new L){const n=e,i=this.v0,s=this.v1,a=this.v2,r=this.v3;return n.set(Di(t,i.x,s.x,a.x,r.x),Di(t,i.y,s.y,a.y,r.y),Di(t,i.z,s.z,a.z,r.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class Fc extends tn{constructor(t=new ct,e=new ct){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new ct){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new ct){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class ym extends tn{constructor(t=new L,e=new L){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new L){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new L){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Oc extends tn{constructor(t=new ct,e=new ct,n=new ct){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new ct){const n=e,i=this.v0,s=this.v1,a=this.v2;return n.set(Ii(t,i.x,s.x,a.x),Ii(t,i.y,s.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class kc extends tn{constructor(t=new L,e=new L,n=new L){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new L){const n=e,i=this.v0,s=this.v1,a=this.v2;return n.set(Ii(t,i.x,s.x,a.x),Ii(t,i.y,s.y,a.y),Ii(t,i.z,s.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class zc extends tn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new ct){const n=e,i=this.points,s=(i.length-1)*t,a=Math.floor(s),r=s-a,c=i[a===0?a:a-1],l=i[a],h=i[a>i.length-2?i.length-1:a+1],d=i[a>i.length-3?i.length-1:a+2];return n.set(Hr(r,c.x,l.x,h.x,d.x),Hr(r,c.y,l.y,h.y,d.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(i.clone())}return this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const i=this.points[e];t.points.push(i.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(new ct().fromArray(i))}return this}}var Us=Object.freeze({__proto__:null,ArcCurve:cm,CatmullRomCurve3:Nc,CubicBezierCurve:Bc,CubicBezierCurve3:gm,EllipseCurve:na,LineCurve:Fc,LineCurve3:ym,QuadraticBezierCurve:Oc,QuadraticBezierCurve3:kc,SplineCurve:zc});class vm extends tn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){const t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){const n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Us[n](e,t))}return this}getPoint(t,e){const n=t*this.getLength(),i=this.getCurveLengths();let s=0;for(;s<i.length;){if(i[s]>=n){const a=i[s]-n,r=this.curves[s],c=r.getLength(),l=c===0?0:1-a/c;return r.getPointAt(l,e)}s++}return null}getLength(){const t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const t=[];let e=0;for(let n=0,i=this.curves.length;n<i;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){const e=[];let n;for(let i=0,s=this.curves;i<s.length;i++){const a=s[i],r=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,c=a.getPoints(r);for(let l=0;l<c.length;l++){const h=c[l];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){const i=t.curves[e];this.curves.push(i.clone())}return this.autoClose=t.autoClose,this}toJSON(){const t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){const i=this.curves[e];t.curves.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){const i=t.curves[e];this.curves.push(new Us[i.type]().fromJSON(i))}return this}}class Vr extends vm{constructor(t){super(),this.type="Path",this.currentPoint=new ct,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){const n=new Fc(this.currentPoint.clone(),new ct(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,i){const s=new Oc(this.currentPoint.clone(),new ct(t,e),new ct(n,i));return this.curves.push(s),this.currentPoint.set(n,i),this}bezierCurveTo(t,e,n,i,s,a){const r=new Bc(this.currentPoint.clone(),new ct(t,e),new ct(n,i),new ct(s,a));return this.curves.push(r),this.currentPoint.set(s,a),this}splineThru(t){const e=[this.currentPoint.clone()].concat(t),n=new zc(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,i,s,a){const r=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(t+r,e+c,n,i,s,a),this}absarc(t,e,n,i,s,a){return this.absellipse(t,e,n,n,i,s,a),this}ellipse(t,e,n,i,s,a,r,c){const l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+l,e+h,n,i,s,a,r,c),this}absellipse(t,e,n,i,s,a,r,c){const l=new na(t,e,n,i,s,a,r,c);if(this.curves.length>0){const d=l.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(l);const h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){const t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}}class sa extends ge{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);const s=[],a=[],r=[],c=[],l=new L,h=new ct;a.push(0,0,0),r.push(0,0,1),c.push(.5,.5);for(let d=0,u=3;d<=e;d++,u+=3){const f=n+d/e*i;l.x=t*Math.cos(f),l.y=t*Math.sin(f),a.push(l.x,l.y,l.z),r.push(0,0,1),h.x=(a[u]/t+1)/2,h.y=(a[u+1]/t+1)/2,c.push(h.x,h.y)}for(let d=1;d<=e;d++)s.push(d,d+1,0);this.setIndex(s),this.setAttribute("position",new Kt(a,3)),this.setAttribute("normal",new Kt(r,3)),this.setAttribute("uv",new Kt(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new sa(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class nt extends ge{constructor(t=1,e=1,n=1,i=32,s=1,a=!1,r=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:s,openEnded:a,thetaStart:r,thetaLength:c};const l=this;i=Math.floor(i),s=Math.floor(s);const h=[],d=[],u=[],f=[];let g=0;const y=[],m=n/2;let p=0;x(),a===!1&&(t>0&&v(!0),e>0&&v(!1)),this.setIndex(h),this.setAttribute("position",new Kt(d,3)),this.setAttribute("normal",new Kt(u,3)),this.setAttribute("uv",new Kt(f,2));function x(){const M=new L,R=new L;let T=0;const E=(e-t)/n;for(let U=0;U<=s;U++){const w=[],S=U/s,P=S*(e-t)+t;for(let F=0;F<=i;F++){const j=F/i,I=j*c+r,B=Math.sin(I),O=Math.cos(I);R.x=P*B,R.y=-S*n+m,R.z=P*O,d.push(R.x,R.y,R.z),M.set(B,E,O).normalize(),u.push(M.x,M.y,M.z),f.push(j,1-S),w.push(g++)}y.push(w)}for(let U=0;U<i;U++)for(let w=0;w<s;w++){const S=y[w][U],P=y[w+1][U],F=y[w+1][U+1],j=y[w][U+1];h.push(S,P,j),h.push(P,F,j),T+=6}l.addGroup(p,T,0),p+=T}function v(M){const R=g,T=new ct,E=new L;let U=0;const w=M===!0?t:e,S=M===!0?1:-1;for(let F=1;F<=i;F++)d.push(0,m*S,0),u.push(0,S,0),f.push(.5,.5),g++;const P=g;for(let F=0;F<=i;F++){const I=F/i*c+r,B=Math.cos(I),O=Math.sin(I);E.x=w*O,E.y=m*S,E.z=w*B,d.push(E.x,E.y,E.z),u.push(0,S,0),T.x=B*.5+.5,T.y=O*.5*S+.5,f.push(T.x,T.y),g++}for(let F=0;F<i;F++){const j=R+F,I=P+F;M===!0?h.push(I,I+1,j):h.push(I+1,I,j),U+=3}l.addGroup(p,U,M===!0?1:2),p+=U}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new nt(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class oe extends nt{constructor(t=1,e=1,n=32,i=1,s=!1,a=0,r=Math.PI*2){super(0,t,e,n,i,s,a,r),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:s,thetaStart:a,thetaLength:r}}static fromJSON(t){return new oe(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Wi extends ge{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};const s=[],a=[];r(i),l(n),h(),this.setAttribute("position",new Kt(s,3)),this.setAttribute("normal",new Kt(s.slice(),3)),this.setAttribute("uv",new Kt(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function r(x){const v=new L,M=new L,R=new L;for(let T=0;T<e.length;T+=3)f(e[T+0],v),f(e[T+1],M),f(e[T+2],R),c(v,M,R,x)}function c(x,v,M,R){const T=R+1,E=[];for(let U=0;U<=T;U++){E[U]=[];const w=x.clone().lerp(M,U/T),S=v.clone().lerp(M,U/T),P=T-U;for(let F=0;F<=P;F++)F===0&&U===T?E[U][F]=w:E[U][F]=w.clone().lerp(S,F/P)}for(let U=0;U<T;U++)for(let w=0;w<2*(T-U)-1;w++){const S=Math.floor(w/2);w%2===0?(u(E[U][S+1]),u(E[U+1][S]),u(E[U][S])):(u(E[U][S+1]),u(E[U+1][S+1]),u(E[U+1][S]))}}function l(x){const v=new L;for(let M=0;M<s.length;M+=3)v.x=s[M+0],v.y=s[M+1],v.z=s[M+2],v.normalize().multiplyScalar(x),s[M+0]=v.x,s[M+1]=v.y,s[M+2]=v.z}function h(){const x=new L;for(let v=0;v<s.length;v+=3){x.x=s[v+0],x.y=s[v+1],x.z=s[v+2];const M=m(x)/2/Math.PI+.5,R=p(x)/Math.PI+.5;a.push(M,1-R)}g(),d()}function d(){for(let x=0;x<a.length;x+=6){const v=a[x+0],M=a[x+2],R=a[x+4],T=Math.max(v,M,R),E=Math.min(v,M,R);T>.9&&E<.1&&(v<.2&&(a[x+0]+=1),M<.2&&(a[x+2]+=1),R<.2&&(a[x+4]+=1))}}function u(x){s.push(x.x,x.y,x.z)}function f(x,v){const M=x*3;v.x=t[M+0],v.y=t[M+1],v.z=t[M+2]}function g(){const x=new L,v=new L,M=new L,R=new L,T=new ct,E=new ct,U=new ct;for(let w=0,S=0;w<s.length;w+=9,S+=6){x.set(s[w+0],s[w+1],s[w+2]),v.set(s[w+3],s[w+4],s[w+5]),M.set(s[w+6],s[w+7],s[w+8]),T.set(a[S+0],a[S+1]),E.set(a[S+2],a[S+3]),U.set(a[S+4],a[S+5]),R.copy(x).add(v).add(M).divideScalar(3);const P=m(R);y(T,S+0,x,P),y(E,S+2,v,P),y(U,S+4,M,P)}}function y(x,v,M,R){R<0&&x.x===1&&(a[v]=x.x-1),M.x===0&&M.z===0&&(a[v]=R/2/Math.PI+.5)}function m(x){return Math.atan2(x.z,-x.x)}function p(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Wi(t.vertices,t.indices,t.radius,t.details)}}class Ui extends Wi{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,i=1/n,s=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-i,-n,0,-i,n,0,i,-n,0,i,n,-i,-n,0,-i,n,0,i,-n,0,i,n,0,-n,0,-i,n,0,-i,-n,0,i,n,0,i],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(s,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Ui(t.radius,t.detail)}}class Gc extends Vr{constructor(t){super(t),this.uuid=dn(),this.type="Shape",this.holes=[]}getPointsHoles(t){const e=[];for(let n=0,i=this.holes.length;n<i;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){const i=t.holes[e];this.holes.push(i.clone())}return this}toJSON(){const t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){const i=this.holes[e];t.holes.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){const i=t.holes[e];this.holes.push(new Vr().fromJSON(i))}return this}}const _m={triangulate:function(o,t,e=2){const n=t&&t.length,i=n?t[0]*e:o.length;let s=Hc(o,0,i,e,!0);const a=[];if(!s||s.next===s.prev)return a;let r,c,l,h,d,u,f;if(n&&(s=bm(o,t,s,e)),o.length>80*e){r=l=o[0],c=h=o[1];for(let g=e;g<i;g+=e)d=o[g],u=o[g+1],d<r&&(r=d),u<c&&(c=u),d>l&&(l=d),u>h&&(h=u);f=Math.max(l-r,h-c),f=f!==0?32767/f:0}return Oi(s,a,e,r,c,f,0),a}};function Hc(o,t,e,n,i){let s,a;if(i===Nm(o,t,e,n)>0)for(s=t;s<e;s+=n)a=Wr(s,o[s],o[s+1],a);else for(s=e-n;s>=t;s-=n)a=Wr(s,o[s],o[s+1],a);return a&&Gs(a,a.next)&&(zi(a),a=a.next),a}function Gn(o,t){if(!o)return o;t||(t=o);let e=o,n;do if(n=!1,!e.steiner&&(Gs(e,e.next)||he(e.prev,e,e.next)===0)){if(zi(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function Oi(o,t,e,n,i,s,a){if(!o)return;!a&&s&&Rm(o,n,i,s);let r=o,c,l;for(;o.prev!==o.next;){if(c=o.prev,l=o.next,s?wm(o,n,i,s):xm(o)){t.push(c.i/e|0),t.push(o.i/e|0),t.push(l.i/e|0),zi(o),o=l.next,r=l.next;continue}if(o=l,o===r){a?a===1?(o=Mm(Gn(o),t,e),Oi(o,t,e,n,i,s,2)):a===2&&Sm(o,t,e,n,i,s):Oi(Gn(o),t,e,n,i,s,1);break}}}function xm(o){const t=o.prev,e=o,n=o.next;if(he(t,e,n)>=0)return!1;const i=t.x,s=e.x,a=n.x,r=t.y,c=e.y,l=n.y,h=i<s?i<a?i:a:s<a?s:a,d=r<c?r<l?r:l:c<l?c:l,u=i>s?i>a?i:a:s>a?s:a,f=r>c?r>l?r:l:c>l?c:l;let g=n.next;for(;g!==t;){if(g.x>=h&&g.x<=u&&g.y>=d&&g.y<=f&&di(i,r,s,c,a,l,g.x,g.y)&&he(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function wm(o,t,e,n){const i=o.prev,s=o,a=o.next;if(he(i,s,a)>=0)return!1;const r=i.x,c=s.x,l=a.x,h=i.y,d=s.y,u=a.y,f=r<c?r<l?r:l:c<l?c:l,g=h<d?h<u?h:u:d<u?d:u,y=r>c?r>l?r:l:c>l?c:l,m=h>d?h>u?h:u:d>u?d:u,p=Wo(f,g,t,e,n),x=Wo(y,m,t,e,n);let v=o.prevZ,M=o.nextZ;for(;v&&v.z>=p&&M&&M.z<=x;){if(v.x>=f&&v.x<=y&&v.y>=g&&v.y<=m&&v!==i&&v!==a&&di(r,h,c,d,l,u,v.x,v.y)&&he(v.prev,v,v.next)>=0||(v=v.prevZ,M.x>=f&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&di(r,h,c,d,l,u,M.x,M.y)&&he(M.prev,M,M.next)>=0))return!1;M=M.nextZ}for(;v&&v.z>=p;){if(v.x>=f&&v.x<=y&&v.y>=g&&v.y<=m&&v!==i&&v!==a&&di(r,h,c,d,l,u,v.x,v.y)&&he(v.prev,v,v.next)>=0)return!1;v=v.prevZ}for(;M&&M.z<=x;){if(M.x>=f&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&di(r,h,c,d,l,u,M.x,M.y)&&he(M.prev,M,M.next)>=0)return!1;M=M.nextZ}return!0}function Mm(o,t,e){let n=o;do{const i=n.prev,s=n.next.next;!Gs(i,s)&&Vc(i,n,n.next,s)&&ki(i,s)&&ki(s,i)&&(t.push(i.i/e|0),t.push(n.i/e|0),t.push(s.i/e|0),zi(n),zi(n.next),n=o=s),n=n.next}while(n!==o);return Gn(n)}function Sm(o,t,e,n,i,s){let a=o;do{let r=a.next.next;for(;r!==a.prev;){if(a.i!==r.i&&Im(a,r)){let c=Wc(a,r);a=Gn(a,a.next),c=Gn(c,c.next),Oi(a,t,e,n,i,s,0),Oi(c,t,e,n,i,s,0);return}r=r.next}a=a.next}while(a!==o)}function bm(o,t,e,n){const i=[];let s,a,r,c,l;for(s=0,a=t.length;s<a;s++)r=t[s]*n,c=s<a-1?t[s+1]*n:o.length,l=Hc(o,r,c,n,!1),l===l.next&&(l.steiner=!0),i.push(Pm(l));for(i.sort(Em),s=0;s<i.length;s++)e=Tm(i[s],e);return e}function Em(o,t){return o.x-t.x}function Tm(o,t){const e=Am(o,t);if(!e)return t;const n=Wc(e,o);return Gn(n,n.next),Gn(e,e.next)}function Am(o,t){let e=t,n=-1/0,i;const s=o.x,a=o.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){const u=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(u<=s&&u>n&&(n=u,i=e.x<e.next.x?e:e.next,u===s))return i}e=e.next}while(e!==t);if(!i)return null;const r=i,c=i.x,l=i.y;let h=1/0,d;e=i;do s>=e.x&&e.x>=c&&s!==e.x&&di(a<l?s:n,a,c,l,a<l?n:s,a,e.x,e.y)&&(d=Math.abs(a-e.y)/(s-e.x),ki(e,o)&&(d<h||d===h&&(e.x>i.x||e.x===i.x&&Cm(i,e)))&&(i=e,h=d)),e=e.next;while(e!==r);return i}function Cm(o,t){return he(o.prev,o,t.prev)<0&&he(t.next,o,o.next)<0}function Rm(o,t,e,n){let i=o;do i.z===0&&(i.z=Wo(i.x,i.y,t,e,n)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==o);i.prevZ.nextZ=null,i.prevZ=null,Lm(i)}function Lm(o){let t,e,n,i,s,a,r,c,l=1;do{for(e=o,o=null,s=null,a=0;e;){for(a++,n=e,r=0,t=0;t<l&&(r++,n=n.nextZ,!!n);t++);for(c=l;r>0||c>0&&n;)r!==0&&(c===0||!n||e.z<=n.z)?(i=e,e=e.nextZ,r--):(i=n,n=n.nextZ,c--),s?s.nextZ=i:o=i,i.prevZ=s,s=i;e=n}s.nextZ=null,l*=2}while(a>1);return o}function Wo(o,t,e,n,i){return o=(o-e)*i|0,t=(t-n)*i|0,o=(o|o<<8)&16711935,o=(o|o<<4)&252645135,o=(o|o<<2)&858993459,o=(o|o<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,o|t<<1}function Pm(o){let t=o,e=o;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==o);return e}function di(o,t,e,n,i,s,a,r){return(i-a)*(t-r)>=(o-a)*(s-r)&&(o-a)*(n-r)>=(e-a)*(t-r)&&(e-a)*(s-r)>=(i-a)*(n-r)}function Im(o,t){return o.next.i!==t.i&&o.prev.i!==t.i&&!Dm(o,t)&&(ki(o,t)&&ki(t,o)&&Um(o,t)&&(he(o.prev,o,t.prev)||he(o,t.prev,t))||Gs(o,t)&&he(o.prev,o,o.next)>0&&he(t.prev,t,t.next)>0)}function he(o,t,e){return(t.y-o.y)*(e.x-t.x)-(t.x-o.x)*(e.y-t.y)}function Gs(o,t){return o.x===t.x&&o.y===t.y}function Vc(o,t,e,n){const i=Ss(he(o,t,e)),s=Ss(he(o,t,n)),a=Ss(he(e,n,o)),r=Ss(he(e,n,t));return!!(i!==s&&a!==r||i===0&&Ms(o,e,t)||s===0&&Ms(o,n,t)||a===0&&Ms(e,o,n)||r===0&&Ms(e,t,n))}function Ms(o,t,e){return t.x<=Math.max(o.x,e.x)&&t.x>=Math.min(o.x,e.x)&&t.y<=Math.max(o.y,e.y)&&t.y>=Math.min(o.y,e.y)}function Ss(o){return o>0?1:o<0?-1:0}function Dm(o,t){let e=o;do{if(e.i!==o.i&&e.next.i!==o.i&&e.i!==t.i&&e.next.i!==t.i&&Vc(e,e.next,o,t))return!0;e=e.next}while(e!==o);return!1}function ki(o,t){return he(o.prev,o,o.next)<0?he(o,t,o.next)>=0&&he(o,o.prev,t)>=0:he(o,t,o.prev)<0||he(o,o.next,t)<0}function Um(o,t){let e=o,n=!1;const i=(o.x+t.x)/2,s=(o.y+t.y)/2;do e.y>s!=e.next.y>s&&e.next.y!==e.y&&i<(e.next.x-e.x)*(s-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==o);return n}function Wc(o,t){const e=new Xo(o.i,o.x,o.y),n=new Xo(t.i,t.x,t.y),i=o.next,s=t.prev;return o.next=t,t.prev=o,e.next=i,i.prev=e,n.next=e,e.prev=n,s.next=n,n.prev=s,n}function Wr(o,t,e,n){const i=new Xo(o,t,e);return n?(i.next=n.next,i.prev=n,n.next.prev=i,n.next=i):(i.prev=i,i.next=i),i}function zi(o){o.next.prev=o.prev,o.prev.next=o.next,o.prevZ&&(o.prevZ.nextZ=o.nextZ),o.nextZ&&(o.nextZ.prevZ=o.prevZ)}function Xo(o,t,e){this.i=o,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function Nm(o,t,e,n){let i=0;for(let s=t,a=e-n;s<e;s+=n)i+=(o[a]-o[s])*(o[s+1]+o[a+1]),a=s;return i}class Ni{static area(t){const e=t.length;let n=0;for(let i=e-1,s=0;s<e;i=s++)n+=t[i].x*t[s].y-t[s].x*t[i].y;return n*.5}static isClockWise(t){return Ni.area(t)<0}static triangulateShape(t,e){const n=[],i=[],s=[];Xr(t),qr(n,t);let a=t.length;e.forEach(Xr);for(let c=0;c<e.length;c++)i.push(a),a+=e[c].length,qr(n,e[c]);const r=_m.triangulate(n,i);for(let c=0;c<r.length;c+=3)s.push(r.slice(c,c+3));return s}}function Xr(o){const t=o.length;t>2&&o[t-1].equals(o[0])&&o.pop()}function qr(o,t){for(let e=0;e<t.length;e++)o.push(t[e].x),o.push(t[e].y)}class oa extends ge{constructor(t=new Gc([new ct(.5,.5),new ct(-.5,.5),new ct(-.5,-.5),new ct(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];const n=this,i=[],s=[];for(let r=0,c=t.length;r<c;r++){const l=t[r];a(l)}this.setAttribute("position",new Kt(i,3)),this.setAttribute("uv",new Kt(s,2)),this.computeVertexNormals();function a(r){const c=[],l=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,d=e.depth!==void 0?e.depth:1;let u=e.bevelEnabled!==void 0?e.bevelEnabled:!0,f=e.bevelThickness!==void 0?e.bevelThickness:.2,g=e.bevelSize!==void 0?e.bevelSize:f-.1,y=e.bevelOffset!==void 0?e.bevelOffset:0,m=e.bevelSegments!==void 0?e.bevelSegments:3;const p=e.extrudePath,x=e.UVGenerator!==void 0?e.UVGenerator:Bm;let v,M=!1,R,T,E,U;p&&(v=p.getSpacedPoints(h),M=!0,u=!1,R=p.computeFrenetFrames(h,!1),T=new L,E=new L,U=new L),u||(m=0,f=0,g=0,y=0);const w=r.extractPoints(l);let S=w.shape;const P=w.holes;if(!Ni.isClockWise(S)){S=S.reverse();for(let D=0,ht=P.length;D<ht;D++){const K=P[D];Ni.isClockWise(K)&&(P[D]=K.reverse())}}const j=Ni.triangulateShape(S,P),I=S;for(let D=0,ht=P.length;D<ht;D++){const K=P[D];S=S.concat(K)}function B(D,ht,K){return ht||console.error("THREE.ExtrudeGeometry: vec does not exist"),D.clone().addScaledVector(ht,K)}const O=S.length,Z=j.length;function X(D,ht,K){let lt,Q,Rt;const _t=D.x-ht.x,A=D.y-ht.y,b=K.x-D.x,z=K.y-D.y,at=_t*_t+A*A,st=_t*z-A*b;if(Math.abs(st)>Number.EPSILON){const it=Math.sqrt(at),At=Math.sqrt(b*b+z*z),gt=ht.x-A/it,Mt=ht.y+_t/it,Ut=K.x-z/At,Ht=K.y+b/At,ot=((Ut-gt)*z-(Ht-Mt)*b)/(_t*z-A*b);lt=gt+_t*ot-D.x,Q=Mt+A*ot-D.y;const Jt=lt*lt+Q*Q;if(Jt<=2)return new ct(lt,Q);Rt=Math.sqrt(Jt/2)}else{let it=!1;_t>Number.EPSILON?b>Number.EPSILON&&(it=!0):_t<-Number.EPSILON?b<-Number.EPSILON&&(it=!0):Math.sign(A)===Math.sign(z)&&(it=!0),it?(lt=-A,Q=_t,Rt=Math.sqrt(at)):(lt=_t,Q=A,Rt=Math.sqrt(at/2))}return new ct(lt/Rt,Q/Rt)}const q=[];for(let D=0,ht=I.length,K=ht-1,lt=D+1;D<ht;D++,K++,lt++)K===ht&&(K=0),lt===ht&&(lt=0),q[D]=X(I[D],I[K],I[lt]);const J=[];let et,rt=q.concat();for(let D=0,ht=P.length;D<ht;D++){const K=P[D];et=[];for(let lt=0,Q=K.length,Rt=Q-1,_t=lt+1;lt<Q;lt++,Rt++,_t++)Rt===Q&&(Rt=0),_t===Q&&(_t=0),et[lt]=X(K[lt],K[Rt],K[_t]);J.push(et),rt=rt.concat(et)}for(let D=0;D<m;D++){const ht=D/m,K=f*Math.cos(ht*Math.PI/2),lt=g*Math.sin(ht*Math.PI/2)+y;for(let Q=0,Rt=I.length;Q<Rt;Q++){const _t=B(I[Q],q[Q],lt);mt(_t.x,_t.y,-K)}for(let Q=0,Rt=P.length;Q<Rt;Q++){const _t=P[Q];et=J[Q];for(let A=0,b=_t.length;A<b;A++){const z=B(_t[A],et[A],lt);mt(z.x,z.y,-K)}}}const H=g+y;for(let D=0;D<O;D++){const ht=u?B(S[D],rt[D],H):S[D];M?(E.copy(R.normals[0]).multiplyScalar(ht.x),T.copy(R.binormals[0]).multiplyScalar(ht.y),U.copy(v[0]).add(E).add(T),mt(U.x,U.y,U.z)):mt(ht.x,ht.y,0)}for(let D=1;D<=h;D++)for(let ht=0;ht<O;ht++){const K=u?B(S[ht],rt[ht],H):S[ht];M?(E.copy(R.normals[D]).multiplyScalar(K.x),T.copy(R.binormals[D]).multiplyScalar(K.y),U.copy(v[D]).add(E).add(T),mt(U.x,U.y,U.z)):mt(K.x,K.y,d/h*D)}for(let D=m-1;D>=0;D--){const ht=D/m,K=f*Math.cos(ht*Math.PI/2),lt=g*Math.sin(ht*Math.PI/2)+y;for(let Q=0,Rt=I.length;Q<Rt;Q++){const _t=B(I[Q],q[Q],lt);mt(_t.x,_t.y,d+K)}for(let Q=0,Rt=P.length;Q<Rt;Q++){const _t=P[Q];et=J[Q];for(let A=0,b=_t.length;A<b;A++){const z=B(_t[A],et[A],lt);M?mt(z.x,z.y+v[h-1].y,v[h-1].x+K):mt(z.x,z.y,d+K)}}}tt(),ut();function tt(){const D=i.length/3;if(u){let ht=0,K=O*ht;for(let lt=0;lt<Z;lt++){const Q=j[lt];St(Q[2]+K,Q[1]+K,Q[0]+K)}ht=h+m*2,K=O*ht;for(let lt=0;lt<Z;lt++){const Q=j[lt];St(Q[0]+K,Q[1]+K,Q[2]+K)}}else{for(let ht=0;ht<Z;ht++){const K=j[ht];St(K[2],K[1],K[0])}for(let ht=0;ht<Z;ht++){const K=j[ht];St(K[0]+O*h,K[1]+O*h,K[2]+O*h)}}n.addGroup(D,i.length/3-D,0)}function ut(){const D=i.length/3;let ht=0;Et(I,ht),ht+=I.length;for(let K=0,lt=P.length;K<lt;K++){const Q=P[K];Et(Q,ht),ht+=Q.length}n.addGroup(D,i.length/3-D,1)}function Et(D,ht){let K=D.length;for(;--K>=0;){const lt=K;let Q=K-1;Q<0&&(Q=D.length-1);for(let Rt=0,_t=h+m*2;Rt<_t;Rt++){const A=O*Rt,b=O*(Rt+1),z=ht+lt+A,at=ht+Q+A,st=ht+Q+b,it=ht+lt+b;Pt(z,at,st,it)}}}function mt(D,ht,K){c.push(D),c.push(ht),c.push(K)}function St(D,ht,K){wt(D),wt(ht),wt(K);const lt=i.length/3,Q=x.generateTopUV(n,i,lt-3,lt-2,lt-1);It(Q[0]),It(Q[1]),It(Q[2])}function Pt(D,ht,K,lt){wt(D),wt(ht),wt(lt),wt(ht),wt(K),wt(lt);const Q=i.length/3,Rt=x.generateSideWallUV(n,i,Q-6,Q-3,Q-2,Q-1);It(Rt[0]),It(Rt[1]),It(Rt[3]),It(Rt[1]),It(Rt[2]),It(Rt[3])}function wt(D){i.push(c[D*3+0]),i.push(c[D*3+1]),i.push(c[D*3+2])}function It(D){s.push(D.x),s.push(D.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON(),e=this.parameters.shapes,n=this.parameters.options;return Fm(e,n,t)}static fromJSON(t,e){const n=[];for(let s=0,a=t.shapes.length;s<a;s++){const r=e[t.shapes[s]];n.push(r)}const i=t.options.extrudePath;return i!==void 0&&(t.options.extrudePath=new Us[i.type]().fromJSON(i)),new oa(n,t.options)}}const Bm={generateTopUV:function(o,t,e,n,i){const s=t[e*3],a=t[e*3+1],r=t[n*3],c=t[n*3+1],l=t[i*3],h=t[i*3+1];return[new ct(s,a),new ct(r,c),new ct(l,h)]},generateSideWallUV:function(o,t,e,n,i,s){const a=t[e*3],r=t[e*3+1],c=t[e*3+2],l=t[n*3],h=t[n*3+1],d=t[n*3+2],u=t[i*3],f=t[i*3+1],g=t[i*3+2],y=t[s*3],m=t[s*3+1],p=t[s*3+2];return Math.abs(r-h)<Math.abs(a-l)?[new ct(a,1-c),new ct(l,1-d),new ct(u,1-g),new ct(y,1-p)]:[new ct(r,1-c),new ct(h,1-d),new ct(f,1-g),new ct(m,1-p)]}};function Fm(o,t,e){if(e.shapes=[],Array.isArray(o))for(let n=0,i=o.length;n<i;n++){const s=o[n];e.shapes.push(s.uuid)}else e.shapes.push(o.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}class Ns extends Wi{constructor(t=1,e=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],i=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,i,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Ns(t.radius,t.detail)}}class Hs extends ge{constructor(t=.5,e=1,n=32,i=1,s=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:i,thetaStart:s,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);const r=[],c=[],l=[],h=[];let d=t;const u=(e-t)/i,f=new L,g=new ct;for(let y=0;y<=i;y++){for(let m=0;m<=n;m++){const p=s+m/n*a;f.x=d*Math.cos(p),f.y=d*Math.sin(p),c.push(f.x,f.y,f.z),l.push(0,0,1),g.x=(f.x/e+1)/2,g.y=(f.y/e+1)/2,h.push(g.x,g.y)}d+=u}for(let y=0;y<i;y++){const m=y*(n+1);for(let p=0;p<n;p++){const x=p+m,v=x,M=x+n+1,R=x+n+2,T=x+1;r.push(v,M,T),r.push(M,R,T)}}this.setIndex(r),this.setAttribute("position",new Kt(c,3)),this.setAttribute("normal",new Kt(l,3)),this.setAttribute("uv",new Kt(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Hs(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Tt extends ge{constructor(t=1,e=32,n=16,i=0,s=Math.PI*2,a=0,r=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:s,thetaStart:a,thetaLength:r},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const c=Math.min(a+r,Math.PI);let l=0;const h=[],d=new L,u=new L,f=[],g=[],y=[],m=[];for(let p=0;p<=n;p++){const x=[],v=p/n;let M=0;p===0&&a===0?M=.5/e:p===n&&c===Math.PI&&(M=-.5/e);for(let R=0;R<=e;R++){const T=R/e;d.x=-t*Math.cos(i+T*s)*Math.sin(a+v*r),d.y=t*Math.cos(a+v*r),d.z=t*Math.sin(i+T*s)*Math.sin(a+v*r),g.push(d.x,d.y,d.z),u.copy(d).normalize(),y.push(u.x,u.y,u.z),m.push(T+M,1-v),x.push(l++)}h.push(x)}for(let p=0;p<n;p++)for(let x=0;x<e;x++){const v=h[p][x+1],M=h[p][x],R=h[p+1][x],T=h[p+1][x+1];(p!==0||a>0)&&f.push(v,M,T),(p!==n-1||c<Math.PI)&&f.push(M,R,T)}this.setIndex(f),this.setAttribute("position",new Kt(g,3)),this.setAttribute("normal",new Kt(y,3)),this.setAttribute("uv",new Kt(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Tt(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class aa extends Wi{constructor(t=1,e=0){const n=[1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],i=[2,1,0,0,3,2,1,3,0,2,3,1];super(n,i,t,e),this.type="TetrahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new aa(t.radius,t.detail)}}class xn extends ge{constructor(t=1,e=.4,n=12,i=48,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:i,arc:s},n=Math.floor(n),i=Math.floor(i);const a=[],r=[],c=[],l=[],h=new L,d=new L,u=new L;for(let f=0;f<=n;f++)for(let g=0;g<=i;g++){const y=g/i*s,m=f/n*Math.PI*2;d.x=(t+e*Math.cos(m))*Math.cos(y),d.y=(t+e*Math.cos(m))*Math.sin(y),d.z=e*Math.sin(m),r.push(d.x,d.y,d.z),h.x=t*Math.cos(y),h.y=t*Math.sin(y),u.subVectors(d,h).normalize(),c.push(u.x,u.y,u.z),l.push(g/i),l.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=i;g++){const y=(i+1)*f+g-1,m=(i+1)*(f-1)+g-1,p=(i+1)*(f-1)+g,x=(i+1)*f+g;a.push(y,m,x),a.push(m,p,x)}this.setIndex(a),this.setAttribute("position",new Kt(r,3)),this.setAttribute("normal",new Kt(c,3)),this.setAttribute("uv",new Kt(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new xn(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}class ra extends ge{constructor(t=new kc(new L(-1,-1,0),new L(-1,1,0),new L(1,1,0)),e=64,n=1,i=8,s=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:n,radialSegments:i,closed:s};const a=t.computeFrenetFrames(e,s);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;const r=new L,c=new L,l=new ct;let h=new L;const d=[],u=[],f=[],g=[];y(),this.setIndex(g),this.setAttribute("position",new Kt(d,3)),this.setAttribute("normal",new Kt(u,3)),this.setAttribute("uv",new Kt(f,2));function y(){for(let v=0;v<e;v++)m(v);m(s===!1?e:0),x(),p()}function m(v){h=t.getPointAt(v/e,h);const M=a.normals[v],R=a.binormals[v];for(let T=0;T<=i;T++){const E=T/i*Math.PI*2,U=Math.sin(E),w=-Math.cos(E);c.x=w*M.x+U*R.x,c.y=w*M.y+U*R.y,c.z=w*M.z+U*R.z,c.normalize(),u.push(c.x,c.y,c.z),r.x=h.x+n*c.x,r.y=h.y+n*c.y,r.z=h.z+n*c.z,d.push(r.x,r.y,r.z)}}function p(){for(let v=1;v<=e;v++)for(let M=1;M<=i;M++){const R=(i+1)*(v-1)+(M-1),T=(i+1)*v+(M-1),E=(i+1)*v+M,U=(i+1)*(v-1)+M;g.push(R,T,U),g.push(T,E,U)}}function x(){for(let v=0;v<=e;v++)for(let M=0;M<=i;M++)l.x=v/e,l.y=M/i,f.push(l.x,l.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new ra(new Us[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}}class Y extends En{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new kt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new kt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=lc,this.normalScale=new ct(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=jo,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class Vs extends fe{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new kt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}}class Om extends Vs{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(fe.DEFAULT_UP),this.updateMatrix(),this.groundColor=new kt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}}const Po=new ce,Yr=new L,$r=new L;class ca{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ct(512,512),this.map=null,this.mapPass=null,this.matrix=new ce,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Qo,this._frameExtents=new ct(1,1),this._viewportCount=1,this._viewports=[new re(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera,n=this.matrix;Yr.setFromMatrixPosition(t.matrixWorld),e.position.copy(Yr),$r.setFromMatrixPosition(t.target.matrixWorld),e.lookAt($r),e.updateMatrixWorld(),Po.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Po),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Po)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}class km extends ca{constructor(){super(new De(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(t){const e=this.camera,n=Ps*2*t.angle*this.focus,i=this.mapSize.width/this.mapSize.height,s=t.distance||e.far;(n!==e.fov||i!==e.aspect||s!==e.far)&&(e.fov=n,e.aspect=i,e.far=s,e.updateProjectionMatrix()),super.updateMatrices(t)}copy(t){return super.copy(t),this.focus=t.focus,this}}class zm extends Vs{constructor(t,e,n=0,i=Math.PI/3,s=0,a=2){super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(fe.DEFAULT_UP),this.updateMatrix(),this.target=new fe,this.distance=n,this.angle=i,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new km}get power(){return this.intensity*Math.PI}set power(t){this.intensity=t/Math.PI}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}const jr=new ce,Ci=new L,Io=new L;class Gm extends ca{constructor(){super(new De(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new ct(4,2),this._viewportCount=6,this._viewports=[new re(2,1,1,1),new re(0,1,1,1),new re(3,1,1,1),new re(1,1,1,1),new re(3,0,1,1),new re(1,0,1,1)],this._cubeDirections=[new L(1,0,0),new L(-1,0,0),new L(0,0,1),new L(0,0,-1),new L(0,1,0),new L(0,-1,0)],this._cubeUps=[new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,0,1),new L(0,0,-1)]}updateMatrices(t,e=0){const n=this.camera,i=this.matrix,s=t.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),Ci.setFromMatrixPosition(t.matrixWorld),n.position.copy(Ci),Io.copy(n.position),Io.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(Io),n.updateMatrixWorld(),i.makeTranslation(-Ci.x,-Ci.y,-Ci.z),jr.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(jr)}}class ke extends Vs{constructor(t,e,n=0,i=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new Gm}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}}class Hm extends ca{constructor(){super(new Mc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Vm extends Vs{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(fe.DEFAULT_UP),this.updateMatrix(),this.target=new fe,this.shadow=new Hm}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class Wm{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Zr(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const e=Zr();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}}function Zr(){return(typeof performance>"u"?Date:performance).now()}class Xm{constructor(t,e,n=0,i=1/0){this.ray=new Os(t,e),this.near=n,this.far=i,this.camera=null,this.layers=new Jo,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}intersectObject(t,e=!0,n=[]){return qo(t,this,n,e),n.sort(Kr),n}intersectObjects(t,e=!0,n=[]){for(let i=0,s=t.length;i<s;i++)qo(t[i],this,n,e);return n.sort(Kr),n}}function Kr(o,t){return o.distance-t.distance}function qo(o,t,e,n){if(o.layers.test(t.layers)&&o.raycast(t,e),n===!0){const i=o.children;for(let s=0,a=i.length;s<a;s++)qo(i[s],t,e,!0)}}class qm extends am{constructor(t=10,e=10,n=4473924,i=8947848){n=new kt(n),i=new kt(i);const s=e/2,a=t/e,r=t/2,c=[],l=[];for(let u=0,f=0,g=-r;u<=e;u++,g+=a){c.push(-r,0,g,r,0,g),c.push(g,0,-r,g,0,r);const y=u===s?n:i;y.toArray(l,f),f+=3,y.toArray(l,f),f+=3,y.toArray(l,f),f+=3,y.toArray(l,f),f+=3}const h=new ge;h.setAttribute("position",new Kt(c,3)),h.setAttribute("color",new Kt(l,3));const d=new Ic({vertexColors:!0,toneMapped:!1});super(h,d),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Yo}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Yo);class Ym{constructor(){this.modals={about:document.getElementById("modal-about"),skills:document.getElementById("modal-skills"),projects:document.getElementById("modal-projects"),arcade:document.getElementById("modal-arcade"),easel:document.getElementById("modal-easel"),wardrobe:document.getElementById("modal-wardrobe"),leaderboard:document.getElementById("modal-leaderboard"),tasks:document.getElementById("modal-tasks"),farm:document.getElementById("modal-farm"),pk:document.getElementById("modal-pk"),bag:document.getElementById("modal-bag"),home:document.getElementById("modal-home"),exit:document.getElementById("modal-exit"),map:document.getElementById("modal-map"),shop:document.getElementById("modal-shop"),piano:document.getElementById("modal-piano")},this.iframe=document.getElementById("arcade-iframe"),this.arcadeLobby=document.getElementById("arcade-lobby"),this.arcadeTitle=document.getElementById("arcade-title"),this.arcadeBackBtn=document.getElementById("btn-arcade-back"),this.closeButtons=document.querySelectorAll(".modal-close"),this.overlayList=document.querySelectorAll(".modal-overlay"),this.isAnyModalOpen=!1,this.init(),this.hydrateFromConfig()}init(){this.closeButtons.forEach(t=>{t.addEventListener("click",e=>{let n=t.getAttribute("data-close");n&&n.startsWith("modal-")&&(n=n.replace("modal-","")),this.closeModal(n)})}),this.overlayList.forEach(t=>{t.addEventListener("click",e=>{if(e.target===t){const n=t.id.replace("modal-","");this.closeModal(n)}})}),window.addEventListener("keydown",t=>{t.key==="Escape"&&this.isAnyModalOpen&&this.closeAllModals()})}async hydrateFromConfig(){try{const e=(await Zc(()=>import("./site-config-CqbHk6xq.js"),[],import.meta.url)).siteConfig;if(e.developer){const s=e.developer,a=document.querySelector("#modal-about .avatar-placeholder");a&&(a.textContent=s.avatar||"🌻");const r=document.querySelector("#modal-about .profile-info");r&&(r.innerHTML=`
            <h3>${s.name}</h3>
            <p class="tagline">${s.tagline}</p>
          `);const c=document.querySelector("#modal-about .bio-text");c&&(c.innerHTML=`
            <p>${s.bio}</p>
            <p><strong>联系邮箱:</strong> ${s.email}</p>
            <div style="margin-top: 20px; display: flex; gap: 12px; pointer-events: auto;">
              <a href="../../class.html" class="hud-btn" style="padding: 8px 16px; font-size: 0.8rem; text-decoration: none;">我的课表</a>
              <a href="../../album.html" class="hud-btn" style="padding: 8px 16px; font-size: 0.8rem; text-decoration: none;">我的相册</a>
            </div>
          `)}const n=document.querySelector("#modal-projects .projects-grid");n&&e.games&&(n.innerHTML="",e.games.forEach(s=>{const a=document.createElement("div");a.className="project-item",a.innerHTML=`
            <div class="project-img">${s.emoji||"🎮"}</div>
            <div class="project-detail">
              <h3>${s.name}</h3>
              <p>运行于网页主页“韭菜盒子”工具箱板块下的经典互动小游戏，适配桌面端与移动端。</p>
              <button class="tag play-btn" style="margin-top: 6px; display: inline-block; text-decoration: none; cursor: pointer; border: none; background: none; color: inherit; padding: 0; font-family: inherit; text-align: left;">直接游玩</button>
            </div>
          `;const r=a.querySelector(".play-btn");r&&r.addEventListener("click",c=>{c.preventDefault(),this.launchGame(s)}),n.appendChild(a)}));const i=document.querySelector(".arcade-games-grid");i&&e.games&&(i.innerHTML="",e.games.forEach(s=>{const a=document.createElement("div");a.className="arcade-game-card",a.innerHTML=`
            <div class="arcade-game-icon">${s.emoji||"🕹️"}</div>
            <div class="arcade-game-title">${s.name}</div>
          `,a.addEventListener("click",()=>{this.launchGame(s)}),i.appendChild(a)})),this.arcadeBackBtn&&this.arcadeBackBtn.addEventListener("click",()=>{this.showLobby()})}catch(t){console.error("Failed to dynamically import site config:",t)}}launchGame(t){let e=t.path;const n=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1";t.id==="21dian"&&(e=n?`http://${window.location.hostname}:8080/games/21dian/index.html`:t.path);let i;e.startsWith("http://")||e.startsWith("https://")?i=e:i="../../"+e.replace(/^\.\//,"");const s=localStorage.getItem("sso_access_token"),a=localStorage.getItem("sso_user");if(s&&a)try{const r=new URL(i,window.location.href);r.searchParams.set("sso_access_token",s),r.searchParams.set("sso_user",a),i=r.toString()}catch{i.includes("?")?i+=`&sso_access_token=${s}&sso_user=${encodeURIComponent(a)}`:i+=`?sso_access_token=${s}&sso_user=${encodeURIComponent(a)}`}window.open(i,"_blank")}showLobby(){this.iframe&&(this.iframe.src="",this.iframe.style.display="none"),this.arcadeLobby&&(this.arcadeLobby.style.display="block"),this.arcadeTitle&&(this.arcadeTitle.textContent="复古街机 · 游戏大厅"),this.arcadeBackBtn&&(this.arcadeBackBtn.style.display="none")}openModal(t){const e=this.modals[t];if(e){if(t==="arcade"&&this.showLobby(),t==="easel"){const n=document.getElementById("easel-iframe");n&&(n.src="./paint.html")}e.classList.add("open"),this.isAnyModalOpen=!0,window.dispatchEvent(new CustomEvent("modal-opened",{detail:{modalId:t}})),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalOpened=="function"&&window.parent.appShell.onModalOpened(t)}}closeModal(t){const e=this.modals[t];if(e){if(e.classList.remove("open"),t==="arcade"&&this.iframe&&(this.iframe.src=""),t==="easel"){const n=document.getElementById("easel-iframe");n&&(n.src="")}this.isAnyModalOpen=Array.from(this.overlayList).some(n=>n.classList.contains("open")),this.isAnyModalOpen||(window.dispatchEvent(new CustomEvent("modal-closed",{detail:{modalId:t}})),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed(t))}}closeAllModals(){Object.keys(this.modals).forEach(t=>this.closeModal(t))}}class $m{constructor(t,e){this.scene=t,this.themeConfig=e,this.particles=null,this.particleCount=150,this.particleGeometry=null,this.particleMaterial=null,this.isNight=!1,this.isIndoor=!1,this.initLights(),this.initFog(),this.initParticles()}setIndoorMode(t){this.isIndoor=t,this.particles&&(this.particles.visible=!t)}initLights(){const t=this.themeConfig.colors.sky===330776,e=t?14544639:16777215,n=t?4128:58879,i=t?.75:1.1,s=new Om(e,n,i);s.position.set(0,50,0),this.scene.add(s),this.hemiLight=s;const a=t?14280949:16776679,r=t?.95:1.75,c=new Vm(a,r);c.position.set(20,40,20),c.castShadow=!0;const l="ontouchstart"in window||navigator.maxTouchPoints>0;c.shadow.mapSize.width=l?1024:2048,c.shadow.mapSize.height=l?1024:2048,c.shadow.camera.near=.5,c.shadow.camera.far=100;const h=30;c.shadow.camera.left=-h,c.shadow.camera.right=h,c.shadow.camera.top=h,c.shadow.camera.bottom=-h,c.shadow.bias=-5e-4,this.scene.add(c),this.sun=c}initFog(){const t=this.themeConfig.colors.fog||14743546,n=this.themeConfig.colors.sky===330776?.012:.009;this.scene.fog=new ea(t,n)}initParticles(){const t=this.themeConfig.colors.sky===330776;this.particleGeometry=new ge;const e=new Float32Array(this.particleCount*3),n=[];for(let c=0;c<this.particleCount;c++)e[c*3]=(Math.random()-.5)*60,e[c*3+1]=Math.random()*(t?30:22),e[c*3+2]=(Math.random()-.5)*60,n.push({y:t?.08+Math.random()*.08:.05+Math.random()*.05,x:(Math.random()-.5)*.04,z:(Math.random()-.5)*.04});this.particleGeometry.setAttribute("position",new qe(e,3)),this.particleSpeeds=n;const i=document.createElement("canvas");i.width=16,i.height=16;const s=i.getContext("2d"),a=s.createRadialGradient(8,8,0,8,8,8);t?(a.addColorStop(0,"rgba(255, 255, 255, 0.95)"),a.addColorStop(.4,"rgba(255, 255, 255, 0.7)"),a.addColorStop(1,"rgba(255, 255, 255, 0)")):(a.addColorStop(0,"rgba(128, 222, 234, 0.85)"),a.addColorStop(1,"rgba(128, 222, 234, 0)")),s.fillStyle=a,s.fillRect(0,0,16,16);const r=new Uc(i);this.particleMaterial=new Dc({size:t?.45:.6,map:r,transparent:!0,blending:Es,depthWrite:!1}),this.particles=new rm(this.particleGeometry,this.particleMaterial),this.scene.add(this.particles)}update(t){if(!this.particles)return;const e=this.particleGeometry.attributes.position.array,n=this.themeConfig.colors.sky===330776;for(let l=0;l<this.particleCount;l++){const h=l*3,d=this.particleSpeeds[l];n?(e[h]+=d.x+Math.sin(t*5e-4+l)*.01,e[h+1]-=d.y*.5,e[h+2]+=d.z+Math.cos(t*5e-4+l)*.01,e[h+1]<.5&&(e[h]=(Math.random()-.5)*60,e[h+1]=25,e[h+2]=(Math.random()-.5)*60)):(e[h]+=d.x+Math.sin(t*.001+l)*.015,e[h+1]+=d.y*.4,e[h+2]+=d.z,e[h+1]>22&&(e[h]=(Math.random()-.5)*60,e[h+1]=-1,e[h+2]=(Math.random()-.5)*60))}this.particleGeometry.attributes.position.needsUpdate=!0;let i,s,a,r,c;this.isIndoor?(i=.75,s=.05,a=new kt(16765312),r=new kt(790036),c=new kt(790036)):(i=this.isNight?.18:n?.75:1.1,s=this.isNight?.22:n?.95:1.75,a=new kt(this.isNight?9479342:n?14280949:16776679),r=new kt(this.isNight?461586:this.themeConfig.colors.sky),c=new kt(this.isNight?461586:this.themeConfig.colors.fog)),this.hemiLight&&(this.hemiLight.intensity+=(i-this.hemiLight.intensity)*.04),this.sun&&(this.sun.intensity+=(s-this.sun.intensity)*.04,this.sun.color.lerp(a,.04)),this.scene.background.lerp(r,.04),this.scene.fog&&this.scene.fog.color.lerp(c,.04)}}class jm{constructor(t,e){this.scene=t,this.themeConfig=e,this.colliders=[],this.interactables=[],this.streetlights=[],this.group=new dt;const n=this.themeConfig.colors,i=n.sky===330776;this.materials={sand:new Y({color:n.sand,flatShading:!0}),dirt:new Y({color:n.dirt,flatShading:!0}),stone:new Y({color:i?9479342:13619151,flatShading:!0}),wood:new Y({color:i?5125166:10586239,flatShading:!0}),leaves:new Y({color:i?1793568:5025616,flatShading:!0}),coconut:new Y({color:6111287,flatShading:!0}),umbrellaRed:new Y({color:i?13959168:16732754,flatShading:!0}),umbrellaWhite:new Y({color:16777215,flatShading:!0}),seaWater:new Lt({color:n.seaWater,transparent:!0,opacity:i?.72:.58,side:ye}),arcadeBody:new Y({color:i?4073251:2503224,flatShading:!0}),arcadeScreen:new Lt({color:i?2733814:58998}),neonRed:new Lt({color:16732754}),neonBlue:new Lt({color:4244735})};const s=this.scene.add;this.scene.add=a=>{a.isLight?s.call(this.scene,a):this.group.add(a)},this.buildWorld(),this.scene.add=s,s.call(this.scene,this.group)}buildWorld(){this.themeConfig.colors.sky,this.createMainGround(0,0,0,22),this.createVastOcean(),this.createOuterBoundaries(),this.decorateAboutZone(),this.decorateSkillsZone(),this.decorateProjectsZone(),this.decorateArcadeZone(),this.createBeachDecorations(),this.createSwing(4.5,.6,6),this.createBallVendor(-5,.6,6),this.createSummerDecorations(),this.createCozyHouse(-10,.6,-9),this.createStreetlamps(),this.createPaimon(2.5,2.5),this.createLakePortal(-6.5,.6,-1.5)}createFarmField(t,e,n){this.farmGroup=new dt,this.farmGroup.position.set(t,e,n);const i=1.8,s=1.8;this.farmPlots3D=[];for(let a=0;a<2;a++)for(let r=0;r<3;r++){const c=(r-1)*i,l=(a-.5)*s,h=new G(1.4,.12,1.4),d=new _(h,this.materials.dirt);d.position.set(c,.06,l),d.receiveShadow=!0,d.castShadow=!0,this.farmGroup.add(d);const u=new G(1.5,.08,.08),f=this.materials.stone,g=new _(u,f);g.position.set(c,.12,l-.7),this.farmGroup.add(g);const y=new _(u,f);y.position.set(c,.12,l+.7),this.farmGroup.add(y);const m=new _(new G(.08,.08,1.4),f);m.position.set(c-.7,.12,l),this.farmGroup.add(m);const p=new _(new G(.08,.08,1.4),f);p.position.set(c+.7,.12,l),this.farmGroup.add(p);const x=new dt;x.position.set(c,.12,l),this.farmGroup.add(x),this.farmPlots3D.push({row:a,col:r,index:a*3+r,mesh:d,plantGroup:x,x:t+c,z:n+l}),this.interactables.push({id:`farm_plot_${a*3+r}`,name:"农田格子",x:t+c,y:e,z:n+l,triggerRadius:1.2})}this.scene.add(this.farmGroup)}createMainGround(t,e,n,i){const s=new dt;s.position.set(t,e,n);const a=new nt(i,i-.2,.6,12),r=new _(a,this.materials.sand);r.position.y=.3,r.receiveShadow=!0,r.castShadow=!0,s.add(r);const c=new nt(i-.2,i-1.5,1.8,12),l=new _(c,this.materials.dirt);l.position.y=-.9,l.castShadow=!0,s.add(l),this.scene.add(s),this.colliders.push({mesh:r,radius:i,worldX:t,worldZ:n,worldY:.6,type:"floor"})}createVastOcean(){const t=new Xe(160,160),e=new _(t,this.materials.seaWater);e.rotation.x=-Math.PI/2,e.position.y=.18,e.receiveShadow=!0,this.scene.add(e)}createOuterBoundaries(){const n=this.themeConfig.colors.sky===330776;for(let i=0;i<20;i++){const s=i/20*Math.PI*2;if(Math.abs(s)<.2||Math.abs(s-Math.PI)<.2||Math.abs(s-Math.PI/2)<.2)continue;const a=Math.sin(s)*21.2,r=Math.cos(s)*21.2;n?this.createPineTree(a,.6,r,1.1+Math.random()*.3):this.createPalmTree(a,.6,r,1.2+Math.random()*.4)}}createPalmTree(t,e,n,i){const s=new dt;s.position.set(t,e,n),s.scale.set(i,i,i);const a=new dt,r=5;let c=0,l=0;const h=new nt(.08,.12,.4,5);for(let g=0;g<r;g++){const y=new _(h,this.materials.wood);y.position.set(l,c+.2,0);const m=.08*g;y.rotation.z=m,y.castShadow=!0,a.add(y),c+=.36*Math.cos(m),l-=.36*Math.sin(m)}s.add(a);const d=new dt;d.position.set(l,c,0);const u=new G(.8,.02,.25);u.translate(.4,0,0);const f=6;for(let g=0;g<f;g++){const y=new _(u,this.materials.leaves);y.rotation.y=g/f*Math.PI*2,y.rotation.z=-.22,y.castShadow=!0,d.add(y)}s.add(d),this.scene.add(s)}createPineTree(t,e,n,i){const s=new dt;s.position.set(t,e,n),s.scale.set(i,i,i);const a=new nt(.12,.18,.6,5),r=new _(a,this.materials.wood);r.position.y=.3,r.castShadow=!0,s.add(r);for(let d=0;d<3;d++){const u=new oe(.55-d*.12,.6,6),f=new _(u,this.materials.leaves);f.position.y=.7+d*.4,f.castShadow=!0,s.add(f)}const c=new Tt(.06,5,5),l=new Lt({color:16776679}),h=new _(c,l);h.position.y=1.7,s.add(h),this.scene.add(s)}decorateAboutZone(){const t=this.themeConfig.colors.sky===330776,e=new dt;e.position.set(0,.6,0);const n=new nt(.07,.07,.6,5);n.translate(0,-.3,0),n.rotateZ(.95);for(let d=0;d<3;d++){const u=new _(n,this.materials.wood);u.position.set(-1.8,.35,1.8),u.rotation.y=d*Math.PI*2/3,u.castShadow=!0,e.add(u)}const i=new dt;i.position.set(-1.8,.15,1.8);const s=new Lt({color:16733986}),a=new oe(.18,.45,5),r=new _(a,s);r.position.set(0,.2,0),i.add(r);const c=new _(a,new Lt({color:16748800}));c.position.set(.08,.15,-.05),c.rotation.z=.2,c.scale.set(.8,.8,.8),i.add(c);const l=new _(a,new Lt({color:16766464}));l.position.set(-.08,.12,.06),l.rotation.z=-.2,l.scale.set(.7,.7,.7),i.add(l),e.add(i);const h=new ke(16733986,0,10,1.2);if(h.position.set(-1.8,.8,1.8),this.scene.add(h),this.streetlights.push(h),t){this.createSnowman(1.8,.6,-1.3);const d=new dt;d.position.set(1.5,.04,-2.2),d.rotation.y=-.45;const u=new _(new G(1.2,.08,.4),this.materials.wood);u.position.y=.25,u.castShadow=!0,d.add(u);const f=new _(new G(.08,.25,.35),this.materials.wood);f.position.set(-.5,.125,0),f.castShadow=!0,d.add(f);const g=new _(new G(.08,.25,.35),this.materials.wood);g.position.set(.5,.125,0),g.castShadow=!0,d.add(g),e.add(d)}else{const d=new _(new G(.5,.08,1.1),this.materials.umbrellaWhite);d.position.set(1.5,.04,-1.2),d.rotation.y=-.4,d.castShadow=!0,e.add(d);const u=new _(new G(.48,.1,.25),this.materials.umbrellaRed);u.position.set(1.5,.12,-1.6),u.rotation.y=-.4,e.add(u);const f=new dt;f.position.set(2.4,0,-2.4);const g=new _(new nt(.04,.04,2.2,5),this.materials.wood);g.position.y=1.1,g.castShadow=!0,f.add(g);const y=new oe(1.2,.5,8),m=new _(y,this.materials.umbrellaRed);m.position.y=2.1,m.castShadow=!0,f.add(m);const p=new _(new oe(1.22,.48,8),this.materials.umbrellaWhite);p.position.y=2.1,p.rotation.y=Math.PI/8,f.add(p),e.add(f)}this.scene.add(e),this.interactables.push({id:"about",name:"关于我",x:0,y:.6,z:0,triggerRadius:3.5})}createSnowman(t,e,n){const i=new dt;i.position.set(t,e,n);const s=new _(new Tt(.4,8,8),this.materials.umbrellaWhite);s.position.y=.4,s.castShadow=!0,i.add(s);const a=new _(new Tt(.26,8,8),this.materials.umbrellaWhite);a.position.y=.9,a.castShadow=!0,i.add(a);const r=new oe(.04,.12,4);r.rotateX(Math.PI/2);const c=new _(r,new Y({color:16754470}));c.position.set(0,.9,.26),i.add(c);const l=new Tt(.03,4,4),h=new Lt({color:1118481}),d=new _(l,h);d.position.set(-.08,.96,.23);const u=new _(l,h);u.position.set(.08,.96,.23),i.add(d),i.add(u);const f=new _(new nt(.24,.24,.08,8),this.materials.umbrellaRed);f.position.y=.7,i.add(f);const g=new _(new nt(.15,.18,.2,8),this.materials.arcadeBody);g.position.y=1.18,g.castShadow=!0,i.add(g),this.scene.add(i)}decorateSkillsZone(){const t=this.themeConfig.colors.sky===330776,e=-12,n=-3,i=.6;if(t){const s=new dt;s.position.set(e,i,n);const a=new _(new nt(.3,.4,1.8,8),this.materials.wood);a.position.y=.9,a.castShadow=!0,s.add(a);for(let h=0;h<4;h++){const d=new _(new oe(1.6-h*.35,1.6,8),this.materials.leaves);d.position.y=1.8+h*.9,d.castShadow=!0,s.add(d)}const r=new _(new Tt(.18,6,6),new Lt({color:16771899}));r.position.y=5.2,s.add(r);const c=[16732754,4244735,16771899,14696699];for(let h=0;h<12;h++){const d=new _(new Tt(.12,5,5),new Lt({color:c[h%c.length]})),u=1.8+Math.floor(h/3)*.9,f=1.3-Math.floor(h/3)*.3,g=h%3*(Math.PI*2/3)+u*.5;d.position.set(Math.cos(g)*f,u+.2,Math.sin(g)*f),s.add(d)}const l=[16732754,4244735,14696699];for(let h=0;h<3;h++){const d=new _(new G(.4,.4,.4),new Y({color:l[h],flatShading:!0}));d.position.set(.6-h*.5,.2,.5+h*.2),d.rotation.y=h*.4,d.castShadow=!0,s.add(d)}this.scene.add(s)}else{const s=new dt;s.position.set(e,i,n);const a=new nt(.24,.4,4.2,7),r=new _(a,this.materials.wood);r.position.y=2.1,r.rotation.z=-.1,r.castShadow=!0,s.add(r);const c=new dt;c.position.set(-.2,4.1,0);const l=new G(2,.02,.45);l.translate(1,0,0);const h=8;for(let u=0;u<h;u++){const f=new _(l,this.materials.leaves);f.rotation.y=u/h*Math.PI*2,f.rotation.z=-.25,f.castShadow=!0,c.add(f)}s.add(c);const d=new Tt(.24,5,5);for(let u=0;u<3;u++){const f=new _(d,this.materials.coconut),g=u/3*Math.PI*2;f.position.set(-.2+Math.cos(g)*.3,3.8,Math.sin(g)*.3),f.castShadow=!0,s.add(f)}this.scene.add(s)}this.interactables.push({id:"skills",name:"技术栈",x:-12,y:.6,z:-1,triggerRadius:3})}decorateProjectsZone(){const t=this.themeConfig.colors.sky===330776,e=12,n=-3,i=.6,s=new dt;s.position.set(e,i,n);const a=new nt(.08,.08,2.5,5),r=new _(a,this.materials.wood);r.position.set(-1.8,1.25,0),r.castShadow=!0,s.add(r);const c=new _(a,this.materials.wood);c.position.set(1.8,1.25,0),c.castShadow=!0,s.add(c);const l=new _(new G(3.6,2,.15),this.materials.wood);l.position.y=2.25,l.castShadow=!0,s.add(l);const h=new _(new G(3.2,1.7,.08),this.materials.stone);h.position.set(0,2.25,.06),s.add(h);const d=new Y({color:t?13959168:4244735,flatShading:!0}),u=new Y({color:t?3046706:16754470,flatShading:!0}),f=new Tt(.32,8,8);f.scale(1,2.4,.12);const g=new _(f,d);g.position.set(-1.2,.6,.2),g.rotation.set(.1,.2,-.15),g.castShadow=!0,s.add(g);const y=new _(f,u);y.position.set(1.2,.6,.2),y.rotation.set(.1,-.2,.15),y.castShadow=!0,s.add(y);const m=new Tt(.08,5,5),p=new Lt({color:16774557}),x=new _(m,p);x.position.set(-1.8,3.3,.1),s.add(x);const v=new _(m,p);v.position.set(1.8,3.3,.1),s.add(v);const M=new ke(16774557,0,6,1.2);M.position.set(e-1.8,i+3.3,n+.1),this.scene.add(M),this.streetlights.push(M);const R=new ke(16774557,0,6,1.2);R.position.set(e+1.8,i+3.3,n+.1),this.scene.add(R),this.streetlights.push(R),this.scene.add(s),this.interactables.push({id:"projects",name:"项目展示",x:12,y:.6,z:-1,triggerRadius:3})}decorateArcadeZone(){const t=this.themeConfig.colors.sky===330776,e=0,n=-12,i=.6,s=new dt;s.position.set(e,i,n);const a=new _(new G(1.2,1,1),this.materials.arcadeBody);a.position.y=.5,a.castShadow=!0,s.add(a);const r=new _(new G(1.2,1.2,.8),this.materials.arcadeBody);r.position.set(0,1.4,-.1),r.castShadow=!0,s.add(r);const c=new Xe(.95,.72);c.rotateX(-.1);const l=new _(c,this.materials.arcadeScreen);l.position.set(0,1.4,.31),s.add(l);const h=new _(new G(1.3,.2,.5),this.materials.arcadeBody);h.position.set(0,.95,.3),h.rotation.x=.15,h.castShadow=!0,s.add(h);const d=new _(new nt(.015,.015,.18,4),this.materials.stone);d.position.set(-.3,1.05,.4),d.rotation.x=.15,s.add(d);const u=new _(new Tt(.05,5,5),this.materials.neonRed);u.position.set(-.3,1.14,.42),s.add(u);const f=new nt(.035,.035,.03,5);f.rotateX(.15);for(let P=0;P<3;P++){const F=new _(f,P%2===0?this.materials.neonRed:this.materials.neonBlue);F.position.set(.15+P*.12,1,.4),s.add(F)}const g=new _(new G(1.2,.25,.85),this.materials.arcadeBody);g.position.set(0,2.05,-.05),s.add(g);const y=new _(new Xe(1,.18),new Lt({color:t?2733814:16754470}));y.position.set(0,2.05,.38),s.add(y);const m=new nt(.04,.04,1.5,5),p=new _(m,this.materials.wood);p.position.set(-.9,.75,.2),p.castShadow=!0,s.add(p);const x=new _(m,this.materials.wood);x.position.set(.9,.75,.2),x.castShadow=!0,s.add(x);const v=new oe(.08,.22,5),M=new Lt({color:16740419}),R=new _(v,M);R.position.set(-.9,1.62,.2),s.add(R);const T=new _(v,M);T.position.set(.9,1.62,.2),s.add(T);const E=new ke(16733986,0,5,1.2);E.position.set(e-.9,i+1.62,n+.2),this.scene.add(E),this.streetlights.push(E);const U=new ke(16733986,0,5,1.2);U.position.set(e+.9,i+1.62,n+.2),this.scene.add(U),this.streetlights.push(U),this.scene.add(s);const w=t?2733814:65280,S=new zm(w,2,6,Math.PI/6,.5,1);S.position.set(0,4,-12),S.target=a,this.scene.add(S),this.interactables.push({id:"arcade",name:"复古街机",x:0,y:.6,z:-10.4,triggerRadius:2.2})}createBeachDecorations(){const t=this.themeConfig.colors.sky===330776,e=new Hs(21.8,22.2,32);e.rotateX(-Math.PI/2);const n=new Lt({color:16777215,transparent:!0,opacity:t?.95:.8,side:ye}),i=new _(e,n);i.position.y=.22,this.scene.add(i),this.createBeachBall(.6,.6,-1.8,.24,t?16777215:16732754),this.createBeachBall(10,.6,-1.5,.26,t?16777215:4244735),t?(this.createSnowHeap(3.5,.61,2.5,.2),this.createSnowHeap(-10.5,.61,1.5,.28),this.createSnowHeap(-3.5,.61,-1.5,.18),this.createSnowHeap(8.5,.61,3.5,.24)):(this.createStarfish(3.5,.61,2.5,16740419),this.createStarfish(-10.5,.61,1.5,16740419),this.createShell(-3.5,.61,-1.5,16775620),this.createShell(8.5,.61,3.5,16775620),this.createExtraUmbrella(-5.8,.6,-5,4244735),this.createExtraUmbrella(8,.6,-7,16771899))}createBeachBall(t,e,n,i,s){const a=new dt;a.position.set(t,e+i,n);const r=new Tt(i,8,8),c=new Y({color:s,flatShading:!0}),l=new _(r,c);l.castShadow=!0,a.add(l);const h=new nt(i+.005,i+.005,i*.4,8,1,!0),d=s===16777215?13959168:16777215,u=new Y({color:d,flatShading:!0}),f=new _(h,u);f.rotation.z=Math.PI/4,a.add(f),this.scene.add(a)}createStarfish(t,e,n,i){const s=new oe(.18,.05,5),a=new Y({color:i,flatShading:!0}),r=new _(s,a);r.position.set(t,e,n),r.rotation.x=Math.PI/2,r.rotation.z=Math.random()*Math.PI,r.castShadow=!0,this.scene.add(r)}createShell(t,e,n,i){const s=new aa(.12,1);s.scale(1.2,.8,.8);const a=new Y({color:i,flatShading:!0}),r=new _(s,a);r.position.set(t,e,n),r.rotation.set(Math.random()*.4,Math.random()*Math.PI,Math.random()*.4),r.castShadow=!0,this.scene.add(r)}createSnowHeap(t,e,n,i){const s=new Tt(i,5,4);s.scale(1.2,.5,1.2);const a=new _(s,this.materials.umbrellaWhite);a.position.set(t,e+i*.25,n),a.castShadow=!0,this.scene.add(a)}createExtraUmbrella(t,e,n,i){const s=new dt;s.position.set(t,e,n);const a=new _(new nt(.03,.03,1.8,5),this.materials.wood);a.position.y=.9,a.castShadow=!0,s.add(a);const r=new Y({color:i,flatShading:!0}),c=new Y({color:16777215,flatShading:!0}),l=new _(new oe(.9,.4,8),r);l.position.y=1.7,l.castShadow=!0,s.add(l);const h=new _(new oe(.92,.38,8),c);h.position.y=1.7,h.rotation.y=Math.PI/8,s.add(h),this.scene.add(s)}createSwing(t,e,n){const i=new dt;i.position.set(t,e,n);const s=new nt(.05,.05,2.1,6);s.translate(0,-1.05,0);const a=new _(s,this.materials.wood);a.position.set(-1,2.05,0),a.rotation.set(-.19,0,-.15),a.castShadow=!0,i.add(a);const r=new _(s,this.materials.wood);r.position.set(-1,2.05,0),r.rotation.set(.19,0,-.15),r.castShadow=!0,i.add(r);const c=new _(s,this.materials.wood);c.position.set(1,2.05,0),c.rotation.set(-.19,0,.15),c.castShadow=!0,i.add(c);const l=new _(s,this.materials.wood);l.position.set(1,2.05,0),l.rotation.set(.19,0,.15),l.castShadow=!0,i.add(l);const h=new _(new nt(.05,.05,2.25,6),this.materials.wood);h.rotation.z=Math.PI/2,h.position.set(0,2.05,0),h.castShadow=!0,i.add(h),this.swingSeat=new dt,this.swingSeat.position.set(0,2.05,0);const d=new _(new G(.6,.03,.22),this.materials.wood);d.position.set(0,-1.1,0),d.castShadow=!0,this.swingSeat.add(d);const u=new _(new nt(.01,.01,1.1),this.materials.stone);u.position.set(-.24,-.55,0),this.swingSeat.add(u);const f=new _(new nt(.01,.01,1.1),this.materials.stone);f.position.set(.24,-.55,0),this.swingSeat.add(f),i.add(this.swingSeat),this.scene.add(i),this.interactables.push({id:"swing",name:"秋千",x:t,y:e,z:n+.6,triggerRadius:1.8})}createBallVendor(t,e,n){const i=this.themeConfig.colors.sky===330776,s=new dt;s.position.set(t,e,n);const a=new _(new G(1.6,.8,.8),this.materials.wood);a.position.y=.4,a.castShadow=!0,a.receiveShadow=!0,s.add(a);const r=new _(new G(1.7,.08,.9),this.materials.sand);r.position.y=.84,r.castShadow=!0,s.add(r);const c=new nt(.03,.03,1.4,5),l=new _(c,this.materials.wood);l.position.set(-.7,1.4,-.3),l.castShadow=!0,s.add(l);const h=new _(c,this.materials.wood);h.position.set(.7,1.4,-.3),h.castShadow=!0,s.add(h);const d=new _(new G(1.8,.06,1.1),this.materials.umbrellaRed);d.position.set(0,2.15,.1),d.rotation.x=.28,d.castShadow=!0,s.add(d);const u=new _(new G(1.82,.05,.3),this.materials.umbrellaWhite);u.position.set(0,2.15,.1),u.rotation.x=.28,s.add(u);const f=new _(new G(.6,.25,.5),this.materials.coconut);f.position.set(-.35,.98,.05),f.castShadow=!0,s.add(f);const g=new Tt(.12,6,6),y=i?[16777215,16777215,16777215]:[16732754,4244735,16771899];for(let x=0;x<3;x++){const v=new _(g,new Y({color:y[x],flatShading:!0}));v.position.set(-.42+x*.12,1.08,.05+x%2*.05),s.add(v)}const m=new _(new G(.6,.25,.05),this.materials.umbrellaWhite);m.position.set(.35,1.2,.15),m.rotation.y=-.15,m.castShadow=!0,s.add(m);const p=new _(new G(.4,.08,.06),new Y({color:i?13959168:5025616}));p.position.set(.35,1.2,.16),p.rotation.y=-.15,s.add(p),this.scene.add(s),this.interactables.push({id:"ball_vendor",name:i?"领雪球":"领沙滩球",x:t,y:e,z:n+.8,triggerRadius:1.8})}createCozyHouse(t,e,n){const i=this.themeConfig.colors.sky===330776,s=new dt;s.position.set(t,e,n);const a=new G(4,.12,4),r=new _(a,this.materials.wood);r.position.y=.06,r.receiveShadow=!0,r.castShadow=!0,s.add(r),this.colliders.push({mesh:r,radius:2.2,worldX:t,worldZ:n,worldY:e+.12,type:"floor"});const c=new G(.2,3.2,.2);[{x:-1.9,z:-1.9},{x:1.9,z:-1.9},{x:-1.9,z:1.9},{x:1.9,z:1.9}].forEach(P=>{const F=new _(c,this.materials.wood);F.position.set(P.x,1.6,P.z),F.castShadow=!0,s.add(F)});const h=new Y({color:i?6323595:14742257,flatShading:!0}),d=new _(new G(3.8,3.2,.08),h);d.position.set(0,1.6,-1.9),d.castShadow=!0,s.add(d);const u=new _(new G(.08,3.2,3.8),h);u.position.set(-1.9,1.6,0),u.castShadow=!0,s.add(u);const f=new _(new G(.08,3.2,3.8),h);f.position.set(1.9,1.6,0),f.castShadow=!0,s.add(f);const g=new _(new G(1.3,3.2,.08),h);g.position.set(-1.25,1.6,1.9),g.castShadow=!0,s.add(g);const y=new _(new G(1.3,3.2,.08),h);y.position.set(1.25,1.6,1.9),y.castShadow=!0,s.add(y);const m=new _(new G(1.2,1,.08),h);m.position.set(0,2.7,1.9),m.castShadow=!0,s.add(m);const p=new Gc;p.moveTo(-1.9,3.2),p.lineTo(1.9,3.2),p.lineTo(0,4.15),p.closePath();const x=new oa(p,{depth:.08,bevelEnabled:!1}),v=new _(x,h);v.position.set(0,0,1.9-.08),v.castShadow=!0,s.add(v);const M=new _(x,h);M.position.set(0,0,-1.9),M.castShadow=!0,s.add(M);const R=i?13959168:16740419,T=new Y({color:R,flatShading:!0}),E=new _(new G(2.5,.08,4),T);E.position.set(-1.05,3.68,0),E.rotation.z=.48,E.castShadow=!0,s.add(E);const U=new _(new G(2.5,.08,4),T);U.position.set(1.05,3.68,0),U.rotation.z=-.48,U.castShadow=!0,s.add(U);const w=new _(new G(.7,.22,.03),this.materials.wood);w.position.set(0,2.4,1.92),s.add(w);const S=new _(new G(.4,.08,.04),new Y({color:5025616}));S.position.set(0,2.4,1.94),s.add(S),this.interactables.push({id:"enter_house",name:"进入房子",x:t,y:e+.12,z:n+1.9,triggerRadius:1.5}),this.scene.add(s)}createSummerDecorations(){const t=this.themeConfig.colors.sky===330776;if(this.swimRings=[],t){const a=new G(.8,.38,.8),r=new Y({color:16119285,flatShading:!0}),c=new _(a,r);c.position.set(13,.18,13),c.castShadow=!0,this.scene.add(c),this.swimRings.push({mesh:c,baseX:13,baseZ:13,phase:0});const l=new _(a,r);l.position.set(-13,.18,12),l.castShadow=!0,this.scene.add(l),this.swimRings.push({mesh:l,baseX:-13,baseZ:12,phase:Math.PI})}else{const a=new xn(.3,.08,6,12);a.rotateX(Math.PI/2);const r=new Y({color:16728193,flatShading:!0}),c=new Y({color:16771899,flatShading:!0}),l=new _(a,r);l.position.set(-2.2,.62,-2.5),l.rotation.set(.1,0,.15),l.castShadow=!0,this.scene.add(l);const h=new _(a,c);h.position.set(13,.18,13),this.scene.add(h),this.swimRings.push({mesh:h,baseX:13,baseZ:13,phase:0});const d=new _(a,r);d.position.set(-13,.18,12),this.scene.add(d),this.swimRings.push({mesh:d,baseX:-13,baseZ:12,phase:Math.PI})}const e=new dt;e.position.set(2.4,0,-2.4);const n=t?[16732754,5025616,16771899]:[16732754,4244735,16771899],i=new Tt(.18,6,6);i.scale(1,1.25,1);const s=new nt(.005,.005,.8,4);for(let a=0;a<3;a++){const r=new Y({color:n[a],flatShading:!0}),c=new _(i,r),l=a/3*Math.PI*2,h=Math.cos(l)*.22,d=Math.sin(l)*.22,u=1.3+Math.random()*.25;c.position.set(h,u,d),c.rotation.z=(Math.random()-.5)*.2,c.castShadow=!0,e.add(c);const f=new _(s,this.materials.stone);f.position.set(h/2,u-.4,d/2),f.lookAt(new L(h,u,d)),f.rotateX(Math.PI/2),e.add(f)}this.scene.add(e),this.balloons=e}update(t,e){if(this.swingSeat&&(this.swingSeat.rotation.x=Math.sin(t*.002)*.18),this.swimRings&&this.swimRings.forEach(n=>{n.mesh.position.y=.18+Math.sin(t*.0016+n.phase)*.04,n.mesh.rotation.y=t*3e-4+n.phase}),this.balloons&&(this.balloons.rotation.z=Math.sin(t*.0015)*.06,this.balloons.rotation.x=Math.cos(t*.001)*.04),this.streetlights){const n=e&&e.isNight?1.4:0;this.streetlights.forEach(i=>{let s=n;i.color.getHex()===16733986&&e&&e.isNight&&(s=1.4+Math.sin(t*.02)*.25+(Math.random()-.5)*.12),i.intensity+=(s-i.intensity)*.08})}this.paimon&&(this.paimon.position.y=1.25+Math.sin(t*.0025)*.08,this.paimon.rotation.y=t*6e-4)}createStreetlamps(){this.streetlights=[],this.createStreetlamp(-8,-4,16711807),this.createStreetlamp(-4,-11,62975),this.createStreetlamp(2,4,3800852),this.createFairyLightsDecoration()}createStreetlamp(t,e,n=16771899){const i=new dt;i.position.set(t,.6,e);const s=new nt(.06,.08,2.2,4),a=new _(s,this.materials.wood);a.position.y=1.1,a.castShadow=!0,i.add(a);const r=new Lt({color:n}),c=new _(new G(.4,.06,.06),r);c.position.set(.18,2.1,0),i.add(c);const l=new _(new nt(.1,.16,.28,5),this.materials.arcadeBody);l.position.set(.36,1.9,0),l.castShadow=!0,i.add(l);const h=new Lt({color:n}),d=new _(new Tt(.08,5,5),h);d.position.set(.36,1.76,0),i.add(d),this.scene.add(i);const u=new ke(n,0,9,1.3);u.position.set(t+.36,2.3,e),this.scene.add(u),this.streetlights.push(u)}createFairyLightString(t,e,n=12,i=.4){const s=[16711765,62975,3800852,16771899,12386559,16748800],a=[],r=20;for(let f=0;f<=r;f++){const g=f/r,y=t.x+(e.x-t.x)*g,m=t.z+(e.z-t.z)*g,p=t.y+(e.y-t.y)*g-i*Math.sin(g*Math.PI);a.push(new L(y,p,m))}const c=new Nc(a),l=new ra(c,20,.012,4,!1),h=new Y({color:2236962}),d=new _(l,h);this.scene.add(d);const u=new Tt(.06,5,5);for(let f=0;f<n;f++){const g=(f+.5)/n,y=c.getPointAt(g),m=s[f%s.length],p=new Lt({color:m}),x=new _(u,p);if(x.position.copy(y),this.scene.add(x),f%3===1){const v=new ke(m,0,4,1.5);v.position.copy(y),v.userData={maxIntensity:.85},this.scene.add(v),this.streetlights.push(v)}}}createFairyLightsDecoration(){this.createFairyLightString(new L(-11.9,3.8,-7.1),new L(-8.1,3.8,-7.1),10,.35),this.createFairyLightString(new L(-8.1,3.65,-6.9),new L(-8,2.8,-4),12,.5),this.createFairyLightString(new L(3.5,2.65,6),new L(5.5,2.65,6),8,.25)}createPaimon(t,e){this.themeConfig.colors.sky;const n=new dt;n.position.set(t,1.25,e);const i=new Y({color:16769202,flatShading:!0}),s=new _(new Tt(.18,8,8),i);s.position.y=.18,s.castShadow=!0,n.add(s);const a=new Y({color:16776432,flatShading:!0}),r=new _(new Tt(.2,6,6),a);r.position.set(0,.22,-.02),n.add(r);const c=new oe(.06,.25,4);c.rotateX(Math.PI/6);const l=new _(c,a);l.position.set(-.16,.08,-.04),l.rotation.z=.3,l.castShadow=!0,n.add(l);const h=new _(c,a);h.position.set(.16,.08,-.04),h.rotation.z=-.3,h.castShadow=!0,n.add(h);const d=new Lt({color:1710618}),u=new _(new nt(.08,.1,.05,5),d);u.position.y=.36,n.add(u);const f=new Y({color:16777215,flatShading:!0}),g=new _(new oe(.12,.32,5),f);g.position.y=-.08,g.rotation.x=Math.PI,g.castShadow=!0,n.add(g);const y=new Lt({color:870305}),m=new _(new G(.14,.04,.04),y);m.position.set(0,.06,.1),n.add(m);const p=new Y({color:2503224,flatShading:!0}),x=new _(new G(.24,.35,.04),p);x.position.set(0,-.1,-.1),x.rotation.x=.1,n.add(x),this.scene.add(n),this.paimon=n,this.interactables.push({id:"paimon",name:"派蒙 (打开菜单)",x:t,y:.6,z:e,triggerRadius:2.2})}createLakePortal(t,e,n){const i=new dt;i.position.set(t,e,n);const s=new nt(.8,.9,.2,8),a=new Y({color:6111287,flatShading:!0}),r=new _(s,a);r.position.y=.1,r.castShadow=!0,r.receiveShadow=!0,i.add(r);const c=new Y({color:7901340,flatShading:!0}),l=new _(new G(.2,2,.2),c);l.position.set(-.6,1.1,0),l.castShadow=!0,l.receiveShadow=!0,i.add(l);const h=l.clone();h.position.x=.6,i.add(h);const d=new _(new G(1.4,.2,.2),c);d.position.set(0,2.1,0),d.castShadow=!0,i.add(d);const u=new Xe(1,1.8),f=new Lt({color:58879,transparent:!0,opacity:.5,side:ye}),g=new _(u,f);g.position.set(0,1.1,0),i.add(g);const y=new _(new G(.8,.25,.05),new Y({color:4073251}));y.position.set(0,2.3,0),y.castShadow=!0,i.add(y);const m=new _(new G(.6,.1,.06),new Lt({color:58879}));m.position.set(0,2.3,.01),i.add(m),this.scene.add(i),this.interactables.push({id:"enter_lake",name:"前往云顶天池",x:t,y:e,z:n,triggerRadius:1.8})}}class Zm{constructor(t,e){this.scene=t,this.themeConfig=e,this.colliders=[],this.interactables=[],this.group=new dt,this.materials={wood:new Y({color:7951688,flatShading:!0}),woodLight:new Y({color:14142664,flatShading:!0}),wall:new Y({color:16448250,flatShading:!0}),wallTrim:new Y({color:15723497,flatShading:!0}),glass:new Lt({color:14743546,transparent:!0,opacity:.25,side:ye}),leaves:new Y({color:4431943,flatShading:!0}),coconut:new Y({color:4073251,flatShading:!0}),carpet:new Y({color:16772275,flatShading:!0}),sofaBody:new Y({color:12310267,flatShading:!0}),sofaCushion:new Y({color:14938877,flatShading:!0}),metalGold:new Y({color:16763432,flatShading:!0}),white:new Y({color:16777215,flatShading:!0}),paintingSun:new Lt({color:16771899}),paintingArt:new Lt({color:16740419}),bedSpread:new Y({color:16747136,flatShading:!0})},this.buildHouseMap(),this.scene.add(this.group)}buildHouseMap(){const t=new G(24,.12,24),e=new _(t,this.materials.woodLight);e.position.y=.06,e.receiveShadow=!0,e.castShadow=!0,this.group.add(e),this.colliders.push({mesh:e,radius:16,worldX:0,worldZ:0,worldY:.12,type:"floor"});const n=new G(.4,5.5,.4);[{x:-11.8,z:-11.8},{x:11.8,z:-11.8},{x:-11.8,z:11.8},{x:11.8,z:11.8}].forEach(M=>{const R=new _(n,this.materials.wood);R.position.set(M.x,2.75,M.z),R.castShadow=!0,this.group.add(R)});for(let M=-10;M<=10;M+=5){const R=new G(23.6,.15,.25),T=new _(R,this.materials.wood);T.position.set(0,5.4,M),this.group.add(T)}const s=new _(new G(23.6,5.5,.1),this.materials.wall);s.position.set(0,2.75,-11.8),s.castShadow=!0,s.receiveShadow=!0,this.group.add(s);const a=new _(new G(.1,5.5,23.6),this.materials.wall);a.position.set(11.8,2.75,0),a.castShadow=!0,a.receiveShadow=!0,this.group.add(a);const r=new _(new G(.1,5.5,5.8),this.materials.wall);r.position.set(-11.8,2.75,-8.9),r.castShadow=!0,this.group.add(r);const c=new _(new G(.1,5.5,5.8),this.materials.wall);c.position.set(-11.8,2.75,8.9),c.castShadow=!0,this.group.add(c);const l=new _(new G(.1,1.6,12),this.materials.wall);l.position.set(-11.8,.8,0),l.castShadow=!0,this.group.add(l);const h=new _(new G(.1,1.4,12),this.materials.wall);h.position.set(-11.8,4.8,0),h.castShadow=!0,this.group.add(h);const d=new _(new G(.04,2.4,12),this.materials.glass);d.position.set(-11.8,2.8,0),this.group.add(d);const u=new _(new G(10.6,5.5,.1),this.materials.wall);u.position.set(-6.5,2.75,11.8),u.castShadow=!0,this.group.add(u);const f=new _(new G(10.6,5.5,.1),this.materials.wall);f.position.set(6.5,2.75,11.8),f.castShadow=!0,this.group.add(f);const g=new _(new G(2.4,2.5,.1),this.materials.wall);g.position.set(0,4.25,11.8),g.castShadow=!0,this.group.add(g);const y=new _(new G(2.5,3.1,.2),this.materials.wood);y.position.set(0,1.5,11.8),this.group.add(y);const m=new _(new G(1.3,.35,.05),this.materials.wood);m.position.set(0,3.25,11.68),m.castShadow=!0,this.group.add(m);const p=new _(new G(.8,.12,.06),new Y({color:16732754}));p.position.set(0,3.25,11.7),this.group.add(p),this.interactables.push({id:"exit_house",name:"离开房子",x:0,y:.12,z:11.2,triggerRadius:1.6}),this.createBed(-8,-7),this.createEasel(8,-8),this.createWardrobe(11,0),this.createSofaLounge(0,-2),this.createDiningTable(-10.5,0),this.createMonstera(-9.5,9.5);const x=new nt(4,4,.01,24),v=new _(x,this.materials.carpet);v.position.set(0,.125,3),v.receiveShadow=!0,this.group.add(v),this.createSunsetPainting(0,-11.73),this.createReservedSpot(8.5,8.5),this.createCeilingLight(),this.createWindowScenery(),this.createFloorLamp(1.8,-3.2)}createBed(t,e){const n=new dt;n.position.set(t,.12,e);const i=new _(new G(2.6,.32,3),this.materials.wood);i.castShadow=!0,n.add(i);const s=new _(new G(2.4,.28,2.8),this.materials.white);s.position.y=.24,n.add(s);const a=new _(new G(2.42,.29,2),this.materials.bedSpread);a.position.set(0,.26,.4),a.castShadow=!0,n.add(a);const r=new _(new G(.9,.16,.5),this.materials.white);r.position.set(-.55,.4,-1),n.add(r);const c=new _(new G(.9,.16,.5),this.materials.white);c.position.set(.55,.4,-1),n.add(c);const l=new _(new G(.7,.5,.7),this.materials.wood);l.position.set(-1.8,.1,-1),l.castShadow=!0,n.add(l);const h=new _(new G(.7,.5,.7),this.materials.wood);h.position.set(1.8,.1,-1),h.castShadow=!0,n.add(h);const d=new _(new nt(.08,.08,.18,4),this.materials.metalGold);d.position.set(-1.8,.44,-1),n.add(d);const u=new _(new nt(.12,.18,.2,8),this.materials.white);u.position.set(-1.8,.62,-1),n.add(u);const f=new ke(16758605,.9,8,1.5);f.position.set(-1.8,.65,-1),n.add(f),this.group.add(n),this.interactables.push({id:"house_bed",name:"躺下",x:t,y:.12,z:e,triggerRadius:2})}createEasel(t,e){const n=new dt;n.position.set(t,.12,e),n.rotation.y=-Math.PI/4;const i=new _(new nt(.035,.035,2.4,4),this.materials.wood);i.position.set(-.5,1.15,0),i.rotation.z=-.15,i.castShadow=!0,n.add(i);const s=new _(new nt(.035,.035,2.4,4),this.materials.wood);s.position.set(.5,1.15,0),s.rotation.z=.15,s.castShadow=!0,n.add(s);const a=new _(new nt(.035,.035,2.4,4),this.materials.wood);a.position.set(0,1.15,-.5),a.rotation.x=.22,a.castShadow=!0,n.add(a);const r=new _(new G(1.4,.07,.14),this.materials.wood);r.position.set(0,1.05,.08),r.castShadow=!0,n.add(r);const c=new _(new G(1.2,.9,.04),this.materials.white);c.position.set(0,1.5,.08),c.rotation.x=-.08,c.castShadow=!0,n.add(c);const l=new _(new Xe(1.14,.84),new Lt({color:11725810}));l.position.set(0,1.5,.11),l.rotation.x=-.08,n.add(l);const h=new _(new Tt(.11,6,6),this.materials.paintingSun);h.position.set(.2,1.62,.12),n.add(h);const d=new _(new Xe(1.14,.35),new Lt({color:48340}));d.position.set(0,1.28,.12),d.rotation.x=-.08,n.add(d),this.group.add(n),this.interactables.push({id:"house_easel",name:"写生",x:t,y:.12,z:e,triggerRadius:1.8})}createWardrobe(t,e){const n=new dt;n.position.set(t,.12,e);const i=new _(new G(.9,2.8,1.8),this.materials.wood);i.position.y=1.4,i.castShadow=!0,i.receiveShadow=!0,n.add(i);const s=new _(new G(.06,2.5,.82),this.materials.woodLight);s.position.set(-.46,1.4,-.42),n.add(s);const a=new _(new G(.06,2.5,.82),this.materials.woodLight);a.position.set(-.46,1.4,.42),n.add(a);const r=new _(new Tt(.06,4,4),this.materials.metalGold);r.position.set(-.52,1.4,-.08),n.add(r);const c=new _(new Tt(.06,4,4),this.materials.metalGold);c.position.set(-.52,1.4,.08),n.add(c);const l=new G(2,.01,1.8),h=new _(l,this.materials.carpet);h.position.set(-1.4,.005,0),h.receiveShadow=!0,n.add(h);const d=new dt;d.position.set(-2.4,0,1);const u=new _(new nt(.25,.25,.05,6),this.materials.metalGold);u.position.y=.025,u.castShadow=!0,d.add(u);const f=new _(new nt(.035,.035,2,4),this.materials.wood);f.position.y=1,f.castShadow=!0,d.add(f);const g=new _(new nt(.18,.3,.35,8),this.materials.white);g.position.y=2,g.castShadow=!0,d.add(g);const y=new _(new Tt(.07,6,6),new Lt({color:16774557}));y.position.y=1.9,d.add(y);const m=new ke(16772290,2.2,10,1.2);m.position.set(0,1.9,0),m.castShadow=!1,d.add(m),n.add(d),this.group.add(n),this.interactables.push({id:"house_wardrobe",name:"衣柜换装",x:t-1.4,y:.12,z:e,triggerRadius:2})}createSofaLounge(t,e){const n=new dt;n.position.set(t,.12,e);const i=new G(4.2,.01,2.8),s=new _(i,this.materials.carpet);s.position.y=.005,n.add(s);const a=new _(new G(3,.28,1.2),this.materials.sofaBody);a.position.y=.24,a.castShadow=!0,n.add(a);const r=new _(new G(3,.8,.25),this.materials.sofaBody);r.position.set(0,.72,-.475),r.castShadow=!0,n.add(r);const c=new _(new G(.25,.55,1.2),this.materials.sofaBody);c.position.set(-1.375,.42,0),c.castShadow=!0,n.add(c);const l=new _(new G(.25,.55,1.2),this.materials.sofaBody);l.position.set(1.375,.42,0),l.castShadow=!0,n.add(l);for(let p=0;p<3;p++){const x=new _(new G(.82,.15,.85),this.materials.sofaCushion);x.position.set(-.82+p*.82,.38,.05),x.castShadow=!0,n.add(x)}const h=new dt;h.position.set(0,0,.9);const d=new _(new G(1.6,.06,.8),this.materials.wood);d.position.y=.35,d.castShadow=!0,h.add(d);const u=new nt(.04,.04,.35,4),f=new _(u,this.materials.wood);f.position.set(-.7,.175,0),f.castShadow=!0,h.add(f);const g=new _(u,this.materials.wood);g.position.set(.7,.175,0),g.castShadow=!0,h.add(g);const y=new _(new nt(.08,.06,.12,5),this.materials.coconut);y.position.set(0,.44,0),y.castShadow=!0,h.add(y);const m=new _(new Tt(.1,5,5),this.materials.leaves);m.position.set(0,.52,0),h.add(m),n.add(h),this.group.add(n)}createDiningTable(t,e){const n=new dt;n.position.set(t,.12,e);const i=new _(new G(.9,.08,2.5),this.materials.wood);i.position.y=1,i.castShadow=!0,n.add(i);const s=new nt(.035,.035,1,4);[{x:-.38,z:-1.1},{x:.38,z:-1.1},{x:-.38,z:1.1},{x:.38,z:1.1}].forEach(m=>{const p=new _(s,this.materials.wood);p.position.set(m.x,.5,m.z),p.castShadow=!0,n.add(p)});const r=new G(.42,.06,.42),c=new nt(.02,.02,.5,4);for(let m=-1;m<=1;m+=2){const p=new dt;p.position.set(.68*m,0,0);const x=new _(r,this.materials.wood);x.position.y=.53,x.castShadow=!0,p.add(x);for(let M=-1;M<=1;M+=2)for(let R=-1;R<=1;R+=2){const T=new _(c,this.materials.wood);T.position.set(.16*M,.25,.16*R),T.castShadow=!0,p.add(T)}const v=new _(new G(.06,.5,.42),this.materials.wood);v.position.set(.18*m,.78,0),v.castShadow=!0,p.add(v),n.add(p)}const l=[13959168,2001125,16757504];for(let m=0;m<3;m++){const p=new _(new G(.38,.06,.3),new Y({color:l[m],flatShading:!0}));p.position.set(-.06,1.07+m*.062,.3),p.rotation.y=.12*m-.08,p.castShadow=!0,n.add(p)}const h=new _(new nt(.12,.09,.22,5),this.materials.white);h.position.set(0,1.15,-.5),h.castShadow=!0,n.add(h);const d=new _(new Tt(.16,6,6),this.materials.leaves);d.position.set(0,1.3,-.5),n.add(d);const u=new _(new nt(.08,.08,.04,4),this.materials.metalGold);u.position.set(.2,1.06,.8),n.add(u);const f=new _(new nt(.015,.015,.35,4),this.materials.metalGold);f.position.set(.2,1.22,.8),f.rotation.z=-.2,n.add(f);const g=new _(new nt(.08,.14,.16,6),this.materials.white);g.position.set(.13,1.38,.8),n.add(g);const y=new ke(16777184,.8,6,1.2);y.position.set(.13,1.34,.8),n.add(y),this.group.add(n)}createMonstera(t,e){const n=new dt;n.position.set(t,.12,e);const i=new _(new nt(.35,.28,.6,6),this.materials.carpet);i.position.y=.3,i.castShadow=!0,n.add(i);const s=new nt(.03,.03,.9,4);for(let a=0;a<5;a++){const r=new _(s,this.materials.wood),c=a/5*Math.PI*2;r.position.set(Math.cos(c)*.14,.6,Math.sin(c)*.14),r.rotation.z=Math.cos(c)*.45,r.rotation.x=Math.sin(c)*.45,n.add(r);const l=new _(new Tt(.35,5,5),this.materials.leaves);l.scale.set(1.3,.2,1.8),l.position.set(Math.cos(c)*.52,.96,Math.sin(c)*.52),l.rotation.y=c,l.rotation.x=.45,l.castShadow=!0,n.add(l)}this.group.add(n)}createSunsetPainting(t,e){const n=new _(new G(4.2,2,.05),this.materials.wood);n.position.set(t,3,e),n.castShadow=!0,this.group.add(n);const i=new _(new G(3.8,1.6,.02),this.materials.paintingArt);i.position.set(t,3,e+.035),this.group.add(i);const s=new _(new Tt(.24,6,6),this.materials.paintingSun);s.position.set(t+.8,3.2,e+.05),this.group.add(s)}createReservedSpot(t,e){const n=new dt;n.position.set(t,.12,e);const i=new _(new G(3,.02,3),new Y({color:9479342,flatShading:!0,transparent:!0,opacity:.5}));i.position.y=.01,n.add(i);const s=new _(new nt(.02,.02,.45,4),this.materials.wood);s.position.set(0,.22,0),s.castShadow=!0,n.add(s);const a=new _(new G(.6,.25,.03),this.materials.wood);a.position.set(0,.44,0),a.castShadow=!0,n.add(a),this.group.add(n)}createCeilingLight(){const t=new dt;t.position.set(0,5.4,0);const e=new _(new nt(.2,.2,.06,6),this.materials.wood);t.add(e);const n=new _(new nt(.015,.015,1.2,4),new Y({color:1118481}));n.position.y=-.6,t.add(n);const i=new _(new nt(.08,.35,.28,8),this.materials.metalGold);i.position.y=-1.34,i.castShadow=!0,t.add(i);const s=new _(new Tt(.12,6,6),new Lt({color:16775620}));s.position.y=-1.48,t.add(s),this.group.add(t);const a=new ke(16772290,1.7,28,1.2);a.position.set(0,3.82,0),a.castShadow=!1,this.group.add(a)}createWindowScenery(){const t=new dt;t.position.set(-17.5,-1.2,0);const e=new nt(3.5,2.5,1.5,8),n=new _(e,this.materials.wood);n.receiveShadow=!0,t.add(n);const i=new _(new nt(3.5,3.4,.2,8),this.materials.woodLight);i.position.y=.85,i.receiveShadow=!0,t.add(i);const s=new dt;s.position.set(0,.95,-.6),s.scale.set(.65,.65,.65);const a=new _(new nt(.18,.25,2.5,5),this.materials.wood);a.position.y=1.25,a.rotation.z=-.12,s.add(a);const r=new dt;r.position.set(-.15,2.5,0);const c=new G(1.4,.02,.35);c.translate(.7,0,0);for(let m=0;m<6;m++){const p=new _(c,this.materials.leaves);p.rotation.y=m/6*Math.PI*2,p.rotation.z=-.2,r.add(p)}s.add(r),t.add(s);const l=new _(new Tt(1.2,10,10),new Lt({color:16769154}));l.position.set(-4.5,7.8,-4.5),t.add(l);const h=new dt;h.position.set(1.5,4,3);const d=new Y({color:16448250,flatShading:!0});for(let m=0;m<3;m++){const p=new _(new Tt(.35+m*.1,5,5),d);p.position.set(m*.4-.4,0,m%2*.1),h.add(p)}t.add(h);const u=new ke(8445674,1.5,12,1.2);u.position.set(-1,3.2,-1),t.add(u);const f=new Tt(.06,4,4),g=new Lt({color:16772275});[{x:-3.5,y:5.5,z:-2},{x:-2,y:6.5,z:2},{x:1.5,y:5.2,z:-3},{x:2.5,y:7,z:1},{x:-1.2,y:4.5,z:3.5},{x:-5,y:6,z:0}].forEach(m=>{const p=new _(f,g);p.position.set(m.x,m.y,m.z),t.add(p)}),this.group.add(t)}createFloorLamp(t,e){const n=new dt;n.position.set(t,.12,e);const i=new _(new nt(.3,.3,.05,6),this.materials.metalGold);i.castShadow=!0,n.add(i);const s=new _(new nt(.04,.04,2.2,4),this.materials.wood);s.position.y=1.1,s.castShadow=!0,n.add(s);const a=new _(new nt(.2,.35,.4,8),this.materials.white);a.position.y=2.2,a.castShadow=!0,n.add(a);const r=new _(new Tt(.08,6,6),new Lt({color:16771899}));r.position.y=2.1,n.add(r);const c=new ke(16765312,1.2,12,1.2);c.position.set(0,2,0),c.castShadow=!1,n.add(c),this.group.add(n)}}class Ri{constructor(t,e,n,i){this.scene=t,this.camera=e,this.colliders=n,this.themeConfig=i,this.position=new L(0,4,0),this.velocity=new L,this.speed=8,this.jumpForce=7,this.gravity=18,this.isGrounded=!1,this.radius=.6,this.controlsLocked=!1,this.targetRotation=0,this.keys={w:!1,a:!1,s:!1,d:!1,space:!1,shift:!1},this.cameraAngleH=Math.PI/2,this.cameraAngleV=.35,this.cameraDistance=8.5,this.isSitting=!1,this.swingRef=null,this.isLyingDown=!1,this.initMesh(),this.initControls()}initMesh(){this.group=new dt,this.group.position.copy(this.position),this.activeModel="girl";const t=this.themeConfig.player.hairColor||16747136,e=this.themeConfig.player.clothingColor||16777215,n=this.themeConfig.player.hatColor||16765312;this.rebuildMesh(t,e,n)}rebuildMesh(t,e,n){for(;this.group.children.length>0;){const T=this.group.children[0];this.group.remove(T),T.geometry&&T.geometry.dispose(),T.material&&(Array.isArray(T.material)?T.material.forEach(E=>E.dispose()):T.material.dispose())}this.tailL=null,this.tailR=null,this.catTail=null;const i=this.themeConfig.colors.sky===330776,s=new Y({color:16769213,flatShading:!0}),a=new Y({color:16777215,flatShading:!0}),r=new Y({color:t,flatShading:!0});this.hairMat=r;const c=new nt(.2,.24,.35,8),l=new Y({color:e,flatShading:!0});this.clothingMat=l,this.body=new _(c,l),this.body.position.y=.55,this.body.castShadow=!0,this.group.add(this.body);const h=i?2503224:4149685,d=new nt(.24,.3,.3,8),u=new Y({color:h,flatShading:!0}),f=new _(d,u);f.position.y=.25,f.castShadow=!0,this.group.add(f);const g=new Tt(.34,8,8);this.head=new _(g,s),this.head.position.y=.94,this.head.castShadow=!0,this.group.add(this.head);const y=new nt(.08,.08,.15,6),m=new _(y,s);m.position.y=.75,this.group.add(m);const p=i?6111287:this.activeModel==="boy"?16732754:16777215,x=new Y({color:p,flatShading:!0}),v=new Tt(.09,6,6);if(v.scale(1,i?1:.7,1.3),this.footL=new _(v,x),this.footL.position.set(-.16,.04,0),this.footR=new _(v,x),this.footR.position.set(.16,.04,0),!i&&this.activeModel==="girl"){const T=new G(.12,.04,.08),E=new _(T,x);E.position.set(-.16,.06,.08);const U=new _(T,x);U.position.set(.16,.06,.08),this.group.add(E),this.group.add(U)}this.group.add(this.footL),this.group.add(this.footR),this.activeModel==="girl"?this.buildGirlModel(r,a,n,i):this.activeModel==="boy"?this.buildBoyModel(r,a,n,i):this.activeModel==="kitty"&&this.buildKittyModel(r,a,n,i);const M=i?13959168:16777215,R=new Y({color:M,transparent:!i,opacity:i?1:.8,side:ye,flatShading:!0});if(i){const T=new Xe(.55,.7,2,4);this.cape=new _(T,R),this.cape.position.set(.05,.62,-.22),this.cape.rotation.x=.12,this.cape.rotation.y=.05,this.cape.castShadow=!0,this.group.add(this.cape)}else{const T=new Xe(.65,.75,3,5);this.cape=new _(T,R),this.cape.position.set(0,.48,-.32),this.cape.rotation.x=.15,this.cape.castShadow=!0,this.group.add(this.cape)}this.scene.add(this.group)}buildGirlModel(t,e,n,i){const s=new Tt(.36,8,8),a=new _(s,t);a.position.set(0,.98,-.04),this.group.add(a);const r=new G(.18,.18,.12),c=new _(r,t);c.position.set(-.12,1.05,.26),c.rotation.z=-.2,c.rotation.y=.1,this.group.add(c);const l=new _(r,t);l.position.set(.12,1.05,.26),l.rotation.z=.2,l.rotation.y=-.1,this.group.add(l);const h=new oe(.1,.52,6);if(h.rotateX(Math.PI),this.tailL=new _(h,t),this.tailL.position.set(-.35,.94,-.05),this.tailL.rotation.z=-.25,this.group.add(this.tailL),this.tailR=new _(h,t),this.tailR.position.set(.35,.94,-.05),this.tailR.rotation.z=.25,this.group.add(this.tailR),i){const P=new _(new G(.07,.07,.04),e);P.position.set(.24,1.12,.24),P.rotation.z=Math.PI/4,this.group.add(P)}else{const P=new _(new G(.08,.08,.04),new Y({color:5025616}));P.position.set(.24,1.12,.24),P.rotation.z=-.4;const F=new _(new G(.06,.06,.04),new Y({color:16732754}));F.position.set(.24,1.14,.26),F.rotation.z=-.4,this.group.add(P),this.group.add(F)}if(i){const P=new dt;P.position.set(0,1.25,-.04);const F=new oe(.35,.6,8);F.translate(0,.3,0);const j=new Y({color:n,flatShading:!0});this.hatMat=j;const I=new _(F,j);I.rotation.z=-.15,I.rotation.x=-.1,I.castShadow=!0,P.add(I);const B=new nt(.36,.36,.12,8),O=new _(B,e);O.position.y=.05,P.add(O);const Z=new Tt(.08,6,6),X=new _(Z,e);X.position.set(.08,.62,-.04),P.add(X),this.group.add(P)}else{const P=new dt;P.position.set(0,1.28,-.04);const F=new nt(.72,.72,.04,10),j=new Y({color:n,flatShading:!0});this.hatMat=j;const I=new _(F,j);I.castShadow=!0,P.add(I);const B=new nt(.32,.38,.25,8),O=new _(B,j);O.position.y=.14,O.castShadow=!0,P.add(O);const Z=new nt(.39,.39,.06,8),X=new _(Z,e);X.position.y=.05,P.add(X),this.group.add(P)}const d=new dt;d.position.set(0,1.22,.3),d.rotation.x=-.15;const u=new Tt(.12,6,6);u.scale(1,1,.2);const f=new Lt({color:1710618}),g=new _(u,f);g.position.x=-.16;const y=new _(u,f);y.position.x=.16,d.add(g),d.add(y);const m=i?16777215:16744619,p=new Y({color:m,flatShading:!0});if(i){const P=new G(.48,.2,.06),F=new _(P,p);F.position.set(0,0,.02),d.add(F)}else{const P=new nt(.15,.15,.05,8);P.rotateX(Math.PI/2);const F=new _(P,p);F.position.set(-.16,0,.02);const j=new _(P,p);j.position.set(.16,0,.02),d.add(F),d.add(j)}this.group.add(d);const x=new dt;x.position.set(.1,i?1.55:1.48,-.06);const v=new Tt(.14,6,6);v.scale(1,.9,1.1);const M=i?11583173:16765312,R=new Y({color:M,flatShading:!0}),T=new _(v,R);x.add(T);const E=new Tt(.04,4,4),U=new _(E,R);U.position.set(-.06,.09,.05);const w=new _(E,R);w.position.set(.06,.09,.05),x.add(U),x.add(w);const S=new _(new Tt(.02,4,4),new Y({color:16747136}));if(S.position.set(.08,0,.11),x.add(S),i){const P=new nt(.11,.11,.04,6),F=new _(P,new Y({color:12986408}));F.position.y=-.06,x.add(F)}else{const P=new _(new Tt(.02,4,4),e);P.position.set(.06,.12,.08),x.add(P)}if(this.group.add(x),i){const P=new dt;P.position.set(0,.58,.3);const F=new _(new G(.25,.25,.25),new Y({color:3046706,flatShading:!0}));F.castShadow=!0,P.add(F);const j=new _(new G(.27,.05,.27),new Y({color:13959168,flatShading:!0}));P.add(j),this.group.add(P)}else{const P=new dt;P.position.set(0,.58,.35);const F=new G(.3,.16,.06),j=new _(F,new Y({color:16732754}));P.add(j);const I=new G(.32,.04,.08),B=new _(I,new Y({color:5025616}));B.position.y=-.09,P.add(B),this.group.add(P)}this.buildFaceDetails()}buildBoyModel(t,e,n,i){const s=new Tt(.35,8,8),a=new _(s,t);a.position.set(0,.98,-.04),this.group.add(a);const r=new oe(.08,.22,4);r.rotateX(Math.PI/1.8);for(let tt=0;tt<4;tt++){const ut=new _(r,t),Et=-.15+tt*.1;ut.position.set(Et,1.08,.26),ut.rotation.y=Et*.5,ut.castShadow=!0,this.group.add(ut)}const c=new oe(.07,.22,4);c.rotateX(-.3),[{x:-.14,y:1.25,z:-.08},{x:.14,y:1.25,z:-.08},{x:0,y:1.28,z:-.04},{x:-.08,y:1.24,z:-.2},{x:.08,y:1.24,z:-.2}].forEach(tt=>{const ut=new _(c,t);ut.position.set(tt.x,tt.y,tt.z),ut.castShadow=!0,this.group.add(ut)});const h=new dt;h.position.set(0,1.24,-.04);const d=new Y({color:n,flatShading:!0});this.hatMat=d;const u=new nt(.35,.36,.22,8),f=new _(u,d);f.castShadow=!0,h.add(f);const g=new G(.46,.02,.35),y=new _(g,d);y.position.set(0,-.06,.28),y.rotation.x=.14,y.castShadow=!0,h.add(y);const m=new Tt(.04,4,4),p=new _(m,e);p.position.y=.12,h.add(p),this.group.add(h);const x=new dt;x.position.set(0,1.22,.3);const v=new G(.14,.09,.02),M=new Lt({color:1118481}),R=new _(v,M);R.position.x=-.16;const T=new _(v,M);T.position.x=.16,x.add(R),x.add(T);const E=new Y({color:i?16777215:2201331,flatShading:!0}),U=new _(new G(.18,.02,.03),E);U.position.set(0,0,.01),x.add(U);const w=new _(new G(.02,.11,.04),E);w.position.set(-.24,0,.01);const S=new _(new G(.02,.11,.04),E);S.position.set(.24,0,.01),x.add(w),x.add(S),this.group.add(x);const P=new dt;P.position.set(-.35,.65,.05),P.scale.set(.8,.8,.8);const F=new Y({color:16732754,flatShading:!0}),j=new _(new G(.22,.12,.15),F);j.castShadow=!0,P.add(j);const I=new Tt(.03,4,4),B=new _(I,new Lt({color:16777215}));B.position.set(-.05,.08,.08);const O=new _(I,new Lt({color:16777215}));O.position.set(.05,.08,.08),P.add(B),P.add(O);const Z=new Tt(.06,5,5);Z.scale(1.2,.8,1);const X=new _(Z,F);X.position.set(-.14,.04,.08);const q=new _(Z,F);q.position.set(.14,.04,.08),P.add(X),P.add(q),this.group.add(P);const J=new dt;J.position.set(.25,.52,.28),J.rotation.set(-.15,-.4,.35);const et=new Y({color:58998,flatShading:!0}),rt=new _(new G(.15,.9,.04),et);rt.castShadow=!0,J.add(rt);const H=new _(new G(.16,.2,.05),new Y({color:16771899,flatShading:!0}));H.position.y=.05,J.add(H),this.group.add(J),this.buildFaceDetails()}buildKittyModel(t,e,n,i){const s=t,a=new Tt(.07,6,6);a.scale(1.3,.8,1);const r=new _(a,e);r.position.set(0,.86,.29),this.group.add(r);const c=new Tt(.035,4,4),l=new Y({color:16747136}),h=new _(c,l);h.position.set(0,.89,.35),this.group.add(h);const d=new G(.26,.015,.015),u=new Lt({color:1118481});for(let rt=0;rt<3;rt++){const H=new _(d,u);H.position.set(-.26,.86+(rt-1)*.04,.25),H.rotation.z=-(rt-1)*.12-.05,H.rotation.y=.2,this.group.add(H);const tt=new _(d,u);tt.position.set(.26,.86+(rt-1)*.04,.25),tt.rotation.z=(rt-1)*.12+.05,tt.rotation.y=-.2,this.group.add(tt)}const f=new oe(.12,.28,4);f.rotateX(.1);const g=new _(f,s);g.position.set(-.22,1.2,.06),g.rotation.z=.25,g.castShadow=!0,this.group.add(g);const y=new _(f,s);y.position.set(.22,1.2,.06),y.rotation.z=-.25,y.castShadow=!0,this.group.add(y);const m=new Y({color:16747136,flatShading:!0}),p=new oe(.08,.2,4);p.rotateX(.1);const x=new _(p,m);x.position.set(-.21,1.21,.09),x.rotation.z=.25,this.group.add(x);const v=new _(p,m);v.position.set(.21,1.21,.09),v.rotation.z=-.25,this.group.add(v);const M=i?3046706:13959168,R=new Y({color:M,flatShading:!0}),T=new nt(.21,.21,.06,8),E=new _(T,R);E.position.y=.73,this.group.add(E);const U=new Y({color:n,flatShading:!0});this.hatMat=U;const w=new Tt(.07,6,6),S=new _(w,U);S.position.set(0,.69,.28),this.group.add(S);const P=new xn(.03,.01,4,8),F=new _(P,U);F.position.set(0,.74,.25),this.group.add(F),this.catTail=new dt,this.catTail.position.set(0,.22,-.28);let j=this.catTail;const I=4,B=new nt(.04,.04,.18,5);B.translate(0,.09,0);for(let rt=0;rt<I;rt++){const H=new _(B,s);H.position.set(0,rt===0?0:.15,rt===0?0:-.05),H.rotation.x=-.3,H.castShadow=!0,j.add(H),j=H}this.group.add(this.catTail);const O=new dt;O.position.set(0,.56,.32),O.rotation.set(.1,-.4,.2);const Z=new Y({color:48340,flatShading:!0}),X=new _(new G(.18,.09,.05),Z);X.castShadow=!0,O.add(X);const q=new oe(.05,.08,3);q.rotateX(Math.PI/2);const J=new _(q,Z);J.position.set(-.11,0,0),O.add(J);const et=new _(new Tt(.012,4,4),new Lt({color:16777215}));et.position.set(.06,.02,.03),O.add(et),this.group.add(O),this.buildFaceDetails()}buildFaceDetails(){const t=new Tt(.06,5,5),e=new Lt({color:5125166}),n=new _(t,e);n.position.set(-.11,.94,.27);const i=new _(t,e);i.position.set(.11,.94,.27),this.group.add(n),this.group.add(i);const s=new Tt(.05,4,4),a=new Y({color:16747136,flatShading:!0}),r=new _(s,a);r.position.set(-.19,.87,.25);const c=new _(s,a);c.position.set(.19,.87,.25),this.group.add(r),this.group.add(c)}updateModel(t){if(this.activeModel===t)return;this.activeModel=t;const e=this.hairMat?this.hairMat.color.getHex():this.themeConfig.player.hairColor||16747136,n=this.clothingMat?this.clothingMat.color.getHex():this.themeConfig.player.clothingColor||16777215,i=this.hatMat?this.hatMat.color.getHex():this.themeConfig.player.hatColor||16765312;this.rebuildMesh(e,n,i)}initControls(){const t=(c,l)=>{if(this.isSitting||this.isLyingDown){l&&(c.key===" "||c.key==="Spacebar")&&this.standUp();return}if(this.controlsLocked)return;const h=c.key.toLowerCase();if((h==="w"||c.key==="ArrowUp")&&(this.keys.w=l),(h==="s"||c.key==="ArrowDown")&&(this.keys.s=l),(h==="a"||c.key==="ArrowLeft")&&(this.keys.a=l),(h==="d"||c.key==="ArrowRight")&&(this.keys.d=l),c.key===" "||c.key==="Spacebar"){const d=window.parent&&window.parent.isRadialMenuOpen;this.keys.space=d?!1:l}c.key==="Shift"&&(this.keys.shift=l)};window.addEventListener("keydown",c=>t(c,!0)),window.addEventListener("keyup",c=>t(c,!1));let e=!1,n={x:0,y:0};window.addEventListener("mousedown",c=>{e=!0,n={x:c.clientX,y:c.clientY}}),window.addEventListener("mousemove",c=>{if(!e)return;const l=c.clientX-n.x,h=c.clientY-n.y;this.cameraAngleH-=l*.005,this.cameraAngleV=Math.max(.1,Math.min(1.2,this.cameraAngleV+h*.005)),n={x:c.clientX,y:c.clientY}}),window.addEventListener("mouseup",()=>{e=!1});let i=null;document.addEventListener("touchstart",c=>{for(let l=0;l<c.changedTouches.length;l++){const h=c.changedTouches[l],d=h.target&&h.target.closest?h.target:null,u=d?d.closest("#mobile-controls")||d.closest(".hud-header")||d.closest(".modal-overlay")||d.closest(".modal-card")||d.closest(".sso-sidebar")||d.closest(".sidebar-overlay")||d.id==="audio-btn":!1,f=h.clientX<window.innerWidth*.45;if(!u&&!f&&i===null){e=!0,i=h.identifier,n={x:h.clientX,y:h.clientY};break}}}),document.addEventListener("touchmove",c=>{if(!e||i===null)return;let l=null;for(let u=0;u<c.touches.length;u++)if(c.touches[u].identifier===i){l=c.touches[u];break}if(!l)return;c.preventDefault();const h=l.clientX-n.x,d=l.clientY-n.y;this.cameraAngleH-=h*.005,this.cameraAngleV=Math.max(.1,Math.min(1.2,this.cameraAngleV+d*.005)),n={x:l.clientX,y:l.clientY}},{passive:!1});const s=c=>{if(i===null)return;let l=!1;for(let h=0;h<c.changedTouches.length;h++)if(c.changedTouches[h].identifier===i){l=!0;break}l&&(e=!1,i=null)};document.addEventListener("touchend",s),document.addEventListener("touchcancel",s),window.addEventListener("modal-opened",()=>{this.controlsLocked=!0,this.resetInputs()}),window.addEventListener("modal-closed",()=>{this.controlsLocked=!1});const a=document.getElementById("btn-jump");a&&(a.addEventListener("touchstart",c=>{if(c.preventDefault(),this.isSitting||this.isLyingDown){this.standUp();return}this.controlsLocked||(this.keys.space=!0)}),a.addEventListener("touchend",c=>{c.preventDefault(),this.keys.space=!1}));const r=document.getElementById("btn-run");r&&(r.addEventListener("touchstart",c=>{c.preventDefault(),this.controlsLocked||(this.keys.shift=!0)}),r.addEventListener("touchend",c=>{c.preventDefault(),this.keys.shift=!1}))}resetInputs(){this.keys={w:!1,a:!1,s:!1,d:!1,space:!1,shift:!1},this.velocity.set(0,this.velocity.y,0)}update(t,e){if(window.self!==window.top&&window.parent&&(window.parent.isRadialMenuOpen?(this.keys.space=!1,window.parent.keys&&(window.parent.keys.space=!1)):window.parent.keys&&(this.keys.space=this.keys.space||window.parent.keys.space),window.parent.keys&&(this.keys.shift=this.keys.shift||window.parent.keys.shift,this.keys.j=this.keys.j||window.parent.keys.j)),(this.isSitting||this.isLyingDown)&&this.keys.space&&(this.standUp(),window.parent&&window.parent.keys&&(window.parent.keys.space=!1),this.keys.space=!1),this.isLyingDown){this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.group.rotation.x=-Math.PI/2,this.group.rotation.y=0,this.group.rotation.z=0,this.body.rotation.x=0,this.footL.position.set(-.16,.05,0),this.footR.position.set(.16,.05,0),this.body.position.y=.38,this.head.position.y=.88,this.cape.rotation.x=.15;const M=this.cape.geometry.attributes.position;for(let w=0;w<M.count;w++)M.setZ(w,0);M.needsUpdate=!0;const R=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,T=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,E=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(R-this.camera.position.x)*.08,this.camera.position.y+=(T-this.camera.position.y)*.08,this.camera.position.z+=(E-this.camera.position.z)*.08;const U=this.position.clone().add(new L(0,.4,0));this.camera.lookAt(U);return}if(this.isSitting&&this.swingRef){if(this.swingRef.isStatic)this.position.copy(this.swingRef.position),this.position.y+=.22,this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.group.rotation.y=this.swingRef.rotationY;else{const w=this.swingRef.rotation.x,S=1.1;this.position.x=this.swingRef.parent.position.x+this.swingRef.position.x,this.position.y=this.swingRef.parent.position.y+this.swingRef.position.y-S*Math.cos(w)-.28,this.position.z=this.swingRef.parent.position.z+this.swingRef.position.z-S*Math.sin(w),this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.group.rotation.y=0}this.footL.position.set(-.16,.15,.18),this.footR.position.set(.16,.15,.18),this.body.position.y=.3,this.head.position.y=.8,this.cape.rotation.x=-.1+Math.sin(e*.002)*.05;const M=this.cape.geometry.attributes.position;for(let w=0;w<M.count;w++)M.setZ(w,0);M.needsUpdate=!0,this.tailL&&(this.tailL.rotation.z=-.2-Math.sin(e*.002)*.1),this.tailR&&(this.tailR.rotation.z=.2+Math.sin(e*.002)*.1),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.003)*.15);const R=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,T=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,E=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(R-this.camera.position.x)*.08,this.camera.position.y+=(T-this.camera.position.y)*.08,this.camera.position.z+=(E-this.camera.position.z)*.08;const U=this.position.clone().add(new L(0,.8,0));this.camera.lookAt(U);return}let n=0,i=0;if(!this.controlsLocked&&(this.keys.w&&(i-=1),this.keys.s&&(i+=1),this.keys.a&&(n-=1),this.keys.d&&(n+=1),window.self!==window.top&&window.parent&&window.parent.joystickDir)){const M=window.parent.joystickDir;(M.x!==0||M.y!==0)&&(n+=M.x,i+=M.y)}const a=new L(n,0,i).normalize().clone().applyAxisAngle(new L(0,1,0),this.cameraAngleH),r=this.keys.shift?this.speed*1.6:this.speed;if(this.velocity.x=a.x*r,this.velocity.z=a.z*r,this.isGrounded||(this.velocity.y-=this.gravity*t),this.position.addScaledVector(this.velocity,t),this.app&&this.app.currentMap==="house")this.position.x<-11.5&&(this.position.x=-11.5),this.position.x>11.5&&(this.position.x=11.5),this.position.z<-11.5&&(this.position.z=-11.5),this.position.z>11.5&&(this.position.z=11.5);else{const R=Math.sqrt(this.position.x*this.position.x+this.position.z*this.position.z);R>21.2&&(this.position.x=this.position.x/R*21.2,this.position.z=this.position.z/R*21.2)}let c=!1,l=-999;for(const M of this.colliders)if(M.type==="floor"){const R=this.position.x-M.worldX,T=this.position.z-M.worldZ;Math.sqrt(R*R+T*T)<M.radius+.1&&this.position.y>=M.worldY-.8&&this.position.y<=M.worldY+.1&&(l=Math.max(l,M.worldY),c=!0)}c?this.velocity.y<=0&&(this.position.y=l,this.velocity.y=0,this.isGrounded=!0):this.isGrounded=!1,this.position.y<-10&&(this.position.set(0,4,0),this.velocity.set(0,0,0),this.isGrounded=!1);const h=window.parent&&window.parent.isRadialMenuOpen;this.keys.space&&this.isGrounded&&!this.controlsLocked&&!h&&(this.velocity.y=this.jumpForce,this.isGrounded=!1,this.keys.space=!1,window.parent&&window.parent.keys&&(window.parent.keys.space=!1)),this.group.position.copy(this.position);const d=Math.sqrt(this.velocity.x*this.velocity.x+this.velocity.z*this.velocity.z);if(d>.1){this.targetRotation=Math.atan2(this.velocity.x,this.velocity.z);let M=this.targetRotation-this.group.rotation.y;M=Math.atan2(Math.sin(M),Math.cos(M)),this.group.rotation.y+=M*.15;const R=this.keys.shift?24:16;this.footL.position.z=Math.sin(e*.001*R)*.25,this.footL.position.y=.05+Math.max(0,Math.cos(e*.001*R))*.12,this.footR.position.z=-Math.sin(e*.001*R)*.25,this.footR.position.y=.05+Math.max(0,-Math.cos(e*.001*R))*.12,this.tailL&&(this.tailL.rotation.z=-.2-Math.abs(Math.sin(e*.001*R))*.18),this.tailR&&(this.tailR.rotation.z=.2+Math.abs(Math.sin(e*.001*R))*.18),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.001*R*1.5)*.35,this.catTail.rotation.z=Math.cos(e*.001*R*1.5)*.06),this.body.rotation.x=this.keys.shift?.22:.1,this.body.position.y=.38+Math.abs(Math.sin(e*.001*R))*.06,this.head.position.y=.88+Math.abs(Math.sin(e*.001*R))*.04}else this.body.rotation.x=0,this.footL.position.set(-.16,.05,0),this.footR.position.set(.16,.05,0),this.body.position.y=.38+Math.sin(e*.003)*.02,this.head.position.y=.88+Math.sin(e*.003)*.02,this.tailL&&(this.tailL.rotation.z=-.2+Math.sin(e*.003)*.04),this.tailR&&(this.tailR.rotation.z=.2-Math.sin(e*.003)*.04),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.003)*.15,this.catTail.rotation.z=Math.cos(e*.003)*.03);const u=this.cape.geometry.attributes.position,f=18,g=2.2,y=.08+d*.03;for(let M=0;M<u.count;M++){u.getX(M);const T=.4-u.getY(M),E=Math.sin(e*.001*f-T*g)*y*(T/.8);u.setZ(M,E)}u.needsUpdate=!0;const m=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,p=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,x=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(m-this.camera.position.x)*.08,this.camera.position.y+=(p-this.camera.position.y)*.08,this.camera.position.z+=(x-this.camera.position.z)*.08;const v=this.position.clone().add(new L(0,.8,0));this.camera.lookAt(v)}sit(t){this.isSitting=!0,this.swingRef=t,this.controlsLocked=!0}lieDown(t){this.isLyingDown=!0,this.controlsLocked=!0,this.position.copy(t),this.position.y=t.y+.58,window.parent&&window.parent.appShell&&typeof window.parent.appShell.hideMobileControls=="function"&&window.parent.appShell.hideMobileControls(),window.gameApp&&typeof window.gameApp.updateTaskProgress=="function"&&window.gameApp.updateTaskProgress("rest",1)}updateOutfit(t,e){const n=parseInt(e);t==="hair"&&this.hairMat?this.hairMat.color.setHex(n):t==="clothing"&&this.clothingMat?this.clothingMat.color.setHex(n):t==="hat"&&this.hatMat&&this.hatMat.color.setHex(n)}standUp(){if(this.isLyingDown){this.isLyingDown=!1,this.controlsLocked=!1,this.group.rotation.x=0,this.group.rotation.z=0,this.position.z+=1.4,this.position.y=.8;const n=document.getElementById("bed-hud");n&&(n.style.display="none"),window.parent&&window.parent.appShell&&typeof window.parent.appShell.showMobileControls=="function"&&window.parent.appShell.showMobileControls();return}const t=this.swingRef&&this.swingRef.isStatic;this.isSitting=!1,this.swingRef=null,this.controlsLocked=!1,t?(this.position.x>0?this.position.x+=.9:this.position.x-=.9,this.position.y=.6):(this.position.z+=1.2,this.position.y=.8);const e=document.getElementById("exit-sitting-hud");e&&(e.style.display="none")}}class Li{constructor(t,e,n,i){this.player=t,this.generator=e,this.modalManager=n,this.app=i,this.promptEl=document.getElementById("interact-prompt"),this.promptTextEl=this.promptEl?this.promptEl.querySelector(".prompt-text"):null,this.mobileInteractBtn=document.getElementById("btn-interact")||window.parent&&window.parent.document.getElementById("btn-interact"),this.activeInteractZone=null,this.isTransitioningCamera=!1,this.cameraSavedState=null,this.init()}init(){window.addEventListener("keydown",t=>{t.key.toLowerCase()==="e"&&this.triggerActiveInteraction()}),this.mobileInteractBtn&&(this.mobileInteractBtn.addEventListener("touchstart",t=>{t.preventDefault(),this.triggerActiveInteraction()},{passive:!1}),this.mobileInteractBtn.addEventListener("click",t=>{t.preventDefault(),this.triggerActiveInteraction()})),window.addEventListener("modal-closed",()=>{this.isTransitioningCamera&&this.cameraSavedState&&(this.isTransitioningCamera=!1,this.player.cameraDistance=this.cameraSavedState.distance,this.player.cameraAngleH=this.cameraSavedState.angleH,this.player.cameraAngleV=this.cameraSavedState.angleV,this.cameraSavedState.rotationY!==void 0&&(this.player.group.rotation.y=this.cameraSavedState.rotationY),this.cameraSavedState.controlsLocked!==void 0&&(this.player.controlsLocked=this.cameraSavedState.controlsLocked),this.activeInteractZone=null)})}update(){if(this.player.carriedBall){this.activeInteractZone={id:"drop_ball",name:"放下"},this.showPrompt("放下");return}if(this.player.controlsLocked)return;let t=null,e=999;const n=this.player.position;for(const i of this.generator.interactables){if(i.id.startsWith("farm_plot_")&&this.app&&this.app.gameData){const l=parseInt(i.id.replace("farm_plot_","")),h=this.app.gameData.farmPlots[l];if(h&&h.status!=="ready")continue}const s=n.x-i.x,a=n.y-i.y,r=n.z-i.z,c=Math.sqrt(s*s+a*a+r*r);if(c<i.triggerRadius&&c<e&&(e=c,t=i,i.id.startsWith("farm_plot_")&&this.app&&this.app.gameData)){const l=parseInt(i.id.replace("farm_plot_","")),h=this.app.gameData.farmPlots[l];if(h)if(h.status==="empty")i.name="种植农作物";else if(h.status==="ready")i.name="收割作物";else{const d=h.seedId==="sunflower_seed"?30:60,u=Math.floor((Date.now()-h.plantTime)/1e3),f=Math.max(0,d-u);i.name=`作物生长中 (${f}s)`}}}if(this.app&&this.app.beachBallsList)for(const i of this.app.beachBallsList){if(i.isCarried)continue;const s=n.x-i.position.x,a=n.y-i.position.y,r=n.z-i.position.z,c=Math.sqrt(s*s+a*a+r*r);c<1.6&&c<e&&(e=c,t={id:"pick_ball",name:"抱起",ball:i})}t?(this.activeInteractZone=t,this.showPrompt(t.name)):(this.activeInteractZone=null,this.hidePrompt())}showPrompt(t){if(this.promptEl&&this.promptEl.classList.add("visible"),this.mobileInteractBtn){this.mobileInteractBtn.style.display="flex";let e=!1;if(this.activeInteractZone&&this.activeInteractZone.id.startsWith("farm_plot_")&&this.app&&this.app.gameData){const s=parseInt(this.activeInteractZone.id.replace("farm_plot_","")),a=this.app.gameData.farmPlots[s];a&&a.status==="empty"&&(e=!0)}const n=`
<svg style="display: flex;" class="lucide lucide-sparkles" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275z"/>
  <path d="m5 3 1 2.5L8.5 6 6 7 5 9.5 4 7 1.5 6 4 5.5z"/>
  <path d="m19 17 1 2.5 2.5.5-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z"/>
</svg>`,i=`
<svg style="display: flex;" class="lucide lucide-sprout" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M7 20h10" />
  <path d="M10 20V12h4v8" />
  <path d="M12 12a5 5 0 0 0-5-5H4v2h3a3 3 0 0 1 3 3v0" />
  <path d="M12 8a5 5 0 0 1 5-5h3v2h-3a3 3 0 0 0-3 3v0" />
</svg>`;this.mobileInteractBtn.innerHTML=e?i:n}}hidePrompt(){this.promptEl&&this.promptEl.classList.remove("visible"),this.mobileInteractBtn&&(this.mobileInteractBtn.style.display="none")}pickUpBall(t){t.isCarried=!0,this.player.carriedBall=t,this.hidePrompt(),this.mobileInteractBtn&&(this.mobileInteractBtn.textContent="👐")}dropCarriedBall(){const t=this.player.carriedBall;if(!t)return;t.isCarried=!1,this.player.carriedBall=null,t.throwNoCollideTimer=.4;const e=new L(0,0,1).applyQuaternion(this.player.group.quaternion);t.velocity.copy(this.player.velocity),t.velocity.addScaledVector(e,5.5),t.velocity.y=2.8,t.isGrounded=!1,this.hidePrompt(),this.mobileInteractBtn&&(this.mobileInteractBtn.textContent="✨")}triggerActiveInteraction(){if(!this.activeInteractZone)return;const t=this.activeInteractZone;if(t.id==="drop_ball"){this.dropCarriedBall();return}if(t.id==="pick_ball"){this.pickUpBall(t.ball);return}if(t.id==="paimon"){try{window.parent&&window.parent.appShell&&typeof window.parent.appShell.toggleSidebar=="function"?window.parent.appShell.toggleSidebar():typeof window.openSSOSidebar=="function"&&window.openSSOSidebar()}catch(e){console.warn("[交互] 打开侧边栏失败:",e)}this.hidePrompt();return}if(t.id==="enter_house"){this.player.carriedBall&&this.dropCarriedBall(),this.app.switchMap("house");return}if(t.id==="exit_house"){this.player.carriedBall&&this.dropCarriedBall(),this.app.modalMgr?this.app.modalMgr.openModal("exit"):this.app.switchMap("island");return}if(t.id==="swing"){this.player.isSitting?this.player.standUp():(this.player.carriedBall&&this.dropCarriedBall(),this.player.sit(this.generator.swingSeat),this.hidePrompt());return}if(t.id==="ball_vendor"){window.dispatchEvent(new CustomEvent("spawn-ball",{detail:{x:t.x,z:t.z}}));return}if(t.id==="house_bed"){if(this.player.isLyingDown)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e=new L(t.x,t.y,t.z);this.player.lieDown(e),this.hidePrompt();const n=document.getElementById("bed-hud");n&&(n.style.display="flex")}return}if(t.id.startsWith("farm_plot_")){const e=parseInt(t.id.replace("farm_plot_",""));this.app&&typeof this.app.triggerPlotInteraction=="function"&&this.app.triggerPlotInteraction(e),this.hidePrompt();return}if(t.id==="pk_crystal"){this.modalManager.openModal("pk"),this.hidePrompt();return}if(t.id==="house_easel"){this.modalManager.openModal("easel"),this.hidePrompt();return}if(t.id==="house_wardrobe"){this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV,rotationY:this.player.group.rotation.y,controlsLocked:this.player.controlsLocked},this.isTransitioningCamera=!0,this.player.controlsLocked=!0,this.player.cameraDistance=2.4,this.player.cameraAngleH=0,this.player.cameraAngleV=.08,this.player.group.rotation.y=0,setTimeout(()=>{this.modalManager.openModal("wardrobe"),this.hidePrompt()},450);return}this.player.controlsLocked||(this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV},this.isTransitioningCamera=!0,t.id==="arcade"?(this.player.cameraDistance=2.4,this.player.cameraAngleH=0,this.player.cameraAngleV=.15):t.id==="skills"?(this.player.cameraDistance=9.5,this.player.cameraAngleV=.5):t.id==="projects"&&(this.player.cameraDistance=7,this.player.cameraAngleH=-Math.PI/2,this.player.cameraAngleV=.25),setTimeout(()=>{this.modalManager.openModal(t.id),this.hidePrompt()},450))}}class Km{constructor(t,e,n,i,s){this.scene=t,this.radius=.36,this.position=new L(e,n,i),this.velocity=new L((Math.random()-.5)*1.5,3.2,(Math.random()-.5)*1.5),this.gravity=15,this.friction=.985,this.bounceElasticity=.65,this.isGrounded=!1,this.throwNoCollideTimer=0,this.initMesh(s)}initMesh(t){this.group=new dt,this.group.position.copy(this.position);const e=new Tt(this.radius,12,12),n=new Y({color:t,flatShading:!0});this.ballMesh=new _(e,n),this.ballMesh.castShadow=!0,this.ballMesh.receiveShadow=!0,this.group.add(this.ballMesh);const i=new Y({color:16777215,flatShading:!0}),s=new nt(this.radius+.005,this.radius+.005,this.radius*.25,12,1,!0),a=new _(s,i);a.rotation.x=Math.PI/2,this.group.add(a);const r=new nt(this.radius+.004,this.radius+.004,this.radius*.25,12,1,!0),c=new _(r,i);c.rotation.z=Math.PI/2,this.group.add(c),this.scene.add(this.group)}update(t,e){if(this.throwNoCollideTimer>0&&(this.throwNoCollideTimer-=t),this.isCarried){const s=new L(0,0,1).applyQuaternion(e.group.quaternion);this.position.copy(e.position).addScaledVector(s,.65),this.position.y+=.65,this.velocity.set(0,0,0),this.isGrounded=!1,this.group.position.copy(this.position);return}this.isGrounded||(this.velocity.y-=this.gravity*t),this.velocity.x*=Math.pow(this.friction,t*60),this.velocity.z*=Math.pow(this.friction,t*60),this.position.addScaledVector(this.velocity,t);const n=this.app&&this.app.currentMap==="house"?.12:.6;if(this.position.y-this.radius<=n?(this.position.y=n+this.radius,this.velocity.y<-1.5?this.velocity.y=-this.velocity.y*this.bounceElasticity:(this.velocity.y=0,this.isGrounded=!0)):this.isGrounded=!1,this.app&&this.app.currentMap==="house"){const s=11.8-this.radius;this.position.x<-s?(this.position.x=-s,this.velocity.x=-this.velocity.x*this.bounceElasticity,this.playKickSound()):this.position.x>s&&(this.position.x=s,this.velocity.x=-this.velocity.x*this.bounceElasticity,this.playKickSound()),this.position.z<-s?(this.position.z=-s,this.velocity.z=-this.velocity.z*this.bounceElasticity,this.playKickSound()):this.position.z>s&&(this.position.z=s,this.velocity.z=-this.velocity.z*this.bounceElasticity,this.playKickSound())}else{const a=Math.sqrt(this.position.x*this.position.x+this.position.z*this.position.z);if(a+this.radius>21.5){const r=this.position.x/a,c=this.position.z/a,l=this.velocity.x*r+this.velocity.z*c;l>0&&(this.velocity.x-=2*l*r,this.velocity.z-=2*l*c,this.velocity.x*=.68,this.velocity.z*=.68),this.position.x=r*(21.5-this.radius),this.position.z=c*(21.5-this.radius)}}if(this.throwNoCollideTimer<=0){const s=this.position.x-e.position.x,a=this.position.z-e.position.z,r=Math.sqrt(s*s+a*a),c=(e.radius||.6)+this.radius-.05;if(r<c&&Math.abs(this.position.y-e.position.y)<1.3){const l=Math.atan2(s,a),h=new L(Math.sin(l),0,Math.cos(l)),d=c-r;this.position.x+=h.x*d,this.position.z+=h.z*d;const u=Math.sqrt(e.velocity.x*e.velocity.x+e.velocity.z*e.velocity.z),f=4.8,g=u*1.3,y=f+g;this.velocity.x=h.x*y,this.velocity.z=h.z*y,this.velocity.y=2.4+g*.45,this.isGrounded=!1,this.playKickSound()}}const i=Math.sqrt(this.velocity.x*this.velocity.x+this.velocity.z*this.velocity.z);if(i>.08){const s=-this.velocity.z/i,a=this.velocity.x/i,r=i/this.radius*t;this.ballMesh.rotateOnWorldAxis(new L(s,0,a),r)}this.group.position.copy(this.position)}playKickSound(){window.dispatchEvent(new CustomEvent("kick-sound",{detail:{freq:140+Math.random()*60}}))}destroy(){this.scene.remove(this.group),this.group.traverse(t=>{t.isMesh&&(t.geometry.dispose(),t.material&&t.material.dispose&&t.material.dispose())})}}class Jm{constructor(){if(document.addEventListener("dblclick",n=>{n.preventDefault()},{passive:!1}),document.addEventListener("selectstart",n=>{n.target.tagName!=="INPUT"&&n.target.tagName!=="TEXTAREA"&&n.preventDefault()}),"ontouchstart"in window||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0)document.body.classList.add("is-mobile");else{const n=()=>{document.body.classList.add("is-mobile"),window.removeEventListener("touchstart",n)};window.addEventListener("touchstart",n)}this.container=document.getElementById("canvas-container"),this.clock=new Wm,this.renderer=null,this.scene=null,this.camera=null,this.player=null,this.environment=null,this.islandGen=null,this.modalMgr=null,this.interactMgr=null,this.beachBallsList=[],this.activeBombs=[],this.activeExplosions=[],this.bombCooldownActive=!1;const e=Hn.activeTheme||"beach";this.themeConfig=Hn.themes[e],this.audioCtx=null,this.isPlayingMusic=!1,this.synthInterval=null,this.initEngine(),this.initWorld(),this.initSSO(),this.initGameSystems(),this.animate()}initSSO(){const t=new URLSearchParams(window.location.search),e=t.get("sso_access_token"),n=t.get("sso_user");if(e&&n){localStorage.setItem("sso_access_token",e),localStorage.setItem("sso_user",n),t.delete("sso_access_token"),t.delete("sso_user");const E=t.toString(),U=window.location.pathname+(E?"?"+E:"")+window.location.hash;window.history.replaceState({},document.title,U)}const i=document.getElementById("sso-login-btn"),s=document.getElementById("sso-user-info"),a=document.getElementById("sso-avatar");document.getElementById("sso-sidebar");const r=document.getElementById("sidebar-overlay"),c=document.getElementById("sidebar-close-btn"),l=document.getElementById("sidebar-avatar"),h=document.getElementById("sidebar-username"),d=document.getElementById("sidebar-user-status"),u=document.getElementById("sidebar-login-btn"),f=document.getElementById("sidebar-logout-btn");window.showMockToast=function(E){let U=document.querySelector(".mock-toast");U&&U.remove();const w=document.createElement("div");w.className="mock-toast",w.textContent=`${E} 功能正在开发中，敬请期待！😊`,document.body.appendChild(w),setTimeout(()=>{w.classList.add("show")},50),setTimeout(()=>{w.classList.remove("show"),setTimeout(()=>w.remove(),300)},2200)};const g=()=>{const E=document.getElementById("sso-sidebar"),U=document.getElementById("sidebar-overlay");E&&E.classList.add("open"),U&&U.classList.add("visible"),this.player&&(this.player.controlsLocked=!0,this.player.resetInputs())};window.openSSOSidebar=()=>{g()};const y=()=>{const E=document.getElementById("sso-sidebar"),U=document.getElementById("sidebar-overlay");E&&E.classList.remove("open"),U&&U.classList.remove("visible"),this.player&&(this.player.controlsLocked=!1)},m=E=>{E.stopPropagation(),g()};i&&i.addEventListener("click",m),s&&s.addEventListener("click",m),c&&c.addEventListener("click",E=>{E.stopPropagation(),y()}),r&&r.addEventListener("click",E=>{E.stopPropagation(),y()});const p=()=>{const E=localStorage.getItem("sso_access_token"),U=localStorage.getItem("sso_user");if(E&&U)try{const w=JSON.parse(U);i&&(i.style.display="none"),s&&(s.style.display="flex");const S=w.avatar||'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E';a&&(a.src=S),l&&(l.src=S),h&&(h.textContent=w.username),d&&(d.textContent="已登录",d.style.borderColor="rgba(100, 255, 150, 0.4)",d.style.color="#5aff8a"),u&&(u.style.display="none"),f&&(f.style.display="flex")}catch(w){console.error("Parse user failed",w)}else i&&(i.style.display="flex"),s&&(s.style.display="none"),l&&(l.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E'),h&&(h.textContent="未登录"),d&&(d.textContent="游客",d.style.borderColor="rgba(255, 140, 105, 0.25)",d.style.color="var(--primary)"),u&&(u.style.display="inline-block"),f&&(f.style.display="none")},x=document.getElementById("sidebar-back-2d-btn");if(x){const E=U=>{U.stopPropagation(),(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1")&&window.location.port==="3000"?window.location.href="http://127.0.0.1:8000/index.html":window.location.href="/index.html"};x.addEventListener("click",E)}u&&u.addEventListener("click",E=>{E.preventDefault();let w=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?"http://127.0.0.1:8000/index.html":"/index.html";if(document.referrer&&(document.referrer.includes("index.html")||document.referrer.endsWith("/")))try{const P=new URL(document.referrer);(P.pathname==="/"||P.pathname.endsWith("/index.html"))&&(w=P.origin+P.pathname)}catch{}const S=window.location.href;window.location.href=`${w}?sso_return_url=${encodeURIComponent(S)}`}),f&&f.addEventListener("click",E=>{E.preventDefault(),localStorage.removeItem("sso_access_token"),localStorage.removeItem("sso_user"),p(),y(),window.location.reload()});const v=document.getElementById("sidebar-stuck-btn");v&&v.addEventListener("click",E=>{E.stopPropagation(),this.unstuckPlayer(),y()});const M=document.getElementById("btn-map-island"),R=document.getElementById("btn-map-house");M&&M.addEventListener("click",E=>{E.stopPropagation(),this.switchMap("island"),y()}),R&&R.addEventListener("click",E=>{E.stopPropagation(),this.switchMap("house"),y()}),[{id:"btn-sidebar-leaderboard",name:"leaderboard"},{id:"btn-sidebar-tasks",name:"tasks"},{id:"btn-sidebar-farm",name:"farm"},{id:"btn-sidebar-pk",name:"pk"},{id:"btn-sidebar-bag",name:"bag"},{id:"btn-sidebar-home",name:"home"}].forEach(E=>{const U=document.getElementById(E.id);U&&U.addEventListener("click",w=>{w.stopPropagation(),y(),E.name==="farm"?(this.switchMap("farm"),setTimeout(()=>{if(window.showMockToast){let S=document.querySelector(".mock-toast");S&&S.remove();const P=document.createElement("div");P.className="mock-toast",P.textContent="已传送至您的 3D 农场岛！走近泥地格按 E 种植/收割 🌾",document.body.appendChild(P),setTimeout(()=>P.classList.add("show"),50),setTimeout(()=>{P.classList.remove("show"),setTimeout(()=>P.remove(),300)},2200)}},this.currentMap==="house"?600:50)):E.name==="pk"?(this.switchMap("pk_arena",new L(0,.6+.1,-6.5)),setTimeout(()=>{if(window.showMockToast){let S=document.querySelector(".mock-toast");S&&S.remove();const P=document.createElement("div");P.className="mock-toast",P.textContent="已传送至 3D 竞技大厅！走近前方蓝色的“决斗水晶”按 E 开启匹配决斗 ⚔️",document.body.appendChild(P),setTimeout(()=>P.classList.add("show"),50),setTimeout(()=>{P.classList.remove("show"),setTimeout(()=>P.remove(),300)},2500)}},this.currentMap==="house"?600:50)):this.modalMgr&&this.modalMgr.openModal(E.name)})}),p(),window.addEventListener("keydown",E=>{if(E.key==="Escape"){const U=document.activeElement;if(U&&(U.tagName==="INPUT"||U.tagName==="TEXTAREA"||U.isContentEditable))return;const w=document.getElementById("btn-settle-close");if(w){E.preventDefault(),w.click();return}if(this.modalMgr&&this.modalMgr.isAnyModalOpen){E.preventDefault(),this.modalMgr.closeAllModals();return}if(window.self!==window.top&&window.parent&&window.parent.appShell&&typeof window.parent.appShell.toggleSidebar=="function"){E.preventDefault(),window.parent.appShell.toggleSidebar();return}const S=document.getElementById("sso-sidebar");S&&(E.preventDefault(),S.classList.contains("open")?y():g())}}),document.addEventListener("touchmove",E=>{E.target.closest(".scrollable")||E.target.closest(".wardrobe-sidebar")||E.target.closest(".modal-body")||E.target.closest(".sso-sidebar")||E.cancelable&&E.preventDefault()},{passive:!1})}initEngine(){this.scene=new nm;const t=this.themeConfig.colors.sky||11725810;this.scene.background=new kt(t),this.camera=new De(45,window.innerWidth/window.innerHeight,.1,200),this.renderer=new Rc({antialias:!0,alpha:!1}),this.renderer.setSize(window.innerWidth,window.innerHeight);const e="ontouchstart"in window||navigator.maxTouchPoints>0;this.renderer.setPixelRatio(e?Math.min(window.devicePixelRatio,1.35):Math.min(window.devicePixelRatio,2)),this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=e?$o:Jr,this.renderer.toneMapping=Qr,this.renderer.toneMappingExposure=1.35,this.container.appendChild(this.renderer.domElement),window.addEventListener("resize",()=>this.onWindowResize())}initWorld(){this.currentMap="island",document.body.id==="page-lobby"?this.currentMap="island":document.body.id==="page-house"?this.currentMap="house":document.body.id==="page-farm"?this.currentMap="farm":document.body.id==="page-pvp"?this.currentMap="pk_arena":document.body.id==="page-lake"&&(this.currentMap="lake"),this.modalMgr=new Ym,this.environment=new $m(this.scene,this.themeConfig),this.currentMap==="island"?(this.islandGen=new jm(this.scene,this.themeConfig),this.player=new Ri(this.scene,this.camera,this.islandGen.colliders,this.themeConfig),this.interactMgr=new Li(this.player,this.islandGen,this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="house"?(this.houseGen=new Zm(this.scene,this.themeConfig),this.houseGen.group.visible=!0,this.player=new Ri(this.scene,this.camera,this.houseGen.colliders,this.themeConfig),this.interactMgr=new Li(this.player,this.houseGen,this.modalMgr,this),this.environment.setIndoorMode(!0)):this.currentMap==="farm"?(this.farmGroup=new dt,this.scene.add(this.farmGroup),this.farmGroup.visible=!0,this.buildFarmPlatform(),this.player=new Ri(this.scene,this.camera,this.farmColliders||[],this.themeConfig),this.interactMgr=new Li(this.player,{interactables:this.farmInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="pk_arena"?(this.pkArenaGroup=new dt,this.scene.add(this.pkArenaGroup),this.pkArenaGroup.visible=!0,this.buildPKPlatform(),this.player=new Ri(this.scene,this.camera,this.pkArenaColliders||[],this.themeConfig),this.interactMgr=new Li(this.player,{interactables:this.pkArenaInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="lake"&&(this.lakeGroup=new dt,this.scene.add(this.lakeGroup),this.lakeGroup.visible=!0,this.buildLakePlatform(),this.player=new Ri(this.scene,this.camera,this.lakeColliders||[],this.themeConfig),this.interactMgr=new Li(this.player,{interactables:this.lakeInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1),window.addEventListener("piano-note-played",a=>{this.currentMap==="lake"&&this.spawnNoteParticle(a.detail.note)})),this.player.app=this;const e=new URLSearchParams(window.location.search).get("spawn");if(e){const a=e.split(",").map(Number);a.length===3&&!a.some(isNaN)&&(this.player.position.set(a[0],a[1],a[2]),this.player.group.position.copy(this.player.position),this.currentMap==="house"||this.currentMap==="farm"?(this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="pk_arena"?a[2]<0?(this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):(this.player.group.rotation.y=-Math.PI/2,this.player.cameraAngleH=-Math.PI/2):(this.currentMap==="island"||this.currentMap==="lake")&&(this.player.group.rotation.y=0,this.player.cameraAngleH=0))}else this.currentMap==="house"?(this.player.position.set(0,.12+.1,9.5),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="farm"?(this.player.position.set(0,.6+.1,-8),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="pk_arena"?(this.player.position.set(-5,.6+.1,0),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=-Math.PI/2,this.player.cameraAngleH=-Math.PI/2):this.currentMap==="lake"?(this.player.position.set(0,.6+.1,8.5),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):(this.player.position.set(0,4,0),this.player.group.position.copy(this.player.position));const n=Hn.activeTheme==="christmas";window.addEventListener("spawn-ball",a=>{if(this.currentMap!=="island")return;const r=a.detail.x,c=a.detail.z+.6,l=n?[16777215,14743546,16120573]:[16732754,4244735,16771899,16747136,58998],h=l[Math.floor(Math.random()*l.length)],d=new Km(this.scene,r,1.3,c,h);if(d.app=this,this.beachBallsList.push(d),this.beachBallsList.length>5){let u=-1;for(let f=0;f<this.beachBallsList.length;f++)if(!this.beachBallsList[f].isCarried){u=f;break}u!==-1&&this.beachBallsList.splice(u,1)[0].destroy()}this.playCustomSound(n?320:450,.12,"sine",.08)}),window.addEventListener("kick-sound",a=>{this.playCustomSound(n?a.detail.freq*.6:a.detail.freq,.16,n?"sine":"triangle",.18)}),this.initWardrobeUI();const i=document.getElementById("btn-toggle-time");if(i){const a=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.environment&&(this.environment.isNight=!this.environment.isNight,this.playCustomSound(this.environment.isNight?220:440,.4,"sine",.08))};i.addEventListener("touchstart",a,{passive:!1}),i.addEventListener("click",a)}const s=document.getElementById("btn-stand-up");if(s){const a=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.player&&this.player.isLyingDown&&this.player.standUp()};s.addEventListener("touchstart",a,{passive:!1}),s.addEventListener("click",a)}window.parent&&window.parent.appShell&&typeof window.parent.appShell.onMapLoaded=="function"&&window.parent.appShell.onMapLoaded(this.currentMap)}initWardrobeUI(){const t=(n,i)=>{const s=document.getElementById(n);if(!s)return;s.querySelectorAll(".color-btn").forEach(r=>{r.addEventListener("click",()=>{var l;(l=s.querySelector(".color-btn.active"))==null||l.classList.remove("active"),r.classList.add("active");const c=r.getAttribute("data-color");this.player&&this.player.updateOutfit(i,c)})})};t("wardrobe-hair","hair"),t("wardrobe-clothes","clothing"),t("wardrobe-hat","hat"),document.querySelectorAll(".model-btn").forEach(n=>{n.addEventListener("click",()=>{var s;(s=document.querySelector(".model-btn.active"))==null||s.classList.remove("active"),n.classList.add("active");const i=n.getAttribute("data-model");if(this.player){this.player.updateModel(i);const a=document.getElementById("wardrobe-hair-title"),r=document.getElementById("wardrobe-clothing-title"),c=document.getElementById("wardrobe-hat-title");i==="kitty"?(a&&(a.textContent="毛皮颜色 (Fur Color)"),r&&(r.textContent="小猫背心 (Vest Color)"),c&&(c.textContent="金铃铛颜色 (Bell Color)")):(a&&(a.textContent="发发 / 毛毛"),r&&(r.textContent="服装颜色"),c&&(c.textContent="配饰 / 铃铛颜色")),this.playCustomSound(440,.15,"triangle",.06)}})})}playCustomSound(t,e,n="sine",i=.05){if(window.parent&&typeof window.parent.playCustomSound=="function"){window.parent.playCustomSound(t,e,n,i);return}try{this.audioCtx||(this.audioCtx=new(window.AudioContext||window.webkitAudioContext)),this.audioCtx.state==="suspended"&&this.audioCtx.resume();const s=this.audioCtx.createOscillator(),a=this.audioCtx.createGain();s.type=n,s.frequency.setValueAtTime(t,this.audioCtx.currentTime),a.gain.setValueAtTime(i,this.audioCtx.currentTime),a.gain.exponentialRampToValueAtTime(1e-4,this.audioCtx.currentTime+e),s.connect(a),a.connect(this.audioCtx.destination),s.start(),s.stop(this.audioCtx.currentTime+e)}catch(s){console.warn("Play custom sound failed",s)}}initMobileJoystick(){}initAudioSynth(){}playMelodyLoop(){}playMelodyLoop(){const t=Hn.activeTheme==="christmas",e=t?1.2:1,n=[[130.81,196,261.63,329.63,392].map(r=>r*e),[146.83,220,293.66,349.23,440].map(r=>r*e),[164.81,246.94,329.63,392,493.88].map(r=>r*e),[116.54,174.61,233.08,293.66,349.23].map(r=>r*e)];let i=0,s=0;const a=(r,c,l="sine",h=.05)=>{if(!this.isPlayingMusic||!this.audioCtx)return;const d=this.audioCtx.createOscillator(),u=this.audioCtx.createGain();d.type=l,d.frequency.setValueAtTime(r,this.audioCtx.currentTime),u.gain.setValueAtTime(h,this.audioCtx.currentTime),u.gain.exponentialRampToValueAtTime(1e-4,this.audioCtx.currentTime+c),d.connect(u),u.connect(this.audioCtx.destination),d.start(),d.stop(this.audioCtx.currentTime+c)};this.synthInterval=setInterval(()=>{const r=n[i],c=[0,2,1,3,2,4,3,1],l=c[s%c.length],h=r[l];if(a(h,.9,"sine",t?.05:.08),s%4===0&&Math.random()>.3){const u=h*2;a(u,1.6,"sine",t?.04:.03)}s++,s%16===0&&(i=(i+1)%n.length)},320)}onWindowResize(){this.camera.aspect=window.innerWidth/window.innerHeight,this.camera.updateProjectionMatrix(),this.renderer.setSize(window.innerWidth,window.innerHeight)}switchMap(t,e=null,n=null,i=null){let s="";t==="island"?s="lobby.html":t==="house"?s="house.html":t==="farm"?s="farm.html":t==="pk_arena"?s="pvp.html":t==="lake"&&(s="lake.html");const a=[];e&&a.push(`spawn=${e.x.toFixed(2)},${e.y.toFixed(2)},${e.z.toFixed(2)}`),n&&a.push(`modal=${n}`),i&&a.push(`action=${i}`),a.length>0&&(s+="?"+a.join("&"));const r=document.getElementById("fade-overlay");r&&r.classList.add("fade-in"),setTimeout(()=>{window.location.href=s},450)}unstuckPlayer(){if(this.player&&((this.player.isSitting||this.player.isLyingDown)&&this.player.standUp(),this.currentMap==="house"?this.player.position.set(0,.12+.1,9.5):this.player.position.set(-10,.6+.1,-5.2),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=this.currentMap==="house"?Math.PI:0,this.player.cameraAngleH=this.currentMap==="house"?Math.PI:0,window.showMockToast)){let t=document.querySelector(".mock-toast");t&&t.remove();const e=document.createElement("div");e.className="mock-toast",e.textContent="重置成功！角色已脱离卡死 🌀",document.body.appendChild(e),setTimeout(()=>{e.classList.add("show")},50),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>e.remove(),300)},2200)}}animate(){if(requestAnimationFrame(()=>this.animate()),window.parent&&window.parent.keys){const n=!!window.parent.keys.j;n&&!this.lastParentJ&&typeof this.playerPerformAttack=="function"&&this.playerPerformAttack(),this.lastParentJ=n}const t=Math.min(this.clock.getDelta(),.1),e=this.clock.getElapsedTime()*1e3;this.player&&this.player.update(t,e),this.environment&&this.environment.update(e),this.islandGen&&this.islandGen.update(e,this.environment),this.interactMgr&&this.interactMgr.update(),this.beachBallsList&&this.player&&this.beachBallsList.forEach(n=>n.update(t,this.player)),this.updateGameSystemsFrame(t,e),this.currentMap==="lake"&&this.updateLakeFrame(t,e),this.renderer&&this.scene&&this.camera&&this.renderer.render(this.scene,this.camera)}getInitialGameData(){return{coins:200,level:1,exp:0,pkPoints:1e3,pkWins:0,pkLoses:0,onlineTime:0,backpack:[{id:"sunflower_seed",name:"向日葵种子",type:"seed",count:5,quality:"green",desc:"可在农田里种植，成熟后收割获得丰厚金币。"},{id:"strawberry_seed",name:"草莓种子",type:"seed",count:2,quality:"blue",desc:"可在农田里种植，成熟收割获得巨额回报。"}],farmPlots:[{id:0,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:1,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:2,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:3,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:4,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:5,status:"empty",seedId:null,plantTime:0,unlocked:!0}],homeFurnitures:[],ownedFurnitures:["painting_1","tree_1"],tasks:[{id:"kick_ball",name:"在群岛领取沙滩球或踢球 1 次",progress:0,target:1,reward:50,status:"ongoing",type:"kick"},{id:"rest_bed",name:"在温馨小屋床上休息 1 次",progress:0,target:1,reward:50,status:"ongoing",type:"rest"},{id:"play_billiards",name:"游玩 1 局弹射台球游戏",progress:0,target:1,reward:80,status:"ongoing",type:"game_billiards"},{id:"play_poker",name:"游玩 1 局 21点纸牌游戏",progress:0,target:1,reward:80,status:"ongoing",type:"game_poker"},{id:"crop_harvest",name:"收割成熟的农地作物 3 次",progress:0,target:3,reward:100,status:"ongoing",type:"harvest"}],dailyChestClaimed:!1,lastTaskResetDate:new Date().toLocaleDateString()}}async loadGameData(){const t=localStorage.getItem("sso_access_token"),e=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";let n=null;if(t)try{const a=await(await fetch(`${e}/api/game/data?game_id=3d-home-all`,{headers:{Authorization:`Bearer ${t}`}})).json();a.success&&a.data&&a.data.save_data&&(n=a.data.save_data)}catch(s){console.error("从云端加载存档失败，采用本地缓存",s)}if(!n){const s=localStorage.getItem("player_game_data");if(s)try{n=JSON.parse(s)}catch(a){console.error("本地存档解析失败",a)}}if(!n)n=this.getInitialGameData();else{const s=this.getInitialGameData();n=Object.assign({},s,n)}this.gameData=n;const i=new Date().toLocaleDateString();this.gameData.lastTaskResetDate!==i&&(this.gameData.tasks=this.getInitialGameData().tasks,this.gameData.dailyChestClaimed=!1,this.gameData.lastTaskResetDate=i,this.saveGameData()),this.updateBaseUI()}async saveGameData(){localStorage.setItem("player_game_data",JSON.stringify(this.gameData));const t=localStorage.getItem("sso_access_token"),e=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";if(t)try{await fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"3d-home-all",score:this.gameData.level,save_data:this.gameData})}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"pkPoints",score:this.gameData.pkPoints})}).catch(()=>{}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"coins",score:this.gameData.coins})}).catch(()=>{}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"level",score:this.gameData.level})}).catch(()=>{})}catch(n){console.error("云端存档同步失败",n)}this.updateBaseUI()}updateBaseUI(){const t=document.getElementById("farm-coins"),e=document.getElementById("home-coins"),n=document.getElementById("farm-level"),i=document.getElementById("farm-exp"),s=document.querySelector("#modal-bag .bag-coins-val");t&&(t.textContent=this.gameData.coins),e&&(e.textContent=this.gameData.coins),n&&(n.textContent=this.gameData.level),i&&(i.textContent=this.gameData.exp),s&&(s.textContent=this.gameData.coins)}initGameSystems(){this.gameData=this.getInitialGameData(),this.loadGameData(),setInterval(()=>{this.gameData.onlineTime++,this.gameData.onlineTime%60===0&&(this.gameData.exp+=15,this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,this.playCustomSound(523.25,.4,"triangle",.1)),this.saveGameData())},1e3),window.addEventListener("spawn-ball",()=>{this.updateTaskProgress("kick",1)}),window.addEventListener("modal-opened",i=>{const s=i.detail.modalId;s==="leaderboard"&&this.refreshLeaderboard(),s==="tasks"&&this.refreshTasks(),s==="farm"&&this.refreshFarm(),s==="pk"&&this.refreshPK(),s==="bag"&&this.refreshBag(),s==="home"&&this.refreshHome(),s==="shop"&&(this.updateShopCoins(),this.renderShopItems(this.getActiveShopTab()))}),this.initLeaderboardUI(),this.initTasksUI(),this.initFarmUI(),this.initPKUI(),this.initBagUI(),this.initHomeUI(),this.initMapUI(),this.initShopUI(),this.initRadialSeedMenu();const t=new URLSearchParams(window.location.search),e=t.get("modal");if(e&&this.modalMgr&&setTimeout(()=>{this.modalMgr.openModal(e)},500),t.get("action")==="edit"&&setTimeout(()=>{this.enterHomeEditMode()},500),this.currentMap==="pk_arena"&&setTimeout(()=>{this.modalMgr&&this.modalMgr.openModal("pk")},500),this.currentMap==="farm"){const i=document.createElement("div");i.id="farm-bubbles-container",i.style.position="absolute",i.style.top="0",i.style.left="0",i.style.width="100%",i.style.height="100%",i.style.pointerEvents="none",i.style.zIndex="10",document.body.appendChild(i)}window.addEventListener("kick-sound",()=>{this.updateTaskProgress("kick",1)}),this.currentMap==="house"&&(typeof this.renderHomeFurnitures=="function"&&this.renderHomeFurnitures(),this.initExitChoicesUI()),window.addEventListener("keydown",i=>{if(i.target.tagName==="INPUT"||i.target.tagName==="TEXTAREA")return;const s=i.key.toLowerCase();s==="b"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.bag.classList.contains("open")?this.modalMgr.closeModal("bag"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("bag")))):s==="j"?(i.preventDefault(),this.currentMap==="farm"?this.isRadialMenuOpen?this.closeRadialSeedMenu():this.openRadialSeedMenu():this.modalMgr&&(this.modalMgr.modals.tasks.classList.contains("open")?this.modalMgr.closeModal("tasks"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("tasks")))):s==="p"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.leaderboard.classList.contains("open")?this.modalMgr.closeModal("leaderboard"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("leaderboard")))):s==="m"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.map.classList.contains("open")?this.modalMgr.closeModal("map"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("map")))):s==="g"&&(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.shop.classList.contains("open")?this.modalMgr.closeModal("shop"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("shop"))))})}initLeaderboardUI(){const t=document.querySelectorAll("#modal-leaderboard .tab-btn");t.forEach(e=>{e.addEventListener("click",n=>{t.forEach(i=>i.classList.remove("active")),e.classList.add("active"),this.refreshLeaderboard(e.getAttribute("data-tab"))})})}getMockLeaderboard(t){const e=["浮云行者","琴海微风","金色沙滩","椰子冰沙","派蒙小跟班","晨曦守护","月见草","落樱纷飞","温馨秋千","大锤王二"],n=[];let i=t==="pkPoints"?1e3:t==="coins"?200:1,s=t==="pkPoints"?60:t==="coins"?50:2;for(let h=0;h<9;h++)n.push({username:e[h],avatar:"",score:i+(9-h)*s});let a=this.gameData.pkPoints;t==="coins"&&(a=this.gameData.coins),t==="level"&&(a=this.gameData.level);const r=localStorage.getItem("sso_user");let c="您自己",l="";if(r)try{const h=JSON.parse(r);c=h.username,l=h.avatar}catch{}return n.push({username:c,avatar:l,score:a,isMe:!0}),n.sort((h,d)=>d.score-h.score),n.slice(0,10)}async refreshLeaderboard(t="pkPoints"){const e=document.getElementById("leaderboard-list-view"),n=document.getElementById("leaderboard-my-rank");if(!e)return;e.innerHTML='<div style="text-align:center; padding: 20px; font-size: 0.85rem; color: var(--text-muted);">数据加载中...</div>';const i=localStorage.getItem("sso_access_token"),s=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";let a=[],r=!1;if(i)try{const f=await fetch(`${s}/api/game/leaderboard?game_id=${t}`).then(g=>g.json());f.success&&f.leaderboard&&f.leaderboard.length>0&&(a=f.leaderboard,r=!0)}catch(f){console.error("加载服务端排行榜失败",f)}r||(a=this.getMockLeaderboard(t)),e.innerHTML="";const c=localStorage.getItem("sso_user");let l="您自己";if(c)try{l=JSON.parse(c).username}catch{}a.forEach((f,g)=>{const y=f.username===l||f.isMe,m=document.createElement("div");m.className=`leaderboard-item rank-${g+1}`,y&&(m.style.background="rgba(255, 140, 105, 0.15)",m.style.borderColor="rgba(255, 140, 105, 0.3)");const p=f.avatar||'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E',x=t==="pkPoints"?" 积分":t==="coins"?" 金币":" 级";m.innerHTML=`
        <div class="leaderboard-rank" style="font-weight: bold; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%;">${g+1}</div>
        <img class="leaderboard-avatar" src="${p}" alt="头像" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1.5px solid rgba(255,255,255,0.2);">
        <div class="leaderboard-name" style="flex: 1; margin-left: 10px; font-size: 0.9rem; font-weight: 600;">${f.username}</div>
        <div class="leaderboard-score" style="font-size: 0.95rem; font-weight: bold; color: var(--primary);">${f.score}${x}</div>
      `,e.appendChild(m)});let h=this.gameData.pkPoints;t==="coins"&&(h=this.gameData.coins),t==="level"&&(h=this.gameData.level);let d="未上榜";const u=a.findIndex(f=>f.username===l||f.isMe);u!==-1&&(d=`第 ${u+1} 名`),n&&(n.innerHTML=`
        <span>当前名次: <strong style="color: var(--primary);">${d}</strong></span>
        <span style="margin-left: 20px;">我的数值: <strong style="color: var(--secondary);">${h}</strong></span>
      `)}initTasksUI(){const t=document.getElementById("btn-tasks-claim-chest"),e=document.getElementById("tasks-chest-btn"),n=i=>{if(i.stopPropagation(),this.gameData.tasks.filter(a=>a.progress>=a.target).length===5&&!this.gameData.dailyChestClaimed){this.gameData.dailyChestClaimed=!0,this.gameData.coins+=300,this.showCoinFloatText(300,i.clientX,i.clientY),this.gameData.exp+=100;let a=!1;this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,a=!0),this.saveGameData(),this.updateBaseUI(),this.refreshTasks(),a?setTimeout(()=>{this.playCustomSound(523.25,.4,"triangle",.1),this.showToast("恭喜升级啦！✨ 等级提升！")},300):(this.playCustomSound(880,.1,"sine",.05),setTimeout(()=>this.playCustomSound(1200,.2,"sine",.05),100))}};t&&t.addEventListener("click",n),e&&e.addEventListener("click",n)}updateTaskProgress(t,e=1){let n=!1;this.gameData.tasks.forEach(i=>{i.type===t&&i.status==="ongoing"&&(i.progress=Math.min(i.target,i.progress+e),i.progress>=i.target&&(i.status="claimable"),n=!0)}),n&&this.saveGameData()}refreshTasks(){const t=document.getElementById("tasks-list");if(!t)return;t.innerHTML="";const e=this.gameData.tasks.filter(c=>c.progress>=c.target).length,n=document.getElementById("tasks-progress-text"),i=document.getElementById("tasks-progress-bar"),s=document.getElementById("tasks-chest-btn"),a=document.getElementById("tasks-chest-tips"),r=document.getElementById("btn-tasks-claim-chest");n&&(n.textContent=`${e} / 5`),i&&(i.style.width=`${e/5*100}%`),this.gameData.dailyChestClaimed?(s&&(s.textContent="📦",s.style.animation="none",s.style.cursor="default"),a&&(a.innerHTML='<span style="color: #4caf50; font-weight: bold;">每日宝箱奖励已领取！📯</span><br><span style="font-size: 0.68rem;">获得了 300金币 + 100经验。明天再来吧！🌟</span>'),r&&(r.textContent="已领取",r.disabled=!0,r.style.background="rgba(255,255,255,0.08)",r.style.color="var(--text-muted)",r.style.borderColor="transparent")):e===5?(s&&(s.textContent="🎁",s.style.animation="chestBounce 1.2s infinite alternate ease-in-out",s.style.cursor="pointer"),a&&(a.innerHTML='<span style="color: #ffd700; font-weight: bold;">今日任务已全部达成！✨</span><br><span style="font-size: 0.68rem; color: #fff;">快点击宝箱或下方按钮领取额外大奖！</span>'),r&&(r.textContent="开启宝箱",r.disabled=!1,r.style.background="linear-gradient(135deg, #ffd700 0%, #ff9800 100%)",r.style.color="#000",r.style.borderColor="#ffd700")):(s&&(s.textContent="🎁",s.style.animation="none",s.style.cursor="default"),a&&(a.textContent="完成今日全部 5 个任务即可开启宝箱，获得 300 金币与 100 经验！"),r&&(r.textContent="未达成",r.disabled=!0,r.style.background="rgba(255,255,255,0.04)",r.style.color="var(--text-muted)",r.style.borderColor="transparent")),this.gameData.tasks.forEach(c=>{const l=document.createElement("div");l.className=`task-card-item ${c.status==="claimed"?"task-completed":""}`;let h="";c.status==="ongoing"?h=`<button class="task-btn-action" data-action="go" data-type="${c.type}">去完成</button>`:c.status==="claimable"?h=`<button class="task-btn-action task-btn-claim" data-action="claim" data-id="${c.id}">领取奖励</button>`:h='<button class="task-btn-action task-btn-done">已领取</button>';const d=Math.min(100,Math.floor(c.progress/c.target*100));l.innerHTML=`
        <div class="task-meta">
          <span class="task-title">${c.name}</span>
          <span class="task-reward">🎁 +${c.reward}金币</span>
        </div>
        <div class="task-progress-wrap" style="margin-top: 10px;">
          <div class="task-progress-bar">
            <div class="task-progress-fill" style="width: ${d}%;"></div>
          </div>
          <span class="task-progress-text">${c.progress}/${c.target}</span>
          ${h}
        </div>
      `;const u=l.querySelector(".task-btn-claim");u&&u.addEventListener("click",g=>{g.stopPropagation(),this.claimTaskReward(c.id,g.clientX,g.clientY)});const f=l.querySelector('.task-btn-action[data-action="go"]');f&&f.addEventListener("click",g=>{if(g.stopPropagation(),this.modalMgr.closeAllModals(),c.type==="game_billiards"){const y=Hn.games.find(m=>m.id==="billiards");y&&this.modalMgr.launchGame(y),this.updateTaskProgress("game_billiards",1)}else if(c.type==="game_poker"){const y=Hn.games.find(m=>m.id==="21dian");y&&this.modalMgr.launchGame(y),this.updateTaskProgress("game_poker",1)}else c.type==="kick"?this.switchMap("island",new L(-5,.7,5)):c.type==="rest"?this.switchMap("house",new L(2.8,.22,4)):c.type==="harvest"&&this.switchMap("farm",new L(0,.7,-8))}),t.appendChild(l)})}claimTaskReward(t,e,n){const i=this.gameData.tasks.find(s=>s.id===t);!i||i.status!=="claimable"||(i.status="claimed",this.gameData.coins+=i.reward,this.saveGameData(),this.showCoinFloatText(i.reward,e,n),this.refreshTasks())}showCoinFloatText(t,e,n){const i=document.createElement("div");i.className="coin-float-text";const s=e!==void 0?e:window.innerWidth/2,a=n!==void 0?n:window.innerHeight/2;i.style.left=`${s}px`,i.style.top=`${a}px`;const r=t>0;i.innerHTML=`${r?"+":""}${t} <span style="font-size: 1.1em; margin-left: 2px;">🪙</span>`,i.style.color=r?"#ffd700":"#ff8a80",i.style.textShadow=r?"0 0 10px rgba(255,215,0,0.6)":"0 0 10px rgba(255,138,128,0.6)",document.body.appendChild(i),r?(this.playCustomSound(987.77,.08,"square",.03),setTimeout(()=>this.playCustomSound(1318.51,.25,"square",.03),80)):this.playCustomSound(329.63,.15,"sawtooth",.04),setTimeout(()=>{i.remove()},1e3)}showToast(t){let e=document.querySelector(".mock-toast");e&&e.remove();const n=document.createElement("div");n.className="mock-toast",n.textContent=t,document.body.appendChild(n),setTimeout(()=>{n.classList.add("show")},50),setTimeout(()=>{n.classList.remove("show"),setTimeout(()=>n.remove(),300)},2200)}triggerPlotInteraction(t){const e=this.gameData.farmPlots[t];if(e)if(e.status==="empty")this.activePlotIndex=t,this.openRadialSeedMenu();else if(e.status==="ready")this.harvestCrop(t);else{const n=e.seedId==="sunflower_seed"?30:60,i=Math.floor((Date.now()-e.plantTime)/1e3),s=Math.max(0,n-i),a=e.seedId==="sunflower_seed"?"向日葵":"草莓";this.showToast(`${a} 正在生长中，还需等待 ${s} 秒 ⏳`)}}initFarmUI(){this.refreshFarm()}refreshFarm(){const t=document.getElementById("farm-grid");t&&(t.innerHTML="",this.gameData.farmPlots.forEach((e,n)=>{const i=document.createElement("div");if(i.className="farm-plot",!e.unlocked)i.classList.add("locked"),i.innerHTML=`
          <div style="font-size: 1.5rem; opacity: 0.4;">🔒</div>
          <span style="font-size: 0.65rem; color: #ff8a80; margin-top: 4px;">未解锁</span>
        `;else if(e.status==="empty")i.innerHTML=`
          <div style="font-size: 1.8rem; color: #2ecc71;">➕</div>
          <span style="font-size: 0.72rem; color: var(--text-muted); margin-top: 4px;">空地</span>
        `,i.addEventListener("click",()=>{this.activePlotIndex=n,this.openRadialSeedMenu()});else{const s=e.status==="ready",a=e.seedId==="sunflower_seed"?"🌻":"🍓",r=e.seedId==="sunflower_seed"?"向日葵":"草莓";let c="";if(s)c='<span class="plot-crop-ready">🌾 可收割</span>';else{const l=e.seedId==="sunflower_seed"?30:60,h=Math.floor((Date.now()-e.plantTime)/1e3);c=`<span class="plot-crop-timer">⏳ ${Math.max(0,l-h)}s</span>`}i.innerHTML=`
          <span class="plot-crop-icon">${a}</span>
          <span class="plot-crop-name">${r}</span>
          ${c}
        `,s&&i.addEventListener("click",()=>{this.harvestCrop(n)})}t.appendChild(i)}))}buyAndPlant(t){const e=t==="sunflower_seed"?10:20;if(this.gameData.coins<e){alert("金币不足，无法购买种子！");return}this.gameData.coins-=e;const n=this.gameData.farmPlots[this.activePlotIndex];n.status="growing",n.seedId=t,n.plantTime=Date.now(),this.saveGameData(),document.getElementById("sub-modal-seed-shop").style.display="none",this.player&&(this.player.controlsLocked=!1),this.refreshFarm(),this.playCustomSound(330,.25,"sine",.1),this.recreateCrop3D(this.activePlotIndex);const i=t==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功播种了 ${i} 种子 🌱`)}harvestCrop(t){const e=this.gameData.farmPlots[t];if(!e||e.status!=="ready")return;const n=e.seedId==="sunflower_seed"?"sunflower_crop":"strawberry_crop",i=e.seedId==="sunflower_seed"?"新鲜向日葵":"多汁草莓",s=e.seedId,a=e.seedId==="sunflower_seed"?15:35;e.status="empty",e.seedId=null,e.plantTime=0;const r=this.gameData.backpack.find(l=>l.id===n);r?r.count++:this.gameData.backpack.push({id:n,name:i,type:"collect",count:1,quality:s==="sunflower_seed"?"green":"blue",desc:"在自家农田收获的优质作物，可直接在背包中出售以换取游戏币。"}),this.gameData.exp+=a,this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,this.playCustomSound(523.25,.4,"triangle",.1)),this.saveGameData(),this.refreshFarm(),this.updateTaskProgress("harvest",1),this.playCustomSound(440,.2,"sine",.1),this.recreateCrop3D(t);const c=s==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功收割了 ${c} 🌾！已存入背包`)}recreateCrop3D(t){if(!this.farmPlots3D)return;const e=this.farmPlots3D[t];if(!e)return;e.plantGroup.clear();const n=this.gameData.farmPlots[t];if(n.status==="empty"||!n.seedId)return;const i=new dt;if(n.seedId==="sunflower_seed"){const a=new nt(.04,.04,.7,6),r=new Y({color:3046706}),c=new _(a,r);c.position.y=.35,c.castShadow=!0,i.add(c);const l=new nt(.2,.2,.06,8),h=new Y({color:16771899}),d=new _(l,h);d.position.set(0,.7,.05),d.rotation.x=Math.PI/4,i.add(d);const u=new nt(.1,.1,.08,8),f=new Y({color:6111287}),g=new _(u,f);g.position.set(0,.72,.07),g.rotation.x=Math.PI/4,i.add(g)}else{const a=new G(.25,.04,.25),r=new Y({color:2600544}),c=new _(a,r);c.position.y=.04,i.add(c);const l=new oe(.18,.35,6),h=new Y({color:16717636}),d=new _(l,h);d.rotation.x=Math.PI,d.position.y=.25,d.castShadow=!0,i.add(d)}e.plantGroup.add(i),n.status==="ready"?e.plantGroup.scale.set(1,1,1):e.plantGroup.scale.set(.15,.15,.15)}initPKUI(){const t=document.getElementById("btn-pk-match");t&&t.addEventListener("click",s=>{s.stopPropagation(),this.triggerPKMatching()});const e=document.getElementById("btn-cancel-match");e&&e.addEventListener("click",s=>{s.stopPropagation(),this.cancelPKMatching()});const n=document.getElementById("btn-create-room");n&&n.addEventListener("click",s=>{s.stopPropagation(),alert("正在努力创建房间中... 暂无其他联机对手，已为您指派了机器人。"),this.modalMgr.closeAllModals(),this.triggerPKMatching()});const i=document.getElementById("btn-pk-attack");i&&(i.addEventListener("touchstart",s=>{s.preventDefault(),s.stopPropagation(),this.playerPerformAttack()},{passive:!1}),i.addEventListener("click",s=>{s.stopPropagation(),this.playerPerformAttack()})),window.addEventListener("keydown",s=>{s.key.toLowerCase()==="j"&&this.playerPerformAttack()}),window.addEventListener("mousedown",s=>{if(s.button===0&&this.isPKActive){const a=s.target.tagName.toLowerCase();if(a==="button"||a==="a"||s.target.closest(".sidebar-container")||s.target.closest(".modal-card")||s.target.closest(".pk-hud")||s.target.closest(".action-buttons"))return;this.playerPerformAttack()}})}refreshPK(){const t=document.getElementById("pk-points-val"),e=document.getElementById("pk-rank-badge"),n=document.getElementById("pk-win-rate"),i=document.getElementById("pk-total-battles");t&&(t.textContent=this.gameData.pkPoints);const s=this.gameData.pkPoints;let a="🥉 皇家青铜";s>=1200&&s<1500&&(a="🥈 璀璨白银"),s>=1500&&s<1800&&(a="🥇 荣耀黄金"),s>=1800&&(a="👑 傲世战神"),e&&(e.textContent=a);const r=this.gameData.pkWins+this.gameData.pkLoses;if(i&&(i.textContent=r),n){const l=r>0?Math.floor(this.gameData.pkWins/r*100):0;n.textContent=`${l}%`}const c=document.getElementById("room-list");c&&(c.innerHTML=`
        <div class="room-card">
          <span>🎮 浮空挑战赛房 #102</span>
          <span style="color: #2ecc71;">在线匹配中...</span>
        </div>
        <div class="room-card">
          <span>🤖 人机搏击训练室 #001</span>
          <span style="color: var(--primary);">常驻训练</span>
        </div>
      `)}triggerPKMatching(){const t=document.getElementById("radar-overlay");if(!t)return;t.style.display="flex",this.modalMgr.closeAllModals(),this.radarTimerVal=0;const e=document.getElementById("radar-timer");e&&(e.textContent="0"),this.matchingInterval=setInterval(()=>{this.radarTimerVal++,e&&(e.textContent=this.radarTimerVal),this.radarTimerVal>=3&&(this.cancelPKMatching(),this.startPKMatch(!0))},1e3)}cancelPKMatching(){this.matchingInterval&&(clearInterval(this.matchingInterval),this.matchingInterval=null);const t=document.getElementById("radar-overlay");t&&(t.style.display="none")}startPKMatch(t=!0){if(this.currentMap!=="pk_arena"){this.switchMap("pk_arena");return}(this.isHomeBuildActive||document.getElementById("home-edit-hud")&&document.getElementById("home-edit-hud").style.display==="flex")&&this.exitHomeEditMode(!1),this.isPKActive=!0,this.pkOpponentType=t?"robot":"player",(!this.pkArenaColliders||this.pkArenaColliders.length===0)&&this.buildPKPlatform(),this.player&&(this.player.colliders=this.pkArenaColliders||[]),this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!1),this.interactMgr.generator={interactables:[]},document.getElementById("pk-hud").style.display="flex",this.playerHP=100,this.opponentHP=100,this.updatePKHPUI(),this.playerEquippedWeapon=null,this.playerWeapon3D&&(this.player.group.remove(this.playerWeapon3D),this.playerWeapon3D=null),this.activeBombs=[],this.activeExplosions=[],this.bombCooldownActive=!1;const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");e&&(e.style.display="none");const n=document.getElementById("pk-debug-info");if(n&&(n.style.display="block",n.textContent="准备战斗，请先走向擂台周边的武器架拾取武器..."),t){this.opponent3D&&(this.pkArenaGroup.remove(this.opponent3D),this.opponent3D=null);const i=new dt,s=new _(new G(.4,.4,.4),new Y({color:15158332}));s.position.y=1.35,i.add(s);const a=new _(new G(.5,.7,.3),new Y({color:2899536}));a.position.y=.8,i.add(a);const r=new nt(.08,.08,.45,8),c=new _(r,new Y({color:3426654}));c.position.set(-.16,.225,0),i.add(c);const l=c.clone();l.position.x=.16,i.add(l),i.position.set(5.5,.6,0),this.pkArenaGroup.add(i),this.opponent3D=i,this.opponentVelocity=new L(0,0,0),this.opponentIsGrounded=!0,this.opponentEquippedWeapon="sword";const h=this.createSword3D();h.position.set(.35,.8,.1),h.rotation.x=Math.PI/2,this.opponent3D.add(h),this.opponentWeapon3D=h}}updatePKHPUI(){const t=document.getElementById("pk-hud-p1-hp"),e=document.getElementById("pk-hud-p2-hp"),n=document.getElementById("pk-hud-p1-hp-text"),i=document.getElementById("pk-hud-p2-hp-text");t&&(t.style.width=`${this.playerHP}%`),e&&(e.style.width=`${this.opponentHP}%`),n&&(n.textContent=`${this.playerHP} / 100`),i&&(i.textContent=`${this.opponentHP} / 100`)}playDamageBubble(t,e,n=!1){const i=document.createElement("div");i.className="damage-bubble",n?(i.style.color="#ff1744",i.textContent=`-${e} HP`):(i.style.color="#ffeb3b",i.textContent=`-${e}`),document.body.appendChild(i),(()=>{if(!this.camera||!i.parentElement)return;const a=t.clone().add(new L(0,n?1:1.3,0));a.project(this.camera);const r=(a.x*.5+.5)*window.innerWidth,c=(-(a.y*.5)+.5)*window.innerHeight;i.style.left=`${r}px`,i.style.top=`${c}px`})(),setTimeout(()=>{i.classList.add("fade-up")},30),setTimeout(()=>{i.remove()},750)}showScreenFlash(){let t=document.getElementById("player-hurt-flash");t||(t=document.createElement("div"),t.id="player-hurt-flash",document.body.appendChild(t)),t.style.opacity="1",setTimeout(()=>{t.style.opacity="0"},120)}playerPerformAttack(){if(!(!this.isPKActive||this.playerHP<=0||!this.playerEquippedWeapon))if(this.playerEquippedWeapon==="bomb"){if(this.bombCooldownActive){if(this.playCustomSound(150,.1,"sine",.1),window.showMockToast){let t=document.querySelector(".mock-toast");t&&t.remove();const e=document.createElement("div");e.className="mock-toast",e.textContent="炸弹正在冷却中！💣",document.body.appendChild(e),setTimeout(()=>e.classList.add("show"),50),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>e.remove(),300)},1200)}return}this.triggerBombCooldown(),this.throwBomb()}else this.playerWeapon3D&&(this.playerWeapon3D.rotation.z=-Math.PI/2,setTimeout(()=>{this.playerWeapon3D&&(this.playerWeapon3D.rotation.z=0)},150)),this.playCustomSound(260,.1,"triangle",.15),this.performMeleeAttack()}performMeleeAttack(){const t=this.player.position,e=this.opponent3D.position,n=t.x-e.x,i=t.z-e.z,s=Math.sqrt(n*n+i*i);if(console.log(`[PK Damage Check] Player: (${t.x.toFixed(2)}, ${t.z.toFixed(2)}), Robot: (${e.x.toFixed(2)}, ${e.z.toFixed(2)}), Plane Distance: ${s.toFixed(2)}`),s<=4.5){let a=20,r=1.8;this.playerEquippedWeapon==="sword"?(a=20,r=2):this.playerEquippedWeapon==="hammer"&&(a=10,r=7.5),this.opponentHP=Math.max(0,this.opponentHP-a),this.updatePKHPUI(),this.playDamageBubble(e,a,!1),this.opponent3D&&(this.opponent3D.traverse(l=>{l.isMesh&&l.material&&(l.userData.origColor===void 0&&(l.userData.origColor=l.material.color.getHex()),l.material.color.setHex(16724787))}),setTimeout(()=>{this.opponent3D&&this.opponent3D.traverse(l=>{l.isMesh&&l.material&&l.userData.origColor!==void 0&&l.material.color.setHex(l.userData.origColor)})},150));const c=new L().subVectors(e,t).normalize();c.y=.4,this.opponentVelocity.addScaledVector(c,r*2.8),this.playCustomSound(120,.15,"sawtooth",.1),this.opponentHP<=0&&this.endPKBattle(!0)}else{console.log(`[PK Damage Check] MISS - Distance ${s.toFixed(2)}m is greater than 4.5m`);const a=document.getElementById("pk-debug-info");if(a){const r=document.createElement("span");r.style.color="#ff5722",r.style.fontWeight="bold",r.style.marginLeft="10px",r.textContent="[MISS - 距离过远]",a.appendChild(r),setTimeout(()=>r.remove(),1200)}}}triggerBombCooldown(){this.bombCooldownActive=!0;let t=5;const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack"),n=()=>{e&&(e.disabled=!0,e.style.opacity="0.5",e.innerHTML=`<span style="font-size: 1.1rem; font-weight: bold; color: #ffeb3b; font-family: system-ui; display: flex; align-items: center; justify-content: center;">💣 ${t}s</span>`)};n();const i=setInterval(()=>{if(this.playerEquippedWeapon!=="bomb"){clearInterval(i),this.bombCooldownActive=!1,e&&(e.disabled=!1,e.style.opacity="1");return}t--,t<=0?(clearInterval(i),this.bombCooldownActive=!1,this.playerEquippedWeapon==="bomb"&&this.playerWeapon3D&&(this.playerWeapon3D.visible=!0),e&&(e.disabled=!1,e.style.opacity="1",e.innerHTML=`
<svg style="display: flex;" class="lucide lucide-bomb" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="11" cy="13" r="9" />
  <path d="m19.5 4.5-3.5 3.5" />
  <path d="m21 3-2.5 2.5" />
  <path d="M19 8.5c.5-.5 1-1.5.5-2.5-.5-.5-1.5 0-2 .5" />
</svg>`)):n()},1e3)}throwBomb(){if(!this.player)return;this.playCustomSound(350,.1,"sine",.1),this.playerWeapon3D&&(this.playerWeapon3D.visible=!1);const t=new L(0,0,1).applyQuaternion(this.player.group.quaternion).normalize(),e=this.createBomb3D(),n=this.player.position.clone().add(t.clone().multiplyScalar(.5));n.y+=1,e.position.copy(n),this.scene.add(e);const s=t.clone().multiplyScalar(9);s.y=4;const a={mesh:e,velocity:s,position:n,timeElapsed:0,maxLifetime:1.5};this.activeBombs||(this.activeBombs=[]),this.activeBombs.push(a)}updateActiveBombs(t){if(!this.activeBombs||this.activeBombs.length===0)return;const e=9.8,n=.6;for(let i=this.activeBombs.length-1;i>=0;i--){const s=this.activeBombs[i];s.timeElapsed+=t,s.velocity.y-=e*t,s.position.addScaledVector(s.velocity,t),s.mesh.position.copy(s.position),s.mesh.rotation.x+=.05,s.mesh.rotation.y+=.05;let a=!1;if(s.position.y<=n&&Math.sqrt(s.position.x*s.position.x+s.position.z*s.position.z)<8&&(s.position.y=n,a=!0),this.opponent3D&&!a){const r=this.opponent3D.position;s.position.distanceTo(r)<.8&&(a=!0)}s.timeElapsed>=s.maxLifetime&&(a=!0),a&&(this.explodeBomb(s.position),this.scene.remove(s.mesh),this.activeBombs.splice(i,1))}}explodeBomb(t){if(this.playCustomSound(180,.35,"sawtooth",.25),setTimeout(()=>{this.playCustomSound(60,.2,"sine",.3)},50),this.createExplosionEffects(t),this.opponent3D&&this.isPKActive){const e=this.opponent3D.position;if(t.distanceTo(e)<=3.5){const a=e.clone().sub(t);a.y=0,a.normalize(),this.opponentVelocity.addScaledVector(a,6),this.opponentVelocity.y=3.5,this.opponentIsGrounded=!1,this.opponentHP=Math.max(0,this.opponentHP-50),this.updatePKHPUI(),this.playDamageBubble(e,50,!1),this.opponent3D.traverse(c=>{c.isMesh&&c.material&&(c.userData.origColor===void 0&&(c.userData.origColor=c.material.color.getHex()),c.material.color.setHex(16724787))}),setTimeout(()=>{this.opponent3D&&this.opponent3D.traverse(c=>{c.isMesh&&c.material&&c.userData.origColor!==void 0&&c.material.color.setHex(c.userData.origColor)})},150),this.opponentHP<=0&&this.endPKBattle(!0)}}}createExplosionEffects(t){const e=new Tt(.2,8,8),n=new Lt({color:16754470,transparent:!0,opacity:.9,depthWrite:!1}),i=new _(e,n);i.position.copy(t),this.scene.add(i);const s={mesh:i,type:"ball",scaleSpeed:9,opacitySpeed:2.2,scale:1,opacity:.9};this.activeExplosions||(this.activeExplosions=[]),this.activeExplosions.push(s);const a=12,r=new G(.08,.08,.08),c=[16727296,16761095,7697781];for(let l=0;l<a;l++){const h=c[Math.floor(Math.random()*c.length)],d=new Y({color:h,transparent:!0,opacity:.9,flatShading:!0}),u=new _(r,d);u.position.copy(t);const f=Math.random()*Math.PI*2,g=1.5+Math.random()*3.5,y=new L(Math.cos(f)*g,2.5+Math.random()*3,Math.sin(f)*g);this.scene.add(u);const m={mesh:u,type:"particle",velocity:y,opacity:.9,rotationSpeed:new L(Math.random()*10,Math.random()*10,Math.random()*10)};this.activeExplosions.push(m)}}updateExplosionEffects(t){if(!this.activeExplosions||this.activeExplosions.length===0)return;const e=9.8;for(let n=this.activeExplosions.length-1;n>=0;n--){const i=this.activeExplosions[n];i.type==="ball"?(i.scale+=i.scaleSpeed*t,i.opacity-=i.opacitySpeed*t,i.mesh.scale.set(i.scale,i.scale,i.scale),i.mesh.material.opacity=Math.max(0,i.opacity),i.opacity<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.activeExplosions.splice(n,1))):i.type==="particle"&&(i.velocity.y-=e*t,i.mesh.position.addScaledVector(i.velocity,t),i.mesh.rotation.x+=i.rotationSpeed.x*t,i.mesh.rotation.y+=i.rotationSpeed.y*t,i.mesh.rotation.z+=i.rotationSpeed.z*t,i.opacity-=1.8*t,i.mesh.material.opacity=Math.max(0,i.opacity),i.opacity<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.activeExplosions.splice(n,1)))}}endPKBattle(t=!0){if(!this.isPKActive)return;this.isPKActive=!1,this.player&&(this.player.position.set(0,.6+.1,-6),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position)),this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!0);const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");e&&(e.style.display="none");let n=t?20:-10;this.gameData.pkPoints+n<0&&(n=-this.gameData.pkPoints),this.gameData.pkPoints+=n,t?this.gameData.pkWins++:this.gameData.pkLoses++,this.saveGameData();const i=t?"🎉 荣耀胜利！":"💀 惜败对手",s=t?"成功击败挑战者，天梯积分 +20！":"不幸败于挑战者，天梯积分 -10。",a=document.createElement("div");a.style.position="fixed",a.style.inset="0",a.style.zIndex="500",a.style.background="rgba(15,17,21,0.85)",a.style.backdropFilter="blur(20px)",a.style.webkitBackdropFilter="blur(20px)",a.style.display="flex",a.style.alignItems="center",a.style.justifyContent="center",a.style.color="white",a.innerHTML=`
      <div class="modal-card settle-card">
        <h2 class="settle-title" style="color: ${t?"#d97706":"#e74c3c"};">${i}</h2>
        <p class="settle-desc">${s}</p>
        <div class="settle-score-box">
          <span>当前天梯积分: <strong class="settle-score-val">${this.gameData.pkPoints}</strong></span>
        </div>
        <div class="settle-buttons">
          <button class="hud-btn settle-btn-action" id="btn-settle-retry">继续挑战 ⚔️</button>
          <button class="hud-btn settle-btn-secondary" id="btn-settle-close">返回群岛 🏝️</button>
        </div>
      </div>
    `,document.body.appendChild(a),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalOpened=="function"&&window.parent.appShell.onModalOpened("pk_settle");const r=a.querySelector("#btn-settle-close");r&&r.addEventListener("click",()=>{a.remove(),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed("pk_settle"),this.switchMap("island"),document.getElementById("pk-hud").style.display="none",document.getElementById("pk-debug-info")&&(document.getElementById("pk-debug-info").style.display="none")});const c=a.querySelector("#btn-settle-retry");c&&c.addEventListener("click",()=>{a.remove(),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed("pk_settle"),this.startPKMatch(!0)})}initMapUI(){document.querySelectorAll("#modal-map .map-node").forEach(e=>{e.addEventListener("click",()=>{const n=e.getAttribute("data-map");n&&(this.playCustomSound(440,.08,"sine",.15),setTimeout(()=>{this.playCustomSound(554.37,.08,"sine",.15)},80),this.modalMgr&&this.modalMgr.closeModal("map"),this.switchMap(n))})})}initBagUI(){const t=document.querySelectorAll("#modal-bag .bag-tabactive");t.forEach(e=>{e.addEventListener("click",n=>{t.forEach(i=>i.classList.remove("active")),e.classList.add("active"),this.refreshBag(e.getAttribute("data-tab"))})})}refreshBag(t="seed"){this.updateBaseUI();const e=document.getElementById("bag-grid"),n=document.getElementById("bag-item-detail");if(!e||!n)return;e.innerHTML="";const i=this.gameData.backpack.filter(s=>s.type===t);for(let s=0;s<20;s++){const a=document.createElement("div");a.className="bag-item-box";const r=i[s];if(r&&r.count>0){const c=`q-${r.quality||"white"}`;a.classList.add(c);let l="📦";r.id.includes("seed")?l="🌱":r.id==="sunflower_crop"?l="🌻":r.id==="strawberry_crop"?l="🍓":r.id.includes("painting")?l="🖼️":r.id.includes("tree")?l="🎄":r.id.includes("sofa")?l="🛋️":r.id.includes("swing")&&(l="🎪"),a.innerHTML=`
          <span style="font-size: 1.8rem;">${l}</span>
          <span class="bag-item-count">${r.count}</span>
        `,a.addEventListener("click",()=>{document.querySelectorAll(".bag-item-box.active").forEach(h=>h.classList.remove("active")),a.classList.add("active"),this.showBagItemDetail(r)})}else a.innerHTML="";e.appendChild(a)}n.querySelector(".item-detail-empty").style.display="flex",n.querySelector(".item-detail-content").style.display="none"}showBagItemDetail(t){const e=document.getElementById("bag-item-detail"),n=e.querySelector(".item-detail-empty"),i=e.querySelector(".item-detail-content");n.style.display="none",i.style.display="flex";let s="📦";t.id.includes("seed")?s="🌱":t.id==="sunflower_crop"?s="🌻":t.id==="strawberry_crop"?s="🍓":t.id.includes("painting")?s="🖼️":t.id.includes("tree")?s="🎄":t.id.includes("sofa")?s="🛋️":t.id.includes("swing")&&(s="🎪");const a={white:"普普通通",green:"翠绿新生",blue:"蔚蓝奇迹",purple:"秘境紫光",gold:"傲视至尊"},r=`bq-${t.quality||"white"}`,c=a[t.quality||"white"];let l="出售",h=!1,d=10;t.id==="sunflower_crop"?(d=20,h=!1):t.id==="strawberry_crop"?(d=45,h=!1):t.id.includes("seed")?(h=!0,l="去农田种植"):(h=!0,l="摆放家具");const f=t.count>1?`
      <div class="bag-sell-range-container" style="display: flex; flex-direction: column; gap: 4px; width: 100%; margin-bottom: 6px; padding: 0 10px; box-sizing: border-box;">
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.72rem; color: var(--text-muted);">
          <span>选择出售数量</span>
          <span class="range-val" style="font-weight: bold; color: var(--primary);"><strong id="sell-count-label">1</strong> / ${t.count}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; width: 100%;">
          <button class="bag-range-btn" id="btn-range-minus">-</button>
          <input type="range" id="sell-count-range" min="1" max="${t.count}" value="1" style="flex: 1; height: 6px; background: rgba(0,0,0,0.1); border-radius: 4px; outline: none; cursor: pointer; accent-color: var(--primary);" />
          <button class="bag-range-btn" id="btn-range-plus">+</button>
        </div>
      </div>
    `:"";i.innerHTML=`
      <div style="font-size: 3.5rem; margin-top: 20px;">${s}</div>
      <h3 style="font-size: 1.1rem; font-weight: bold; color: white; margin-top: 10px;">${t.name}</h3>
      <span class="bag-right-quality-badge ${r}">${c}</span>
      <p style="font-size: 0.75rem; color: var(--text-muted); line-height: 1.4; padding: 0 10px; margin-top: 12px; flex-grow: 1;">${t.desc}</p>
      
      <div style="width: 100%; display: flex; flex-direction: column; gap: 10px; margin-top: auto;">
        ${f}
        ${h?`<button class="hud-btn" id="btn-bag-use" style="width: 100%; padding: 8px 0; background: rgba(100, 255, 100, 0.15); border-color: rgba(100,255,100,0.3); color: #fff;">${l}</button>`:""}
        <button class="hud-btn" id="btn-bag-sell" style="width: 100%; padding: 8px 0; background: rgba(255, 140, 105, 0.1); border-color: rgba(255, 140, 105, 0.3); color: #fff;">出售 (获得 ${d}金币)</button>
      </div>
    `;const g=i.querySelector("#btn-bag-sell"),y=i.querySelector("#sell-count-range"),m=i.querySelector("#sell-count-label"),p=i.querySelector("#btn-range-minus"),x=i.querySelector("#btn-range-plus");let v=1;const M=T=>{v=Math.max(1,Math.min(t.count,T)),y&&(y.value=v),m&&(m.textContent=v),g&&(g.textContent=`出售 (获得 ${v*d}金币)`)};y&&y.addEventListener("input",T=>{M(parseInt(T.target.value)||1)}),p&&p.addEventListener("click",T=>{T.stopPropagation(),M(v-1)}),x&&x.addEventListener("click",T=>{T.stopPropagation(),M(v+1)}),g&&g.addEventListener("click",T=>{T.stopPropagation(),this.sellBagItem(t.id,d,v,T.clientX,T.clientY)});const R=i.querySelector("#btn-bag-use");R&&R.addEventListener("click",T=>{T.stopPropagation(),this.modalMgr.closeAllModals(),t.id.includes("seed")?this.switchMap("farm",new L(0,.7,-8)):this.switchMap("house",null,"home")})}sellBagItem(t,e,n,i,s){const a=this.gameData.backpack.find(c=>c.id===t);if(!a||a.count<n)return;a.count-=n;const r=e*n;this.gameData.coins+=r,this.saveGameData(),this.showCoinFloatText(r,i,s),this.refreshBag(document.querySelector("#modal-bag .bag-tabactive.active").getAttribute("data-tab"))}initHomeUI(){const t=document.getElementById("btn-enter-edit-mode");t&&t.addEventListener("click",s=>{s.stopPropagation(),this.modalMgr.closeAllModals(),this.enterHomeEditMode()});const e=document.getElementById("btn-edit-cancel");e&&e.addEventListener("click",s=>{s.stopPropagation(),this.exitHomeEditMode(!1)});const n=document.getElementById("btn-edit-save");n&&n.addEventListener("click",s=>{s.stopPropagation(),this.exitHomeEditMode(!0)});const i=document.getElementById("btn-edit-rotate");i&&i.addEventListener("click",s=>{s.stopPropagation(),this.rotateEditFurniture()}),window.addEventListener("keydown",s=>{s.key.toLowerCase()==="r"&&this.rotateEditFurniture()})}initExitChoicesUI(){document.querySelectorAll(".exit-choice-btn").forEach(e=>{e.addEventListener("click",n=>{n.stopPropagation();const i=e.getAttribute("data-target");this.modalMgr.closeModal("exit"),i==="island"?this.switchMap("island"):i==="farm"?this.switchMap("farm"):i==="pk"&&this.switchMap("pk_arena")})})}refreshHome(){const t=document.getElementById("furniture-shop-grid");if(!t)return;t.innerHTML="",[{id:"painting_1",type:"painting",name:"浮空岛日落挂画",price:50,emoji:"🖼️"},{id:"tree_1",type:"christmas_tree",name:"闪烁圣诞树",price:100,emoji:"🎄"},{id:"sofa_1",type:"rabbit_sofa",name:"粉嫩兔子沙发",price:150,emoji:"🛋️"},{id:"swing_1",type:"swing_chair",name:"室内网兜秋千",price:200,emoji:"🎪"}].forEach(n=>{const i=document.createElement("div");i.className="furniture-shop-card";const s=this.gameData.ownedFurnitures.includes(n.id);let a="";s?a=`<button class="hud-btn" data-action="place" data-id="${n.id}" style="width: 100%; font-size: 0.75rem; background: rgba(100, 255, 100, 0.15); border-color: rgba(100,255,100,0.3);">摆放家具</button>`:a=`<button class="hud-btn" data-action="buy" data-id="${n.id}" style="width: 100%; font-size: 0.75rem;">购买 (${n.price}金币)</button>`,i.innerHTML=`
        <div style="font-size: 2.2rem;">${n.emoji}</div>
        <div style="font-size: 0.8rem; font-weight: bold; color: #fff;">${n.name}</div>
        ${a}
      `;const r=i.querySelector('button[data-action="buy"]');r&&r.addEventListener("click",l=>{l.stopPropagation(),this.buyFurniture(n,l.clientX,l.clientY)});const c=i.querySelector('button[data-action="place"]');c&&c.addEventListener("click",l=>{l.stopPropagation(),this.modalMgr.closeAllModals(),this.startPlacingFurniture(n.type,n.id)}),t.appendChild(i)})}buyFurniture(t,e,n){if(this.gameData.coins<t.price){alert("金币不足，无法购买该家具！");return}this.gameData.coins-=t.price,this.gameData.ownedFurnitures.push(t.id),this.gameData.backpack.push({id:t.id,name:t.name,type:"decor",count:1,quality:"purple",desc:"购买于家园工坊的精美家具模型。进入家园编辑模式即可随意定位摆放它！"}),this.saveGameData(),this.refreshHome(),this.showCoinFloatText(-t.price,e,n)}enterHomeEditMode(){if(this.currentMap!=="house"){this.switchMap("house",null,null,"edit");return}this.isHomeBuildActive=!0,this.player.controlsLocked=!0,this.player.resetInputs(),this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV,position:this.camera.position.clone()},this.player.cameraDistance=8.5,this.player.cameraAngleV=Math.PI/2.1,this.player.cameraAngleH=Math.PI,this.editGrid=new qm(12,24,5227511,4473924),this.editGrid.position.set(0,.13,5),this.scene.add(this.editGrid),document.getElementById("home-edit-hud").style.display="flex"}startPlacingFurniture(t,e){this.enterHomeEditMode(),this.pendingFurnitureId=e,this.pendingFurnitureType=t,this.editPreviewGroup=this.createFurnitureModel(t),this.editPreviewGroup.position.set(0,.12,5),this.editPreviewGroup.traverse(n=>{n.isMesh&&(n.material=n.material.clone(),n.material.transparent=!0,n.material.opacity=.55,n.material.color.setHex(5227511))}),this.scene.add(this.editPreviewGroup),this.editFurnitureRotationY=0}rotateEditFurniture(){!this.isHomeBuildActive||!this.editPreviewGroup||(this.editFurnitureRotationY+=Math.PI/2,this.editPreviewGroup.rotation.y=this.editFurnitureRotationY,this.playCustomSound(400,.08,"sine",.05))}exitHomeEditMode(t=!0){if(this.isHomeBuildActive){if(this.isHomeBuildActive=!1,this.cameraSavedState&&(this.player.cameraDistance=this.cameraSavedState.distance,this.player.cameraAngleH=this.cameraSavedState.angleH,this.player.cameraAngleV=this.cameraSavedState.angleV,this.player.controlsLocked=!1),this.editGrid&&(this.scene.remove(this.editGrid),this.editGrid=null),t&&this.editPreviewGroup&&this.pendingFurnitureId){const e=this.editPreviewGroup.position;this.gameData.homeFurnitures.push({id:this.pendingFurnitureId+"_"+Date.now(),type:this.pendingFurnitureType,x:e.x,y:e.y,z:e.z,ry:this.editFurnitureRotationY});const n=this.gameData.backpack.find(i=>i.id===this.pendingFurnitureId);n&&(n.count--,n.count<=0&&(this.gameData.backpack=this.gameData.backpack.filter(i=>i.id!==this.pendingFurnitureId))),this.saveGameData(),this.renderHomeFurnitures(),this.playCustomSound(494,.2,"sine",.1)}this.editPreviewGroup&&(this.scene.remove(this.editPreviewGroup),this.editPreviewGroup=null),this.pendingFurnitureId=null,this.pendingFurnitureType=null,document.getElementById("home-edit-hud").style.display="none"}}renderHomeFurnitures(){this.houseGen&&(this.houseGen.furnituresGroup||(this.houseGen.furnituresGroup=new dt,this.houseGen.group.add(this.houseGen.furnituresGroup)),this.houseGen.furnituresGroup.clear(),this.gameData.homeFurnitures.forEach(t=>{const e=this.createFurnitureModel(t.type);e.position.set(t.x,t.y,t.z),e.rotation.y=t.ry,this.houseGen.furnituresGroup.add(e)}))}updateGameSystemsFrame(t,e){if(this.updateActivePlotForRadialMenu(),this.updateFarmPlotsFrame(),this.updatePKBattleFrame(t),this.updateHomeBuildFrame(),this.updatePKHallAnimations(t,e),this.currentMap==="farm"&&this.player&&this.player.position.y<-3.5&&(this.player.position.set(0,.6+.1,-8),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),window.showMockToast)){let n=document.querySelector(".mock-toast");n&&n.remove();const i=document.createElement("div");i.className="mock-toast",i.textContent="小心！不要掉入农场外的浮空深渊哦 ☁️",document.body.appendChild(i),setTimeout(()=>i.classList.add("show"),50),setTimeout(()=>{i.classList.remove("show"),setTimeout(()=>i.remove(),300)},2e3)}}updatePKHallAnimations(t,e){if(this.currentMap==="pk_arena"&&(this.pkCrystalMesh&&this.pkCrystalMesh.visible&&(this.pkCrystalMesh.rotation.y+=.015,this.pkCrystalMesh.position.y=1.35+Math.sin(e*.002)*.12),this.swordPreview&&(this.swordPreview.rotation.y+=.015,this.swordPreview.position.y=1.45+Math.sin(e*.0025)*.06),this.hammerPreview&&(this.hammerPreview.rotation.y+=.015,this.hammerPreview.position.y=1.45+Math.cos(e*.0025)*.06),this.bombPreview&&(this.bombPreview.rotation.y+=.015,this.bombPreview.position.y=1.45+Math.sin(e*.0025+1)*.06),!this.isPKActive&&(this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!0),this.player&&this.player.position.y<-3.5&&(this.player.position.set(0,.6+.1,-6),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),window.showMockToast)))){let n=document.querySelector(".mock-toast");n&&n.remove();const i=document.createElement("div");i.className="mock-toast",i.textContent="小心！不要跌落入云海深渊哦 ☁️",document.body.appendChild(i),setTimeout(()=>i.classList.add("show"),50),setTimeout(()=>{i.classList.remove("show"),setTimeout(()=>i.remove(),300)},2200)}}updateFarmPlotsFrame(){const t=document.getElementById("farm-bubbles-container");if(!t)return;const e=this.farmPlots3D;if(!e||!this.gameData||this.currentMap!=="farm"){t.innerHTML="";return}this.gameData.farmPlots.forEach((n,i)=>{const s=e[i];if(s){if(n.status!=="empty"&&s.plantGroup.children.length===0&&this.recreateCrop3D(i),n.status==="growing"){const a=n.seedId==="sunflower_seed"?30:60,r=Math.floor((Date.now()-n.plantTime)/1e3);if(r>=a)n.status="ready",this.saveGameData(),this.refreshFarm(),this.recreateCrop3D(i);else{const l=.15+r/a*.85;s.plantGroup.scale.set(l,l,l)}}if(n.status!=="empty"&&n.seedId){let a=document.getElementById(`crop-bubble-${i}`);a||(a=document.createElement("div"),a.id=`crop-bubble-${i}`,a.className="farm-crop-bubble",t.appendChild(a));const r=n.seedId==="sunflower_seed"?30:60,c=Math.floor((Date.now()-n.plantTime)/1e3),l=Math.max(0,r-c);if(n.status==="ready")a.innerHTML="🌾 可收割",a.style.background="linear-gradient(135deg, #27ae60, #1e824c)",a.style.borderColor="rgba(255,255,255,0.3)";else{const f=n.seedId==="sunflower_seed"?"🌻":"🍓";a.innerHTML=`${f} ⏳ ${l}s`,a.style.background="rgba(15,17,21,0.85)",a.style.borderColor="rgba(255,255,255,0.12)"}const h=new L(s.x,1.3,s.z);h.project(this.camera);const d=(h.x*.5+.5)*window.innerWidth,u=(-(h.y*.5)+.5)*window.innerHeight;a.style.left=`${d}px`,a.style.top=`${u}px`,a.style.opacity="1"}else{const a=document.getElementById(`crop-bubble-${i}`);a&&a.remove()}}})}updatePKBattleFrame(t){if(this.updateActiveBombs(t),this.updateExplosionEffects(t),!this.isPKActive||!this.opponent3D)return;if(this.player.position.y<-3.5){this.endPKBattle(!1);return}if(this.opponent3D.position.y<-3.5){this.endPKBattle(!0);return}const e=this.opponent3D,n=this.player.position;if(this.opponentIsGrounded||(this.opponentVelocity.y-=9.8*t),e.position.addScaledVector(this.opponentVelocity,t),this.opponentVelocity.x*=.88,this.opponentVelocity.z*=.88,e.position.y<=.6?Math.sqrt(e.position.x*e.position.x+e.position.z*e.position.z)<8?(e.position.y=.6,this.opponentVelocity.y=0,this.opponentIsGrounded=!0):this.opponentIsGrounded=!1:this.opponentIsGrounded=!1,this.opponentIsGrounded&&this.playerHP>0){const r=e.position.distanceTo(n),c=n.x-e.position.x,l=n.z-e.position.z,h=Math.atan2(c,l);e.rotation.y=h,r>1.8?e.translateZ(2.4*t):Math.random()<.018&&this.opponentPerformAttack()}const i=document.getElementById("pk-debug-info");i&&(this.playerEquippedWeapon?i.style.display="none":(i.style.display="block",i.innerHTML='<span style="font-weight: bold; color: #ffeb3b; animation: settleBlink 1.2s infinite;">⚠️ 尚未装备武器！请走向擂台周边的武器架拾取武器 ⚔️</span>'));const s=this.player.position;[{x:-7.5,z:0,weapon:"sword"},{x:7.5,z:0,weapon:"hammer"},{x:0,z:6.8,weapon:"bomb"}].forEach(r=>{if(s.distanceTo(new L(r.x,.6,r.z))<1.6&&this.playerEquippedWeapon!==r.weapon){const l=r.weapon;this.playerEquippedWeapon=l;const h=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");if(h){h.style.display="flex";const u={sword:`
<svg style="display: flex;" class="lucide lucide-swords" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5" />
  <line x1="13" x2="19" y1="19" y2="13" />
  <line x1="16" x2="20" y1="16" y2="20" />
  <line x1="19" x2="21" y1="21" y2="19" />
  <polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5" />
  <line x1="5" x2="9" y1="14" y2="18" />
  <line x1="7" x2="4" y1="17" y2="20" />
  <line x1="3" x2="5" y1="19" y2="21" />
</svg>`,hammer:`
<svg style="display: flex;" class="lucide lucide-hammer" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m15 5 4 4" />
  <path d="M21.5 12H16c-.5 0-1-.5-1-1V4.5L9 9.5c-.5.5-.5 1.5 0 2l11 11c.5.5 1.5.5 2 0z" />
  <path d="m2.1 21.9 10.3-10.3" />
</svg>`,bomb:`
<svg style="display: flex;" class="lucide lucide-bomb" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="11" cy="13" r="9" />
  <path d="m19.5 4.5-3.5 3.5" />
  <path d="m21 3-2.5 2.5" />
  <path d="M19 8.5c.5-.5 1-1.5.5-2.5-.5-.5-1.5 0-2 .5" />
</svg>`};h.innerHTML=u[l]||u.sword}this.playerWeapon3D&&this.player.group.remove(this.playerWeapon3D);let d;if(l==="sword"?d=this.createSword3D():l==="hammer"?d=this.createHammer3D():d=this.createBomb3D(),d.position.set(.32,.8,.1),d.rotation.x=Math.PI/2,this.player.group.add(d),this.playerWeapon3D=d,this.playCustomSound(600,.15,"sine",.1),window.showMockToast){let u=document.querySelector(".mock-toast");u&&u.remove();const f=document.createElement("div");f.className="mock-toast";const g={sword:"长剑 ⚔️",hammer:"大锤 🔨",bomb:"炸弹 💣"};f.textContent=`已装备武器：${g[l]}！`,document.body.appendChild(f),setTimeout(()=>f.classList.add("show"),50),setTimeout(()=>{f.classList.remove("show"),setTimeout(()=>f.remove(),300)},1800)}}})}opponentPerformAttack(){if(this.opponentHP<=0||this.playerHP<=0)return;if(this.opponentWeapon3D&&(this.opponentWeapon3D.rotation.z=-Math.PI/2,setTimeout(()=>{this.opponentWeapon3D&&(this.opponentWeapon3D.rotation.z=0)},150)),this.playCustomSound(220,.1,"sawtooth",.1),this.opponent3D.position.distanceTo(this.player.position)<=2.2){this.playerHP=Math.max(0,this.playerHP-15),this.updatePKHPUI(),this.showScreenFlash(),this.playDamageBubble(this.player.position,15,!0);const n=new L().subVectors(this.player.position,this.opponent3D.position).normalize();n.y=.35,this.player.velocity.addScaledVector(n,4.2),this.playCustomSound(100,.2,"sine",.15),this.playerHP<=0&&this.endPKBattle(!1)}}updateHomeBuildFrame(){if(!this.isHomeBuildActive||!this.editPreviewGroup)return;const t=new ct(0,0),e=new Xm;e.setFromCamera(t,this.camera);const n=e.intersectObjects(this.scene.children,!0);let i=null;for(let s=0;s<n.length;s++){const a=n[s];if(a.point&&Math.abs(a.point.y-.12)<.2){i=a.point;break}}if(i){let s=Math.round(i.x*2)/2,a=Math.round(i.z*2)/2;s=Math.max(-4,Math.min(4,s)),a=Math.max(1,Math.min(9,a)),this.editPreviewGroup.position.set(s,.12,a)}}buildFarmPlatform(){this.farmGroup.clear();const t=new nt(12,12.5,1.2,32),e=new Y({color:5025616,flatShading:!0}),n=new _(t,e);n.position.y=0,n.receiveShadow=!0,n.castShadow=!0,this.farmGroup.add(n);const i=new nt(12.5,12,1.5,32),s=new Y({color:6111287,flatShading:!0}),a=new _(i,s);a.position.y=-1.35,this.farmGroup.add(a),this.farmPlots3D=[];const r=new Y({color:4073251,flatShading:!0}),c=new Y({color:7951688,flatShading:!0}),l=[{x:-3.6,z:-2.2},{x:0,z:-2.2},{x:3.6,z:-2.2},{x:-3.6,z:2.2},{x:0,z:2.2},{x:3.6,z:2.2}];l.forEach((y,m)=>{const p=new dt;p.position.set(y.x,.6,y.z);const x=new _(new G(2.4,.02,2.4),r);x.receiveShadow=!0,p.add(x);const v=new _(new G(2.6,.1,.1),c);v.position.set(0,.05,1.25),v.castShadow=!0,p.add(v);const M=v.clone();M.position.z=-1.25,p.add(M);const R=new _(new G(.1,.1,2.4),c);R.position.set(1.25,.05,0),R.castShadow=!0,p.add(R);const T=R.clone();T.position.x=-1.25,p.add(T);const E=new dt;E.position.set(0,0,0),p.add(E),this.farmGroup.add(p),this.farmPlots3D.push({x:y.x,z:y.z,plantGroup:E})});const h=new nt(.12,.16,1,6),d=new Y({color:5125166}),u=new Ui(.6),f=new Y({color:1793568,flatShading:!0});[{x:-8,z:-8},{x:8,z:-8},{x:-8,z:8},{x:8,z:8}].forEach(y=>{const m=new dt;m.position.set(y.x,.6,y.z);const p=new _(h,d);p.position.y=.5,p.castShadow=!0,m.add(p);const x=new _(u,f);x.position.y=1.1,x.castShadow=!0,m.add(x),this.farmGroup.add(m)}),this.farmColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:12}],this.farmInteractables=l.map((y,m)=>({id:`farm_plot_${m}`,name:"农田格子",x:y.x,y:.6,z:y.z,triggerRadius:1.8}))}buildPKPlatform(){this.pkArenaGroup.clear();const t=new nt(8,8.2,.4,32),e=new Y({color:1779781,flatShading:!0,emissive:461593}),n=new _(t,e);n.position.y=.4,n.receiveShadow=!0,n.castShadow=!0,this.pkArenaGroup.add(n);const i=new xn(8.02,.05,8,48);i.rotateX(Math.PI/2);const s=new Lt({color:2733814}),a=new _(i,s);a.position.y=.58,this.pkArenaGroup.add(a);const r=new xn(8.1,.03,8,48);r.rotateX(Math.PI/2);const c=new Lt({color:15684432}),l=new _(r,c);l.position.y=.55,this.pkArenaGroup.add(l);const h=new Lt({color:58879,transparent:!0,opacity:.65}),d=new G(3.6,.01,.16),u=new _(d,h);u.position.set(0,.605,0),this.pkArenaGroup.add(u);const f=new G(.16,.01,3.6),g=new _(f,h);g.position.set(0,.605,0),this.pkArenaGroup.add(g);const y=new xn(.6,.04,4,24);y.rotateX(Math.PI/2);const m=new _(y,h);m.position.set(0,.605,0),this.pkArenaGroup.add(m);const p=new Y({color:7901340,flatShading:!0});for(let w=0;w<6;w++){const S=w*Math.PI/3,P=10.5,F=Math.cos(S)*P,j=Math.sin(S)*P,I=new dt;I.position.set(F,.4,j);const B=new nt(.5,.6,.4,8),O=new _(B,p);O.position.y=.2,O.castShadow=!0,O.receiveShadow=!0,I.add(O);const Z=new nt(.35,.35,3.8,8),X=new _(Z,p);X.position.y=2.1,X.castShadow=!0,X.receiveShadow=!0,I.add(X);const q=new nt(.5,.4,.3,8),J=new _(q,p);J.position.y=4.15,J.castShadow=!0,I.add(J);const et=new Ns(.25),rt=new _(et,new Lt({color:w%2===0?2733814:15684432,transparent:!0,opacity:.95}));rt.position.y=4.65,I.add(rt),this.pkArenaGroup.add(I)}const x=new Y({color:16777215,flatShading:!0,transparent:!0,opacity:.88});for(let w=0;w<8;w++){const S=w*Math.PI/4+Math.random()*.2,P=21+Math.random()*5,F=Math.cos(S)*P,j=Math.sin(S)*P,I=-2.5-Math.random()*2,B=new dt;B.position.set(F,I,j);const O=3+Math.floor(Math.random()*4);for(let Z=0;Z<O;Z++){const X=2.5+Math.random()*3.5,q=new Tt(X,6,6),J=new _(q,x);J.position.set((Math.random()-.5)*X*1.6,(Math.random()-.5)*X*.6,(Math.random()-.5)*X*1.6),B.add(J)}this.pkArenaGroup.add(B)}const v=new Y({color:4545124,flatShading:!0});for(let w=0;w<10;w++){const S=Math.random()*Math.PI*2,P=9.5+Math.random()*4,F=Math.cos(S)*P,j=Math.sin(S)*P,I=.2+Math.random()*2.2,B=new Ui(.25+Math.random()*.45),O=new _(B,v);O.position.set(F,I,j),O.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),O.castShadow=!0,this.pkArenaGroup.add(O)}const M=new nt(.3,.4,.4,8),R=new _(M,p);R.position.set(0,.8,-5),R.castShadow=!0,R.receiveShadow=!0,this.pkArenaGroup.add(R);const T=new Ns(.3),E=new Lt({color:58879,transparent:!0,opacity:.88});this.pkCrystalMesh=new _(T,E),this.pkCrystalMesh.scale.set(1,2,1),this.pkCrystalMesh.position.set(0,1.45,-5),this.pkArenaGroup.add(this.pkCrystalMesh);const U=[{x:-7.5,z:0,weapon:"sword"},{x:7.5,z:0,weapon:"hammer"},{x:0,z:6.8,weapon:"bomb"}];this.swordPreview=null,this.hammerPreview=null,this.bombPreview=null,U.forEach(w=>{const S=new dt;S.position.set(w.x,.6,w.z),w.z>0&&(S.rotation.y=Math.PI);const P=new nt(.05,.05,1.3,8),F=new Y({color:5125166,flatShading:!0}),j=new _(P,F);j.position.set(0,.65,-.4),j.castShadow=!0,S.add(j);const I=new _(P,F);I.position.set(0,.65,.4),I.castShadow=!0,S.add(I);const B=new G(.06,.06,1),O=new _(B,F);O.position.set(0,1.15,0),O.castShadow=!0,S.add(O);const Z=new G(.2,.08,1.1),X=new _(Z,new Y({color:4073251,flatShading:!0}));X.position.set(0,.04,0),X.receiveShadow=!0,S.add(X);let q;w.weapon==="sword"?(q=this.createSword3D(),this.swordPreview=q):w.weapon==="hammer"?(q=this.createHammer3D(),this.hammerPreview=q):(q=this.createBomb3D(),this.bombPreview=q),q.scale.set(.65,.65,.65),q.position.set(0,1.45,0),S.add(q),this.pkArenaGroup.add(S)}),this.pkArenaColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:8}],this.pkArenaInteractables=[{id:"pk_crystal",name:"决斗匹配",x:0,y:.6,z:-5,triggerRadius:1.8}]}createSword3D(){const t=new dt,e=new nt(.02,.02,.18,6),n=new Y({color:4073251,flatShading:!0}),i=new _(e,n);i.position.y=-.2,i.castShadow=!0,t.add(i);const s=new G(.14,.04,.04),a=new Y({color:16757504,flatShading:!0}),r=new _(s,a);r.position.y=-.1,r.castShadow=!0,t.add(r);const c=new G(.06,.55,.018),l=new Y({color:13621468,emissive:1118481,flatShading:!0}),h=new _(c,l);h.position.y=.22,h.castShadow=!0,t.add(h);const d=new oe(.042,.08,4),u=new _(d,l);return u.position.y=.525,u.rotation.y=Math.PI/4,u.castShadow=!0,t.add(u),t}createHammer3D(){const t=new dt,e=new nt(.02,.02,.8,6),n=new Y({color:2171169,flatShading:!0}),i=new _(e,n);i.position.y=-.1,i.castShadow=!0,t.add(i);const s=new G(.24,.32,.24),a=new Y({color:4545124,flatShading:!0}),r=new _(s,a);r.position.y=.38,r.castShadow=!0,t.add(r);const c=new G(.25,.06,.25),l=new Y({color:16757504,flatShading:!0}),h=new _(c,l);return h.position.y=.38,t.add(h),t}createBomb3D(){const t=new dt,e=new Tt(.18,10,10),n=new Y({color:2503224,flatShading:!0}),i=new _(e,n);i.position.y=.1,i.castShadow=!0,t.add(i);const s=new nt(.04,.05,.06,8),a=new Y({color:5533306,flatShading:!0}),r=new _(s,a);r.position.y=.28,r.castShadow=!0,t.add(r);const c=new nt(.008,.008,.1,4),l=new Y({color:16766287,flatShading:!0}),h=new _(c,l);h.position.set(.02,.35,0),h.rotation.z=-.3,t.add(h);const d=new Tt(.025,4,4),u=new Lt({color:16727296}),f=new _(d,u);return f.position.set(.05,.4,0),t.add(f),t}createFurnitureModel(t){const e=new dt;if(t==="painting"){const n=new G(1.2,.8,.06),i=new Y({color:5125166,flatShading:!0}),s=new _(n,i);s.castShadow=!0,e.add(s);const a=new G(1.1,.7,.01),r=new Y({color:16774112,flatShading:!0}),c=new _(a,r);c.position.z=.031,e.add(c);const l=new nt(.18,.18,.01,12);l.rotateX(Math.PI/2);const h=new Lt({color:16740419}),d=new _(l,h);d.position.set(0,.1,.038),e.add(d);const u=new G(1.1,.25,.01),f=new Y({color:2733814,flatShading:!0}),g=new _(u,f);g.position.set(0,-.2,.038),e.add(g)}else if(t==="christmas_tree"){const n=new nt(.1,.12,.4,8),i=new Y({color:6111287,flatShading:!0}),s=new _(n,i);s.position.y=.2,s.castShadow=!0,e.add(s);const a=new Y({color:1793568,flatShading:!0}),r=new _(new oe(.55,.65,8),a);r.position.y=.65,r.castShadow=!0,e.add(r);const c=new _(new oe(.42,.52,8),a);c.position.y=1.05,c.castShadow=!0,e.add(c);const l=new _(new oe(.28,.38,8),a);l.position.y=1.4,l.castShadow=!0,e.add(l);const h=[16717636,16771899,58998,2733814,14696699];for(let d=0;d<12;d++){const u=new Tt(.045,4,4),f=new Lt({color:h[d%h.length]}),g=new _(u,f),y=.4+Math.random()*1.1,m=.55*(1.5-y)/1.5,p=Math.random()*Math.PI*2;g.position.set(Math.cos(p)*m,y,Math.sin(p)*m),e.add(g)}}else if(t==="rabbit_sofa"){const n=new Y({color:16744619,flatShading:!0}),i=new Y({color:16777215,flatShading:!0}),s=new G(1.2,.3,.6),a=new _(s,n);a.position.y=.15,a.castShadow=!0,e.add(a);const r=new G(1.2,.55,.15),c=new _(r,n);c.position.set(0,.5,-.22),c.castShadow=!0,e.add(c);const l=new G(.14,.35,.08),h=new _(l,n);h.position.set(-.25,.9,-.22),h.rotation.z=.12,e.add(h);const d=new _(new G(.08,.25,.01),i);d.position.set(-.25,.9,-.179),d.rotation.z=.12,e.add(d);const u=new _(l,n);u.position.set(.25,.9,-.22),u.rotation.z=-.12,e.add(u);const f=new _(new G(.08,.25,.01),i);f.position.set(.25,.9,-.179),f.rotation.z=-.12,e.add(f);const g=new G(1.02,.1,.48),y=new _(g,i);y.position.set(0,.32,.03),e.add(y);const m=new G(.12,.38,.55),p=new _(m,n);p.position.set(-.54,.34,.02),p.castShadow=!0,e.add(p);const x=p.clone();x.position.x=.54,e.add(x)}else if(t==="swing_chair"){const n=new Y({color:9479342,flatShading:!0}),i=new Y({color:14737632,flatShading:!0}),s=new Y({color:5227511,flatShading:!0}),a=new xn(.35,.03,8,24);a.rotateX(Math.PI/2);const r=new _(a,n);r.position.y=.03,e.add(r);const c=new nt(.03,.03,1.7,8),l=new _(c,n);l.position.set(0,.85,-.32),l.rotation.x=-.05,l.castShadow=!0,e.add(l);const h=new G(.06,.06,.38),d=new _(h,n);d.position.set(0,1.7,-.16),e.add(d);const u=new nt(.008,.008,.1,4),f=new _(u,i);f.position.set(-.16,1.25,.02),f.rotation.z=.15,e.add(f);const g=new _(u,i);g.position.set(.16,1.25,.02),g.rotation.z=-.15,e.add(g);const y=new nt(.24,.28,.12,12),m=new _(y,s);m.position.set(0,.82,.02),m.castShadow=!0,e.add(m);const p=new Tt(.28,8,8,0,Math.PI,0,Math.PI/2);p.rotateX(Math.PI/2);const x=new Y({color:5227511,transparent:!0,opacity:.8,side:ye,flatShading:!0}),v=new _(p,x);v.position.set(0,1.05,.02),v.rotation.y=Math.PI,e.add(v)}return e}initShopUI(){document.querySelectorAll("#modal-shop .shop-tabactive").forEach(r=>{r.addEventListener("click",c=>{const l=r.getAttribute("data-tab");this.switchShopTab(l)})}),this.switchShopTab("agriculture");const e=document.getElementById("btn-shop-count-minus"),n=document.getElementById("btn-shop-count-plus"),i=document.getElementById("btn-shop-count-plus10"),s=document.getElementById("shop-buy-count-slider"),a=document.getElementById("btn-shop-execute-buy");e&&s&&e.addEventListener("click",()=>{let r=parseInt(s.value)||1;r>1&&(s.value=r-1,this.updateShopBuyCountUI())}),n&&s&&n.addEventListener("click",()=>{let r=parseInt(s.value)||1;r<99&&(s.value=r+1,this.updateShopBuyCountUI())}),i&&s&&i.addEventListener("click",()=>{let r=parseInt(s.value)||1;s.value=Math.min(99,r+10),this.updateShopBuyCountUI()}),s&&s.addEventListener("input",()=>{this.updateShopBuyCountUI()}),a&&a.addEventListener("click",r=>{if(!this.selectedShopItem)return;const c=parseInt(s?s.value:1)||1;this.executeShopBuy(this.selectedShopItem,c,r.clientX,r.clientY)})}switchShopTab(t){const e=document.querySelectorAll("#modal-shop .shop-tabactive");e.forEach(n=>{n.getAttribute("data-tab")===t&&(e.forEach(i=>{i.classList.remove("active"),i.style.borderLeftColor="transparent",i.style.color="var(--text-muted)"}),n.classList.add("active"),n.style.borderLeftColor="#27ae60",n.style.color="#fff",this.renderShopItems(t))})}getActiveShopTab(){const t=document.querySelector("#modal-shop .shop-tabactive.active");return t?t.getAttribute("data-tab"):"agriculture"}getActiveBagTab(){const t=document.querySelector("#modal-bag .bag-tabactive.active");return t?t.getAttribute("data-tab"):"seed"}updateShopCoins(){const t=document.querySelector("#modal-shop .shop-coins-val");t&&(t.textContent=this.gameData.coins)}updateShopBuyCountUI(){const t=document.getElementById("shop-buy-count-slider"),e=document.getElementById("shop-buy-count-text"),n=document.querySelector("#shop-item-detail .shop-detail-total-price");if(!t||!this.selectedShopItem)return;const i=parseInt(t.value)||1;if(e&&(e.textContent=i),n)if(this.selectedShopItem.id.startsWith("coin_"))n.textContent="免费";else{const s=this.selectedShopItem.price*i;n.textContent=`🪙 ${s}`}}showShopItemDetail(t){this.selectedShopItem=t;const e=document.getElementById("shop-item-detail");if(!e)return;const n=e.querySelector(".shop-detail-empty"),i=e.querySelector(".shop-detail-content");n&&(n.style.display="none"),i&&(i.style.display="flex");const s=e.querySelector(".shop-detail-icon");if(s){const d=t.name.split(" ").pop()||"📦";s.textContent=d}const a=e.querySelector(".shop-detail-title");a&&(a.textContent=t.name.replace(/ 🌻| 🍓| 🖼️| 🎄| 🛋️| 🎪| 🪙| 🎁| 💎/,""));const r=e.querySelector(".shop-detail-owned");if(r)if(t.type==="seed"){const d=this.gameData.backpack.find(u=>u.id===t.id&&u.type==="seed");r.textContent=`已持有: ${d?d.count:0}`}else if(t.type==="decor"){const d=this.gameData.ownedFurnitures.includes(t.id);r.textContent=d?"✅ 已解锁":"🔒 未拥有"}else r.textContent="★ 免费福利";const c=e.querySelector(".shop-detail-desc");c&&(c.textContent=t.desc);const l=e.querySelector(".shop-detail-unit-price");l&&(t.id.startsWith("coin_")?l.textContent="￥0.00":l.textContent=`🪙 ${t.price}`);const h=document.getElementById("shop-buy-count-slider");h&&(h.value=1),this.updateShopBuyCountUI()}renderShopItems(t){const e=document.getElementById("shop-grid");if(!e)return;e.innerHTML="";let n=[];t==="agriculture"?n=[{id:"sunflower_seed",name:"向日葵种子 🌻",price:10,desc:"成熟需要 30 秒。收割可获得 20 金币 + 15 经验。",quality:"green",type:"seed"},{id:"strawberry_seed",name:"草莓种子 🍓",price:20,desc:"成熟需要 60 秒。收割可获得 45 金币 + 35 经验。",quality:"blue",type:"seed"}]:t==="decorations"?n=[{id:"painting_1",name:"浮空岛日落挂画 🖼️",price:50,desc:"悬挂在墙壁上的精美装饰，带来悠闲的落日余晖。",type:"decor",quality:"purple"},{id:"tree_1",name:"闪烁圣诞树 🎄",price:100,desc:"闪耀着七彩微光的圣诞树，散发节日温馨氛围。",type:"decor",quality:"purple"},{id:"sofa_1",name:"粉嫩兔子沙发 🛋️",price:150,desc:"兔耳设计的粉色单人沙发，触感松软，极度舒适。",type:"decor",quality:"purple"},{id:"swing_1",name:"室内网兜秋千 🎪",price:200,desc:"挂在天花板上的编织网秋千，轻轻摇曳，治愈满满。",type:"decor",quality:"purple"}]:t==="topup"&&(n=[{id:"coin_100",name:"免费金币充值包 🪙",amount:100,desc:"白嫖小包。免费充值 100 金币，附赠吃到金币声效！",type:"topup",quality:"gold",price:0},{id:"coin_500",name:"金币充值礼包 🎁",amount:500,desc:"免费大包。点击即刻免费充值 500 金币！",type:"topup",quality:"gold",price:0},{id:"coin_1000",name:"超级金币充值包 💎",amount:1e3,desc:"免费巨包！狂揽 1000 金币，金币爆屏！",type:"topup",quality:"gold",price:0}]);for(let s=0;s<12;s++){const a=document.createElement("div");a.className="shop-item-box";const r=n[s];if(r){const c=`q-${r.quality||"white"}`;a.classList.add(c),this.selectedShopItem&&this.selectedShopItem.id===r.id&&a.classList.add("active");const l=r.name.split(" ").pop()||"📦";a.innerHTML=`
          <span style="font-size: 1.8rem;">${l}</span>
          <span class="shop-item-box-price">${r.id.startsWith("coin_")?"免费":"🪙"+r.price}</span>
        `,a.addEventListener("click",()=>{document.querySelectorAll(".shop-item-box.active").forEach(h=>h.classList.remove("active")),a.classList.add("active"),this.showShopItemDetail(r)})}else a.innerHTML="";e.appendChild(a)}if(n.some(s=>this.selectedShopItem&&s.id===this.selectedShopItem.id))this.showShopItemDetail(this.selectedShopItem);else{this.selectedShopItem=null;const s=document.getElementById("shop-item-detail");if(s){const a=s.querySelector(".shop-detail-empty"),r=s.querySelector(".shop-detail-content");a&&(a.style.display="flex"),r&&(r.style.display="none")}}}executeShopBuy(t,e,n,i){if(t.id.startsWith("coin_")){const a=t.amount*e;this.gameData.coins+=a,this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(a,n,i),this.showShopItemDetail(t),setTimeout(()=>{this.refreshBag(this.getActiveBagTab())},50);return}const s=t.price*e;if(this.gameData.coins<s){alert("金币不足，无法购买！");return}if(this.gameData.coins-=s,t.type==="seed"){const a=this.gameData.backpack.find(r=>r.id===t.id&&r.type==="seed");a?a.count+=e:this.gameData.backpack.push({id:t.id,name:t.name.replace(/ 🌻| 🍓/,""),type:"seed",count:e,quality:t.quality,desc:t.desc}),this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(-s,n,i),this.showShopItemDetail(t),this.refreshFarm(),this.refreshBag("seed")}else if(t.type==="decor"){this.gameData.ownedFurnitures.includes(t.id)||this.gameData.ownedFurnitures.push(t.id);const a=this.gameData.backpack.find(r=>r.id===t.id&&r.type==="decor");a?a.count+=e:this.gameData.backpack.push({id:t.id,name:t.name.replace(/ 🖼️| 🎄| 🛋️| 🎪/,""),type:"decor",count:e,quality:"purple",desc:"购买于家园工坊的精美家具模型。进入家园编辑模式即可随意定位摆放它！"}),this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(-s,n,i),this.showShopItemDetail(t),this.refreshHome(),this.refreshBag("decor")}}initRadialSeedMenu(){const t=document.getElementById("btn-close-radial");t&&t.addEventListener("click",()=>{this.closeRadialSeedMenu()}),document.querySelectorAll("#radial-seed-menu .radial-item-btn").forEach(n=>{n.addEventListener("click",i=>{if(i.stopPropagation(),n.classList.contains("disabled")||n.style.opacity==="0.5"){this.showToast("请走近空农地后再种植！");return}const s=n.getAttribute("data-seed");this.plantCropFromRadialMenu(s)})}),window.addEventListener("keydown",n=>{if(this.isRadialMenuOpen)if(n.key==="1"){const i=document.getElementById("radial-seed-sunflower");i&&i.click()}else if(n.key==="2"){const i=document.getElementById("radial-seed-strawberry");i&&i.click()}else n.key==="Escape"&&this.closeRadialSeedMenu()})}openRadialSeedMenu(){const t=document.getElementById("radial-seed-menu");t&&(this.isRadialMenuOpen=!0,window.parent&&(window.parent.isRadialMenuOpen=!0),t.classList.add("open"),t.style.display="block",this.updateRadialCounts(),this.updateActivePlotForRadialMenu())}closeRadialSeedMenu(){const t=document.getElementById("radial-seed-menu");t&&(this.isRadialMenuOpen=!1,window.parent&&(window.parent.isRadialMenuOpen=!1),t.classList.remove("open"),setTimeout(()=>{this.isRadialMenuOpen||(t.style.display="none")},300))}updateRadialCounts(){const t=document.querySelector("#radial-seed-sunflower .radial-count"),e=document.querySelector("#radial-seed-strawberry .radial-count"),n=this.gameData.backpack.find(s=>s.id==="sunflower_seed"&&s.type==="seed"),i=this.gameData.backpack.find(s=>s.id==="strawberry_seed"&&s.type==="seed");t&&(t.textContent=n?n.count:0),e&&(e.textContent=i?i.count:0)}updateActivePlotForRadialMenu(){if(!this.isRadialMenuOpen||this.currentMap!=="farm"||!this.player||!this.farmPlots3D)return;let t=null,e=1/0;this.gameData.farmPlots.forEach((i,s)=>{if(i.unlocked&&i.status==="empty"){const a=this.farmPlots3D[s];if(a){const r=this.player.position.x-a.x,c=this.player.position.z-a.z,l=Math.sqrt(r*r+c*c);l<e&&(e=l,t=s)}}});const n=document.getElementById("radial-seed-menu");n&&(t!==null&&e<2.2?(this.activePlotIndex=t,n.querySelectorAll(".radial-item-btn").forEach(i=>{i.classList.remove("disabled"),i.style.opacity="1"})):(this.activePlotIndex=null,n.querySelectorAll(".radial-item-btn").forEach(i=>{i.classList.add("disabled"),i.style.opacity="0.5"})))}plantCropFromRadialMenu(t){if(this.activePlotIndex===null){this.showToast("请靠近空农地后再种植！");return}const e=this.gameData.backpack.find(s=>s.id===t&&s.type==="seed");if(!e||e.count<=0){this.showToast(`${t==="sunflower_seed"?"向日葵":"草莓"}种子数量不足！正为您打开市集商店...`),this.closeRadialSeedMenu(),this.modalMgr.openModal("shop"),this.switchShopTab("agriculture");return}e.count--;const n=this.gameData.farmPlots[this.activePlotIndex];n.status="growing",n.seedId=t,n.plantTime=Date.now(),this.saveGameData(),this.refreshFarm(),this.updateRadialCounts(),this.playCustomSound(330,.25,"sine",.1),this.recreateCrop3D(this.activePlotIndex);const i=t==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功播种了 1 颗 ${i} 种子 🌱`)}buildLakePlatform(){this.lakeGroup.clear(),this.lakeColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:12}],this.lakeInteractables=[],this.bowlsList=[],this.ripplesList=[],this.noteParticles=[],this.lastBowlSoundTime=0,this.lastWaterStepTime=0;const t=new nt(12,12.5,1.2,32),e=new Y({color:15724532,flatShading:!0}),n=new _(t,e);n.position.y=0,n.receiveShadow=!0,n.castShadow=!0,this.lakeGroup.add(n);const i=new nt(12.5,11.8,1.8,32),s=new Y({color:4545124,flatShading:!0}),a=new _(i,s);a.position.y=-1.5,this.lakeGroup.add(a);const r=new sa(6,32);r.rotateX(-Math.PI/2);const c=new Lt({color:5227511,transparent:!0,opacity:.65,side:ye}),l=new _(r,c);l.position.y=.5,this.lakeGroup.add(l);const h=new Y({color:14737632,flatShading:!0}),d=new G(1.6,.22,.4),u=24,f=6.1;for(let mt=0;mt<u;mt++){const St=mt*Math.PI*2/u,Pt=Math.cos(St)*f,wt=Math.sin(St)*f,It=new _(d,h);It.position.set(Pt,.65,wt),It.rotation.y=-St+Math.PI/2,It.castShadow=!0,It.receiveShadow=!0,this.lakeGroup.add(It)}const g=new nt(.42,.28,.22,12,1,!0),y=new nt(.28,.28,.02,12),m=new Y({color:16777215,flatShading:!0,side:ye,emissive:1118481});for(let mt=0;mt<6;mt++){const St=new dt,Pt=mt*Math.PI*2/6+(Math.random()-.5)*.5,wt=2+Math.random()*2.8,It=Math.cos(Pt)*wt,D=Math.sin(Pt)*wt;St.position.set(It,.5,D);const ht=new _(g,m);ht.castShadow=!0,ht.receiveShadow=!0,St.add(ht);const K=new _(y,m);K.position.y=-.1,K.castShadow=!0,St.add(K),this.lakeGroup.add(St),this.bowlsList.push({group:St,position:St.position,rotation:St.rotation,velocity:new L((Math.random()-.5)*.35,0,(Math.random()-.5)*.35),phase:Math.random()*Math.PI*2})}const p=new dt;p.position.set(0,.6,-8);const x=new Y({color:1710618,flatShading:!0}),v=new Y({color:16448250,flatShading:!0}),M=new _(new G(1.6,.82,.65),x);M.position.y=.41,M.castShadow=!0,M.receiveShadow=!0,p.add(M);const R=new _(new G(1.6,.6,.2),x);R.position.set(0,1.12,-.225),R.castShadow=!0,p.add(R);const T=new _(new G(1.5,.05,.25),v);T.position.set(0,.81,.22),T.castShadow=!0,p.add(T);const E=new _(new G(.05,.12,.27),x);E.position.set(-.775,.85,.22),E.castShadow=!0,p.add(E);const U=E.clone();U.position.x=.775,p.add(U);const w=new _(new G(.65,.45,.3),x);w.position.set(0,.225,.65),w.castShadow=!0,w.receiveShadow=!0,p.add(w),this.lakeGroup.add(p),this.lakeInteractables.push({id:"piano",name:"弹奏钢琴",x:0,y:.6,z:-7,triggerRadius:1.6});const S=new Y({color:15658734,flatShading:!0}),P=new G(.8,.36,.45),F=new _(P,S);F.position.set(7.5,.78,0),F.castShadow=!0,F.receiveShadow=!0,this.lakeGroup.add(F),this.lakeInteractables.push({id:"lake_seat_1",name:"坐下静赏",x:7.5,y:.6,z:0,triggerRadius:1.5});const j=new _(P,S);j.position.set(-7.5,.78,0),j.castShadow=!0,j.receiveShadow=!0,this.lakeGroup.add(j),this.lakeInteractables.push({id:"lake_seat_2",name:"坐下静赏",x:-7.5,y:.6,z:0,triggerRadius:1.5});const I=new dt;I.position.set(0,.6,9.5);const B=new _(new nt(.7,.8,.18,8),h);B.position.y=.09,I.add(B);const O=new _(new G(.18,1.8,.18),h);O.position.set(-.55,1,0),O.castShadow=!0,I.add(O);const Z=O.clone();Z.position.x=.55,I.add(Z);const X=new _(new G(1.28,.18,.18),h);X.position.set(0,1.9,0),X.castShadow=!0,I.add(X);const q=new _(new Xe(.9,1.6),new Lt({color:58879,transparent:!0,opacity:.45,side:ye}));q.position.set(0,1,0),I.add(q);const J=new _(new G(.7,.2,.04),new Y({color:4073251}));J.position.set(0,2.1,0),I.add(J);const et=new _(new G(.5,.08,.05),new Lt({color:58879}));et.position.set(0,2.1,.01),I.add(et),this.lakeGroup.add(I),this.lakeInteractables.push({id:"exit_house",name:"返回海岛大厅",x:0,y:.6,z:8.5,triggerRadius:1.5});const rt=new nt(.1,.14,.8,6),H=new Y({color:5125166}),tt=new Ui(.55),ut=new Y({color:3046706,flatShading:!0});[{x:-9.5,z:-9.5},{x:9.5,z:-9.5},{x:-9.5,z:9.5},{x:9.5,z:9.5}].forEach(mt=>{const St=new dt;St.position.set(mt.x,.6,mt.z);const Pt=new _(rt,H);Pt.position.y=.4,Pt.castShadow=!0,St.add(Pt);const wt=new _(tt,ut);wt.position.y=.95,wt.castShadow=!0,St.add(wt),this.lakeGroup.add(St)}),this.initPianoKeysEvents()}initPianoKeysEvents(){const t=document.querySelectorAll("#modal-piano .piano-key"),e={C4:261.63,D4:293.66,E4:329.63,F4:349.23,G4:392,A4:440,B4:493.88,C5:523.25};t.forEach(a=>{const r=c=>{c.preventDefault();const l=a.getAttribute("data-note"),h=e[l];h&&(this.playCustomSound(h,.8,"sine",.1),window.dispatchEvent(new CustomEvent("piano-note-played",{detail:{note:l}})),a.classList.add("active"),setTimeout(()=>a.classList.remove("active"),120))};a.addEventListener("mousedown",r),a.addEventListener("touchstart",r,{passive:!1})});const n={a:"C4",s:"D4",d:"E4",f:"F4",g:"G4",h:"A4",j:"B4",k:"C5"},i=a=>{const r=this.modalMgr?this.modalMgr.modals.piano:null;if(r&&r.classList.contains("open")){const c=a.key.toLowerCase(),l=n[c];if(l){const h=document.querySelector(`#modal-piano .piano-key[data-note="${l}"]`);if(h){const d=e[l];this.playCustomSound(d,.8,"sine",.1),window.dispatchEvent(new CustomEvent("piano-note-played",{detail:{note:l}})),h.classList.add("active"),setTimeout(()=>h.classList.remove("active"),120)}}}};window._pianoKeydownHandler&&window.removeEventListener("keydown",window._pianoKeydownHandler),window._pianoKeydownHandler=i,window.addEventListener("keydown",i);const s=document.getElementById("btn-exit-sitting");s&&s.addEventListener("click",a=>{a.preventDefault(),this.player&&this.player.isSitting&&this.player.standUp()})}spawnNoteParticle(t){const e=document.createElement("canvas");e.width=64,e.height=64;const n=e.getContext("2d");n.fillStyle="#ffd700",n.font='bold 44px Outfit, "Noto Sans SC", sans-serif',n.textAlign="center",n.textBaseline="middle";const i=["🎵","🎶","楽","✨","♩","♩"],s=i[Math.floor(Math.random()*i.length)];n.fillText(s,32,32);const a=new Uc(e),r=new Lc({map:a,transparent:!0,opacity:.95,blending:Es}),c=new sm(r),l=(Math.random()-.5)*.9,h=-7.5+(Math.random()-.5)*.3;c.position.set(l,1.45,h);const d=.32+Math.random()*.16;c.scale.set(d,d,d),this.lakeGroup.add(c),this.noteParticles.push({sprite:c,texture:a,material:r,velocity:new L((Math.random()-.5)*.7,1.1+Math.random()*.7,(Math.random()-.5)*.5),age:0,maxAge:1.6+Math.random()*.8})}playBowlCollisionSound(t,e){const n=Date.now();if(n-this.lastBowlSoundTime<80)return;this.lastBowlSoundTime=n;const i=[523.25,587.33,659.25,783.99,880,1046.5,1174.66,1318.51],s=i[Math.floor(Math.random()*i.length)];try{window.audioCtx||(window.audioCtx=new(window.AudioContext||window.webkitAudioContext)),window.audioCtx.state==="suspended"&&window.audioCtx.resume();const a=window.audioCtx.currentTime,r=.75*Math.min(e,1.2),c=.05*Math.min(e,1.2),l=window.audioCtx.createOscillator(),h=window.audioCtx.createGain();l.type="sine",l.frequency.setValueAtTime(s,a),h.gain.setValueAtTime(c,a),h.gain.exponentialRampToValueAtTime(1e-4,a+r),l.connect(h),h.connect(window.audioCtx.destination),l.start(),l.stop(a+r);const d=window.audioCtx.createOscillator(),u=window.audioCtx.createGain();d.type="sine",d.frequency.setValueAtTime(s*1.5,a),u.gain.setValueAtTime(c*.28,a),u.gain.exponentialRampToValueAtTime(1e-4,a+.25),d.connect(u),u.connect(window.audioCtx.destination),d.start(),d.stop(a+.25);const f=window.audioCtx.createOscillator(),g=window.audioCtx.createGain();f.type="sine",f.frequency.setValueAtTime(s*2,a),g.gain.setValueAtTime(c*.15,a),g.gain.exponentialRampToValueAtTime(1e-4,a+.18),f.connect(g),g.connect(window.audioCtx.destination),f.start(),f.stop(a+.18)}catch(a){console.warn("[音效] 白瓷碗磬钟音效合成失败:",a)}}createRipple(t,e,n){const i=new Hs(.06,.09,32);i.rotateX(-Math.PI/2);const s=new Lt({color:8445674,transparent:!0,opacity:.48,side:ye}),a=new _(i,s);a.position.set(t,e,n),this.lakeGroup.add(a),this.ripplesList.push({mesh:a,geometry:i,material:s,size:.08,maxSize:1.4+Math.random()*.6,speed:1.1,maxOpacity:.5})}updateLakeFrame(t,e){if(!this.player)return;const n=this.player.position.x,i=this.player.position.z,s=Math.sqrt(n*n+i*i);if(s<6&&!this.player.isSitting){if(this.player.position.y=.5,this.player.velocity.y=0,this.player.isGrounded=!0,this.player.keys.w||this.player.keys.s||this.player.keys.a||this.player.keys.d||window.joystickDir&&(window.joystickDir.x!==0||window.joystickDir.y!==0)){const r=Date.now();r-this.lastWaterStepTime>320&&(this.createRipple(n,.505,i),this.lastWaterStepTime=r,this.playCustomSound(120,.18,"sine",.03))}this.bowlsList.forEach(r=>{const c=r.position.x-n,l=r.position.z-i,h=Math.sqrt(c*c+l*l);if(h<.82){const u=h>0?c/h:1,f=h>0?l/h:0,g=1.35;r.velocity.x+=u*g,r.velocity.z+=f*g,r.velocity.length()>2.2&&r.velocity.normalize().multiplyScalar(2.2),r.position.x=n+u*.83,r.position.z=i+f*.83,this.playBowlCollisionSound(r.position,1.1),this.createRipple(r.position.x,.505,r.position.z)}})}if(s>11.8){const a=n/s,r=i/s;this.player.position.x=a*11.8,this.player.position.z=r*11.8,this.player.group.position.copy(this.player.position),this.player.velocity.set(0,0,0)}this.bowlsList.forEach(a=>{a.position.x+=a.velocity.x*t,a.position.z+=a.velocity.z*t,a.velocity.multiplyScalar(.982),a.velocity.x+=(Math.random()-.5)*.08*t,a.velocity.z+=(Math.random()-.5)*.08*t,a.position.y=.5+Math.sin(e*.0022+a.phase)*.018,a.rotation.x=Math.sin(e*.0018+a.phase)*.038,a.rotation.z=Math.cos(e*.0024+a.phase)*.038;const r=Math.sqrt(a.position.x*a.position.x+a.position.z*a.position.z);if(r>5.58){const c=a.position.x/r,l=a.position.z/r,h=a.velocity.x*c+a.velocity.z*l;a.velocity.x-=2*h*c,a.velocity.z-=2*h*l,a.position.x=c*5.56,a.position.z=l*5.56,this.playBowlCollisionSound(a.position,.45),this.createRipple(a.position.x,.505,a.position.z)}});for(let a=0;a<this.bowlsList.length;a++)for(let r=a+1;r<this.bowlsList.length;r++){const c=this.bowlsList[a],l=this.bowlsList[r],h=l.position.x-c.position.x,d=l.position.z-c.position.z,u=Math.sqrt(h*h+d*d),f=.84;if(u<f){const g=h/u,y=d/u,m=l.velocity.x-c.velocity.x,p=l.velocity.z-c.velocity.z,x=m*g+p*y;if(x<0){const T=-1.05*x;c.velocity.x-=T*g*.5,c.velocity.z-=T*y*.5,l.velocity.x+=T*g*.5,l.velocity.z+=T*y*.5}const v=f-u;c.position.x-=g*v*.5,c.position.z-=y*v*.5,l.position.x+=g*v*.5,l.position.z+=y*v*.5;const M=(c.position.x+l.position.x)/2,R=(c.position.z+l.position.z)/2;this.playBowlCollisionSound(new L(M,.5,R),1),this.createRipple(M,.505,R)}}for(let a=this.ripplesList.length-1;a>=0;a--){const r=this.ripplesList[a];r.size+=r.speed*t,r.mesh.scale.set(r.size*10,1,r.size*10),r.material.opacity=r.maxOpacity*(1-r.size/r.maxSize),r.size>=r.maxSize&&(this.lakeGroup.remove(r.mesh),r.geometry.dispose(),r.material.dispose(),this.ripplesList.splice(a,1))}for(let a=this.noteParticles.length-1;a>=0;a--){const r=this.noteParticles[a];r.age+=t,r.sprite.position.addScaledVector(r.velocity,t),r.sprite.position.x+=Math.sin(r.age*6)*.012;const c=r.age/r.maxAge;r.material.opacity=.95*(1-c);const l=(.32+Math.sin(r.age*2)*.05)*(1-c*.4);r.sprite.scale.set(l,l,l),r.age>=r.maxAge&&(this.lakeGroup.remove(r.sprite),r.texture.dispose(),r.material.dispose(),this.noteParticles.splice(a,1))}}}window.gameApp=new Jm;
